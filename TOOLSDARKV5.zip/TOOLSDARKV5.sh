b='\033[34;1m'
g='\033[32;1m'
p='\033[35;1m'
c='\033[36;1m'
r='\033[31;1m'
w='\033[37;1m'
y='\033[33;1m'
e='echo -e'
user=$(whoami)
OS_TYPE="$(uname -o)"
clear
if command -v getprop >/dev/null 2>&1; then
MODEL=$(getprop ro.product.model)
else
MODEL=$(uname -m) # Atau bisa diganti jadi "Linux" atau lainnya
fi
ID="ID-$(whoami)-$MODEL"
echo "$ID"
LIST="/$HOME/TOOLSDARKV5/TOOLSDARKV5/data/.id_terdaftar.txt"
if [ ! -f "$LIST" ]; then
echo "[!] Kamu Tidak Terdaftar di toolsdarkv5 silahkan hubungi"
xdg-open "https://wa.me/6283121432255"
exit
fi
if grep -q "$ID" "$LIST"; then
echo "[✔] Akses diterima. Selamat datang, $ID"
$e $r "                   ∆PERINGATAN∆"
$e $w "    ID SUDAH TERVERIFIKASI HARAP JANGAN GANTI ID ANDA"
$e $w " ATAU HAPUS DATA TERMUX ANDA DAN SUWAKTU WAKTU ID BERUBAH"
$e $w "  BUKAN TANGGUNG JAWAB SAYA MAKA HARAP ANDA MASUK GROUP"
$e $g "silahkan enter untuk melanjutkan"
$e $w " ========================================================="
$e $r "                        ∆WARNING∆"
$e $r " jangan pernah recod toolsdarkv5 atau mau ngerusak hati hati ada bakdornya"
read -s
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
else
$e $b "⢀⣴⣿⣷⣦⡀                         "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $b "⠀⢠⣿⣿⢿⣿⣿⣷⣄                      "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $b "⢀⡾⠋⠀⣰⣿⣿⠻⣿⣷⡀                    "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $b "⠘⠀⠀⢠⣿⣿⠃⠀⠈⠻⣿⣦⡀                  "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $r ⠀"⠀⠀ ⢸⣿⡇⠀⠀⠀⣼⣉⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀   "
$e $r  "⠀⠀⠀⢹⣿⡇⠀⠀⠀⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⣿⠉⠁ "
$e $r  "⠀⠀⠀⠸⣿⣿⣄⠀⠀⠘⢿⣿⡵⠋⠙⢿⣦⡀⠀⠀⣤⣠⠀⣠⣿⡅⠀⣿   "⠀⠀
$e $r  "⠀⠀⠀⠀⠈⠻⢿⣿⣶⣤⣄⣀⠀⠀⠀⠈⠻⣷⣄⣠⣿⣿⡼⠋⠛⣡⡼⠋   "⠀⠀
$e $r  "⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠛⠻⠿⠿⠷⠶⠶⠾⣿⡿⠋⠻⣟⠉⠁      "⠀⠀⠀
$e $r  "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⠶⠋            "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $c  "======================================="
$e $w   "[$r❌$w] $r Akses ditolak!"
$e $w   "ID Anda: $ID"
$e $w   "Silakan daftar dengan kirim ID ke WhatsApp:"
$e $w   ">> wa.me/6288985210094"
$e $c  "======================================="
exit
fi
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_loading.mp3 > /dev/null 2>&1 &
for i in {1..100}
do
echo -ne "'\033[34;1mMemverifikasi ID....$i% \r"
sleep 0.03
done
jam=$(date +"%k")
tanggal=$(date +" %d %B %Y")
if [[ $jam -ge 0 && $jam -lt 10 ]]; then
ucapan="Pagi🏞️"
salam="/$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/pagi.mp3"
elif [[ $jam -ge 10 && $jam -lt 15 ]]; then
ucapan="Siang🌄"
salam="/$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/siang.mp3"
elif [[ $jam -ge 15 && $jam -lt 18 ]]; then
ucapan="Sore🌅"
salam="/$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/siang.mp3"
else
ucapan="🎑Malam"
salam="/$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/malam.mp3"
fi
hari=$(date +%A)
ucap=""
case $hari in
"Monday") ucap="Senin !";;
"Tuesday") ucap="Selasa !";;
"Wednesday") ucap="Rabu !";;
"Thursday") ucap="Kamis !";;
"Friday") ucap="Jumat !";;
"Saturday") ucap="Sabtu !";;
"Sunday") ucap="Minggu !";;
esac
min=100
max=200
random_number=$((RANDOM % ($max - $min + 1) + $min))
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_hello.mp3 > /dev/null 2>&1 &
clear
sleep 0.3
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$w⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣤⣄⣀⡀⠀⠀       • $r • $c • $b • $p •  $y •   $g •$b         ║"
$e $b "║$w   ⢀⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀                         $b    ║"
$e $b "║$w  ⣰⣿⣿⣿⠟⠉⠀⠀⠀⠈⠙⠿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀                          $b    ║"
$e $b "║$w ⢰⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⡀⠀⠀⠀AUTHOR : $g ManzXploit⠀⠀⠀   $b      ║"
$e $b "║$w ⣸⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⡇⠀⠀⠀GITHUB : $g github.com/Enigma$b     ║⠀"⠀⠀
$e $b "║$w ⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡇⠀⠀⠀NOTIF  : $g selamat $ucapan⠀$b      ║⠀"⠀
$e $b "║$w ⢿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⡇⠀⠀⠀USER   : $g $user⠀⠀⠀        $b    ║"
$e $b "║$w⢠⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⡀STATUS : $g ID TERVERIFIKASI⠀⠀⠀$b   ║⠀"
$e $b "║$w⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠉⠉⠛⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀                        $b    ║ "
$e $b "║$w⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀SELAMAT DATANG DI PANEL ⠀⠀$b    ║"
$e $b "║$w⣿⣿⣿⣿⣿⣿⣿⣿⣿⡶⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀  LOGIN TOOLSDARKV5      $b    ║"
$e $b "║$w⢻⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀MASUKAN USERNAME DAN PW  $b    ║"
$e $b "║$w⠀⠙⢿⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀⠀                        $b    ║"
$e $b "║$w   ⠈⠛⢿⣿⣿⣶⣶⣶⣶⣶⣾⣿⣿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀                        $b    ║"
$e $b "║$w       ⠉⠉⠙⠛⠛⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        $b    ║"
$e $b "╚══════════════════════════════════════════════════════╝"
valid_user="DARKV5"
valid_password="bajingan"
read -p "Username: " input_user
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
read -sp "Password: " input_password
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
echo
if [[ "$input_user" == "$valid_user" && "$input_password" == "$valid_password" ]]; then
echo -e "sabar lagi loading, $input_user."
else
echo "\033[31;1mLogin gagal! Username atau password salah."
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
xdg-open "https://wa.me/6283121432255"
exit 0
fi
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_loading.mp3 > /dev/null 2>&1 &
for i in {1..100}
do
echo -ne "'\033[34;1mLoading... $i% \r"
sleep 0.03
done
clear
sleep 0.5
menu_awal() {
while true; do
clear
sleep 0.8
$e $r "         SELAMAT DATANG DI TOOLSDARKV5XGHOOST"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$r        _   _   _   _   _   _   _   _   _   _ 5 $b      ║"
$e $b "║$r       / \ / \ / \ / \ / \ / \ / \ / \ / \ / \  $b      ║"
$e $b "║$r      ( T | O | O | L | S | D | A | K | R | V ) $b      ║"
$e $b "║$r       \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/  $b      ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y         {$r INFORMATION TOOLSDARKV5 X MANZZ $y} $b         ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$b•$w Author : $y Manzz666Ghost $b                            ║"
$e $b "║$g•$w Github : $y https://github.com/EnigmaXploit $b          ║"
$e $b "║$p•$w Rilis  : $y 06/29/2025 $b                               ║"
$e $b "║$c•$w YourId : $y $user $b                                  ║"
$e $b "║$r•$w Pengna : $y $random_number $b                                      ║"
$e $b "║$w•$w Status : $y PREMIUM $b                                  ║"
$e $b "║$y•$w Versi  : $y 4.0.0 $b                                    ║"
$e $b "║$b•$w Notif  : $y Selamat $ucapan $b                          ║"
$e $b "║$g•$w Jam    : $y $(date +"%H:%M") $b                                    ║"
$e $b "║$p•$w Hari   : $y $ucap.$tanggal $b                ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y        {$r MENU TOOLSDARKV5 SILAHKAN PILIH $y } $b         ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y { SPAM } $b║$g MENU SPAMING TOOLSDARKV4 $b                 ║"
$e $b "║$y { DV5  } $b║$g MENU PHISING DAN HACKING DV5 $b             ║"
$e $b "║$y { OSINT} $b║$g MENU MENCARI INFORMASI   $b                 ║"
$e $b "║$y { CRACK} $b║$g REMOTE ACESS TROJAN      $b                 ║"
$e $b "║$y { DDOS } $b║$g MENU NETWORK SERVICES DV5 $b                ║"
$e $b "║$y { BOT  } $b║$g BOT DDOS DAN BOT BIASA   $b                 ║"
$e $b "║$y { LAGU } $b║$g SETTING LAGU TOOLSDARKV5 $b                 ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y      {$r MENU UPDATE DAN UOGRADE TOOLSDARKV4 $y} $b        ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y { INFO   } $b║$g INFO UPDATE TOOLSDARKV4 $b                ║"
$e $b "║$y { CACHE  } $b║$g CLEAR CACHE TOOLSDARKV4 $b                ║"
$e $b "║$y { REPORT } $b║$g REPORT BUG TOOLSDARKV4  $b                ║"
$e $b "║$y { KELUAR } $b║$g KELUAR DARI TOOLSDARKV4 $b                ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b "        ╔════════════════════════╗"
$e $b "   ║════║$r•$y TOOLSDARKV4XMANZZ$b     ║"
$e $b "║══║    ║$p•$y selamat $ucapan $b      ║"
$e $b "║  ║════║$c•$y Jam $(date +"%H:%M")$b             ║"
$e $b "║       ╚════════════════════════╝"
read -p " ╚═════════:" pilih
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
case "$pilih" in
SPAM) spam_menu ;;
DV5) all_menu ;;
BUY) beli ;;
OSINT) cari_info ;;
CRACK) crack_all ;;
DDOS) ddos_attack ;;
BOT) bot_wa ;;
INFO) update ;;
CACHE) bersih ;;
REPORT) bug ;;
KELUAR) metu ;;
LAGU) lagi ;;
*) echo "Pilihan salah"; sleep 1 ;;
esac
done
}
all_menu() {
while true; do
clear
$e $r "       SELAMAT DATANG DI MENU PHISING DAN HACKING"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$r        _   _   _   _   _   _   _   _   _   _ 5 $b      ║"
$e $b "║$r       / \ / \ / \ / \ / \ / \ / \ / \ / \ / \  $b      ║"
$e $b "║$r      ( T | O | O | L | S | D | A | K | R | V ) $b      ║"
$e $b "║$r       \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/  $b      ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$y         {$r INFORMATION TOOLSDARKV4 X MANZZ $y} $b         ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║$b•$w Author : $y Manzz666Ghost $b                            ║"
$e $b "║$g•$w Github : $y https://github.com/EnigmaXploit $b          ║"
$e $b "║$p•$w Rilis  : $y 06/29/2025 $b                               ║"
$e $b "║$c•$w YourId : $y $user $b                                  ║"
$e $b "║$r•$w Pengna : $y $random_number $b                                      ║"
$e $b "║$w•$w Status : $y PREMIUM $b                                  ║"
$e $b "║$y•$w Versi  : $y 5.0.0 $b                                    ║"
$e $b "║$b•$w Notif  : $y Selamat $ucapan $b                          ║"
$e $b "║$g•$w Jam    : $y $(date +"%H:%M") $b                                    ║"
$e $b "║$p•$w Hari   : $y $ucap.$tanggal $b                ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b " ║ ║                                                ║ ║"
$e $b "╔══════════════════════════════════════════════════════╗"
$e $b "║[$y 10 $b] $b║$g SEKER $b                                       ║"
$e $b "║[$y 11 $b] $b║$g ZPHISHER $b                                    ║"
$e $b "║[$y 12 $b] $b║$g WP UP $b                                       ║"
$e $b "║[$y 13 $b] $b║$g WP COMBO $b                                    ║"
$e $b "║[$y 14 $b] $b║$g WP CHECHKERS $b                                ║"
$e $b "║[$y 15 $b] $b║$g SHELL CHECKER $b                               ║"
$e $b "║[$y 16 $b] $b║$g CPANEL BRUTEFORCE $b                           ║"
$e $b "║[$y 17 $b] $b║$g WEBSHELL FINDER $b                             ║"
$e $b "║[$y 18 $b] $b║$g DIRECTORY FINDER  $b                           ║"
$e $b "║[$y 19 $b] $b║$g ADMIN FINDDRR $b                               ║"
$e $b "║[$y 20 $b] $b║$g SUBDOMAIN FINDER $b                            ║"
$e $b "║[$y 21 $b] $b║$g CPANEL CHECKER $b                              ║"
$e $b "║[$y 22 $b] $b║$g SCRAPER API BY ADJISAN $b                      ║"
$e $b "║[$y 23 $b] $b║$g CCTV HACK $b                                   ║"
$e $b "║[$y 24 $b] $b║$g ADMIN FINDER $b                                ║"
$e $b "║[$y 25 $b] $b║$g LINK VIRUS $b                                  ║"
$e $b "║[$y 26 $b] $b║$g MASSDORK $b                                    ║"
$e $b "║[$y 27 $b] $b║$g DDOS MINECRAFT $b                              ║"
$e $b "║[$y 28 $b] $b║$g PROXY FINDER $b                                ║"
$e $b "║[$y bk $b] $b║$g KEMBALI KEMENU AWAL $b                         ║"
$e $b "╚══════════════════════════════════════════════════════╝"
$e $b "        ╔════════════════════════╗"
$e $b "   ║════║$r•$y TOOLSDARKV4XMANZZ$b     ║"
$e $b "║══║    ║$p•$y selamat $ucapan $b      ║"
$e $b "║  ║════║$c•$y Jam $(date +"%H:%M")$b             ║"
$e $b "║       ╚════════════════════════╝"
read -p " ╚═════════:" all
if [[ "$all" == "10" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone https://github.com/thewhiteh4t/seeker.git
cd seeker/
chmod +x install.sh
./install.sh
elif [[ "$all" == "11" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone --depth=1 https://github.com/htr-tech/zphisher.git
cd zphisher
bash zphisher.sh
elif [[ "$all" == "12" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5/
python wpup.py
elif [[ "$all" == "13" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5//dv5/
python WpCombo.py
elif [[ "$all" == "14" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/dv5/
python WpCheckers.py
elif [[ "$all" == "15" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5/Shell-Checker
python shell_checker.py
elif [[ "$all" == "16" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python cpanel_bruteforce.py
elif [[ "$all" == "17" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python webshell_finder.py
elif [[ "$all" == "18" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python directory_finder.py
elif [[ "$all" == "19" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python admin_panel_finder.py
elif [[ "$all" == "20" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python subdomain_finder.py
elif [[ "$all" == "21" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python cpanel_checker.py
elif [[ "$all" == "22" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone https://github.com/balxz/leak-1
elif [[ "$all" == "23" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5/CamXploit/
pip install -r reuqirements.txt
python CamXploit.py
elif [[ "$all" == "24" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5
python admin_panel_finder.p
elif [[ "$all" == "25" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone https://github.com/MrVirusSpm-07/link-virus
cd link-virus
bssh download.sh
elif [[ "$all" == "26" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5/link-virus
bash download.sh
elif [[ "$all" == "27" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/dv5/dorks-eye
pip3  install -r reuirements.txt
python3 dorks-eye.py
elif [[ "$all" == "28" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
pkg install git
git clone https://github.com/mishakorzik/Free-Proxy
cd Free-Proxy
bash Setup.sh
elif [[ "$all" == "bk" ]]; then
break
else
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
echo "Menjalankan perintah tidak dikenali: $spam"
sleep 1
fi
done
}
spam_menu() {
while true; do
clear
$e "SELANAT DATANG DI MENU SPAM TOOLSDARKV5XGHOST"  | lolcat
$e $w "⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣶⣶⣾⣶⣷⣾⣶⣶⣦⣤⣀⡀"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠈⠉⠉⠁⠀⠀⠀⠀⠀⠈⠉⠉⠙⠛⠿⢿⣿⣿⣶⣄⣸⡆⠀⠀⠀⠀⠀⠀⢀⣼"
$e $w "⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⣿⣿⣿⣧⡀⠀⠀⠀⢀⣤⣿⡟"
$e $w "⠈⢻⣷⣦⣄⡀⠀⠀⠀⠐⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⣿⣿⣿⣿⣿⣦⣶⣾⡿⣿⣿⠃"
$e $w "⠀⠀⢻⡏⠛⢿⣶⣄⠀⠀⠈⢳⡄⠀⠀⠀⠀⠴⡿⠿⠿⠛⢋⣿⣿⣿⠇⠹⣿⣿⣿⣤⣾⣿⠏"⠀
$e $w "⠀⠀⠘⣿⢦⡀⠙⣿⣷⣄⠀⠈⣿⡄⠀⠀⠀⠀⠀⠀⢀⣠⣾⣿⣿⠏⠀⠀⢹⣿⣿⣿⣿⠏"⠀⠀
$e $w "⠀⠀⠀⠻⠀⠻⡄⠸⣿⣿⣷⣴⣿⡇⠀⠀⠀⠠⣴⣶⣿⣿⣿⠟⠁⠀⠀⠀⠘⣿⣿⣿⠃"⠀
$e $w "⠀⠀⠀⠀⠀⠀⠹⢸⣿⡟⠻⢿⡿⠁⠀⠀⠀⠀⠈⠛⠛⠋⠁⠀⠀⠀⠀⠀⢠⣿⣿⣿⡆    $p•$b SELAMAT $P : $ucapan"⠀
$e $w "⠀⠀⠀⢰⡄⠀⠀⢸⣿⠀⠀⠀⠁⠰⠶⣾⣷⣶⡦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠸⠛⣱⣿⠇    $b•$p AUTHOR  $P : $p MANZXPLOIT"⠀⠀⠀
$e $w "⠀⠀⠀⠀⢻⣷⣤⣼⣿⠀⠀⠀⠀⠀⠀⠙⢿⣿⣷⣤⣽⣿⣶⣤⣄⣀⣀⣆⣤⣾⡿⠃     $r•$g GIHUB   $p : $g GITHUB.COM/ENIGMAXPLOIT"
$e $w "⠀⠀⠀⠀⠸⣿⣿⠙⢿⡄⠀⠀⠀⠀⠀⠀⠈⠙⠿⡿⠟⠛⠛⠛⠛⠛⢻⣿⡿⠋"
$e $w "⠀⠀⠀⠀⠀⣿⣿⠀⠀⠁⠀⢷⣄⡀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⢸⣿⡀"
$e $w "⠀⠀⠀⠀⠀⠸⣿⡇⠀⠀⠀⠸⣿⣿⣷⣶⣶⣶⣶⠟⠉⠈⣦⣀⡀⠀⠈⣿⣧"
$e $w "⠀⠀⠀⠀⠀⠀⢻⣿⡀⠀⠀⠀⢻⣿⣀⡀⠀⢻⣿⠟⠒⠲⠾⢿⣿⡿⠿⠟⠋"⠀⠀⠀⠀⠀⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠀⠻⣷⣄⢠⡀⠀⢿⡏⠀⠀⢈⡅⣾⠀⠀⣠⠘⠛"⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣾⡇⠀⠈⢷⣤⣶⣿⣃⢸⣷⣾⣿⠂"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡗⠀⠀⠈⠻⠛⠛⠉⣩⣿⣿⠏"⠀⠀⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣧⣀⣀⣀⣠⣤⣶⣿⡿⠛⠁"⠀⠀⠀⠀⠀⠀⠀
$e $w "⠀⠀⠀⠀⠀⠀⠀⠀⠴⡿⢿⠿⠿⠿⠟⠛⠋⠉⠁"
$e "==========================================="
$e $w "[ $r 11 $w ]$g SPAM OTP WA BY MAS AMMAR"
$e $w "[ $r 12 $w ]$g SPAM PAIRING WA"
$e $w "[ $r 13 $w ]$g APALAH"
$e $w "[ $r bk $w ]$g KEMBALI KE MENU AWAL"
$e $r "        ╔════════════════════════╗"
$e $r "   ║════║$r•$y TOOLSDARKV4XMANZZ$r     ║"
$e $r "║══║    ║$p•$y selamat $ucapan $r      ║"
$e $r "║  ║════║$c•$y Jam $(date +"%H:%M")$r             ║"
$e $r "║       ╚════════════════════════╝"
read -p " ╚═════════:" spam
if [[ "$spam" == "11" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/spam/Tools-WhatsApp/
python main.py
elif [[ "$spam" == "2" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/SPAM/spcwa
npm i
npm start
elif [[ "$spam" == "3" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/SPAM/spambeban
node manzspam.js
elif [[ "$spam" == "4" ]]; then
clear
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/SPAM/Spam-Wa
pip install -r install.txt
python brutal.py
elif [[ "$spam" == "bk" ]]; then
break
else
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
echo "Menjalankan perintah tidak dikenali: $spam"
sleep 1
fi
done
}
cari_info() {
while true; do
clear
$e "udah bang jangan di malingin osint api gua , kalau mau beli beli ae"
$e "kontak wa : 6283121432255 jangan di bug anj��"
$e $w "         ════════════════════════════════════════════════════   "
$e $w "                 SELAMAT DATANG DI MENU DOXSINT DV5"
$e $r "                • $c    • $p    • $w    • $b    • $g    • $y     • "
$e $r "         ██████╗  ██████╗ ██╗  ██╗███████╗██╗███╗   ██╗████████╗"
$e $r "         ██╔══██╗██╔═══██╗╚██╗██╔╝██╔════╝██║████╗  ██║╚══██╔══╝"
$e $r "         ██║  ██║██║   ██║ ╚███╔╝ ███████╗██║██╔██╗ ██║   ██║   "
$e $r "         ██║  ██║██║   ██║ ██╔██╗ ╚════██║██║██║╚██╗██║   ██║   "
$e $r "         ██████╔╝╚██████╔╝██╔╝ ██╗███████║██║██║ ╚████║   ██║   "
$e $r "         ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   "
$e $w "         ════════════════════════════════════════════════════   "
$e $r "                           coded by ManzzXGanteng               "
$e $w "         ════════════════════════════════════════════════════   "
$e $w "         [ $r 11 $w ]$g PHONE LEAKS     $w [ $r 12 $w ]$g NIK CHECKER "
$e $w "         [ $r 13 $w ]$g CARI USERNAME   $w [ $r 14 $w ]$g CARI MAHASISWA"
$e $w "         [ $r 15 $w ]$g ARES OSINT      $w [ $r 16 $w ]$g TRACK IP "
$e $w "         [ $r 17 $w ]$g CEK NPSN        $w [ $r 18 $w ]$g CEK PAJAK "
$e $w "         [ $r 19 $w ]$g PEGASUS LACAK   $w [ $r bk $w ]$g KEMBALI KE MENU AWAL"
$e $r "        ╔════════════════════════╗"
$e $r "   ║════║$r•$y TOOLSDARKV5XGHOST$r     ║"
$e $r "║══║    ║$p•$y selamat $ucapan $r      ║"
$e $r "║  ║════║$c•$y Jam $(date +"%H:%M")$r             ║"
$e $r "║       ╚════════════════════════╝"
read -p " ╚═════════:" osint
if [[ $osint == "11" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test/
node leakPhoneToNikPowerful.js
elif [[ $osint == "12" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test/
php NIK.php
elif [[ $osint == "13" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test
node cariUsername.js
elif [[ $osint == "14" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test
node CariSiswaMahasiswa.js
elif [[ $osint == "15" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone  https://github.com/EnigmaXploit/ARESOSINT
python Ares.py
elif [[ $osint == "16" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test
node trackip.js
elif [[ $osint == "17" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test
node ceknpsn.js
elif [[ $osint == "18" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/test
node cekpajak.js
elif [[ $osint == "19" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
git clone https://github.com/yourusername/pegasus-lacak-nomor.git
cd pegasus-lacak-nomor
pip install -r requirements.txt
python main.py
elif [[ "$osint" == "bk" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
break
else
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
echo "Menjalankan perintah tidak dikenali: $spam"
sleep 1
fi
done
}
lagi() {
clear
echo "🎵 DARKV5 MUSIC PLAYER"
echo
if ! command -v mpv >/dev/null 2>&1 || ! command -v yt-dlp >/dev/null 2>&1; then
echo "⚠️ Dependency belum terinstall!"
echo "[1] Install Sekarang"
echo "[0] Kembali"
read -p "Pilih: " p
case $p in
1) install_lagu_dep ;;
*) return ;;
esac
fi
read -p "Masukkan URL YouTube: " url
[ -z "$url" ] && return
echo "⏳ Resolving stream..."
nohup mpv --no-video --ytdl=yes "$url" >/dev/null 2>&1 &
echo "▶️ Lagu diputar di background"
sleep 2
}
crack_all() {
while true; do
clear
echo -e "                                  CODED BY MANZXPLOIT GANTENG BANGET"  | lolcat
$e $w "       ╔═══════════════════════════════════════════════════════════════════════════════════════╗"
$e $w "       ║$g███╗   ███╗███████╗███╗   ██╗██╗   ██╗     ██████╗██████╗  █████╗  ██████╗██╗  ██╗$w     ║"
$e $w "       ║$g████╗ ████║██╔════╝████╗  ██║██║   ██║    ██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝$w     ║"
$e $w "       ║$g██╔████╔██║█████╗  ██╔██╗ ██║██║   ██║    ██║     ██████╔╝███████║██║     █████╔╝ $w     ║"
$e $w "       ║$g██║╚██╔╝██║██╔══╝  ██║╚██╗██║██║   ██║    ██║     ██╔══██╗██╔══██║██║     ██╔═██╗ $w     ║"
$e $w "       ║$g██║ ╚═╝ ██║███████╗██║ ╚████║╚██████╔╝    ╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗$w     ║"
$e $w "       ║$g╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝ ╚═════╝      ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝$w     ║"
$e $w "       ╚═══════════════════════════════════════════════════════════════════════════════════════╝"
$e $w "           ║$g                 INFORMASI MENU CRACK TOOLS DARKV5XGHOTS $w                       ║"
$e $w "           ║$b•$w Author : $y ManzGanteng $w                                                        ║"
$e $w "           ║$c•$w Github : $y EnigmaXploit $w                                                       ║"
$e $w "           ║$g•$w UserUd : $y user $w                                                               ║"
$e $w "           ║$p•$w Status : $y PREMIUM $w                                                            ║"
$e $w "           ╚════════════════════════════════════════════════════════════════════════════════╝"
$e $w "           ║$w[$g FB $w]$g MENU CRACK FACEBOOK $w                                                     ║"
$e $w "           ║$w[$g MB $w]$g MENU CRACK FACEBOOK MULTI BRUTEFORCE $w                                    ║"
$e $w "           ║$w[$g IG $w]$g MENU CRACK INSTAGRAM $w                                                    ║"
$e $w "           ║$w[$g EMAIL $w]$g MENU CRACK GMAIL $w                                                     ║"
$e $w "           ║$w[$g bk $w]$g MENU CRACK GMAIL $w                                                        ║"
$e $w "           ╚════════════════════════════════════════════════════════════════════════════════╝"
read -p "                                        root@menucrack: " osint
if [[ $osint == "FB" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/crack/
python ratu.py
elif [[ $osint == "MB" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/crack/crack-fb/
bash requirements.sh
python pstar7.py
elif [[ $osint == "IG" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/crack/
pythom igFinnXyzz.py
elif [[ $osint == "EMAIL" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/crack/
python Mozz-Xcode.py
elif [[ "$osint" == "bk" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
break
else
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
echo "Menjalankan perintah tidak dikenali: $spam"
sleep 1
fi
done
}
ddos_attack() {
while true; do
clear
$e $r "                       • $c    • $p    • $w    • $b    • $g    • $y     • "
$e $w "        ╔═════════════════════════════════════════════════════════════════════╗"
$e $w "        ║$g    ██████╗ ██████╗  ██████╗ ███████╗    ██████╗ ██╗   ██╗███████╗ $w  ║"
$e $w "        ║$g    ██╔══██╗██╔══██╗██╔═══██╗██╔════╝    ██╔══██╗██║   ██║██╔════╝ $w  ║"
$e $w "        ║$g    ██║  ██║██║  ██║██║   ██║███████╗    ██║  ██║██║   ██║███████╗ $w  ║"
$e $w "        ║$g    ██║  ██║██║  ██║██║   ██║╚════██║    ██║  ██║╚██╗ ██╔╝╚════██║ $w  ║"
$e $w "        ║$g    ██████╔╝██████╔╝╚██████╔╝███████║    ██████╔╝ ╚████╔╝ ███████║ $w  ║"
$e $w "        ║$g    ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝    ╚═════╝   ╚═══╝  ╚══════╝ $w  ║"
$e $w "        ╚═════════════════════════════════════════════════════════════════════╝"
$e $w "            [ $r 10 $w ]$g DDOS DV5 SERVICE $w      [ $r 11 $w ]$g DDOS ZOMBIE SERVICE"
$e $w "            [ $r 12 $w ]$g DDOS SATURNUS    $w      [ $r 13 $w ]$g DDOS TCP MINECRAFT"
$e $w "            [ $r bk $w ]$g KEMBALI KE MENU AWAL"
$e $w "        ═══════════════════════════════════════════════════════════════════════════   "
$e $p "                                    Coded By ManzXganteng"
$e $w "        ═══════════════════════════════════════════════════════════════════════════   "
read -p "                                   root@NetwokService: " service
if [[ $service == "10" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/ddos/ren
node ren.js
elif [[ $service == "11" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/ddos/melted
python melted.py
elif [[ $service == "12" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp > /dev/null 2>&1 &
cd /$HOME/TOOLSDARKV5/TOOLSDARKV5/ddos/c2
pip install -r requirements.txt
python c2.py
elif [[ $service == "13" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
cd /$HOME/TOOLSDSRKV5/TOOLSDARKV5/ddos/RevengeC2
python c2.py
elif [[ $service == "bk" ]]; then
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_klik.mp3 > /dev/null 2>&1 &
break
else
mpv /$HOME/TOOLSDARKV5/TOOLSDARKV5/sound/sound_salah.mp3 > /dev/null 2>&1 &
echo "Menjalankan perintah tidak dikenali: $spam"
sleep 1
fi
done
}
while true; do
menu_awal
done
