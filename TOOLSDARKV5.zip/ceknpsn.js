#!/usr/bin/env node

const axios = require("axios");
const chalk = require("chalk");
const ora = require("ora");
const rl = require("readline-sync");

// =====================
function clear() {
  console.clear();
}

// =====================
// CEK NPSN
// =====================
async function cekNPSN(npsn) {
  const spinner = ora("🔍 Mengambil data sekolah...").start();

  try {
    const res = await axios.get(
      `https://api-sekolah-indonesia.vercel.app/sekolah?npsn=${npsn}`,
      { timeout: 15000 }
    );

    spinner.succeed("✅ Data berhasil ditemukan");

    const data = res.data;

    if (!data || !data.dataSekolah || data.dataSekolah.length === 0) {
      console.log(chalk.red("\n❌ Data sekolah tidak ditemukan"));
      return;
    }

    data.dataSekolah.forEach((s, i) => {
      console.log(chalk.cyan(`\n========== SEKOLAH ${i + 1} ==========`));
      console.log("NPSN        :", chalk.green(s.npsn));
      console.log("Nama        :", chalk.green(s.sekolah));
      console.log("Bentuk      :", chalk.green(s.bentuk));
      console.log("Status      :", chalk.green(s.status));
      console.log("Provinsi    :", chalk.green(s.propinsi));
      console.log("Kab/Kota    :", chalk.green(s.kabupaten_kota));
      console.log("Kecamatan   :", chalk.green(s.kecamatan));
      console.log("Alamat      :", chalk.green(s.alamat_jalan));
      console.log("Lintang     :", chalk.green(s.lintang));
      console.log("Bujur       :", chalk.green(s.bujur));
      console.log(chalk.cyan("===================================="));
    });

    console.log(
      chalk.yellow(`\nTotal Data: ${data.total_data} | Page: ${data.page}`)
    );

  } catch (err) {
    spinner.fail("❌ Gagal mengambil data");
    console.log(chalk.red("Error:"), err.message);
  }
}

// =====================
// MENU
// =====================
async function menu() {
  while (true) {
    clear();
    console.log(chalk.red("╔════════════════════════════╗"));
    console.log(chalk.red("║     CEK NPSN SEKOLAH       ║"));
    console.log(chalk.red("╠════════════════════════════╣"));
    console.log(chalk.white("║ 1. Masukkan NPSN           ║"));
    console.log(chalk.white("║ 2. Keluar Tools            ║"));
    console.log(chalk.red("╚════════════════════════════╝"));

    const pilih = rl.question("\nPilih menu: ");

    if (pilih === "1") {
      const npsn = rl.question("Masukkan NPSN: ");
      if (!npsn) {
        console.log(chalk.red("\n❌ NPSN tidak boleh kosong"));
        rl.question("\nEnter untuk kembali...");
        continue;
      }
      await cekNPSN(npsn);
      rl.question("\nEnter untuk kembali ke menu...");
    } 
    else if (pilih === "2") {
      console.log(chalk.yellow("\n👋 Keluar dari tools"));
      process.exit(0);
    } 
    else {
      console.log(chalk.red("\n❌ Menu tidak valid"));
      rl.question("\nEnter untuk ulang...");
    }
  }
}

// =====================
menu();
