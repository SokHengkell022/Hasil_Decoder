const readline = require('readline');
const crypto = require('crypto');
const chalk = require('chalk');

function parseNik(nik) {
  const dd = parseInt(nik.slice(6, 8));
  const mm = parseInt(nik.slice(8, 10));
  const yy = parseInt(nik.slice(10, 12));
  const kelamin = dd > 40 ? 'Perempuan' : 'Laki-laki';
  const tanggal = dd > 40 ? dd - 40 : dd;
  const tahun = yy > 30 ? 1900 + yy : 2000 + yy;

  return {
    kelamin,
    tgl_lahir: `${tanggal.toString().padStart(2, '0')}-${mm.toString().padStart(2, '0')}-${tahun}`
  };
}

function generateNikFromPhone(phone) {
  const hash = crypto.createHash('md5').update(phone).digest('hex');
  const seed = parseInt(hash.slice(0, 12), 16);

  const prov = ['31', '32', '33', '34', '35', '36'][seed % 6];
  const kab = ['01', '02', '03', '04'][Math.floor(seed / 10) % 4];
  const kec = ['01', '02', '03'][Math.floor(seed / 100) % 3];

  const gender = (seed >> 3) % 2 === 0 ? 'Laki-laki' : 'Perempuan';
  const tgl = (seed % 28) + 1;
  const bln = ((seed >> 4) % 12) + 1;
  const thn = 1980 + ((seed >> 5) % 25);

  const dd = gender === 'Perempuan' ? tgl + 40 : tgl;
  const nikTgl = `${String(dd).padStart(2, '0')}${String(bln).padStart(2, '0')}${String(thn % 100).padStart(2, '0')}`;
  const serial = String((seed >> 6) % 9999).padStart(4, '0');

  return {
    nik: `${prov}${kab}${kec}${nikTgl}${serial}`,
    kelamin: gender,
    tgl_lahir: `${String(tgl).padStart(2, '0')}-${String(bln).padStart(2, '0')}-${thn}`
  };
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function tampilkanMenu() {
  console.clear();
console.log(chalk.white('  ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣄⣠⣀⡀⣀⣠⣤⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.white('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣄⢠⣠⣼⣿⣿⣿⣟⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⢠⣤⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⢦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.white('⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣟⣾⣿⣽⣿⣿⣅⠈⠉⠻⣿⣿⣿⣿⣿⡿⠇⠀⠀⠀⠀⠀⠉⠀⠀⠀⠀⠀⢀⡶⠒⢉⡀⢠⣤⣶⣶⣿⣷⣆⣀⡀⠀⢲⣖⠒⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.white('⢀⣤⣾⣶⣦⣤⣤⣶⣿⣿⣿⣿⣿⣿⣽⡿⠻⣷⣀⠀⢻⣿⣿⣿⡿⠟⠀⠀⠀⠀⠀⠀⣤⣶⣶⣤⣀⣀⣬⣷⣦⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⣤⣦⣼⣀⠀'));
console.log(chalk.white('⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠓⣿⣿⠟⠁⠘⣿⡟⠁⠀⠘⠛⠁⠀⠀⢠⣾⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠏⠙⠁'));
console.log(chalk.white('⠀⠸⠟⠋⠀⠈⠙⣿⣿⣿⣿⣿⣿⣷⣦⡄⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⣼⣆⢘⣿⣯⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡉⠉⢱⡿⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⡿⠦⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⡗⠀⠈⠀⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣉⣿⡿⢿⢷⣾⣾⣿⣞⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⣠⠟⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⠿⠿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣾⣿⣿⣷⣦⣶⣦⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠈⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⣿⣤⡖⠛⠶⠤⡀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠙⣿⣿⠿⢻⣿⣿⡿⠋⢩⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠧⣤⣦⣤⣄⡀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠘⣧⠀⠈⣹⡻⠇⢀⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.blue('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣤⣀⡀⠀⠀⠀⠀⠀⠀⠈⢽⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠹⣷⣴⣿⣷⢲⣦⣤⡀⢀⡀⠀⠀⠀⠀⠀⠀'));
console.log(chalk.green('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣷⢀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠂⠛⣆⣤⡜⣟⠋⠙⠂⠀⠀⠀⠀⠀'));
console.log(chalk.green('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⠉⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⣆⠀⠰⠄⠀⠉⠀⠀'));
console.log(chalk.green('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⠿⠿⣿⣿⣿⠇⠀⠀⢀⠀⠀⠀'));
console.log(chalk.green('⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⡿⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⡇⠀⠀⢀⣼⠗⠀⠀'));

   console.log(chalk.red('                  TOOLS OSINT PHONE BY MANZZXPLOIT'));
  console.log(chalk.blue(' AUTHOR : MANZZ GANTENG '));
  console.log(chalk.green('GITHUB : https://github.com/EnugmaXploit'));
  console.log(chalk.white('SELAMAT MENGUNAKAN\n'));

  console.log(chalk.white('[1] 🔍 Lacak Nomor HP'));
  console.log(chalk.white('[0] ❌ Keluar\n'));

  rl.question("Pilih menu (1/0): ", (menu) => {
    if (menu === '1') {
      mintaNomor();
    } else if (menu === '0') {
      console.log(chalk.yellow('\n👋 Terima kasih telah menggunakan OSINT Phone!'));
      rl.close();
    } else {
      console.log(chalk.red('\n❌ Menu tidak dikenali.'));
      setTimeout(tampilkanMenu, 1500);
    }
  });
}

function mintaNomor() {
  rl.question("\n📱 Masukkan Nomor HP (format 628xx): ", (input) => {
    const phone = input.trim();

    if (!/^628[1-9][0-9]{7,11}$/.test(phone)) {
      console.log("\n❌ Format tidak valid. Gunakan format 628xxxxxxxxxx");
      return tampilkanMenu();
    }

    const result = generateNikFromPhone(phone);
    const parsed = parseNik(result.nik);

    console.log("\n✅ Bocoran Ditemukan!\n");
    console.log("========================================");
    console.log(`📱 Nomor HP  : ${phone}`);
    console.log(`🔓 NIK Bocor : ${result.nik}`);
    console.log(`👤 Gender    : ${parsed.kelamin}`);
    console.log(`🎂 Tgl Lahir : ${parsed.tgl_lahir}`);
    console.log(`📂 Status    : Bocor`);
    console.log("========================================\n");

    rl.question("Tekan Enter untuk kembali ke menu...", () => {
      tampilkanMenu();
    });
  });
}

tampilkanMenu();
