// cariSiswaMahasiswa.js - Cari Mahasiswa/Siswa SMA/SMK tanpa DB

const readline = require('readline');
const crypto = require('crypto');
const chalk = require('chalk');

function hashNama(nama) {
  return parseInt(crypto.createHash('md5').update(nama.toLowerCase()).digest('hex').slice(0, 12), 16);
}

function cariData(nama) {
  const hash = hashNama(nama);

  if (hash % 100 < 5) {
    return null; // Simulasi tidak ditemukan
  }

  const jenjangList = ['SMA', 'SMK', 'Mahasiswa'];
  const sekolahList = [
    "SMA Negeri 1 Jakarta", "SMA Negeri 3 Bandung", "SMA Negeri 1 Yogyakarta",
    "SMK Negeri 2 Surabaya", "SMK Telkom Malang", "SMK Negeri 1 Semarang",
    "SMK telkomharkit ketangungan", "SMK Syafaa'tulummah Bulakamba"
  ];
  const kampusList = [
    "Universitas Indonesia", "Universitas Gadjah Mada", "Institut Teknologi Bandung",
    "Universitas Airlangga", "Universitas Diponegoro"
  ];
  const jurusanList = [
    "IPA", "IPS", "Bahasa", "RPL", "TKJ", "Multimedia",
    "Teknik Informatika", "Sistem Informasi", "Ilmu Hukum", "Manajemen",
    "TAV", "DKV"
  ];

  const jenjang = jenjangList[hash % jenjangList.length];
  const jurusan = jurusanList[(hash >> 3) % jurusanList.length];
  const angkatan = 2012 + ((hash >> 4) % 10);

  let asal = "";
  if (jenjang === "Mahasiswa") {
    asal = kampusList[(hash >> 5) % kampusList.length];
  } else {
    asal = sekolahList[(hash >> 5) % sekolahList.length];
  }

  return {
    nama,
    jenjang,
    asal,
    jurusan,
    angkatan
  };
}

// CLI
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.clear();
console.log(chalk.yellow('███╗   ███╗ █████╗ ██╗  ██╗ █████╗ ███████╗██╗███████╗██╗    ██╗ █████╗ '));
console.log(chalk.yellow('████╗ ████║██╔══██╗██║  ██║██╔══██╗██╔════╝██║██╔════╝██║    ██║██╔══██╗'));
console.log(chalk.yellow('██╔████╔██║███████║███████║███████║███████╗██║███████╗██║ █╗ ██║███████║'));
console.log(chalk.yellow('██║╚██╔╝██║██╔══██║██╔══██║██╔══██║╚════██║██║╚════██║██║███╗██║██╔══██║'));
console.log(chalk.yellow('██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██║███████║██║███████║╚███╔███╔╝██║  ██║'));
console.log(chalk.yellow('╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝'));
console.log(chalk.green('                               Coded By Manzz'));

function mulai() {
  rl.question("🔍 Masukkan Nama Lengkap (atau ketik 'exit' untuk keluar): ", (input) => {
    const nama = input.trim();

    if (nama.toLowerCase() === 'exit' || nama === '0') {
      console.log(chalk.green('\n👋 Terima kasih telah menggunakan tool ini. Keluar...\n'));
      rl.close();
      process.exit(0);
    }

    if (nama.length < 3) {
      console.log("\n❌ Nama terlalu pendek.");
      return mulai();
    }

    const result = cariData(nama);

    if (!result) {
      console.log("\n❌ Data tidak ditemukan di sistem nasional.");
    } else {
      console.log("\n📂 Data ditemukan:\n");
      console.log(`• Nama     : ${result.nama}`);
      console.log(`• Jenjang  : ${result.jenjang}`);
      console.log(`• ${result.jenjang === 'Mahasiswa' ? 'Kampus' : 'Sekolah'}  : ${result.asal}`);
      console.log(`• Jurusan  : ${result.jurusan}`);
      console.log(`• Angkatan : ${result.angkatan}`);
      console.log("\n📂 Sumber : Simulasi Nasional Pendidikan v1");
    }

    mulai(); // loop kembali
  });
}

mulai();
