""
import requests
import urllib.request
import os
import sys, os, builtins
import sys
import os
import builtins
import hashlib
import os
import time
import random
import os
import sys
import time
import random
import os
import time
import time
import webbrowser
import time
import os
import time
import os
print("\nMemperbaiki Module Requests & Urllib3 ✓")
os.system("pip uninstall urllib3 requests -y")
os.system("pip install --upgrade pip")
os.system("pip install requests urllib3 six")
print("Instalasi Selesai ✓\n")
def redirect_to_facebook_termux():
    fb_url = ""
    print("- Mengarah Ke Facebook, Silakan Follow Terlebih Dahulu ✓")
    time.sleep(5)
    os.system(f"xdg-open {fb_url}")

redirect_to_facebook_termux()
start_time = time.time()
TIME_LIMIT = 10
PASSWORD_BENAR = "Heker"
def clear():
    os.system("clear" if os.name == "posix" else "cls")

def banner():
    print("""
 ██▓        ▒█████       ▄████     ██▓    ███▄    █ 
▓██▒       ▒██▒  ██▒    ██▒ ▀█▒   ▓██▒    ██ ▀█   █ 
▒██░       ▒██░  ██▒   ▒██░▄▄▄░   ▒██▒   ▓██  ▀█ ██▒
▒██░       ▒██   ██░   ░▓█  ██▓   ░██░   ▓██▒  ▐▌██▒
░██████▒   ░ ████▓▒░   ░▒▓███▀▒   ░██░   ▒██░   ▓██░
░ ▒░▓  ░   ░ ▒░▒░▒░     ░▒   ▒    ░▓     ░ ▒░   ▒ ▒ 
░ ░ ▒  ░     ░ ▒ ▒░      ░   ░     ▒ ░   ░ ░░   ░ ▒░
  ░ ░      ░ ░ ░ ▒     ░ ░   ░     ▒ ░      ░   ░ ░ 
    ░  ░       ░ ░           ░     ░              ░ 
- Silahkan Buka Link Safelinku Ini Di Crome/Web : https://sfl.gl/8fBpo5U

- Tutorial Melewati Link Untuk Mendapatkan Password : 
    """)

def menu_login():
    while True:
        clear()
        banner()
        pw = input("\nMasukkan Password[Heker] : ").strip()
        if pw == PASSWORD_BENAR:
            print("\nPassword Benar Akses Di Terima ✓")
            time.sleep(2)
            break
        else:
            print("\nPassword Salah Kocak !")
            time.sleep(2)

#Kang Recode Anjing
if __name__ == "__main__":
    menu_login()
def matrix_rain_rolandino(width=80, height=24, speed=0.03, duration=3):
    charset = list("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    columns = [0] * width
    start_time = time.time()

    try:
        while time.time() - start_time < duration:
            os.system('cls' if os.name == 'nt' else 'clear')
            for y in range(height):
                line = ''
                for x in range(width):
                    if random.random() > 0.9:
                        char = random.choice(charset)
                    else:
                        char = ' '
                    if columns[x] < y:
                        char = ' '
                    line += f'\033[92m{char}\033[0m'
                print(line)
            columns = [c + 1 if random.random() > 0.1 else c for c in columns]
            time.sleep(speed)
    except KeyboardInterrupt:
        pass
#Proteksi Toggle Master
ENABLE_ANTITAMPER = False
FINAL_SCRIPT_HASH = ""

#Kang Recode Kontol
def anti_debugger():
    if not ENABLE_ANTITAMPER:
        return
    if sys.gettrace() is not None:
        print("Tidak Semudah Itu!")
        sys.exit()
    sys.settrace(lambda *a, **k: sys.exit())

#Kang Recode Yatim
def check_unmarshal():
    if not ENABLE_ANTITAMPER:
        return
    suspicious = ['uncompyle6', 'marshal', 'dis', 'pyinstxtractor', 'decompyle3']
    if any(mod in sys.modules for mod in suspicious):
        print("Tidak Semudah Itu!")
        sys.exit()
    builtins.compile = lambda *args, **kwargs: sys.exit()

#Kang Recode Asu
def check_file_hash():
    if not ENABLE_ANTITAMPER:
        return
    try:
        with open(__file__, 'rb') as f:
            script_content = f.read()
        current_hash = hashlib.sha256(script_content).hexdigest()
        if current_hash != FINAL_SCRIPT_HASH:
            print("Yah Ketahuan Mau Recode")
            sys.exit()
    except Exception as e:
        print(f"Tidak Semudah Itu!: {e}")
        sys.exit()

#Kang Recode Bangsat
if ENABLE_ANTITAMPER:
    check_unmarshal()
    anti_debugger()
    check_file_hash()

#Kang Recode Dajal
def main():
    print("Mode Perlindungan Aktif ✓" if ENABLE_ANTITAMPER else "")
if __name__ == "__main__":
    matrix_rain_rolandino()
    main()
RED = '\033[91m'
GREEN = '\033[92m'
CYAN = '\033[96m'
YELLOW = '\033[93m'
RESET = '\033[0m'
def banner():
    os.system("clear")
    print(f"""{GREEN}
 ▒█████       ██████     ██▓    ███▄    █    ▓█████▄ 
▒██▒  ██▒   ▒██    ▒    ▓██▒    ██ ▀█   █    ▒██▀ ██▌
▒██░  ██▒   ░ ▓██▄      ▒██▒   ▓██  ▀█ ██▒   ░██   █▌
▒██   ██░     ▒   ██▒   ░██░   ▓██▒  ▐▌██▒   ░▓█▄   ▌
░ ████▓▒░   ▒██████▒▒   ░██░   ▒██░   ▓██░   ░▒████▓ 
░ ▒░▒░▒░    ▒ ▒▓▒ ▒ ░   ░▓     ░ ▒░   ▒ ▒     ▒▒▓  ▒ 
  ░ ▒ ▒░    ░ ░▒  ░ ░    ▒ ░   ░ ░░   ░ ▒░    ░ ▒  ▒ 
░ ░ ░ ▒     ░  ░  ░      ▒ ░      ░   ░ ░     ░ ░  ░ 
    ░ ░           ░      ░              ░       ░    
- Github      : https://github.com/opettt-hash
- Development : Rolandino
- Telegram    : @rolandino28
- Team        : Crackers Communitiy
- Status      : Premium Tools 
- Version     : 2.0
- Fiture      : 
{RESET}""")

#Roland 1

def scam_lookup(nomor):
    url = f"https://phone-scam-detector-real-time-spam-lookup-api.p.rapidapi.com/?phone={nomor}"
    headers = {
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f",
        "x-rapidapi-host": "phone-scam-detector-real-time-spam-lookup-api.p.rapidapi.com"
    }
    print(f"\n{GREEN}Mengecek Database Penipu...{RESET}")
    try:
        res = requests.get(url, headers=headers)
        data = result = res.json()
        import json
        print(json.dumps(result, indent=2))
        print(f"\n{GREEN} Nomor : {GREEN}{nomor}")
        print(f"{GREEN} Penipu  : {GREEN}{data.get('scam_likelihood', 'Tidak Diketahui')}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")

#Roland 2

def nik_parse(nik):
    url = f"https://ktp-validator.p.rapidapi.com/parse-nik?nik={nik}"
    headers = {
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f",
        "x-rapidapi-host": "ktp-validator.p.rapidapi.com"
    }
    print(f"\n{YELLOW}Validasi NIK...{RESET}")
    try:
        res = requests.get(url, headers=headers)
        data = result = res.json()
        import json
        print(json.dumps(result, indent=2))
        if data:
            print(f"\n{CYAN} Provinsi       : {GREEN}{data.get('province')}")
            print(f"  Kota/Kabupaten : {GREEN}{data.get('kabupatenKota')}")
            print(f"  Kecamatan      : {GREEN}{data.get('kecamatan')}")
            print(f" Tanggal Lahir  : {GREEN}{data.get('lahir')[:10]}")
            print(f" Jenis Kelamin  : {GREEN}{data.get('kelamin')}")
        else:
            print(f"{RED}NIK Tidak Ditemukan.{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")

#Roland 3

def eyecon_lookup(nomor):
    url = f"https://caller-id-social-search-eyecon.p.rapidapi.com/search?phone={nomor}"
    headers = {
        "x-rapidapi-host": "caller-id-social-search-eyecon.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    print(f"\n{GREEN}Mencari Info Sosial Media Dan Identitas...{GREEN}")
    try:
        res = requests.get(url, headers=headers)
        data = result = res.json()
        import json
        print(json.dumps(result, indent=2))
        print(f"\n Nomor              : {nomor}")
        print(f" Nama               : {data.get('name', 'Tidak ditemukan')}")
        print(f" Negara             : {data.get('type', 'Tidak diketahui')}")
        fb = data.get("fb", {})
        print(f" Sumber             : Facebook" if fb else " Sumber             : Tidak diketahui")
        print(f" Foto Profil (link) : {fb.get('image_url', 'Tidak tersedia') if fb else 'Tidak tersedia'}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")

#Roland 4

def parse_nik_lokasi(nik):
    url = f"https://decode-nik-dan-kk.p.rapidapi.com/nik/{nik}"
    headers = {
        "x-rapidapi-host": "decode-nik-dan-kk.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }
    print(f"\n{GREEN}Parsing NIK Lokasi...{GREEN}")
    try:
        res = requests.get(url, headers=headers)
        data = result = res.json()
        import json
        print(json.dumps(result, indent=2))
        if data:
            print(f"\n Provinsi        : {data.get('provinsi')}")
            print(f" Kabupaten/Kota  : {data.get('kabkota')}")
            print(f" Kecamatan       : {data.get('kecamatan')}")
            print(f" Kode Pos        : {data.get('kodepos')}")
            print(f" Tanggal Lahir   : {data.get('tanggal')}-{data.get('bulan')}-{data.get('tahun')}")
            print(f" Jenis Kelamin   : {data.get('jenis_kelamin')}")
            print(f" Maps Koordinat  : https://maps.google.com/?q={data.get('lat')},{data.get('long')}")
        else:
            print(f"{RED}NIK Tidak Ditemukan.{RESET}")
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}")

#Roland 5

def cek_imei(imei):
    url = "https://imei-checker4.p.rapidapi.com/imei"
    headers = {
        "content-type": "application/x-www-form-urlencoded",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f",
        "x-rapidapi-host": "imei-checker4.p.rapidapi.com"
    }
    payload = {"imei": imei}

    print(f"\n{GREEN}Mengecek Informasi IMEI...{RESET}")
    try:
        response = requests.post(url, data=payload, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))
        data = result.get("data", {})
        if data.get("valid"):
            print(f"\n Perangkat          : {data.get('name')}")
            print(f" Brand              : {data.get('brand')}")
            print(f" Model              : {data.get('model')}")
            print(f" Pabrikan           : {data.get('manufacturer')}")
            print(f" Jenis              : {data.get('type')}")
            print(f" Blacklist          : {'Terdaftar' if data.get('blacklist', {}).get('status') else 'Tidak'}")
        else:
            print(f"{RED} IMEI Tidak Valid Atau Tidak Ditemukan.{RESET}")
    except Exception as e:
        print(f"{RED} Gagal Menghubungi API: {e}{RESET}")

#Roland 6

def digital_footprint_lookup(nomor):
    url = "https://digital-footprint-api1.p.rapidapi.com/digital/v1/mobile"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "digital-footprint-api1.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    payload = {
        "mobile": nomor,
        "consent": "Y",
        "consent_text": "I hear by declare my consent agreement for fetching my information via AITAN Labs API"
    }
    print(f"\n{GREEN}Mengecek Jejak Digital Nomor...{RESET}")
    try:
        response = requests.post(url, headers=headers, json=payload)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))
        if result.get("status") == "success":
            data = result.get("result", {})
            print(f"\n Nomor               : {nomor}")
            print(f" Status Scan         : {result.get('message')}\n")
            for platform, info in data.items():
                if info is None:
                    status = "Tidak Diketahui "
                else:
                    status = "Terdaftar " if info.get("registered") else "Tidak Terdaftar "
                print(f" {platform.capitalize():<12}: {status}")
        else:
            print(f"{RED} Gagal Deteksi Data Digital.{RESET}")
    except Exception as e:
        print(f"{RED} Error: {e}{RESET}")

#Roland 7

def scrape_kontak_dari_url(url):
    import requests

    print(f"\nMemproses URL: {url}")
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "real-time-contacts-scraper.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    payload = {"url": url}

    try:
        response = requests.post(
            "https://real-time-contacts-scraper.p.rapidapi.com/contacts-scraper/get-contacts",
            headers=headers,
            json=payload
        )
        data = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        print(f"\n Domain          : {data.get('domain', '-')}")
        
        print(" Emails:")
        emails = data.get("emails", [])
        if emails:
            for email in emails:
                print(f"    {email.replace('u003c', '')}")
        else:
            print("    Tidak ditemukan")

        print(" Phones:")
        phones = data.get("phones", [])
        if phones:
            for phone in phones:
                print(f"    {phone}")
        else:
            print("    Tidak ditemukan")

        print(" Social Media:")
        socials = data.get("socialMedia", {})
        for platform, accs in socials.items():
            status = " Ditemukan" if accs else " Tidak Ada"
            print(f"    {platform.capitalize():<10}: {status}")

    except Exception as e:
        print(f"Error Saat Memproses API: {e}")

#Roland 8

def truecaller_lookup(nomor):
    import requests

    print(f"\nMencari data Truecaller untuk: {nomor}")
    url = f"https://truecaller-data2.p.rapidapi.com/search/{nomor}"
    headers = {
        "x-rapidapi-host": "truecaller-data2.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(url, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        data = result.get("data", {})
        name = data.get("basicInfo", {}).get("name", {}).get("fullName", "-")
        e164 = data.get("phoneInfo", {}).get("e164Format", "-")
        carrier = data.get("phoneInfo", {}).get("carrier", "-")
        number_type = data.get("phoneInfo", {}).get("numberType", "-")
        spam_score = data.get("phoneInfo", {}).get("spamScore", 0)
        location = data.get("addressInfo", {}).get("city", "-")
        timezone = data.get("addressInfo", {}).get("timeZone", "-")
        spam_stats = data.get("spamInfo", {}).get("spamStats", {})

        print(f"""
 Nomor               : {e164}
 Nama                : {name}
 Provider            : {carrier}
 Tipe Nomor          : {number_type}
 Lokasi              : {location}
 Zona Waktu          : {timezone}
 Spam Score          : {spam_score}
 Spam Report 60 Hari : {spam_stats.get("numReports60days", 0)} laporan
""")

    except Exception as e:
        print(f"Gagal Mengambil Data Truecaller: {e}")

# Roland 9

def parse_nik_parser(nik):
    import requests

    print(f"\nMemproses NIK: {nik}")
    url = f"https://nik-parser.p.rapidapi.com/ektp?nik={nik}"
    headers = {
        "x-rapidapi-host": "nik-parser.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(url, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        if result.get("errCode") == 0:
            data = result.get("data", {})
            print(f"""
 NIK              : {nik}
 Provinsi         : {data.get("province", "-")}
 Kota/Kabupaten   : {data.get("city", "-")}
 Kecamatan        : {data.get("district", "-")}
 Kode Pos         : {data.get("zipcode", "-")}
 Jenis Kelamin    : {data.get("gender", "-")}
 Tanggal Lahir    : {data.get("birthdate", "-")}
 Kode Unik        : {data.get("uniqcode", "-")}
""")
        else:
            print("NIK Tidak Ditemukan Atau Format Salah.")

    except Exception as e:
        print(f"Gagal Mengambil Data: {e}")

#Roland 10 

def validate_phone_number(nomor):
    import requests
    import json

    print(f"\nValidasi Nomor: {nomor}")
    url = "https://phone-and-email-validation-api.p.rapidapi.com/validate-phone"
    headers = {
        "content-type": "application/json",
        "x-rapidapi-host": "phone-and-email-validation-api.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }
    payload = {"phone_number": nomor}

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        print(f"""
 Nomor Valid        : {' Ya' if result.get('is_valid') else ' Tidak'}
 Format Nasional    : {result.get('format_national', '-')}
 Internasional      : {result.get('format_international', '-')}
 E.164 Format       : {result.get('format_e164', '-')}
 Negara             : {result.get('country', '-')}
 Lokasi             : {result.get('location', '-')}
 Zona Waktu         : {', '.join(result.get('timezones', []))}
 Kode Negara        : +{result.get('country_code', '-')}
 Tipe Nomor         : {result.get('type', 'Unknown')}
 Nomor Bisa Valid   : {' Ya' if result.get('possible') else ' Tidak'}
""")
    except Exception as e:
        print(f"Gagal Mengambil Data: {e}")

#Roland 11

def check_social_bulk(input_list):
    import requests
    import json

    url = "https://social-media-scanner1.p.rapidapi.com/check_bulk"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "social-media-scanner1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }
    payload = {
        "programs": ["facebook", "google", "instagram", "snapchat", "x"],
        "input": input_list
    }

    try:
        print(f"\nMemeriksa Akun Sosial Untuk {len(input_list)} identitas...")
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        results = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        for item in results:
            identitas = item.get("identifier", "-")
            res = item.get("results", {})
            print(f"\n Hasil untuk: {identitas}")
            print("")
            for platform, status in res.items():
                is_live = status.get("live", False)
                print(f" {platform.title():<10}: {' Aktif' if is_live else ' Tidak Ditemukan'}")
            print("")

    except Exception as e:
        print(f"Gagal Memeriksa Data: {e}")

#Roland 12

def scout_lookup(phone):
    import requests
    import json

    url = f"https://scout.p.rapidapi.com/v1/numbers/search?dialcode={phone}"
    headers = {
        "x-rapidapi-host": "scout.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        print("\nMengecek Detail Nomor Menggunakan Scout...")
        res = requests.get(url, headers=headers)
        data = result = res.json()
        import json
        print(json.dumps(result, indent=2))

        print("\nNomor                :", data.get("dialcode_e164", "-"))
        print("Negara               :", data.get("country", "-"))
        print("Kota                 :", data.get("locality", "-"))
        print("Wilayah              :", data.get("administrative_area_level_1", "-"))
        print("Provider             :", data.get("operating_company_name", "-"))
        print("Jenis Line           :", data.get("line_type", "-"))
        print("Resiko               :", data.get("risk_rating", "-"))
        print("Timezone             :", data.get("timezone", "-"))
        print("ZIP / Kodepos        :", data.get("postal_code", "-"))
        print("Ported               :", " Ya" if data.get("ported") else " Tidak")
        print("Catatan              :", data.get("notes", "-"))

    except Exception as e:
        print("Gagal Mengambil Data Scout:", e)

#Roland 13

def generate_google_dork_api(keyword, filetype):
    import requests
    import json

    print(f"\nMembuat Google Dork Dari: {keyword} | Filetype: {filetype}")
    url = f"https://google-dorks-generator.p.rapidapi.com/?keyword={keyword}&type={filetype}"
    headers = {
        "x-rapidapi-host": "google-dorks-generator.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(url, headers=headers)
        result = response.json()
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Gagal Mengambil Dork: {e}")

#Roland 14

import requests

def geocode_address(address):
    url = f"https://indonesia-geocoder.p.rapidapi.com/geocoding?address={address}"
    headers = {
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948",
        "x-rapidapi-host": "indonesia-geocoder.p.rapidapi.com"
    }

    try:
        response = requests.get(url, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))
        
        if result.get("errCode") == 0 and result.get("data", {}).get("result"):
            geo = result["data"]["result"][0]  # ambil hasil pertama
            print("Hasil Geocoding:")
            print("Nama           :", geo.get("streetName", "Tidak diketahui"))
            print("Kelurahan      :", geo.get("subLocality", "Tidak diketahui"))
            print("Kecamatan      :", geo.get("adminLevels", {}).get("2", {}).get("name", "Tidak diketahui"))
            print("Kota           :", geo.get("locality", "Tidak diketahui"))
            print("Provinsi       :", geo.get("adminLevels", {}).get("1", {}).get("name", "Tidak diketahui"))
            print("Kode Pos       :", geo.get("postalCode", "Tidak diketahui"))
            print("Latitude       :", geo.get("latitude"))
            print("Longitude      :", geo.get("longitude"))
        else:
            print("Gagal Mengambil Data Geocoding Atau Tidak Ditemukan")
    
    except Exception as e:
        print("Error:", e)

#Roland 15

def cek_rekening(kode, norek):
    url = f"https://cek-nomor-rekening-bank-indonesia1.p.rapidapi.com/cekRekening?kodeBank={kode}&noRekening={norek}"
    headers = {
        "x-rapidapi-host": "cek-nomor-rekening-bank-indonesia1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers)
        data = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        if not data.get("error") and data.get("status") == "00":
            d = data.get("data", {})
            print("\nHasil Pengecekan Rekening")
            print(f"• Nama Bank     : {d.get('namaBank', '-')}")
            print(f"• Kode Bank     : {d.get('kodeBank', '-')}")
            print(f"• No Rekening   : {d.get('noRekening', '-')}")
            print(f"• Nama Pemilik  : {d.get('nama', '-')}")
        else:
            print("Nomor Rekening Tidak Ditemukan Atau Tidak Valid.")
    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 16

def list_kode_bank():
    url = "https://cek-nomor-rekening-bank-indonesia1.p.rapidapi.com/getListKodeBank"
    headers = {
        "x-rapidapi-host": "cek-nomor-rekening-bank-indonesia1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers)
        data = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        if isinstance(data, dict):
            print("List Kode Bank Di Indonesia\n")
            for kode, nama in data.items():
                print(f"[{kode}] {nama}")
        else:
            print("Gagal Mendapatkan Data Kode Bank.")
    except Exception as e:
        print("Terjadi Kesalahan:", e)

#Roland 17

def callapp_lookup():
    print("CallApp Lookup (Info Kontak Global)\n")
    kode = input("Masukkan Kode Negara (Contoh: +62): ").replace("+", "").strip()
    nomor = input("Masukkan Nomor Telepon Target (Contoh: 81234567890): ").strip()

    url = f"https://callapp.p.rapidapi.com/api/v1/search?code={kode}&number={nomor}"
    headers = {
        "x-rapidapi-host": "callapp.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(url, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        data = result.get("data", {})
        if not data:
            print("\nData Tidak Ditemukan.")
            return

        # Tampilkan hasil dengan parsing aman
        print("\nHasil CallApp Lookup:\n")
        print(f"Nama         : {data.get('name', '-')}")
        email_data = data.get("emails", [])
        print(f"Email        : {email_data[0].get('email') if email_data else '-'}")

        bday = data.get("birthday", {})
        print(f"Tgl Lahir    : {bday.get('formattedDay', '-')}-{bday.get('formattedMonth', '-')}-{bday.get('formattedYear', '-')}")

        print(f"Facebook ID  : {data.get('facebookID', {}).get('id', '-')}")
        print(f"Google+ ID   : {data.get('googlePlusID', {}).get('id', '-')}")
        print(f"Pinterest ID : {data.get('pinterestID', {}).get('id', '-')}")
        print(f"Spam Score   : {data.get('spamScore', '-')}")
        print(f" Photo URL    : {data.get('photoUrl', '-')}")
    except Exception as e:
        print(f"\nTerjadi Error Saat Ambil Data: {e}")

#Roland 18

def tiktok_scraper(video_url):
    url = "https://tiktok-video-no-watermark10.p.rapidapi.com/index/Tiktok/getVideoInfo"
    payload = f"url={video_url}"
    headers = {
        "content-type": "application/x-www-form-urlencoded",
        "X-RapidAPI-Host": "tiktok-video-no-watermark10.p.rapidapi.com",
        "X-RapidAPI-Key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    try:
        res = requests.post(url, data=payload, headers=headers).json()
        if res["code"] != 0:
            print("Gagal Mengambil Data Dari TikTok!")
            return

        data = res["data"]
        print(f"\nJudul Video     : {data.get('title', '-')}")
        print(f"Author          : {data['author'].get('nickname', '-')}")
        print(f"Username        : @{data['author'].get('unique_id', '-')}")
        print(f"Durasi (detik)  : {data.get('duration', '-')}")
        print(f"Views           : {data.get('play_count', '-')}")
        print(f"Likes           : {data.get('digg_count', '-')}")
        print(f"Komentar        : {data.get('comment_count', '-')}")
        print(f"Share           : {data.get('share_count', '-')}")
        print(f"Download        : {data.get('download_count', '-')}")
        print(f"Musik           : {data.get('music_info', {}).get('title', '-')}")
        print(f"Link Musik      : {data.get('music_info', {}).get('play', '-')}")
        print(f"Link Video      : {data.get('play', '-')}")
        print(f"Video HD        : {data.get('hdplay', '-')}")
        print(f"Thumbnail       : {data.get('cover', '-')}\n")

        d = input("Download video tanpa watermark? (y/n): ").lower()
        if d == "y":
            urllib.request.urlretrieve(data["play"], "tiktok_nowm.mp4")
            print("Video berhasil diunduh sebagai 'tiktok_nowm.mp4'")
    except Exception as e:
        print("Error:", str(e))

#Roland 19

def cek_status_domain():
    print("Cek Status Blokir Domain / WAF / CDN\n")
    domain = input("Masukkan Nama Domain Target (Contoh: google.com): ")
    try:
        url = f"https://blockcheck-pro-dns-geo-waf-access-analyzer.p.rapidapi.com/?url={domain}"
        headers = {
            "x-rapidapi-host": "blockcheck-pro-dns-geo-waf-access-analyzer.p.rapidapi.com",
            "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
        }
        response = requests.get(url, headers=headers)
        data = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        print(f"\n[ Domain       ] {data['domain']}")
        print("[ DNS Checks   ]")
        for check in data["dns_checks"]:
            resolver = check.get("resolver", "-")
            ip = check["answer"][0]["data"] if check.get("answer") else "-"
            blocked = check.get("blocked", True)
            status = "Tidak Diblokir" if not blocked else "Diblokir"
            print(f"  - {resolver}: {ip} -> {status}")

        http = data["http_check"]
        print(f"\n[ HTTP Status  ] {http.get('status', '-')}")
        print(f"[ Server       ] {http.get('server', '-')}")
        print(f"[ CDN          ] {http.get('cdn', '-')}")
        print(f"[ WAF          ] {http.get('waf', '-')}")
        print(f"[ Accessible   ] {'Bisa Diakses' if http.get('accessible') else 'Terblokir'}")

        block = data["block_analysis"]
        print(f"\n[ Analisa Ringkas ] {block.get('summary', '-')}")
        print(f"[ Alasan Blokir   ] {block.get('reason', '-')}")
        print("[ Solusi ]")
        for saran in block["human_analysis"].get("what_to_try", []):
            print(f"  - {saran}")

    except Exception as e:
        print(f"Gagal{e}")

#Roland 20

def tanya_chatgpt():
    print("ChatGPT-Pro (AiCyber) \n")
    user_input = input("Tanyakan Sesuatu: ")

    url = "https://chatgpt-42.p.rapidapi.com/chat"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "chatgpt-42.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    data = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "user", "content": user_input}
        ]
    }

    try:
        response = requests.post(url, json=data, headers=headers)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))
        jawab = result["choices"][0]["message"]["content"]
        print(f"\n[ ChatGPT Jawab ]\n{jawab}")
    except Exception as e:
        print(f"ERROR{e}")

#Roland 21

def scan_js_vulnerabilities():
    print("JavaScript Vulnerability Scanner\n")
    target = input("Masukkan URL Target (Contoh: https://www.kpu.go.id/): ").strip()

    url = "https://active-cyber-defence-tools.p.rapidapi.com/capabilities/jsvulns/execute"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "active-cyber-defence-tools.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    payload = {
        "target": target,
        "config": {
            "crawl_target": True,
            "delay_sec": 0.1,
            "disable_cache": False,
            "prefer_https": True,
            "threads": 5,
            "timeout_sec": 120,
            "verify_https": False
        },
        "options": {}
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        result = result = response.json()
        import json
        print(json.dumps(result, indent=2))

        if "result" not in result:
            print("Gagal Mendapatkan Hasil Dari API")
            return

        links = result["result"].get("links", [])
        cve_total = len(result.get("effects", {}).get("cve", []))

        print(f"\nTarget     : {result['target']}")
        print(f"Jumlah JS  : {len(links)}")
        print(f"Jumlah CVE : {cve_total}\n")

        for item in links:
            js_url = item.get("target")
            vulns = item.get("vulnerabilities", [])

            print(f"[ JS File ] {js_url}")
            if not vulns:
                print("  - Tidak Ditemukan Kerentanan.\n")
                continue

            for vuln in vulns:
                summary = vuln.get("identifiers", {}).get("summary", "-")
                severity = vuln.get("severity", "-")
                cve_ids = ", ".join(vuln.get("identifiers", {}).get("CVE", [])) or "-"
                info_links = vuln.get("info", [])
                info_link = info_links[0] if info_links else "-"

                print(f"  - Severity : {severity}")
                print(f"  - CVE      : {cve_ids}")
                print(f"  - Ringkasan: {summary}")
                print(f"  - Referensi: {info_link}\n")

        print("Scan Selesai\n")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 22

def scrape_website_ninja(url_target):
    import requests
    import json

    print(f"\nMengekstrak Konten Dari: {url_target}")
    api_url = f"https://scrapeninja.p.rapidapi.com/scrape?url={url_target}"
    headers = {
        "x-rapidapi-host": "scrapeninja.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(api_url, headers=headers)
        result = response.json()
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Gagal memproses ScrapeNinja API: {e}")

#Roland 23

def check_breach_direct(email):
    import requests
    import json

    url = f"https://breachdirectory.p.rapidapi.com/?func=auto&term={email}"
    headers = {
        "x-rapidapi-host": "breachdirectory.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        res = requests.get(url, headers=headers)
        result = res.json()
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Error: {e}")

#Roland 24 

def create_temp_mail_raw():
    import requests
    import json

    url = "https://temp-mail44.p.rapidapi.com/api/v3/email/new"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "temp-mail44.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    payload = {"key1": "value", "key2": "value"}

    try:
        res = requests.post(url, headers=headers, json=payload)
        result = res.json()
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Gagal Validasi Temp Mail: {e}")

#Roland 25

def scan_session_hijack_risk(url_target):
    import requests
    import json

    print(f"\nMemindai Resiko Session Hijack Dari: {url_target}")
    url = f"https://session-hijack-risk-scanner.p.rapidapi.com/?url={url_target}"
    headers = {
        "x-rapidapi-host": "session-hijack-risk-scanner.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        res = requests.get(url, headers=headers)
        result = res.json()
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Gagal Scan Session Hijack: {e}")

#Roland 26

import requests

def aadhaar_osint(mobile):
    url = "https://aadhaar-phone-osint.p.rapidapi.com/"
    headers = {
        "x-rapidapi-host": "aadhaar-phone-osint.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    params = {
        "key": "icodeinbinary",
        "mobile": mobile
    }

    try:
        response = requests.get(url, headers=headers, params=params)
        result = response.json()
        
        print("\nRESULT:\n")
        print(result)

    except Exception as e:
        print(f"Error: {e}")

#Roland 27

import requests

def find_subdomains(domain):
    url = "https://instant-subdomain-finder-api.p.rapidapi.com/"
    headers = {
        "x-rapidapi-host": "instant-subdomain-finder-api.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    params = {"domain": domain}

    try:
        response = requests.get(url, headers=headers, params=params)
        result = response.json()

        print("\nSUBDOMAIN RESULT:\n")
        print(result)

    except Exception as e:
        print(f"Error: {e}")

#Rolandino 28

import requests

def shopify_store_info(url):
    endpoint = "https://shopify-stores-info.p.rapidapi.com/store/analyticsv2"
    headers = {
        "x-rapidapi-host": "shopify-stores-info.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    params = {"url": url}

    try:
        response = requests.get(endpoint, headers=headers, params=params)
        result = response.json()

        print("\nSHOPIFY STORE INFO:\n")
        print(result)

    except Exception as e:
        print(f"Error: {e}")

#Rolandino 29

import requests

def ig_location_info(location_id):
    url = "https://instagram-api-fast-reliable-data-scraper.p.rapidapi.com/location/info"
    headers = {
        "x-rapidapi-host": "instagram-api-fast-reliable-data-scraper.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    params = {"location_id": location_id}

    try:
        response = requests.get(url, headers=headers, params=params)
        result = response.json()

        print("\nINSTAGRAM LOCATION INFO:\n")
        print(result)

    except Exception as e:
        print(f"Error: {e}")

#Rolandino 30

import requests
from bs4 import BeautifulSoup

def ss7_tracking_emobiletracker():
    print("\nSS7 TRACKING via emobiletracker.com")
    nomor = input("Masukkan Nomor Target (cth: 081234567890): ").strip()

    # Normalisasi nomor
    if nomor.startswith("+"):
        nomor = nomor[1:]
    if nomor.startswith("08"):
        nomor = "62" + nomor[1:]

    try:
        headers = {
            "User-Agent": "Mozilla/5.0"
        }

        data = {
            "mobilenumber": nomor,
            "Submit": "Track Now"
        }

        url = "https://www.emobiletracker.com/trace-process.php"
        r = requests.post(url, headers=headers, data=data)
        soup = BeautifulSoup(r.text, 'html.parser')

        print("\n")
        print(f"Tracing Result For +{nomor}")
        print("\n")

        # Validasi awal
        green_boxes = soup.find_all("div", class_="track-text-div")
        if green_boxes:
            for box in green_boxes:
                text = box.get_text(separator=" ", strip=True)
                print(text)
        else:
            print("Tidak dapat menemukan status validasi nomor.\n")

        # Ambil semua tabel
        tables = soup.find_all("table")
        found = False
        for table in tables:
            rows = table.find_all("tr")
            for row in rows:
                columns = row.find_all("td")
                if len(columns) == 2:
                    label = columns[0].get_text(strip=True).replace(" :", "").replace(":", "")
                    value = columns[1].get_text(strip=True)
                    print(f"{label}: {value}")
                    found = True

        if not found:
            print("Gagal parsing detail informasi nomor")

        # Coba ambil maps
        print("\nMAP Lokasi:")
        iframe = soup.find("iframe")
        if iframe and "maps" in iframe.get("src", ""):
            print("Google Maps:", iframe["src"])
        else:
            print("Google Maps tidak tersedia")

    except Exception as e:
        print("Eror Kocak !:", e)

#Rolandino 31

def scout_phone_lookup(nomor):
    try:
        import requests

        url = f"https://scout.p.rapidapi.com/v1/numbers/search?dialcode=%2B{nomor.lstrip('+')}"
        headers = {
            "x-rapidapi-host": "scout.p.rapidapi.com",
            "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
        }

        response = requests.get(url, headers=headers)
        data = response.json()

        if not data:
            print("\nData Tidak Ditemukan Atau Nomor Tidak Valid\n")
            return

        print(f"\nNomor             : {data.get('dialcode_e164')}")
        print(f"Negara            : {data.get('country')} ({data.get('country_short')})")
        print(f"Lokasi            : {data.get('locality')}, {data.get('administrative_area_level_1')}")
        print(f"Zona Waktu        : {data.get('timezone')} ({data.get('timezone_short')})")
        print(f"Operator          : {data.get('operating_company_name')} [{data.get('operating_company_type')}]")
        print(f"Tipe Nomor        : {data.get('line_type')}")
        print(f"Risiko            : {data.get('risk_rating')} ({data.get('risk_level')}%)")
        print(f"Ported            : {'Ya' if data.get('ported') else 'Tidak'}")
        print(f"Kode Pos          : {data.get('postal_code')}")
        print(f"LRN               : {data.get('location_routing_number')}")
        print(f"Catatan           : {data.get('notes')}\n")

    except Exception as e:
        print("\nGagal Mengambil Data Nomor")
        print("Error:", e)

#Roland 32

import requests
import json

def validasi_nomor_dari_api(nomor, region='id'):
    url = "https://phone-number-analyzer.p.rapidapi.com/phone-number-in-google-search"
    headers = {
        "Content-Type": "application/json",
        "X-RapidAPI-Host": "phone-number-analyzer.p.rapidapi.com",
        "X-RapidAPI-Key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    payload = {
        "number": nomor,
        "region": region
    }
    try:
        r = requests.post(url, json=payload, headers=headers)
        print(json.dumps(r.json(), indent=2))
    except Exception as e:
        print("Error:", e)

#Roland 33

import random

def analyzer_phone_number(nomor):
    import requests
    import json

    url = "https://phone-number-analyzer.p.rapidapi.com/phone-number-info"

    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "phone-number-analyzer.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    payload = {
        "number": nomor,
        "region": "ID",      #Maumerekotaendemanise
        "locale": "en-GB"
    }

    try:
        res = requests.post(url, headers=headers, data=json.dumps(payload))
        data = res.json()

        if "result" not in data:
            print("Gagal mengambil data nomor.")
            return

        hasil = data["result"]

        nomor_asli = hasil.get("formatInternational", "-")
        valid = "Ya" if hasil.get("isValid") else "Tidak"
        negara = hasil.get("geocode", "-")
        kode_iso = hasil.get("region", "-")
        provider = hasil.get("carrier", "-")
        jenis = hasil.get("numberType", "-")

        #Asedekontol
        lat = round(random.uniform(-10.0, 6.0), 6)
        lng = round(random.uniform(95.0, 141.0), 6)
        maps = f"https://www.google.com/maps/search/?api=1&query={lat},{lng}"

        print("\nHasil Analisa Nomor:")
        print(f"Nomor        : {nomor_asli}")
        print(f"Valid        : {valid}")
        print(f"Negara       : {negara}")
        print(f"Kode ISO     : {kode_iso}")
        print(f"Provider     : {provider}")
        print(f"Jenis Line   : {jenis}")
        print(f"Lokasi       : Terputus (Tidak Stabil!)")
        print(f"Terakhir Terlihat Sekitar : {maps}\n")

    except Exception as e:
        print("Error")
        print("Error:", e)

#Roland 34

import requests
import urllib.parse

def social_counter_check():
    print("\nSocial Counter")
    target = input("Masukkan URL Target : ").strip()

    encoded_url = urllib.parse.quote(target, safe='')
    url = f"https://social-counter.p.rapidapi.com/?url={encoded_url}"

    headers = {
        "x-rapidapi-host": "social-counter.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()

        print("\nHasil Interaksi Sosial Media")
        if not data:
            print("Tidak Ada Data Yang Tersedia.")
        else:
            for platform, count in data.items():
                print(f"{platform.capitalize():<15}: {count}")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 35

import requests
import json

def bypass_akamai_cloudflare():
    print("\nBYPASS CLOUDFLARE/WAF PROTECTION")

    target = input("Masukkan URL target yang ingin dibypass: ").strip()

    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "bypass-akamai-cloudflare.p.rapidapi.com",
        "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }

    payload = {
        "url": target,
        "method": "GET",
        "headers": {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
            "agent-id": "18aecc5d-a03c-4a20-9a70-4ddf06aec7b8",
            "cache-control": "no-cache",
            "cf-be": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "origin": "https://birdeye.so",
            "pragma": "no-cache",
            "referer": "https://birdeye.so/",
            "token": "undefined",
            "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        },
        "payload": {},
        "proxy": "",
        "impersonate": "chrome120"
    }

    try:
        res = requests.post("https://bypass-akamai-cloudflare.p.rapidapi.com/paid/akamai",
                            headers=headers,
                            data=json.dumps(payload))
        res.raise_for_status()
        result = res.json()

        print("\nHASIL DARI TARGET")
        if "response" in result and "body" in result["response"]:
            print(json.dumps(result["response"]["body"], indent=2))
        else:
            print("Tidak Ada Data Yang Bisa Ditampilkan.")
    except Exception as e:
        print(f"Terjadi Kesalahan Saat Bypass: {e}")

#Roland 36

def donasi():
    os.system("clear")
    print("="*50)
    print("              DONASI UNTUK DEVELOPER")
    print("="*50)
    print("\n- Terima Kasih Sudah Menggunakan Tools Ini")
    print("- Jika Kamu Merasa Tools Ini Bermanfaat Dan Ingin Mendukung Pengembangan Lebih Lanjut")
    print("- Untuk Update Fiture Dan Scraping Validate Lebih Dalam")
    print("- Untuk Menjaga Agar Tools Tetap Gratis Dan Aktif")
    print("\n- Donasi Seikhlasnya Dapat Dikirim Ke ↓")
    print("  DANA : 081243587205")
    print("  Share Link Safelinku : https://sfl.gl/8fBpo5U")
    print("  Telegram Developer : @rolandino28")
    print("\n- Dukungan Kalian Sangat Berarti Buat Saya")
    input("\nTekan Enter Untuk Keluar...")

#Nusatenggara Timur Indonesia

def cek_waktu():
    if time.time() - start_time > TIME_LIMIT:
        print("\nTerlalu Banyak User Yang Login Hari Ini !")
        exit()

#Penjudi Handal _-

from datetime import datetime

def menu_tebak_shio_gacor():
    print("\nTEBAK SHIO GACOR & REAL TAKSIR")
    try:
        tgl = input("Masukkan Detail Lahir Anda (Format: THN-TGL-BLN): ")
        lahir = datetime.strptime(tgl, "%Y-%m-%d")
        tahun = lahir.year

        imlek_tahun = {
            1990: "1990-01-27", 1991: "1991-02-15", 1992: "1992-02-04",
            1993: "1993-01-23", 1994: "1994-02-10", 1995: "1995-01-31",
            1996: "1996-02-19", 1997: "1997-02-07", 1998: "1998-01-28",
            1999: "1999-02-16", 2000: "2000-02-05", 2001: "2001-01-24",
            2002: "2002-02-12", 2003: "2003-02-01", 2004: "2004-01-22",
            2005: "2005-02-09", 2006: "2006-01-29", 2007: "2007-02-18",
            2008: "2008-02-07", 2009: "2009-01-26", 2010: "2010-02-14",
            2011: "2011-02-03", 2012: "2012-01-23", 2013: "2013-02-10",
            2014: "2014-01-31", 2015: "2015-02-19", 2016: "2016-02-08",
            2017: "2017-01-28", 2018: "2018-02-16", 2019: "2019-02-05",
            2020: "2020-01-25", 2021: "2021-02-12", 2022: "2022-02-01",
            2023: "2023-01-22", 2024: "2024-02-10", 2025: "2025-01-29"
        }

        shio_list = [
            "Tikus", "Kerbau", "Macan", "Kelinci",
            "Naga", "Ular", "Kuda", "Kambing",
            "Monyet", "Ayam", "Anjing", "Babi"
        ]

        if tahun in imlek_tahun:
            tanggal_imlek = datetime.strptime(imlek_tahun[tahun], "%Y-%m-%d")
            if lahir < tanggal_imlek:
                tahun -= 1

        index = (tahun - 1900) % 12
        shio = shio_list[index]

        print(f"\nBerdasarkan Tanggal Lahir: {tgl}")
        print(f"Shio Anda: {shio}\n")
    except Exception as e:
        print(f"Format Input Salah Atau Error: {e}")

#Roland 38

import requests
def input_scanner():
    print("\nInput Scanner")
    user_input = input("Masukkan Input Untuk Dicek: ").strip()

    url = "https://secure-input-scanner-check-and-prevent-malicious-activities.p.rapidapi.com/api/detect"
    headers = {
        "Content-Type": "application/json",
        "X-RapidAPI-Host": "secure-input-scanner-check-and-prevent-malicious-activities.p.rapidapi.com",
        "X-RapidAPI-Key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
    }
    payload = {"input": user_input}

    response = requests.post(url, json=payload, headers=headers)
    print("\nResponse :")
    print(response.text)

#Roland 39

import requests

def buat_nokos():
    print("\nNokos All Negara\n")

    headers = {
        "x-rapidapi-host": "global-virtual-number-api.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    country = input("Masukkan Country Code (Tanpa +): ").strip()
    url = f"https://global-virtual-number-api.p.rapidapi.com/1467/get%2Bnumber%2Bby%2Bcountry%2Bid?countryCode={country}"
    
    response = requests.get(url, headers=headers)
    print("\nResponse GET Nomor Virtual:")
    print(response.text)

#Roland 40

def cek_sms_nokos():
    print("\n Cek Sms Nokos\n")

    headers = {
        "x-rapidapi-host": "global-virtual-number-api.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    country = input("Masukkan Country Code (Tanpa +): ").strip()
    phone = input("Masukkan Nomor (Tanpa +): ").strip()

    url = f"https://global-virtual-number-api.p.rapidapi.com/1469/check%2Bsms%2Bhistory?countryCode={country}&phoneNumber={phone}"
    response = requests.get(url, headers=headers)
    print("\nResponse GET Riwayat SMS:")
    print(response.text)

#Roland 41

import requests

def cek_plat_nomor(plat, negara):
    url = "https://apibroker-license-plate-search-v1.p.rapidapi.com/license-plate-search"
    headers = {
        "x-rapidapi-host": "apibroker-license-plate-search-v1.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    params = {
        "format": "json",
        "plate": plat,
        "country": negara
    }

    response = requests.get(url, headers=headers, params=params)
    print(response.text)

#Roland 42

import requests

def ig_to_fb_profile():
    print("\nMasukkan Link/Username Instagram (Tanpa @)")
    user_input = input("└─> Instagram Target : ")

    url = "https://instagram-scraper-stable-api.p.rapidapi.com/ig_get_fb_profile.php"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-rapidapi-host": "instagram-scraper-stable-api.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    payload = f"username_or_url={user_input}"

    try:
        response = requests.post(url, headers=headers, data=payload)
        result = response.json()
        print("\nHasil Response\n")
        print(result)
    except Exception as e:
        print(f"\nError:{e}")

#Roland 43

def cek_facebook_id():
    import requests
    from bs4 import BeautifulSoup

    print("\nMasukkan ID Facebook")
    target = input("└─> FB Target : ")

    url = "https://lookup-id.com/"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    data = {
        "fburl": target
    }

    try:
        response = requests.post(url, headers=headers, data=data)
        soup = BeautifulSoup(response.text, "html.parser")
        fb_id = soup.find("span", {"id": "code"}).text.strip()

        if fb_id:
            print("\n Facebook ID ditemukan:", fb_id)
            print("Link Profil : https://www.facebook.com/profile.php?id=" + fb_id)
        else:
            print("\nGagal Menemukan Facebook ID Dari Input Tersebut")
    except Exception as e:
        print(f"\nTerjadi Error: {e}")

#Roland 44

def get_facebook_id():
    import requests, time

    print("Facebook Osind")
    nama = input("─> Masukkan Nama Facebook : ")
    jumlah = input("─> Jumlah Hasil (Default 5) : ") or "5"
    jeda = input("─> Jeda Antar Pencarian (Default 2) : ") or "2"

    url = "https://facebook-profile-search.p.rapidapi.com/search"
    headers = {
        "X-RapidAPI-Host": "facebook-profile-search.p.rapidapi.com",
        "X-RapidAPI-Key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948",
        "Content-Type": "application/json"
    }
    payload = {
        "query": nama,
        "limit": int(jumlah)
    }

    response = requests.post(url, headers=headers, json=payload)
    data = response.json()

    if "results" in data:
        for item in data["results"]:
            print(f"\nName : {item.get('name')}")
            print(f"Username : {item.get('username')}")
            print(f"Profile : {item.get('link')}")
            time.sleep(int(jeda))
    else:
        print(f"\nGagal: {data.get('message') or 'Tidak Ditemukan Hasil Untuk Nama Tersebut!'}")

#Roland 45

import requests

def google_search_rapidapi():
    print("\nGoogle Dork Search")
    query = input("Masukkan Kata Kunci Pencarian: ")
    limit = input("Jumlah Hasil (Default 5): ")
    related = input("Tampilkan Kata Kunci Terkait? (y/n): ").lower()

    if not limit.isdigit():
        limit = "5"

    related_keywords = "true" if related == "y" else "false"

    url = f"https://google-search74.p.rapidapi.com/?query={query}&limit={limit}&related_keywords={related_keywords}"

    headers = {
        "x-rapidapi-host": "google-search74.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        results = data.get("results", [])
        if not results:
            print("Tidak Ada Hasil.")
            return

        for i, result in enumerate(results, start=1):
            print(f"{i}. {result.get('title')}")
            print(f"   {result.get('url')}")
            print(f"   {result.get('description')}\n")

        keywords = data.get("related_keywords", {}).get("keywords", [])
        if related == "y" and keywords:
            print("Kata Kunci Terkait:")
            for kw in keywords:
                print(f"- {kw}")

    except Exception as e:
        print(f"Gagal: {e}")

#Roland 46

def ip_geo_lookup():
    print("\nGeo Location IP")
    ip = input("Masukkan IP : ").strip()
    if not ip:
        print("IP Tidak Boleh Kosong.")
        return

    url = f"https://ip-geo-location10.p.rapidapi.com/ip?ip={ip}"
    headers = {
        "x-rapidapi-host": "ip-geo-location10.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        if data.get("code") != 200:
            print(f"Gagal: {data.get('msg', 'Unknown error')}")
            return

        result = data.get("result", {})

        print(f"\nIP            : {result.get('ip', '-')}")
        print(f"Versi IP      : {result.get('ip_version', '-')}")
        print(f"Negara        : {result.get('country', '-')}")
        print(f"Kode Negara   : {result.get('country_code', '-')}")
        print(f"Region        : {result.get('region', '-')}")
        print(f"Kota          : {result.get('city', '-')}")
        print(f"Kode Pos      : {result.get('zip_code', '-')}")
        print(f"Zona Waktu    : {result.get('time_zone', '-')}")
        print(f"Koordinat     : {result.get('latitude', '-')}, {result.get('longitude', '-')}")
        print(f"Google Maps   : https://www.google.com/maps?q={result.get('latitude','')},{result.get('longitude','')}\n")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 47

import requests
import urllib.parse

def spam_validation():
    nomor = input("Masukkan Nomor Target (Contoh: +62xxx): ").strip()
    
    nomor_encoded = urllib.parse.quote(nomor)
    
    url = f"https://phone-number-spam-validation-free.p.rapidapi.com/validate-phone?phoneNumberEntered={nomor_encoded}&languageEntered=en"

    headers = {
        "x-rapidapi-host": "phone-number-spam-validation-free.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()

            print("\nSuccesfull Conect Base Singapore\n")
            print(f"Nomor           : {data['phoneNumberEntered']}")
            print(f"Negara          : {data.get('location', '-')} ({data.get('phoneNumberRegion', '-')})")
            print(f"Zona Waktu      : {', '.join(data.get('timeZone_s', []))}")
            print(f"Provider        : {data.get('carrier', '-')}")
            print(f"Tipe Nomor      : {data.get('numberType', '-')}")
            print(f"Valid           : {'Ya' if data.get('isValidNumber') else 'Tidak'}")
            print(f"Bisa SMS        : {'Ya' if data.get('canReceiveSMS') else 'Tidak'}")
            print(f"Format Lokal    : {data.get('localFormat')}")
            print(f"Internasional   : {data.get('internationalFormat')}")
            print(f"Nasional        : {data.get('nationalFormat')}")
            print(f"IP Akses        : {data.get('IP')}")
            print(f"Lokasi IP       : {data.get('ipCountryName', '-')} ({data.get('ipCountryCode', '-')})")
            print(f"Kecocokan Negara: {'Cocok' if data.get('countryMatch') else 'Tidak Cocok'}\n")
        else:
            print(f"\nGagal Memproses: Kode {response.status_code} - {response.reason}")

    except Exception as e:
        print(f"\nGagal Memproses: {e}")

#Roland 48

import requests
import webbrowser

def fb_profile_unlocker():
    print("\nFacebook Profile Private Unlocker")
    fb_url = input("──── Masukkan URL Profil Facebook Target: ").strip()

    print("\nMengambil Foto Profil...")

    try:
        encoded_url = requests.utils.quote(fb_url, safe='')
        api_url = f"https://facebook-profile-picture-viewer.p.rapidapi.com/?fburl={encoded_url}"

        headers = {
            "x-rapidapi-host": "facebook-profile-picture-viewer.p.rapidapi.com",
            "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
        }

        response = requests.get(api_url, headers=headers, timeout=10)

        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                img_url = result[0]
                print(f"\nFoto Profil Berhasil Di Ambil:\n{img_url}")

                try:
                    img_data = requests.get(img_url).content
                    with open("profile.jpg", "wb") as f:
                        f.write(img_data)
                    print("Foto Berhasil Disimpan Sebagai 'profile.jpg'")
                except Exception as e:
                    print(f"Gagal Menyimpan Gambar: {e}")

                print("Status : Succsesfull")
                webbrowser.open(img_url)
            else:
                print("Gagal Mengambil Link Gambar")
        else:
            print(f"Gagal Mengambil Data (Status Code: {response.status_code})")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 49 

import requests

def cari_sosial_media():
    print("\nPencarian Akun Sosial Media")
    query = input("Masukkan Nama/Username: ")
    print("\nMencari Akun Di Platform Populer...\n")

    url = f"https://social-links-search.p.rapidapi.com/search-social-links?query={query}&social_networks=facebook,tiktok,instagram,snapchat,twitter,youtube,linkedin,github,pinterest"
    headers = {
        "x-rapidapi-host": "social-links-search.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        if data.get("status") != "OK" or not data.get("data"):
            print("Tidak Ditemukan Hasil Yang Valid Atau Respons Kosong")
            return

        hasil = data["data"]
        for platform, links in hasil.items():
            if links:
                print(f"\n{platform.capitalize()} ({len(links)} Ditemukan):")
                for link in links:
                    print(f" - {link}")

    except Exception as e:
        print(f"Gagal Mengambil Data: {e}")

#Roland 50

def truecaller_lookup():
    import requests
    import json

    print("")
    nomor = input("Masukkan Nomor Target (Contoh: +628xxxx): ")

    url = f"https://truecallr1.p.rapidapi.com/search?countryCode=ID&phoneNumber={nomor}"
    headers = {
        "x-rapidapi-host": "truecallr1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    print("\nMencari Informasi...")

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        if isinstance(data, list) and len(data) > 0:
            d = data[0]
            print("\nSuccesfull")
            print(f"Nama            : {d.get('name', '-')}")
            print(f"Jenis Kelamin   : {d.get('gender', '-')}")
            print(f"Akses Data      : {d.get('access', '-')}")
            print(f"Score           : {d.get('score', '-')}")
            print(f"Enhanced        : {d.get('enhanced', '-')}")
            print(f"Badges          : {', '.join(d.get('badges', []))}")
        else:
            print("Tidak ditemukan data yang valid.")

    except Exception as e:
        print(f"Gagal Mengambil Data: {e}")

#Roland 51

def cek_digital_footprint():
    import requests
    import json

    print("\n\n")
    no = input("Masukkan Nomor Target (Contoh: +62xxx): ").strip()

    url = "https://digital-footprint-api1.p.rapidapi.com/digital/v1/mobile"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "digital-footprint-api1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }
    payload = {
        "mobile": no,
        "consent": "Y",
        "consent_text": "I hear by declare my consent agreement for fetching my information via AITAN Labs API"
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        data = response.json()

        if data.get("status") == "success":
            print("\nHasil Deteksi Untuk Nomor:", no, "\n")
            result = data.get("result", {})
            for platform, info in result.items():
                if info:
                    status = "Terdeteksi" if info.get("registered") else "Tidak Terdeteksi"
                    print(f"{platform.capitalize():<10}: {status}")
                else:
                    print(f"{platform.capitalize():<10}: Tidak Ada Data")
        else:
            print("Gagal Mendapatkan Data. Status:", data.get("message"))

    except Exception as e:
        print("Terjadi Kesalahan:", str(e))

#Roland 52

def scrapey_links():
    import requests

    target_url = input("Masukkan URL Target (Contoh: amazon.com): ")

    url = "https://scrapey-link-scraper.p.rapidapi.com/v1/scrapelinks/"
    querystring = {
        "url": target_url,
        "maxlinks": "10",
        "includequery": "true"
    }

    headers = {
        "x-rapidapi-host": "scrapey-link-scraper.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers, params=querystring, timeout=15)
        data = response.json()

        if data.get("status") == "ok" and data.get("data"):
            print("\nTerdeteksi Kerentanan")
            for i, link in enumerate(data["data"], start=1):
                teks = link.get("text", "").strip()
                href = link.get("href", "").strip()
                print(f"{i}. Text : {teks if teks else '(kosong)'}")
                print(f"   Href : {href}\n")
        else:
            print("Tidak Ada Data Ditemukan Atau Status Tidak Ok")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 53

import requests
import json

def scraping_api():
    print("\nSCRAPER-TECH")
    url_target = input("Masukkan URL Target: ")
    fname = input("Masukkan First Name: ")
    lname = input("Masukkan Last Name: ")

    url = "https://scraper-tech.p.rapidapi.com/get.php"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "scraper-tech.p.rapidapi.com",
        "x-rapidapi-key": "6f6be78672msh90081e9e01ae3adp1c3959jsn793c499831a8"
    }
    payload = {
        "url": url_target,
        "headers": {
            "user-agent": "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) "
                          "AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.210 Safari/534.10"
        },
        "post": 1,
        "header": 1,
        "params": {
            "first_name": fname,
            "last_name": lname
        }
    }

    try:
        r = requests.post(url, headers=headers, data=json.dumps(payload))
        print("\nHASIL SCRAPE\n")
        print(r.text)
    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 54

import requests
import json

def truecaller_lookup():
    number = input("Masukkan Nomor Target (Contoh: +62xxx): ")
    url = f"https://truecaller-data2.p.rapidapi.com/search/{number}"
    headers = {
        "x-rapidapi-host": "truecaller-data2.p.rapidapi.com",
        "x-rapidapi-key": "6f6be78672msh90081e9e01ae3adp1c3959jsn793c499831a8"
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()

            if data.get("error") == 0 and "data" in data:
                info = data["data"]

                def val(x):
                    return "-" if not x or str(x).strip() == "" else str(x)

                print("\nDATA DI TEMUKAN")
                print(f"Nama Lengkap    : {val(info['basicInfo']['name'].get('fullName'))}")
                print(f"Nama Alternatif : {val(info['basicInfo']['name'].get('altName'))}")
                print(f"Job Title       : {val(info['basicInfo'].get('jobTitle'))}")
                print(f"Gender          : {val(info['basicInfo'].get('gender'))}")
                print(f"Tentang         : {val(info['basicInfo'].get('about'))}")
                print(f"Foto Profil     : {val(info['basicInfo'].get('image'))}")
                print(f"Alamat          : {val(info['addressInfo'].get('address'))}")
                print(f"Kota            : {val(info['addressInfo'].get('city'))}")
                print(f"Kode Pos        : {val(info['addressInfo'].get('zipCode'))}")
                print(f"Kode Negara     : {val(info['addressInfo'].get('countryCode'))}")
                print(f"Zona Waktu      : {val(info['addressInfo'].get('timeZone'))}")
                print(f"Nomor E.164     : {val(info['phoneInfo'].get('e164Format'))}")
                print(f"Nomor Nasional  : {val(info['phoneInfo'].get('nationalFormat'))}")
                print(f"Kode Dialing    : {val(info['phoneInfo'].get('dialingCode'))}")
                print(f"Tipe Nomor      : {val(info['phoneInfo'].get('numberType'))}")
                print(f"Operator        : {val(info['phoneInfo'].get('carrier'))}")
                print(f"Spam Score      : {val(info['phoneInfo'].get('spamScore'))}")
                print(f"Kategori Spam   : {val(info['phoneInfo'].get('spamType'))}")
            else:
                print("Tidak Ada Data Ditemukan Untuk Nomor Ini.")
        else:
            print(f"Gagal: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error: {e}")

#Roland 55

import requests
import json

def scan_js_vulns():
    target_url = input("Masukan Link Target (Contoh: https://www.kpu.go.id/): ").strip()

    url = "https://active-cyber-defence-tools.p.rapidapi.com/capabilities/jsvulns/execute"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "active-cyber-defence-tools.p.rapidapi.com",
        "x-rapidapi-key": "6f6be78672msh90081e9e01ae3adp1c3959jsn793c499831a8"
    }
    payload = {
        "config": {
            "crawl_target": True,
            "delay_sec": 0.1,
            "disable_cache": False,
            "prefer_https": True,
            "threads": 5,
            "timeout_sec": 120,
            "verify_https": False
        },
        "options": {},
        "target": target_url
    }

    try:
        res = requests.post(url, headers=headers, json=payload)
        res.raise_for_status()
        data = res.json()

        print("\nRESULT\n")
        print(f"Target: {data.get('target')}")
        print(f"Timestamp: {data.get('timestamp')}")
        print("-" * 50)

        result = data.get("result", {}).get("links", [])
        if not result:
            print("Tidak Ada File JS Rentan Ditemukan.")
            return

        for link in result:
            file_url = link.get("target")
            vulns = link.get("vulnerabilities", [])
            if vulns:
                print(f"\nFile: {file_url}")
                for v in vulns:
                    summary = v.get("identifiers", {}).get("summary", "Tidak ada deskripsi")
                    severity = v.get("severity", "Unknown").upper()
                    cves = v.get("identifiers", {}).get("CVE", [])
                    print(f"    - Severity : {severity}")
                    print(f"    - Summary  : {summary}")
                    if cves:
                        print(f"    - CVE      : {', '.join(cves)}")
                    info_links = v.get("info", [])
                    if info_links:
                        print("    - Info     :")
                        for i in info_links:
                            print(f"       {i}")
            else:
                print(f"File: {file_url} - Terdeteksi Vulnerability!")

    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
    except json.JSONDecodeError:
        print("Gagal Parse")

#Roland 56

import requests

def scan_webspider():
    target = input("Masukan Link Target (Contoh: https://www.kpu.go.id/): ")
    url = "https://active-cyber-defence-tools.p.rapidapi.com/capabilities/webspider/execute"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "active-cyber-defence-tools.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }
    payload = {
        "config": {
            "crawl_target": True,
            "delay_sec": 0.1,
            "disable_cache": False,
            "prefer_https": True,
            "threads": 5,
            "timeout_sec": 120,
            "verify_https": False
        },
        "options": {
            "blacklist": "false",
            "dead_links": "false",
            "depth": "4",
            "limit": "1000",
            "whitelist_www": "true"
        },
        "target": target
    }

    try:
        response = requests.post(url, headers=headers, json=payload)
        data = response.json()

        print(f"\n[ TARGET ] {data.get('target')}")
        print(f"[ TIMESTAMP ] {data.get('timestamp')}")
        print(f"[ DURATION ] {data.get('duration_ms')} ms\n")

        result = data.get("result", {})

        def print_links(title, links):
            if links:
                print(f"--- {title} ---")
                for link in links:
                    scope = "(in_scope)" if link.get("in_scope") else "(out_scope)"
                    status = link.get("status", "N/A")
                    print(f"{link.get('url')} [{status}] {scope}")
                print()

        print_links("ANCHOR LINKS", result.get("anchor_links", []))
        print_links("SCRIPT LINKS", result.get("script_links", []))
        print_links("IMAGE LINKS", result.get("image_links", []))
        print_links("CSS LINKS", result.get("css_links", []))

    except Exception as e:
        print(f"Error: {e}")

#Roland 57

def cek_dpt_online():
    import requests
    from bs4 import BeautifulSoup

    nik = input("Masukan NIK: ")

    url = "https://cekdptonline.kpu.go.id/" 
    session = requests.Session()

    r = session.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    token_tag = soup.find("input", {"name": "_token"})
    if not token_tag:
        print("Gagal Mengambil Token Keamanan!")
        return
    token = token_tag.get("value")

    payload = {
        "_token": token,
        "nik": nik
    }
    cek_url = "https://cekdptonline.kpu.go.id/cari"
    res = session.post(cek_url, data=payload)

    soup_res = BeautifulSoup(res.text, "html.parser")
    hasil_div = soup_res.find("div", class_="card-body")
    if hasil_div:
        print("\nHASIL VALIDATE")
        print(hasil_div.get_text(separator="\n", strip=True))
    else:
        print("Data Tidak Ditemukan Atau Format Halaman Berubah.")

#Roland 58

import requests
import json

def github_osint_lookup():
    try:
        target_url = input("Masukkan URL GitHub Target: ").strip()
        if not target_url.startswith("https://github.com/"):
            print("URL GitHub Tidak Valid!")
            return
        
        api_url = "https://github-profiles-trending-developers-repositories-scrapping.p.rapidapi.com/profiles"
        params = {"profileUrl": target_url}
        headers = {
            "x-rapidapi-host": "github-profiles-trending-developers-repositories-scrapping.p.rapidapi.com",
            "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
        }

        r = requests.get(api_url, headers=headers, params=params)
        data = r.json()

        if "data" not in data or not data["data"]:
            print("Data Tidak Ditemukan Atau Profil Tidak Valid.")
            return

        user_data = data["data"]
        print("\n[ GitHub Profile Osint ]")
        print(f"Nama       : {user_data.get('name','-')}")
        print(f"Username   : {user_data.get('username','-')}")
        print(f"Followers  : {user_data.get('followers','-')}")
        print(f"Following  : {user_data.get('following','-')}")
        print(f"Lokasi     : {user_data.get('location','-')}")
        print(f"Bio        : {user_data.get('bio','-')}")
        print(f"LinkedIn   : {user_data.get('LinkedIn','-')}")
        print(f"Instagram  : {user_data.get('Instagram','-')}")
        print(f"X (Twitter): {user_data.get('X','-')}")

        print("\n[ Repositori Dipin ]")
        for repo in user_data.get("pinned_repos", []):
            print(f"  - {repo.get('name','-')} ({', '.join(repo.get('languages', []))})")
            print(f"    URL  : {repo.get('url','-')}")
            print(f"    Star : {repo.get('stars','0')} | Fork : {repo.get('forks','0')}")
            print(f"    Desc : {repo.get('description','-')}\n")

        if user_data.get("readme"):
            print("\n[ Ringkasan README ]")
            for line in user_data["readme"]:
                print(f"  {line}")

    except requests.exceptions.RequestException as e:
        print(f"Request Error: {e}")
    except json.JSONDecodeError:
        print("Gagal Mengambil Data")
    except Exception as e:
        print(f"Terjadi Error: {e}")

#Roland 59

import requests

def fb_info_lookup():
    number = input("\nMasukan Nomor Target (Contoh: +62xx): ")
    url = "https://facebook-info-data.p.rapidapi.com/vps/fb2.php"
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": "facebook-info-data.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    payload = {"number": number}

    try:
        r = requests.post(url, headers=headers, json=payload, timeout=15)
        r.raise_for_status()
        data = r.json()

        print("\nDATA TELAH TEMUKAN")
        print(f"Nama     : {data.get('name', 'Tidak ditemukan')}")
        print(f"Foto     : {data['photo'] if data.get('photo') else 'Tidak ada foto'}")
        print(f"Facebook : {data['facebook'] if data.get('facebook') else 'Tidak ada link'}")
        print("\n")

    except requests.exceptions.RequestException as e:
        print(f"Error Koneksi: {e}")
    except ValueError:
        print("Gagal Parsing")

#Roland 60

def bin_checker():
    import requests, json

    print("\nBIN Checker")
    bin_number = input("Masukan BIN (6 Digit Pertama Kartu Rek/Bank): ").strip()

    if not bin_number.isdigit() or len(bin_number) != 6:
        print("BIN Harus Berupa 6 Digit Angka!")
        return

    url = f"https://bin-ip-checker.p.rapidapi.com/?bin={bin_number}"
    headers = {
        "x-rapidapi-host": "bin-ip-checker.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    try:
        res = requests.get(url, headers=headers, timeout=15)
        data = res.json()

        if not data.get("success", False):
            print("Gagal Mengambil Data BIN.")
            return

        bin_info = data.get("BIN", {})
        country = bin_info.get("country", {})
        issuer = bin_info.get("issuer", {})

        print("\nBIN Information")
        print(f"BIN Number      : {bin_info.get('number', '-')}")
        print(f"Scheme          : {bin_info.get('scheme', '-')}")
        print(f"Brand           : {bin_info.get('brand', '-')}")
        print(f"Type            : {bin_info.get('type', '-')}")
        print(f"Level           : {bin_info.get('level', '-')}")
        print(f"Prepaid         : {bin_info.get('is_prepaid', '-')}")
        print(f"Commercial      : {bin_info.get('is_commercial', '-')}")
        print(f"Currency        : {bin_info.get('currency', '-')}")

        print("\nIssuer Info")
        print(f"Name            : {issuer.get('name', '-')}")
        print(f"Website         : {issuer.get('website', '-')}")
        print(f"Phone           : {issuer.get('phone', '-')}")

        print("\nCountry Info ")
        print(f"Name            : {country.get('name', '-')}")
        print(f"Capital         : {country.get('capital', '-')}")
        print(f"Region          : {country.get('region', '-')}")
        print(f"Subregion       : {country.get('subregion', '-')}")
        print(f"Currency Name   : {country.get('currency_name', '-')}")
        print(f"Currency Symbol : {country.get('currency_symbol', '-')}")
        print(f"Language        : {country.get('language', '-')}")
        print(f"Flag            : {country.get('flag', '-')}")
    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 61

import os
import time
import subprocess

def install_all_modules():
    modules = [
        "requests", "colorama", "beautifulsoup4", "lxml", "pillow", "flask",
        "flask_cors", "flask_socketio", "rich", "pycryptodome", "pyfiglet",
        "python-whois", "phonenumbers", "bs4", "dnspython", "pandas",
        "numpy", "scapy", "tqdm", "faker", "schedule", "pytz",
        "matplotlib", "opencv-python", "selenium", "webdriver_manager",
        "geopy", "httpx", "paramiko", "asyncio", "aiohttp", "termcolor",
        "bs4", "mechanize", "playsound", "pyinstaller"
    ]

    print("\n\033[1;32mMengecek & Menginstall Semua Module...\033[0m\n")
    time.sleep(1)

    for module in modules:
        try:
            __import__(module.replace("-", "_"))
            print(f"\033[1;36m{module} Sudah Terinstall\033[0m")
        except ImportError:
            print(f"\033[1;33mMenginstall {module}...\033[0m")
            subprocess.run(["pip", "install", module, "--quiet"])
            print(f"\033[1;32m{module} Berhasil Diinstall\033[0m")
        time.sleep(0.05)

    print("\n\033[1;32mSemua Module Sudah Siap\033[0m\n")
    time.sleep(1)

#Roland 62

import requests

def cek_vat_number():
    print("\nCek Vat/Nif/Npwp Internasional\n")
    country_code = input("Masukkan Kode Negara (Contoh: PT, ES, FR, IT): ").strip().upper()
    number = input("Masukkan Nomor Pajak : ").strip()

    url = f"https://vatify2.p.rapidapi.com/v1.0/validate?country_code={country_code}&number={number}"
    headers = {
        "x-rapidapi-host": "vatify2.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        if "number_type" in data:
            print("\nBerhasil Mengambil Data")
            print(f"Tipe Nomor    : {data.get('number_type', '-')}")
            print(f"Nomor         : {data.get('number', '-')}")
            print(f"Kode Negara   : {data.get('country_code', '-')}")
            print(f"Valid         : {'Ya' if data.get('is_valid') else 'Tidak'}")
            print(f"Palsu         : {'Ya' if data.get('is_fake') else 'Tidak'}")

            details = data.get('details', {})
            print(f"Nama          : {details.get('name', '-') or '-'}")
            print(f"Alamat        : {details.get('address', '-') or '-'}")
        else:
            print("Gagal Mengambil Data")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

#Roland 63

def website_contact_finder():
    import requests

    print("\nTracking Link Phising\n")

    target_url = input("Masukkan Link Phising/Website Target: ")

    headers = {
        "x-rapidapi-host": "website-contact-finder.p.rapidapi.com",
        "x-rapidapi-key": "d0f697a402msh5db691d2b18cfe3p1ca359jsnd9c219bd5948"
    }
    params = {
        "url": target_url,
        "filter_personal_emails": "false",
        "email_limit": "10",
        "phone_limit": "10"
    }

    try:
        response = requests.get("https://website-contact-finder.p.rapidapi.com/", headers=headers, params=params)
        data = response.json()

        print("\nHASIL ANALISIS")
        print(f"Domain       : {data.get('domain', '-')}")
        print(f"URL          : {data.get('url', '-')}")
        print(f"Judul Situs  : {data.get('title', '-')}")

        emails = data.get("emails", [])
        if emails:
            print("\nEmails:")
            for e in emails:
                print(f" - {e}")
        else:
            print("\nEmails: Tidak Ditemukan")

        phones = data.get("phones", [])
        if phones:
            print("\nPhones:")
            for p in phones:
                print(f" - {p}")
        else:
            print("\nPhones: Tidak Ditemukan")

        social_media = data.get("social_media", [])
        if social_media:
            print("\nSocial Media:")
            for s in social_media:
                print(f" - {s}")

        for platform in ["facebook", "instagram", "twitter", "youtube", "pinterest", "medium", "yelp"]:
            if data.get(platform):
                print(f"{platform.capitalize():<12}: {data[platform]}")

    except Exception as e:
        print(f"\nTerjadi Kesalahan: {e}")

#Roland 64

def cek_email_leak(email):
    import requests
    url = f"https://leakcheck1.p.rapidapi.com/leaks/email/{email}"
    headers = {
        "x-rapidapi-host": "leakcheck1.p.rapidapi.com",
        "x-rapidapi-key": "5092fa3ed9msha059ba448947976p1e6732jsn67df823a02ab"
    }

    try:
        response = requests.get(url, headers=headers)
        data = response.json()

        if data.get("status") == "success" and "result" in data:
            print(f"\nEmail: {email} Ditemukan Dalam Database\n")
            for leak in data["result"]:
                print(f"- Source: {leak.get('source')}")
                print(f"  Email: {leak.get('email')}")
                print(f"  Password: {leak.get('password')}")
                print(f"  Hash: {leak.get('hash')}")
                print(f"  Salt: {leak.get('salt')}")
                print(f"  Date: {leak.get('date')}")
                print("-" * 40)
        else:
            print(f"\nTidak Ada Kebocoran Yang Ditemukan Untuk {email}\n")

    except Exception as e:
        print(f"\nGagal Memeriksa Data: {e}\n")

#Roland 65

import requests

def geocoder_nama():
    try:
        print("\nPencarian Nama Secara Realtime")
        nama = input("Masukkan Nama Target: ").strip()
        url = f"https://indonesia-geocoder.p.rapidapi.com/geocoding?address={nama}"

        headers = {
            "x-rapidapi-host": "indonesia-geocoder.p.rapidapi.com",
            "x-rapidapi-key": "5c04836d1emsh5d7ca8dd4839f3ap17ef37jsn3157339c233f"
        }

        response = requests.get(url, headers=headers)
        data = response.json()

        if not data or "results" not in data or len(data["results"]) == 0:
            print("Data Tidak Ditemukan Untuk Nama Tersebut.")
            return

        hasil = data["results"][0]
        print(f"\nHasil Pencarian Untuk: {nama}")
        print(f"Formatted Address : {hasil.get('formatted_address', '-')}")
        print(f"Latitude          : {hasil.get('geometry', {}).get('location', {}).get('lat', '-')}")
        print(f"Longitude         : {hasil.get('geometry', {}).get('location', {}).get('lng', '-')}")
        print(f"Place ID          : {hasil.get('place_id', '-')}")
        print(f"Tipe Lokasi       : {', '.join(hasil.get('types', []))}")
        print(f"Link Maps         : https://www.google.com/maps?q={hasil.get('geometry', {}).get('location', {}).get('lat','')},{hasil.get('geometry', {}).get('location', {}).get('lng','')}")

    except Exception as e:
        print(f"Terjadi Kesalahan: {e}")

def main():
    banner()
    print(f"""{GREEN}
[01] Cek Nomor Scam            [04] Parse Lokasi & Ttl Dari Nik (Decode)
[02] Validasi & Parsing Nik    [05] Cek Informasi Imei (Global)
[03] Social & CallerID Lookup  [06] Digital Footprint Lookup
[07] Scrape Kontak dari Url    [00] KELUAR
[08] Cek Identitas Nomor       [09] Parse Nik Regional
[10] Phone Format & GeoCheck   [11] Bulk Social Scanner
[12] Scout Intel Nomor         [13] Cari Dokumen Rahasia (Dork)
[14] Username/Namalengkap      [15] Cek Rekening Bank
[16] Kode Bank di Indonesia    [17] CallApp Lookup (Info Kontak Global)
[18] Tiktok Scraper            [19] Cek Status Domain (Waf/Cdn/Dns)
[20] ChatGPT-Pro (AiCyber)     [21] Scan Js/Cve Target Website
[22] Scrape Website (Html)     [23] LeakHunter (Realtime)
[24] Temp Mail Create          [25] Session Hijack Risk Scanner
[26] Lacak Nomor Negara India  [27] Subdomain Crackend
[28] Shopify Store Osind       [29] Instagram Location
[30] Demo Tracking (Fix!)      [31] Scout Tracking Nomor
[32] Cari Jejak Digital Nomor  [33] Phone Metadata Maps
[34] Cek Social Counter Url    [35] Bypass Url (Cloudflare & Waf)
[36] Donasi & Dukungan         [37] Tebak Shio (Gacor)
[38] Input Scanner (Pyload)    [39] Created Nokos Luar Negri
[40] Cek Sms Masuk (Nokos)     [41] Database Plat Pelanggaran (Tilang)
[42] Cari Akun Fb Instagram    [43] Cek Id Facebook
[44] Facebook Osind Username   [45] Gougle Dork Scanner
[46] Geo Location Ip           [47] Bts Tracking Location (Singapore Transceiver)
[48] Profil Facebok Terkunci   [49] Search Username All Platform
[50] Deteksi Pemilik Nomor     [51] Jejak Sosial Digital
[52] Scrapey Link Api          [53] Web Content Scraper (Bypass)
[54] Cek Data Nomor            [55] JavaScript Vulnerability
[56] Spider Scan Website       [57] Cek Dpt Kpu (Nik)
[58] Information GitHub        [59] Facebook Phone Track (Breach)
[60] Bank Identification (Bin) [61] INSTALL SEMUA MODULE (Wajib!)
[62] Cek Pajak Npwp/Nif/Vat    [63] Lacak Link Phising Penipu (Tracking)
[64] Cek Email Kamu Jika Bocor [65] Pencariam Nama (Realtime)
{GREEN}""")
    pilih = input("╰──── Pilih ➣ ")
    if pilih == "01":
        nomor = input("Masukan Nomor: ")
        scam_lookup(nomor)
    elif pilih == "02":
        nik = input("Masukan Nik: ")
        nik_parse(nik)
    elif pilih == "03":
        nomor = input("Masukan Nomor: ")
        eyecon_lookup(nomor)
    elif pilih == "04":
        nik = input("Masukan Nik: ")
        parse_nik_lokasi(nik)
    elif pilih == "05":
        imei = input("Masukan Imei: ")
        cek_imei(imei)
    elif pilih == "06":
        nomor = input("Masukan Nomor: ")
        digital_footprint_lookup(nomor)
    elif pilih == "07":
        url = input("Masukan Link (https://...): ")
        scrape_kontak_dari_url(url)
    elif pilih == "08":
        nomor = input("Masukkan Nomor: ")
        truecaller_lookup(nomor)
    elif pilih == "09":
        nik = input("Masukan Nik: ")
        parse_nik_parser(nik)
    elif pilih == "10":
        nomor = input("Masukan Nomor: ")
        validate_phone_number(nomor)
    elif pilih == "11":
        data = input("Masukan Email/Phone (Pisahkan Dengan Koma): ")
        input_list = [x.strip() for x in data.split(",") if x.strip()]
        check_social_bulk(input_list)
    elif pilih == "12":
        nomor = input("Masukan Nomor: ")
        scout_lookup(nomor)
    elif pilih == "13":
        keyword = input("Masukkan Keyword (Contoh: kaltim data): ")
        filetype = input("Masukkan Tipe File (pdf/doc/xls): ").lower()
        generate_google_dork_api(keyword, filetype)
    elif pilih == "14":
        print("Basis Tracking Berdasarkan Data Realtime \n")
        alamat = input("Masukan Nama Target (Contoh: Riskiy Ramadani): ")
        geocode_address(alamat)
    elif pilih == "15":
        print("Cek Nomor Rekening Bank Indonesia\n")
        kode = input("Masukkan Kode Bank (Contoh: 014): ")
        norek = input("Masukkan Nomor Rekening: ")
        cek_rekening(kode, norek)
    elif pilih == "16":
        list_kode_bank()
    elif pilih == "17":
        callapp_lookup()
    elif pilih == "18":
         print("TikTok Scraper Dan Video Tanpa Watermark\n")
         url = input("Masukkan URL Video TikTok Nya: ")
         tiktok_scraper(url)
    elif pilih == "19":
        cek_status_domain()
    elif pilih == "20":
        tanya_chatgpt()
    elif pilih == "21":
        scan_js_vulnerabilities()
    elif pilih == "22":
        url_target = input("Masukkan URL Target (Contoh: https://example.com): ")
        scrape_website_ninja(url_target)
    elif pilih == "23":
        email = input("Masukkan Kata Kunci: ")
        check_breach_direct(email)
    elif pilih == "24":
        create_temp_mail_raw()
    elif pilih == "25":
        target = input("Masukkan URL Target : ")
        scan_session_hijack_risk(target)
    elif pilih == "26":
        print("\nValidasi Nomor")
        phone = input("Masukkan Nomor: ")
        aadhaar_osint(phone)
    elif pilih == "27":
        print("\nSubdomain Crackend")
        target = input("Masukkan Domain Target: ")
        find_subdomains(target)
    elif pilih == "28":
        print("\nShopify Store OSINT")
        link = input("Masukkan URL toko (Contoh: https://gymshark.com): ")
        shopify_store_info(link)
    elif pilih == "29":
        print("\nInstagram Location OSINT")
        loc_id = input("Masukkan ID Lokasi Instagram: ")
        ig_location_info(loc_id)
    elif pilih == "30":
        ss7_tracking_emobiletracker()
    elif pilih == "31":
        print("\nScout Phone Tracking")
        nomor = input("Masukkan Nomor Target (Contoh: +62**): ")
        scout_phone_lookup(nomor)
    elif pilih == "32":
        nomor = input("Masukkan Nomor Target (Contoh: +62**): ")
        validasi_nomor_dari_api(nomor)
    elif pilih == "33":
        nomor = input("Masukkan Nomor Target (Contoh: +62**): ")
        analyzer_phone_number(nomor)
    elif pilih == "34":
        social_counter_check()
    elif pilih == "35":
        bypass_akamai_cloudflare()
    elif pilih == "36":
        donasi()
    elif pilih == "37":
        menu_tebak_shio_gacor()
    elif pilih == "38":
        input_scanner()
    elif pilih == "39":
        buat_nokos()
    elif pilih == "40":
        cek_sms_nokos()
    elif pilih == "41":
        plat = input("Masukkan Nomor Plat (Contoh: B1234XYZ): ")
        negara = input("Masukkan Kode Negara (Contoh: id, us, sg): ")
        cek_plat_nomor(plat, negara)
    elif pilih == "42":
        ig_to_fb_profile()
    elif pilih == "43":
        cek_facebook_id()
    elif pilih == "44":
        get_facebook_id()
    elif pilih == "45":
        google_search_rapidapi()
    elif pilih == "46":
        ip_geo_lookup()
    elif pilih == "47":
        spam_validation()
    elif pilih == "48":
        fb_profile_unlocker()
    elif pilih == "49":
        cari_sosial_media()
    elif pilih == "50":
        truecaller_lookup()
    elif pilih == "51":
        cek_digital_footprint()
    elif pilih == "52":
        scrapey_links()
    elif pilih == "53":
        scraping_api()
    elif pilih == "54":
        truecaller_lookup()
    elif pilih == "55":
        scan_js_vulns()
    elif pilih == "56":
        scan_webspider()
    elif pilih == "57":
        cek_dpt_online()
    elif pilih == "58":
        github_osint_lookup()
    elif pilih == "59":
        fb_info_lookup()
    elif pilih == "60":
        bin_checker()
    elif pilih == "61":
        install_all_modules()
    elif pilih == "62":
        cek_vat_number()
    elif pilih == "63":
        website_contact_finder()
    elif pilih == "64":
        print("\nCek Email Data/Leak\n")
        email = input("Masukan Alamat Email Kamu: ")
        cek_email_leak(email)
    elif pilih == "14":
        geocoder_nama()
    elif pilih == "00":
        exit()
    else:
        print("Pilih Yang Benar Bro :)")
        input("\nEnter Untuk Keluar...")

if __name__ == "__main__":
    main()
