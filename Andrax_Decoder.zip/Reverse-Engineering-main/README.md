Brangkas Reverse Engineering, Bagi star nya puhh :v
